# Objava nove spletne strani in obvestilo strankam

## Vrstni red objave

1. **Posodobitev strežnika** na novo različico (spletna stran je vključena). Predogled: `https://higifood.si/stran/`.
2. **Platforma → Naročnine**: preverite cenik in podatke izdajatelja (e-pošta, telefon, naslov) – prikažejo se na spletni strani.
3. **Dan pred zamenjavo** pošljite strankam e-pošto spodaj (zaposleni naj na telefonih odprejo platformo z internetno povezavo,
   da se pošljejo morebitni zapisi, vneseni brez povezave).
4. **Zamenjava** po navodilih `program/streznik/SPLETNA-STRAN.md` (nastavitev `.env` in javno ime `app.higifood.si` v tunelu).
5. **Preverjanje**: `higifood.si` prikaže novo stran, gumb »Prijava« odpre `app.higifood.si`, prijava deluje, cenik in kontakt sta pravilna.
6. **Objava** na družbenih omrežjih (besedilo spodaj). Staro gostovanje prekličite po enem tednu brez težav.

Varovalo: če ima telefon še neposlane zapise na starem naslovu, jih nova stran ponudi v pošiljanje (»Pošlji zapise zdaj«).

---

## E-pošta strankam

**Zadeva:** HiGiFood: nova spletna stran in nov naslov za prijavo

Spoštovani,

prenovili smo spletno stran HiGiFood. Na **higifood.si** odslej najdete predstavitev platforme, cenik in kontakt.

**Platforma za evidence se seli na nov naslov: https://app.higifood.si**
Uporabniško ime in geslo ostaneta enaka, vsi vaši podatki so na istem mestu.

Kaj morate narediti:

1. **Pred [datum]** na vsakem telefonu ali tablici, kjer vnašate evidence, enkrat odprite platformo z internetno povezavo
   (tako se pošljejo morebitni zapisi, vneseni brez povezave).
2. **Po [datum]** se prijavite na **app.higifood.si**. Če imate platformo dodano na začetni zaslon telefona,
   staro ikono odstranite in dodajte novo (v brskalniku: Deli → Dodaj na začetni zaslon).
3. Na higifood.si vas gumb **Prijava** (zgoraj desno) vedno pripelje do platforme.

Novosti v platformi:
- obvestila o umikih in odpoklicih iz evropskega sistema RASFF so prevedena v slovenščino;
- pri več obratih sta hiter vnos temperature in čiščenje na strani »Danes« ločena po obratih;
- vsi podatki so v podatkovni bazi, ki je pripravljena na hkratno delo več uporabnikov.

Za vprašanja smo vam na voljo na [e-pošta] ali [telefon].

Lep pozdrav,
[ime in priimek]
HiGiFood – Z znanjem do varne hrane!

---

## Kratka objava (spletna stran, Facebook, LinkedIn)

**Nova spletna stran HiGiFood je na spletu!** 🌿
HACCP brez papirja: elektronski dnevniki, temperature hladilnikov, načrt čiščenja, predloge HACCP načrtov
in poročila v PDF – za gostilne, kuhinje, pekarne in živilske obrate.
Oglejte si funkcije in cenik na **higifood.si** in se dogovorite za 20-minutno predstavitev.
#HACCP #varnahrana #gostinstvo

---

## SMS / kratko sporočilo zaposlenim

HiGiFood: od [datum] se prijavite na app.higifood.si (isto geslo). Pred tem enkrat odprite aplikacijo z internetom. Hvala!
