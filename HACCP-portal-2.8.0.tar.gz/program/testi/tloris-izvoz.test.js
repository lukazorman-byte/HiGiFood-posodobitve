// Izris tlorisa za dokumente: legenda v ločenem pasu pod risbo (brez prekrivanja, samo izrisani tipi, merilo zadnje),
// napisi brez deljenja in rezanja, brez prekrivanja med sabo in s potmi, vse znotraj slike; en podpis na tloris, brez podvojenih tlorisov.
// Razmerja 1:3, 1:1, 3:1; širine 300, 600, 1200 px (6, 12, 24 m pri 50 px/m); 1, 4 in 8 tipov v legendi; dolga imena.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), fs = require("fs"), path = require("path"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");

  const rez = await pg.evaluate(() => {
    // testni tloris: k pasov prostorov z dolgimi imeni, naprave z dolgimi imeni, poti do roba, vrata na spodnji steni, vabe
    const tloris = (w, h, n) => {
      const E = [], tipi = ["kuhinja / priprava", "skladišče", "čisto območje"], poti = ["nečista pot", "čista pot", "topla veriga"];
      const nS = n === 1 ? 1 : n === 4 ? 2 : 3, imena = ["Slaščičarna in priročno skladišče", "Prostor", "Kuhinja"];
      for (let i = 0; i < nS; i++) E.push({ t: "soba", id: "s" + i, x: i * w / nS, y: 0, w: w / nS, h, tip: tipi[i], ime: imena[i] });
      E.push({ t: "oprema", id: "o1", x: 0.2, y: 0.2, w: 0.8, h: 0.7, ikona: "pomivalni stroj", ime: "Industrijski pomivalni stroj" });
      E.push({ t: "oprema", id: "o2", x: Math.max(0.2, w - 1), y: 0.2, w: 0.7, h: 0.7, ikona: "hladilnik", ime: "hladilnik z zamrzovalnikom" });
      if (n >= 4) { E.push({ t: "vrata", id: "v1", x: w / 2, y: h, rot: 0 }); E.push({ t: "pot", id: "p0", vrsta: poti[0], pts: [[w / 2, h - 0.05], [w / 2, h / 2], [0.05, h / 2]] }); }
      if (n >= 8) { E.push({ t: "pot", id: "p1", vrsta: poti[1], pts: [[0.3, 0.05], [0.3, h - 0.1]] }, { t: "pot", id: "p2", vrsta: poti[2], pts: [[1, h * 0.3], [w - 0.02, h * 0.3]] }, { t: "vaba", id: "b1", x: w - 0.3, y: h - 0.3, oznaka: "1", vrsta: "vaba" }); }
      return { naziv: "Test", sirina_m: w, visina_m: h, elementi: E };
    };
    const sek = (a, b, tol) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > tol && Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > tol;
    const box = document.createElement("div"); box.style.cssText = "position:absolute;left:0;top:0;width:auto"; document.body.appendChild(box);
    const out = [];
    for (const raz of [1 / 3, 1, 3]) for (const px of [300, 600, 1200]) for (const n of [1, 4, 8]) {
      const w = px / 50, h = w / raz, t = tloris(w, h, n), r = tlorisIzvoz(t), napake = [];
      box.innerHTML = r.svg; const svg = box.querySelector("svg"), S = svg.getBoundingClientRect();
      const rr = el => { const q = el.getBoundingClientRect(); return { left: q.left - S.left, right: q.right - S.left, top: q.top - S.top, bottom: q.bottom - S.top, width: q.width, height: q.height }; };
      // (1) elementi legende se ne sekajo
      const leg = [...svg.querySelectorAll("[data-leg],[data-merilo]")].map(rr);
      for (let i = 0; i < leg.length; i++) for (let j = i + 1; j < leg.length; j++) if (sek(leg[i], leg[j], 0.5)) napake.push("legenda se prekriva");
      // (2) legenda pod risbo z odmikom ≥ 12
      const ris = [svg.querySelector("[data-risba]"), svg.querySelector("[data-napisi]")].map(rr).filter(q => q.width || q.height), dno = Math.max(...ris.map(q => q.bottom)), lg = rr(svg.querySelector("[data-legenda]"));
      if (lg.top < dno + 12 - 0.5) napake.push("legenda preblizu risbe (" + (lg.top - dno).toFixed(1) + ")");
      // merilo je zadnja vrstica
      const mer = rr(svg.querySelector("[data-merilo]")); if (leg.some(q => q.top > mer.top + 0.5)) napake.push("merilo ni zadnje");
      // (3) napisi: brez deljenja in »…«, ne prekrivajo se med sabo in jih ne seka pot
      const nap = [...svg.querySelectorAll("[data-napisi] text[data-nid]")];
      for (const x of nap) if (/[-‐]$/.test(x.textContent.trim()) || /…/.test(x.textContent)) napake.push("deljen ali odrezan napis: " + x.textContent);
      const nr = nap.map(rr);
      for (let i = 0; i < nr.length; i++) for (let j = i + 1; j < nr.length; j++) if (nap[i].getAttribute("data-nid") !== nap[j].getAttribute("data-nid") && sek(nr[i], nr[j], 0.5)) napake.push("napisa se prekrivata: " + nap[i].textContent + " / " + nap[j].textContent);
      for (const pl of svg.querySelectorAll("polyline")) { const p = pl.getAttribute("points").split(" ").map(s => s.split(",").map(Number));
        for (let i = 1; i < p.length; i++) nr.forEach((q, k) => { const r0 = { x: q.left + 1, y: q.top + 1, w: q.width - 2, h: q.height - 2 }; if (r0.w > 0 && r0.h > 0 && tlDaljica(p[i - 1][0], p[i - 1][1], p[i][0], p[i][1], r0)) napake.push("pot seka napis: " + nap[k].textContent); }); }
      // (4) vse znotraj slike
      for (const el of svg.querySelectorAll("[data-risba] > *, [data-napisi] > *, [data-legenda] > *")) { const q = rr(el); if (q.left < -0.5 || q.top < -0.5 || q.right > r.w + 0.5 || q.bottom > r.h + 0.5) napake.push("zunaj slike: " + el.tagName + " " + (el.textContent || "")); }
      // (5) legenda = izrisani tipi
      const izr = new Set([...svg.querySelectorAll("[data-risba] [data-tip], [data-risba] [data-tip]")].map(e => e.getAttribute("data-tip")).concat([...svg.querySelectorAll("[data-st]")].map(e => "st:" + e.getAttribute("data-st"))));
      const vleg = new Set([...svg.querySelectorAll("[data-leg]")].map(e => e.getAttribute("data-leg")));
      if (izr.size !== vleg.size || [...izr].some(k => !vleg.has(k))) napake.push("legenda " + [...vleg].join(",") + " ≠ izrisano " + [...izr].join(","));
      if (n < 8 && vleg.has("vaba")) napake.push("vaba v legendi brez postaje");
      // generično »Prostor« zamenja vrsta prostora
      if ([...nap].some(x => x.textContent.trim() === "Prostor")) napake.push("generično ime »Prostor«");
      out.push({ raz: raz.toFixed(2), px, n, w: r.w, h: r.h, nleg: vleg.size, napake: [...new Set(napake)] });
    }
    box.remove(); return out;
  });
  for (const x of rez) ok(!x.napake.length && x.w === 470 && x.h <= 640, `razmerje ${x.raz}, ${x.px} px, ${x.n} tipov: ${x.w}×${x.h}, legenda ${x.nleg}${x.napake.length ? " – " + x.napake.slice(0, 4).join("; ") : ""}`);

  // ločljivost: 470 pt × 4,2 ≈ 300 dpi
  const im = await pg.evaluate(async () => { const r = await tlorisToImg({ naziv: "T", sirina_m: 4.25, visina_m: 5.65, elementi: [{ t: "soba", id: "a", x: 0, y: 0, w: 4.25, h: 5.65, tip: "kuhinja / priprava", ime: "Kuhinja" }] }); return { w: r.w, h: r.h }; });
  ok(im.w / (470 / 72) >= 300, "slika tlorisa ≥ 300 dpi pri širini 470 pt (" + im.w + " px)");

  // PDF: en podpis na tloris, podvojeni tloris le enkrat, zaporedno številčenje
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kavarna Sonce" }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce" });
    const t1 = await D.add("tlorisi", { stranka_id: s.id, obrat_id: o.id, naziv: "Pritličje", sirina_m: 6, visina_m: 4, elementi: [{ t: "soba", id: "a", x: 0, y: 0, w: 6, h: 4, tip: "kuhinja / priprava", ime: "Kuhinja" }] });
    const t2 = await D.add("tlorisi", { stranka_id: s.id, obrat_id: o.id, naziv: "Klet", sirina_m: 4, visina_m: 4, elementi: [{ t: "soba", id: "b", x: 0, y: 0, w: 4, h: 4, tip: "skladišče", ime: "Skladišče" }] });
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP", vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }], nevarnosti: [], kontrole: {}, zivila: [], zbiranje: { tlorisi: [{ vrsta: "narisan", id: t1.id, naslov: "Pritličje" }, { vrsta: "narisan", id: t2.id, naslov: "Klet" }, { vrsta: "narisan", id: t1.id, naslov: "Pritličje (kopija)" }] } } });
    return { n: n.id };
  });
  await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector(".stepper button"); await pg.click(".stepper button >> nth=6"); await pg.waitForSelector("#xpdf");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#xpdf")]); const f = path.join(OUT, "tlorisi.pdf"); await dl.saveAs(f);
  const pt = cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" });
  if (pt.error) console.log("ok: pdftotext ni nameščen"); else {
    const t = pt.stdout, n = re => (t.match(re) || []).length;
    ok(n(/Tloris 1: Pritličje/g) === 1 && n(/Tloris 2: Klet/g) === 1 && !/Tloris 3/.test(t) && !/kopija/.test(t), "PDF: dva tlorisa, zaporedno, podvojeni izpuščen");
    ok(n(/^\s*Pritličje\s*$/mg) === 0 && n(/^\s*Klet\s*$/mg) === 0, "PDF: brez drugega podpisa pod sliko");
  }
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
