// Moji podatki in naslovnica: Izdelal = svetovalec (naziv, ime, izobrazba, podjetje, kontakt), Odobril = odgovorna oseba stranke;
// podpisna polja, noga z izdelovalcem, evidenca različic; stranka brez dodeljenega svetovalca ne more izdelati ali urejati HACCP načrta.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pdfB64 = async (pg, fn, arg) => pg.evaluate(async ({ src, arg }) => { const blob = await (0, eval)("(" + src + ")")(arg); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, { src: fn.toString(), arg });
const besedilo = (b64, ime, strani) => { const f = path.join(OUT, ime + ".pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); return cp.spawnSync("pdftotext", ["-layout", ...(strani ? ["-f", "1", "-l", String(strani)] : []), f, "-"], { encoding: "utf8" }).stdout || ""; };
const prijava = async (br, email) => { const pg = await (await br.newContext()).newPage(); await pg.goto(B + "/"); await pg.fill("#le", email); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])"); const k = await pg.waitForSelector("dialog[open] button:has-text('Kasneje')", { timeout: 3000 }).catch(() => null); if (k) { await k.click(); await pg.waitForFunction(() => !document.querySelector("dialog[open]")); } return pg; };
const post = (pg, url, body, method) => pg.evaluate(({ url, body, method }) => fetch(url, { method: method || "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(async x => ({ s: x.status, j: await x.json().catch(() => null) })), { url, body, method });
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Admin"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  fs.mkdirSync(OUT, { recursive: true });
  await pg.evaluate(() => api("PUT", "/api/narocnine/nastavitve", { izdajatelj: { naziv: "HiGiFood, svetovanje d.o.o.", naslov: "Slovenska cesta 1, 1000 Ljubljana", email: "info@higifood.si", telefon: "041 123 456", davcna: "", trr: "", banka: "" } }));
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Kavarna Sonce d.o.o.", odgovorna_oseba: "Ana Kos (iz profila)" }); await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce" });
    await api("POST", "/api/uporabniki", { email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", ime: "Luka Zorman", stranke: [] });
    await api("POST", "/api/uporabniki", { email: "ana@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", ime: "Ana Kos", stranka_id: s.id }); return s.id; });
  // stranka brez svetovalca: načrta ne more ustvariti (strežnik)
  const ana = await prijava(br, "ana@t.si"); ana.on("pageerror", e => errs.push(String(e.stack || e)));
  let r = await post(ana, "/api/d/nacrti", { naziv: "Moj načrt" });
  ok(r.s === 403 && /nima dodeljenega svetovalca/.test(r.j && r.j.napaka), "odgovorna brez svetovalca ne ustvari načrta: " + JSON.stringify(r));
  // svetovalec dodeljen stranki; Moji podatki (stran)
  await pg.evaluate(async sid => { const u = (await api("GET", "/api/uporabniki")).find(x => x.email === "sv@t.si"); await api("PUT", "/api/uporabniki/" + u.id, { stranke: [sid] }); }, sid);
  const sv = await prijava(br, "sv@t.si"); sv.on("pageerror", e => errs.push(String(e.stack || e)));
  await sv.goto(B + "/#/moji-podatki"); await sv.waitForSelector("#mp_ime");
  ok(await sv.inputValue("#mp_podjetje") === "HiGiFood, svetovanje d.o.o." && await sv.inputValue("#mp_ime") === "Luka Zorman", "Moji podatki: privzeto podjetje izdajatelja in ime");
  await sv.fill("#mp_naziv", "mag."); await sv.fill("#mp_izobrazba", "univ. dipl. inž. živilske tehnologije"); await sv.fill("#mp_funkcija", "svetovalec za varnost živil"); await sv.fill("#mp_telefon", "031 555 666");
  ok(/mag\. Luka Zorman, univ\. dipl\. inž\. živilske tehnologije/.test(await sv.textContent("#mp_p")), "Moji podatki: predogled naslovnice " + await sv.textContent("#mp_p") + " DLG: " + await sv.evaluate(() => { const d = document.querySelector("dialog[open]"); return d ? d.textContent.slice(0, 300) : ""; }));
  await sv.click("#mp_s"); await sv.waitForSelector(".toast.show:has-text('Shranjeno')");
  await ana.goto(B + "/#/moji-podatki"); await ana.waitForSelector("#mp_ime"); ok(await ana.inputValue("#mp_podjetje") === "Kavarna Sonce d.o.o.", "odgovorna: privzeto njeno podjetje");
  await ana.fill("#mp_izobrazba", "gostinski tehnik"); await ana.fill("#mp_funkcija", "direktorica"); await ana.click("#mp_s"); await ana.waitForSelector(".toast.show:has-text('Shranjeno')");
  r = await post(ana, "/api/d/nacrti", { naziv: "HACCP Kavarna", verzija_oznaka: "1.0", status: "osnutek", vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }], nevarnosti: [], kontrole: {}, zivila: [], zbiranje: {} } });
  ok(r.s === 200, "z dodeljenim svetovalcem odgovorna lahko ustvari načrt " + JSON.stringify(r).slice(0, 200));
  const nid = r.j && r.j.id;
  // čarovnik (odgovorna), korak 7: povzetek izdelal/odobril
  await ana.evaluate(nid => sessionStorage.setItem("wstep:" + nid, "6"), nid); await ana.goto(B + "/#/carovnik/" + nid); await ana.waitForSelector("#izd_c");
  const kt = await ana.textContent("#izd_c");
  ok(/mag\. Luka Zorman, univ\. dipl\. inž\./.test(kt) && /Ana Kos, gostinski tehnik, direktorica/.test(kt) && !!(await ana.$("#izd_c a[href='#/moji-podatki']")), "korak 7: izdelal = svetovalec, odobril = odgovorna, povezava na Moji podatki\n" + kt);
  // naslovnica PDF, izvozi odgovorna oseba: izdelal je svetovalec
  const b64 = await pdfB64(ana, async nid => { const rec = (await D.list("nacrti")).find(x => x.id === nid), st = (await D.list("stranke")).find(x => x.id === rec.stranka_id), ob = await D.list("obrati", { stranka_id: rec.stranka_id }); await naloziIzdelovalca(rec.stranka_id); return buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); }, nid);
  const t = besedilo(b64, "naslovnica", 1), vse = besedilo(b64, "naslovnica");
  if (process.env.KOPIJA) fs.copyFileSync(path.join(OUT, "naslovnica.pdf"), process.env.KOPIJA);
  ok(/Izdelal\s+mag\. Luka Zorman, univ\. dipl\. inž\. živilske tehnologije/.test(t) && /svetovalec za varnost živil/.test(t) && /HiGiFood, svetovanje d\.o\.o\./.test(t) && /info@higifood\.si · 031 555 666/.test(t) && /Podjetje\s+Kavarna Sonce d\.o\.o\./.test(t), "naslovnica: podatki svetovalca\n" + t);
  ok(/Izdelal \(svetovalec\)\s+Odobril \(odgovorna oseba\)/.test(t) && /Ana Kos/.test(t) && /gostinski tehnik, direktorica/.test(t) && (t.match(/Podpis: _+/g) || []).length === 2 && (t.match(/Datum: _+/g) || []).length === 2, "podpisni polji (osnutek brez datuma potrditve)");
  ok(vse.split("\f").slice(1).filter(x => x.trim()).every(x => /Kavarna Sonce d\.o\.o\. \| HACCP načrt: HACCP Kavarna \| v1\.0/.test(x) && /Izdelal: mag\. Luka Zorman, univ\. dipl\./.test(x) && /Stran \d+ \/ \d+/.test(x)), "noga vsake strani: stranka, dokument, različica, izdelovalec, stran X / Y");
  ok(/Evidenca različic dokumenta[\s\S]*Prva izdaja[\s\S]*Veljavna je različica 1\.0/.test(vse) && !/Kazalo[^\f]*Evidenca različic/.test(vse), "evidenca različic na začetku (ni v kazalu)");
  // svetovalec odstranjen: odgovorna načrta ne more več urejati
  await pg.evaluate(async () => { const u = (await api("GET", "/api/uporabniki")).find(x => x.email === "sv@t.si"); await api("PUT", "/api/uporabniki/" + u.id, { stranke: [] }); });
  r = await post(ana, "/api/d/nacrti/" + nid, { opomba: "x", _razlog: "test" }, "PUT");
  ok(r.s === 403, "brez svetovalca odgovorna ne ureja načrta");
  await ana.goto(B + "/#/nadzorna"); await ana.goto(B + "/#/carovnik/" + nid); await ana.waitForSelector("#wbody");
  ok(/nima dodeljenega svetovalca/.test(await ana.textContent("body")), "čarovnik: obvestilo, da načrt izdela svetovalec");
  // drugi dokumenti svetovalca: izdelovalec na naslovnici
  const t2 = besedilo(await pdfB64(sv, async () => { await naloziIzdelovalca(); return pdfBuild({ naslov: "Kartoteke zaposlenih", stranka: "Kavarna Sonce d.o.o.", verzija: "1.0" }, d => d.p("x")); }), "drugi", 1);
  ok(/Izdelal\s+mag\. Luka Zorman, univ\. dipl\./.test(t2) && /HiGiFood, svetovanje/.test(t2), "drugi dokumenti: izdelovalec na naslovnici");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
