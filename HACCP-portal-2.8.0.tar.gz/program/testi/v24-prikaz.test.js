// Prikaz in uporabnost (točke 8–15) in predpomnilnik zbirk (17): števci storitev po shranjevanju, rumeno opozorilo ob odstopanju,
// decimalna vejica, samodejni roki v koledarju stranke, dnevi v košu, privzeti logotip, odzivna tabela uporabnikov, gumb »Prijavi napako«.
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const ctx0 = await br.newContext({ viewport: { width: 1280, height: 900 } }), pg = await ctx0.newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Prikaz d.o.o." });
    await D.add("usposabljanja", { stranka_id: s.id, tema: "Higienski minimum", datum: "2026-10-01", veljavno_do: "2027-10-01" });
    await D.add("oprema", { stranka_id: s.id, naziv: "Hladilnik 1", tip: "hladilnik", meja_min: 0, meja_max: 4, naslednji_servis: "2027-01-15" });
    await api("POST", "/api/uporabniki", { ime: "Zelo Dolgo Ime Uporabnika Priimek", email: "zelo.dolg.e.naslov.uporabnika@primer-podjetja.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s.id, stranke: [] });
    return s.id; });
  // 8) storitve: števci po shranjevanju (brez menjave zavihka)
  await pg.goto(B + "/#/stranka/" + sid + "/storitve"); await pg.waitForSelector("#st_kpi .kpi");
  await pg.click("#ladd"); await pg.waitForSelector("#f_minute"); await pg.fill("#f_minute", "30"); await pg.selectOption("#f_vrsta", "Obisk na lokaciji"); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForFunction(() => /1\s*opravljena storitev/.test(document.querySelector("#st_kpi").textContent));
  const k = await pg.textContent("#st_kpi"); ok(/0,5 h/.test(k) && /1\s*obisk na lokaciji/.test(k), "8: števci po shranjevanju: 1 storitev, 0,5 h, 1 obisk (" + k.replace(/\s+/g, " ") + ")");
  // 9–10) odstopanje: rumeno opozorilo, decimalna vejica
  await pg.evaluate(async sid => { const ctx = await evCtx({ stranka_id: sid, obrati: {} }); evForm(null, ctx, () => {}, "temperatura"); }, sid);
  await pg.selectOption("#f_oprema", "Hladilnik 1"); await pg.fill("#f_vrednost", "9,5"); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector(".toast.show:has-text('odstopanje')"); const t = await pg.evaluate(() => { const x = document.querySelector(".toast.show"); return { c: x.className, t: x.textContent }; });
  ok(/warn/.test(t.c) && /Opozorilo/.test(t.t) && !/Napaka/.test(t.t) && /Shranjeno – odstopanje/.test(t.t), "9: odstopanje = rumeno »Opozorilo« (" + t.t + ")");
  const sum = await pg.evaluate(async sid => evSummary((await D.list("evidence", { stranka_id: sid }))[0]), sid);
  ok(/9,5 °C/.test(sum) && await pg.evaluate(() => fnum(0) === "0" && fnum(1250.5) === "1.250,5"), "10: decimalna vejica (" + sum + ")");
  // 11) koledar stranke: samodejni roki
  await pg.goto(B + "/#/stranka/" + sid + "/koledar"); await pg.waitForSelector("#kd_avto table");
  const kd = await pg.textContent("#kd_avto"); ok(/Poteče usposabljanje: Higienski minimum/.test(kd) && /Servis\/umerjanje: Hladilnik 1/.test(kd), "11: koledar stranke prikaže samodejne roke");
  // 12) koš: cela dneva navzdol in datum izbrisa
  const kos = await pg.evaluate(async sid => { const o = await D.add("dobavitelji", { stranka_id: sid, naziv: "Za koš" }); await D.del("dobavitelji", o.id); return (await api("GET", "/api/kos")).find(x => x.ime === "Za koš" || x.id); }, sid);
  ok(kos && kos.preostalo_dni === 29 && /T/.test(kos.izbris), "12: koš – takoj po izbrisu 29 celih dni (ne 30), datum izbrisa " + JSON.stringify(kos && [kos.preostalo_dni, kos.izbris]));
  await pg.goto(B + "/#/kos"); await pg.waitForSelector("text=izbris"); ok(/29\s*\(izbris \d/.test(await pg.textContent("#view")), "12: koš prikaže datum dokončnega izbrisa");
  // 13) logotip: brez lastnega 204 in privzeti logotip
  ok(await pg.evaluate(() => fetch("/api/logo").then(r => r.status)) === 204, "13: /api/logo brez logotipa vrne 204 (ne 404)");
  await pg.goto(B + "/#/admin"); await pg.waitForSelector("#lg_prev", { state: "attached" }); await pg.waitForFunction(() => !document.querySelector("#lg_prev").hidden);
  ok(await pg.evaluate(() => { const i = document.querySelector("#lg_prev"); return /logo-svetlo\.png/.test(i.src) && i.naturalWidth > 0; }), "13: administracija pokaže privzeti logotip HiGiFood");
  // 14) uporabniki pri 900 px: kartice, brez vodoravnega drsenja, ime in e-naslov vidna
  await pg.setViewportSize({ width: 900, height: 900 }); await pg.goto(B + "/#/uporabniki"); await pg.waitForSelector("#ut tr[data-id]");
  const u = await pg.evaluate(() => { const tw = document.querySelector("#ut").closest(".tw"), td = [...document.querySelectorAll("#ut td.em")].find(x => /zelo\.dolg/.test(x.textContent)); const r = td.getBoundingClientRect(), w = tw.getBoundingClientRect(); return { ovf: tw.scrollWidth - tw.clientWidth, disp: getComputedStyle(td).display, vidno: r.width > 50 && r.right <= w.right + 1, lbl: getComputedStyle(td, "::before").content }; });
  ok(u.ovf <= 1 && u.vidno && /E-naslov/.test(u.lbl), "14: tabela uporabnikov pri 900 px kot kartice, e-naslov viden " + JSON.stringify(u));
  await pg.setViewportSize({ width: 1280, height: 900 });
  // 15) gumb »Prijavi napako«: kontrast z ozadjem menija
  const kon = await pg.evaluate(() => { const b = document.createElement("button"); b.className = "btn sm nav-btn"; b.textContent = "Prijavi napako"; document.querySelector("nav, .nav, #nav, aside").appendChild(b);
    const lum = c => { const [r, g, b2] = c.match(/[\d.]+/g).slice(0, 3).map(Number).map(v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b2; };
    let el = b.parentElement, bg = "rgba(0, 0, 0, 0)"; while (el && /rgba\(0, 0, 0, 0\)|transparent/.test(bg)) { bg = getComputedStyle(el).backgroundColor; el = el.parentElement; }
    const L1 = lum(getComputedStyle(b).color), L2 = lum(bg); b.remove(); return (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05); });
  ok(kon >= 4.5, "15: kontrast besedila gumba »Prijavi napako« z ozadjem menija " + kon.toFixed(1) + " : 1 (≥ 4,5)");
  // 17) predpomnilnik: dve branji = en zahtevek, po pisanju svež zahtevek
  const n = await pg.evaluate(async sid => { let c = 0; const f0 = window.fetch; window.fetch = (u, o) => { if (String(u).startsWith("/api/d/obrati") && (!o || !o.method || o.method === "GET")) c++; return f0(u, o); };
    await D.list("obrati", { stranka_id: sid }); const a = await D.list("obrati", { stranka_id: sid }); a.push({ x: 1 }); const b = await D.list("obrati", { stranka_id: sid }); const c1 = c;
    await D.add("obrati", { stranka_id: sid, naziv: "Nov obrat" }); const d = await D.list("obrati", { stranka_id: sid }); window.fetch = f0; return { c1, c2: c, b: b.length, d: d.length }; }, sid);
  ok(n.c1 === 1 && n.b === 0 && n.c2 === 2 && n.d === 1, "17: predpomnilnik – ponovno branje brez zahtevka, kopija se ne spremeni, po shranjevanju svež podatek " + JSON.stringify(n));
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
