// Popravki po testiranju 2.3.0 (točke 1–7): obvezen razlog popravka (evidence, CAPA), razponi in meje na strežniku in v obrazcih,
// pozitiven celoštevilski interval, datumi usposabljanja, trajanje storitve, ura dogodka, e-naslov zaposlenega, šarže, CAPA.
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const r = await pg.evaluate(async () => {
    const e = (p) => p.then(() => "OK", x => x.message), o = {};
    const s = await D.add("stranke", { naziv: "Vnosi d.o.o." }); o.sid = s.id;
    // 1) razlog popravka
    const z = await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "H1", vrednost: 3, min: 0, max: 4 });
    o.r1 = await e(D.set("evidence", z.id, { vrednost: 3.5 }));
    o.r2 = await e(D.set("evidence", z.id, { vrednost: 3.5, _razlog: "  " }));
    o.r3 = await e(D.set("evidence", z.id, { vrednost: 3.5, _razlog: "napačno prepisano" }));
    o.rev = (await D.list("evidence", { stranka_id: s.id }))[0].revizije;
    o.r4 = await e(D.set("evidence", z.id, { vrednost: 3.5 })); // brez spremembe: razlog ni potreben
    const c = await D.add("capa", { stranka_id: s.id, opis: "Hladilnik prevroč", cas: "2026-10-20T08:00:00.000Z" });
    o.c1 = await e(D.set("capa", c.id, { takojsnji_ukrep: "premik živil" }));
    o.c2 = await e(D.set("capa", c.id, { takojsnji_ukrep: "premik živil", _razlog: "dopolnitev ukrepa" }));
    o.c3 = await e(D.set("capa", c.id, { rok: "2026-10-01", _razlog: "rok" }));
    o.p = await api("POST", "/api/d/evidence/_potrdi", { ids: [z.id] }).then(x => x.potrjeni.length);
    // 2–3) oprema
    o.o1 = await e(D.add("oprema", { stranka_id: s.id, naziv: "H", meja_min: 8, meja_max: 2 }));
    o.o2 = await e(D.add("oprema", { stranka_id: s.id, naziv: "H", interval_dni: -5 }));
    o.o3 = await e(D.add("oprema", { stranka_id: s.id, naziv: "H", interval_dni: 2.5 }));
    const op = await D.add("oprema", { stranka_id: s.id, naziv: "H2", meja_min: 0, meja_max: 4, interval_dni: 365 }); o.opid = op.id;
    o.o4 = await e(D.set("oprema", op.id, { meja_min: 6 })); // popravek samo spodnje meje nad zgornjo
    o.ev = await e(D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "H2", vrednost: 5, min: 8, max: 2 }));
    // 4–7) usposabljanje, storitve, dogodek, zaposleni
    o.us1 = await e(D.add("usposabljanja", { stranka_id: s.id, tema: "HACCP", datum: "2026-10-31", veljavno_do: "2026-10-01" }));
    o.us2 = await e(D.add("usposabljanja", { stranka_id: s.id, tema: "HACCP", datum: "2026-10-31", veljavno_do: "2027-10-31" }));
    o.s1 = await e(D.add("storitve", { stranka_id: s.id, datum: "2026-10-31", minute: -30 }));
    o.d1 = await e(D.add("dogodki", { stranka_id: s.id, naslov: "X", datum: "2026-11-02", ura: "25:99" }));
    o.d2 = await e(D.add("dogodki", { stranka_id: s.id, naslov: "X", datum: "2026-11-02", ura: "09:30" }));
    o.z1 = await e(D.add("osebje", { stranka_id: s.id, ime: "Ana", email: "napacen-email" }));
    o.z2 = await e(D.add("osebje", { stranka_id: s.id, ime: "Ana", email: "" }));
    o.z3 = await e(D.add("osebje", { stranka_id: s.id, ime: "Ana", email: "ana@podjetje.si" }));
    o.sa = await D.add("sarze", { stranka_id: s.id, izdelek: "Mleko", datum_prevzema: "2026-10-31", rok_uporabe: "2026-10-20", status: "na zalogi" }).then(x => x.status, x => x.message);
    o.sb = await D.add("sarze", { stranka_id: s.id, izdelek: "Mleko", datum_prevzema: today(), rok_uporabe: addDays(today(), 10) }).then(x => x.status || "", x => x.message);
    o.e1 = await e(D.add("sarze", { stranka_id: s.id, izdelek: "Moka", ean: "abc123" }));
    o.e2 = await e(D.add("sarze", { stranka_id: s.id, izdelek: "Moka", ean: "4006381333932" }));
    o.e3 = await e(D.add("sarze", { stranka_id: s.id, izdelek: "Moka", ean: "4006381333931" }));
    o.e4 = await e(D.add("sarze", { stranka_id: s.id, izdelek: "Moka", ean: "96385074" }));
    o.e5 = await e(D.add("sarze", { stranka_id: s.id, izdelek: "Moka", ean: "" }));
    o.ob = await e(D.add("obrati", { stranka_id: s.id, naziv: "O", povrsina: -20 }));
    o.u1 = await e(api("POST", "/api/uporabniki", { ime: "X", email: "ana@@podjetje.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id }));
    o.u2 = await e(api("POST", "/api/uporabniki", { ime: "X", email: "napacen-email", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id }));
    const n = await D.add("nacrti", { stranka_id: s.id, naziv: "Načrt R", verzija_oznaka: "1.0" }); for (const x of ["a", "b", "c"]) await D.set("nacrti", n.id, { opomba: x, _razlog: "dopolnitev" }); o.nid = n.id;
    return o;
  });
  ok(/razlog popravka/.test(r.r1) && /razlog popravka/.test(r.r2) && r.r3 === "OK" && r.rev.length === 1 && r.rev[0].razlog === "napačno prepisano" && r.r4 === "OK", "1: popravek zapisa brez razloga zavrnjen, z razlogom shranjen v revizije " + JSON.stringify([r.r1, r.r2, r.rev.map(x => x.razlog)]));
  ok(/razlog popravka/.test(r.c1) && r.c2 === "OK", "1: CAPA – sprememba brez razloga zavrnjena, z razlogom sprejeta");
  ok(r.p === 1, "1: potrditev zapisa (gumb Potrdi) deluje brez ročnega razloga");
  ok(/Dovoljeno do.*večje ali enako.*Dovoljeno od/.test(r.o1) && /Dovoljeno do/.test(r.o4) && /Dovoljeno do/.test(r.ev), "2: meje od > do zavrnjene (oprema, popravek, temperaturni zapis) " + r.o1);
  ok(/pozitivno celo število/.test(r.o2) && /pozitivno celo število/.test(r.o3), "3: interval −5 in 2,5 dni zavrnjena");
  ok(/Veljavno do.*pred.*Datum/.test(r.us1) && r.us2 === "OK", "4: usposabljanje veljavno do pred datumom zavrnjeno");
  ok(/ne sme biti negativno/.test(r.s1), "5: negativno trajanje storitve zavrnjeno");
  ok(/HH:MM/.test(r.d1) && r.d2 === "OK", "6: ura 25:99 zavrnjena, 09:30 sprejeta");
  ok(/E-naslov ni veljaven/.test(r.z1) && r.z2 === "OK" && r.z3 === "OK", "7: napačen e-naslov zaposlenega zavrnjen, prazen dovoljen");
  ok(/Površina.*negativno/.test(r.ob), "11: obrat z negativno površino zavrnjen");
  ok(/E-naslov ni veljaven/.test(r.u1) && /E-naslov ni veljaven/.test(r.u2), "11: uporabnik z napačnim e-naslovom zavrnjen (jasno sporočilo)");
  ok(r.sa === "pretečeno" && r.sb !== "pretečeno", "5: šarža s pretečenim rokom shranjena s stanjem »pretečeno« (" + r.sa + "), veljavna ne (" + r.sb + ")");
  ok(/8 ali 13 števk/.test(r.e1) && /kontrolna števka/.test(r.e2) && r.e3 === "OK" && r.e4 === "OK" && r.e5 === "OK", "5: EAN – abc123 in napačna kontrolna števka zavrnjena, EAN-13/EAN-8 in prazno sprejeto " + [r.e1, r.e2].join(" | "));
  ok(/Rok izvedbe.*pred/.test(r.c3), "CAPA z rokom pred ugotovitvijo zavrnjena");
  // šarža v obrazcu: opozorilo pred shranjevanjem (rok pred prevzemom), nato stanje »pretečeno«; EAN ob polju
  await pg.goto(B + "/#/stranka/" + r.sid + "/sledljivost"); await pg.waitForTimeout(800);
  const dlg = []; pg.removeAllListeners("dialog"); pg.on("dialog", d => { dlg.push(d.message()); d.accept(); });
  await pg.evaluate(sid => openForm("sarze", null, { stranka_id: sid, dobavitelji: {} }, () => {}), r.sid); await pg.waitForSelector("#f_izdelek");
  await pg.fill("#f_izdelek", "Jogurt"); await pg.fill("#f_ean", "123"); await pg.fill("#f_datum_prevzema", "2026-10-31"); await pg.fill("#f_rok_uporabe", "2026-10-20"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(200);
  ok(/8 ali 13 števk/.test(await pg.evaluate(() => (document.querySelector("#f_ean").closest(".f").querySelector(".f-err") || {}).textContent || "")), "5: obrazec šarže – napačen EAN ob polju");
  await pg.fill("#f_ean", ""); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok(dlg.some(m => /pred datumom prevzema.*pretečeno/.test(m)), "5: obrazec šarže – opozorilo, da je rok pred prevzemom: " + dlg.join(" | "));
  ok(await pg.evaluate(async sid => (await D.list("sarze", { stranka_id: sid })).find(x => x.izdelek === "Jogurt").status, r.sid) === "pretečeno", "5: šarža iz obrazca ima stanje »pretečeno«");
  pg.removeAllListeners("dialog"); pg.on("dialog", d => d.accept());
  // 12) različica dokumenta in interna revizija sta jasno ločeni (seznam načrtov, potrditve)
  await pg.goto(B + "/#/stranka/" + r.sid + "/nacrti"); await pg.waitForSelector("table.t tr[data-id]");
  const vr = await pg.evaluate(() => document.querySelector("table.t tr[data-id]").textContent);
  ok(/1\.0\s*rev\. 4/.test(vr), "12: seznam načrtov: »1.0 rev. 4« (" + vr.replace(/\s+/g, " ") + ")");
  await pg.goto(B + "/#/stranka/" + r.sid + "/potrditve"); await pg.waitForSelector("text=Različica / revizija");
  ok(/Načrt R.*1\.0\s*rev\. 4/.test((await pg.textContent("#view")).replace(/\s+/g, " ")), "12: potrditve kažejo isto: 1.0 rev. 4");
  // obrazci: napaka ob polju (enako kot obvezna polja)
  await pg.goto(B + "/#/stranka/" + r.sid + "/oprema"); await pg.waitForTimeout(800);
  await pg.evaluate(() => openForm("oprema", null, { stranka_id: location.hash.split("/")[2], obrati: {} }, () => {}));
  await pg.fill("#f_naziv", "Hladilnik X"); await pg.fill("#f_meja_min", "8"); await pg.fill("#f_meja_max", "2"); await pg.fill("#f_interval_dni", "-5"); await pg.click("#dlg-f .btn:last-child");
  const f1 = await pg.evaluate(() => [...document.querySelectorAll(".f.bad")].map(l => l.querySelector(".f-err").textContent));
  ok(f1.length === 2 && f1.some(t => /Dovoljeno do/.test(t)) && f1.some(t => /celo število/.test(t)), "obrazec opreme: napaki ob poljih " + JSON.stringify(f1));
  await pg.fill("#f_interval_dni", "abc"); await pg.click("#dlg-f .btn:last-child");
  const f2 = await pg.evaluate(() => [...document.querySelectorAll(".f.bad .f-err")].map(x => x.textContent).join(" | "));
  ok(/npr\. 30/.test(f2) && !/-17,5/.test(f2.split("|").find(x => /Interval/.test(x)) || ""), "3: sporočilo za interval ne navaja primera -17,5 " + f2);
  await pg.evaluate(() => document.querySelector("dialog[open]").close());
  await pg.evaluate(() => openForm("dogodki", null, { stranka_id: location.hash.split("/")[2], obrati: {} }, () => {}));
  ok(await pg.getAttribute("#f_ura", "type") === "time", "6: ura dogodka je polje <input type=time>"); await pg.evaluate(() => document.querySelector("dialog[open]").close());
  // obrazec zapisa evidence: urejanje brez razloga – napaka ob polju Razlog
  const zid = await pg.evaluate(async sid => (await D.add("evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "H2", vrednost: 2, min: 0, max: 4 })).id, r.sid);
  await pg.evaluate(async ({ sid, id }) => { const ctx = await evCtx({ stranka_id: sid, obrati: {} }); evForm((await D.list("evidence", { stranka_id: sid })).find(x => x.id === id), ctx, () => {}); }, { sid: r.sid, id: zid });
  await pg.fill("#f_vrednost", "2,5"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(200);
  ok(/razlog popravka/.test(await pg.evaluate(() => (document.querySelector("#f__razlog").closest(".f").querySelector(".f-err") || {}).textContent || "")), "1: obrazec zapisa – brez razloga napaka ob polju Razlog");
  await pg.fill("#f__razlog", "napaka pri vnosu"); await pg.fill("#f_min", "8"); await pg.fill("#f_max", "2"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(200);
  ok(await pg.evaluate(() => /Dovoljeno do/.test((document.querySelector("#f_max").closest(".f").querySelector(".f-err") || {}).textContent || "")), "2: obrazec zapisa – meje od > do ob polju");
  await pg.fill("#f_min", "0"); await pg.fill("#f_max", "4"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok(await pg.evaluate(async ({ sid, id }) => (await D.list("evidence", { stranka_id: sid })).find(x => x.id === id).revizije.slice(-1)[0].razlog, { sid: r.sid, id: zid }) === "napaka pri vnosu", "1: popravek z razlogom shranjen");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
