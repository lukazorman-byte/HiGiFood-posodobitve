// Javna spletna stran: predogled na /stran/, javni cenik brez zasebnih podatkov, varnostne glave.
const B = process.env.BASE;
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const r = await fetch(B + "/stran/"), t = await r.text();
  ok(r.status === 200 && /HACCP brez papirja/.test(t) && /stran\.js/.test(t), "/stran/ prikaže spletno stran");
  ok(/frame-ancestors 'none'/.test(r.headers.get("content-security-policy") || "") && r.headers.get("x-content-type-options") === "nosniff", "spletna stran ima varnostne glave");
  for (const f of ["stran.css", "stran.js", "logo-svetlo.png", "logo-temno.png", "favicon.png"]) ok((await fetch(B + "/stran/" + f)).status === 200, "datoteka " + f);
  ok((await fetch(B + "/stran/../server.js")).status !== 200 && (await fetch(B + "/stran/%2e%2e/server.js")).status !== 200, "brez dostopa izven mape strani");
  const c = await (await fetch(B + "/api/javno/cenik")).json();
  ok(Array.isArray(c.paketi) && c.paketi.length >= 3 && c.paketi.every(p => p.ime && typeof p.cena === "number" && !p.moduli) && c.ddv === 22, "javni cenik: paketi s cenami (brez seznama modulov)");
  ok(!("stranke" in c) && !("predracuni" in c) && !("izdajatelj" in c) && Object.keys(c.kontakt).sort().join() === "email,naslov,naziv,telefon", "javni cenik ne razkrije naročnin, strank ali TRR");
  ok(c.aplikacija === "", "brez HACCP_APLIKACIJA_URL ni povezave na drugo domeno");
  // domena spletne strani (HACCP_SPLETNA_STRAN=higifood.localhost): stran namesto platforme, stari service worker se odstrani,
  // neposlani zapisi evidenc (platforma je bila prej na tej domeni) se pošljejo s stare seje
  const port = new URL(B).port, H = "http://higifood.localhost:" + port;
  const { chromium } = require("./pw.js"), br = await chromium.launch({ args: ["--host-resolver-rules=MAP higifood.localhost 127.0.0.1"] }), pg = await (await br.newContext()).newPage(), errs = []; pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(H + "/"); await pg.waitForSelector(".cena");
  ok(/HACCP brez papirja/.test(await pg.textContent("h1")), "domena spletne strani prikaže stran, ne platforme");
  ok(/registration\.unregister/.test(await pg.evaluate(() => fetch("/sw.js").then(r => r.text()))), "sw.js na domeni strani odstrani stari service worker");
  const sid = await pg.evaluate(async () => { const j = (m, u, b) => fetch(u, { method: m, headers: { "Content-Type": "application/json" }, body: b && JSON.stringify(b) }).then(r => r.json());
    await j("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "A", geslo: "dolgogeslo123" }); await j("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" });
    const s = await j("POST", "/api/d/stranke", { naziv: "Iz čakalne vrste d.o.o." });
    localStorage.setItem("haccp_offq", JSON.stringify([{ t: 1, c: "evidence", body: { stranka_id: s.id, vrsta: "temperatura", oprema: "H1", vrednost: 3, min: 0, max: 4, skladno: true } }])); return s.id; });
  await pg.reload(); await pg.waitForSelector("#poslji-q"); ok(/neposlani zapisi evidenc \(1\)/.test(await pg.textContent("main")), "opozorilo o neposlanih zapisih");
  await pg.click("#poslji-q"); await pg.waitForFunction(() => !document.getElementById("poslji-q"));
  const ev = await pg.evaluate(id => fetch("/api/d/evidence?stranka_id=" + id).then(r => r.json()), sid);
  ok(Array.isArray(ev) && ev.length === 1 && ev[0].vrednost === 3 && (await pg.evaluate(() => localStorage.getItem("haccp_offq"))) === "[]", "neposlani zapis poslan na strežnik, čakalna vrsta prazna");
  ok(!errs.length, "brez napak JavaScript " + errs.join(";")); await br.close();
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
