// Dvostopenjska prijava: koda se na isti napravi zahteva enkrat na 30 dni (zaupanja vredna naprava, piškotek hz),
// nova naprava kodo zahteva takoj; sprememba gesla in »Pozabi naprave« zaupanje prekličeta.
const crypto = require("crypto"), B = process.env.BASE;
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const dec = s => { let bits = 0, val = 0; const out = []; for (const ch of s.toUpperCase().replace(/[^A-Z2-7]/g, "")) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); };
const totp = (key, ctr) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); const h = crypto.createHmac("sha1", key).update(b).digest(), o = h[h.length - 1] & 15; return String(((h.readUInt32BE(o) & 0x7fffffff) % 1e6)).padStart(6, "0"); };
const req = async (m, p, b, ck) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, ck ? { Cookie: ck } : {}), body: b ? JSON.stringify(b) : undefined }); let j = null; try { j = await r.json(); } catch {} return { s: r.status, j, c: r.headers.getSetCookie() }; };
const pk = (c, ime) => { const x = (c || []).find(v => v.startsWith(ime + "=")); return x ? x.split(";")[0] : ""; };
(async () => {
  await req("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "A", geslo: "dolgogeslo123" });
  let hs = pk((await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" })).c, "hs");
  const z = await req("POST", "/api/auth/2fa/zacni", null, hs), key = dec(z.j.skrivnost); let ctr = Math.floor(Date.now() / 30000);
  const pt = await req("POST", "/api/auth/2fa/potrdi", { koda: totp(key, ctr) }, hs), rez = pt.j.rezervne; ok(pt.s === 200 && rez.length === 8, "2FA vklopljena"); // nadaljnje prijave z rezervnimi kodami (koda TOTP velja ±30 s)
  const prijava = (b, ck) => req("POST", "/api/auth/prijava", Object.assign({ email: "a@t.si", geslo: "dolgogeslo123" }, b), ck);
  let r = await prijava({}); ok(r.s === 401 && r.j.potrebna_koda && /30 dni/.test(r.j.napaka), "brez kode in brez zaupane naprave: koda zahtevana");
  r = await prijava({ koda: rez[0] }); const hz = pk(r.c, "hz"), hzc = (r.c || []).find(v => v.startsWith("hz="));
  ok(r.s === 200 && hz && /Max-Age=2592000/.test(hzc) && /HttpOnly/.test(hzc) && /Path=\/api\/auth/.test(hzc) && pk(r.c, "hs"), "prijava s kodo: naprava zaupana 30 dni (piškotek hz, HttpOnly) in seja");
  r = await prijava({}, hz); ok(r.s === 200 && !pk(r.c, "hz"), "ista naprava v 30 dneh: prijava brez kode");
  r = await prijava({}, "hz=ponarejen"); ok(r.s === 401 && r.j.potrebna_koda, "druga naprava (ali ponarejen piškotek): koda zahtevana");
  r = await prijava({ koda: rez[1], zapomni: false }); ok(r.s === 200 && !pk(r.c, "hz"), "»ne zapomni« (skupni računalnik): naprava ni zaupana");
  hs = pk(r.c, "hs"); const jaz = await req("GET", "/api/auth/jaz", null, hs); ok(jaz.j && jaz.j.totp_naprave === 1, "Moj račun: 1 zaupanja vredna naprava");
  // pozabi naprave
  ok((await req("POST", "/api/auth/2fa/pozabi-naprave", null, hs)).j.pozabljenih === 1, "pozabi zaupanja vredne naprave");
  r = await prijava({}, hz); ok(r.s === 401 && r.j.potrebna_koda, "po »Pozabi naprave« je koda spet zahtevana");
  // sprememba gesla prekliče zaupanje
  r = await prijava({ koda: rez[2] }); const hz2 = pk(r.c, "hz"); hs = pk(r.c, "hs");
  ok((await prijava({}, hz2)).s === 200, "nova zaupanja vredna naprava");
  ok((await req("POST", "/api/auth/geslo", { staro: "dolgogeslo123", novo: "novogeslo12345" }, hs)).s === 200, "sprememba gesla");
  r = await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "novogeslo12345" }, hz2); ok(r.s === 401 && r.j.potrebna_koda, "po spremembi gesla je koda spet zahtevana");
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
