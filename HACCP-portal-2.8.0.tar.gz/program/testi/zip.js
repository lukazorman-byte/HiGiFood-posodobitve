// Branje ZIP za teste: { ime: Buffer } (metodi 0 – brez stiskanja in 8 – deflate)
const zlib = require("zlib");
module.exports = function beriZip(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error("ni ZIP");
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = {};
  for (let i = 0; i < n; i++) {
    const met = buf.readUInt16LE(p + 10), cs = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), kl = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const ime = buf.slice(p + 46, p + 46 + nl).toString("utf8"), lh = off + 30 + buf.readUInt16LE(off + 26) + buf.readUInt16LE(off + 28), d = buf.slice(lh, lh + cs);
    out[ime] = met === 8 ? zlib.inflateRawSync(d) : d; p += 46 + nl + xl + kl;
  }
  return out;
};
