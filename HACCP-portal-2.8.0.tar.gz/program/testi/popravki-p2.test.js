// Popravki po pregledu (2. skupina): prepoznava živil (začetek besede, izjeme), predlogi iz baze ne prepišejo vpisanega,
// samodejne neskladnosti (združevanje, enote, načrt istega obrata), GDPR pri soimenjakih, geslo odgovorne osebe, nastavitve e-pošte,
// rednost vnosov v letnem pregledu.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");

  // 1) profili živil
  const pr = await pg.evaluate(async () => { const db = await baza(), id = n => (profilZivila({ naziv: n }, db) || {}).id;
    const o = {}; for (const n of ["Mleti mandlji", "Omleta", "Ribez", "Arašidovo maslo", "Mleta kava", "Ovseno mleko", "Mleto meso", "Losos", "Tuna", "Piščančja prsa", "Mleko", "Maslo", "Sardele"]) o[n] = id(n); return o; });
  ok(pr["Mleti mandlji"] !== "meso_mleto" && pr["Omleta"] !== "meso_mleto" && pr["Mleta kava"] !== "meso_mleto", "mleti mandlji, omleta, mleta kava niso mleto meso (" + [pr["Mleti mandlji"], pr["Omleta"], pr["Mleta kava"]] + ")");
  ok(pr["Ribez"] !== "ribe" && pr["Arašidovo maslo"] !== "mlecni" && pr["Ovseno mleko"] !== "mlecni", "ribez ni riba, arašidovo maslo in ovseno mleko nista mlečna (" + [pr["Ribez"], pr["Arašidovo maslo"], pr["Ovseno mleko"]] + ")");
  ok(pr["Mleto meso"] === "meso_mleto" && pr["Losos"] === "ribe" && pr["Tuna"] === "ribe" && pr["Sardele"] === "ribe" && pr["Piščančja prsa"] === "perutnina" && pr["Mleko"] === "mlecni" && pr["Maslo"] === "mlecni", "prava živila prepoznana (" + JSON.stringify(pr) + ")");

  // 2) izpolnitev iz baze ne prepiše vpisanega; po popravku naziva se predlog posodobi
  const iz = await pg.evaluate(async () => { const db = await baza();
    const a = { naziv: "Mleko", rezim: "hl8", prevzem: "po dogovoru z dobaviteljem" }; izpolniZivilo(a, db);
    const b = { naziv: "Mleko" }; izpolniZivilo(b, db); const b1 = b.rezim; b.naziv = "Sladoled"; izpolniZivilo(b, db);
    const W = { koraki: [{ id: "k1", naziv: "Suho skladišče" }], zivila: [{ naziv: "Sladkor" }, { naziv: "Med" }] }, p = profilZaNevarnost({ korak_id: "k1", nevarnost: "Plesen" }, W, db);
    return { a, b1, b2: b.rezim, per: (db.drevo_profili.find(x => x.id === "sladoled") || {}).rezim, moka: (profilZivila({ naziv: "Sladkor" }, db) || {}).rezim, sob: p.rezim, top: p.toplotna };
  });
  ok(iz.a.rezim === "hl8" && iz.a.prevzem === "po dogovoru z dobaviteljem", "vpisan režim in prevzem ostaneta");
  ok(iz.b2 === iz.per && iz.b1 !== iz.b2, "po popravku naziva se predlagani režim posodobi");
  ok(iz.sob === iz.moka && iz.sob !== "hl4" && !iz.top, "suha živila: režim " + iz.sob + ", brez izmišljenega hlajenja in toplotne obdelave");

  // 3) samodejne neskladnosti
  const cp = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kuhinja Dve d.o.o." }), o1 = await D.add("obrati", { stranka_id: s.id, naziv: "Obrat 1" }), o2 = await D.add("obrati", { stranka_id: s.id, naziv: "Obrat 2" });
    await D.add("nacrti", { stranka_id: s.id, obrat_id: o2.id, naziv: "HACCP Obrat 2", vsebina: { koraki: [{ id: "k1", naziv: "Skladiščenje v hladilniku" }], nevarnosti: [{ id: "h1", korak_id: "k1", tip: "B", nevarnost: "Rast" }], kontrole: { h1: { hid: "h1", vrsta: "CCP", korektivni: "Ukrep obrata 2" } } } });
    const z1 = await D.add("evidence", { stranka_id: s.id, obrat_id: o1.id, vrsta: "zdravje", oseba: "Ana", simptomi: true }), z2 = await D.add("evidence", { stranka_id: s.id, obrat_id: o1.id, vrsta: "zdravje", oseba: "Bor", simptomi: true });
    const h = await D.add("evidence", { stranka_id: s.id, obrat_id: o1.id, vrsta: "hitri_test", tip_testa: "ATP", mesto: "Deska", vrednost: 500, enota: "RLU", max: 150 });
    const t1 = await D.add("evidence", { stranka_id: s.id, obrat_id: o1.id, vrsta: "temperatura", oprema: "Hladilnik X", vrednost: 9, min: 0, max: 4 });
    const t2 = await D.add("evidence", { stranka_id: s.id, obrat_id: o2.id, vrsta: "temperatura", oprema: "Hladilnik Y", vrednost: 9, min: 0, max: 4 });
    const caps = await api("GET", "/api/d/capa?stranka_id=" + s.id), c = id => caps.find(x => x.id === id) || {};
    return { z1: z1.capa_id, z2: z2.capa_id, h: c(h.capa_id).opis || "", t1: c(t1.capa_id).takojsnji_ukrep || "", t2: c(t2.capa_id).takojsnji_ukrep || "" };
  });
  ok(cp.z1 && cp.z2 && cp.z1 !== cp.z2, "simptomi dveh zaposlenih: dve neskladnosti");
  ok(/500 RLU/.test(cp.h) && !/°C/.test(cp.h), "opis neskladnosti v enoti zapisa (" + cp.h + ")");
  ok(cp.t1 !== "Ukrep obrata 2" && cp.t2 === "Ukrep obrata 2", "korektivni ukrep le iz načrta istega obrata (" + JSON.stringify([cp.t1, cp.t2]) + ")");

  // 4) GDPR: soimenjak pri drugi stranki
  const gd = await pg.evaluate(async () => {
    const s1 = await D.add("stranke", { naziv: "Prva d.o.o." }), s2 = await D.add("stranke", { naziv: "Druga d.o.o." });
    await D.add("osebje", { stranka_id: s1.id, ime: "Marko Kos" }); await D.add("osebje", { stranka_id: s2.id, ime: "Marko Kos" });
    const st = (m, p, b) => api(m, p, b).then(r => ({ s: 200, r }), e => ({ s: e.status, m: e.message }));
    const brez = await st("POST", "/api/gdpr/izvoz", { ime: "Marko Kos" }), z = await st("POST", "/api/gdpr/izvoz", { ime: "Marko Kos", stranka_id: s1.id });
    const an = await st("POST", "/api/gdpr/anonimiziraj", { ime: "Marko Kos", stranka_id: s1.id, potrdi: true });
    const os1 = (await api("GET", "/api/d/osebje?stranka_id=" + s1.id)).map(x => x.ime), os2 = (await api("GET", "/api/d/osebje?stranka_id=" + s2.id)).map(x => x.ime);
    return { brez: brez.s, z: z.s, zn: z.r && z.r.zapisi && (z.r.zapisi.osebje || []).length, an: an.s, os1, os2 };
  });
  ok(gd.brez === 409, "samo ime pri soimenjakih: zahteva e-naslov ali stranko (" + gd.brez + ")");
  ok(gd.z === 200 && gd.zn === 1, "izvoz z izbrano stranko: le zapis te stranke");
  ok(gd.an === 200 && !gd.os1.includes("Marko Kos") && gd.os2.includes("Marko Kos"), "anonimizacija ne zadene soimenjaka pri drugi stranki");

  // 5) geslo odgovorne osebe lahko nastavi le administrator (svetovalec se ne more prijaviti kot ona)
  const u = await pg.evaluate(async () => { const s = (await D.list("stranke"))[0];
    const sv = await api("POST", "/api/uporabniki", { ime: "Sv Etovalec", email: "sv2@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", stranke: [s.id] });
    const od = await api("POST", "/api/uporabniki", { ime: "Od Govorna", email: "od2@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s.id });
    return { od: od.id, sv: sv.id }; });
  const ps = await (await br.newContext()).newPage();
  await ps.goto(B + "/"); await ps.fill("#le", "sv2@t.si"); await ps.fill("#lp", "dolgogeslo123"); await ps.click("#lf button"); await ps.waitForSelector("#shell:not([hidden])");
  const g = await ps.evaluate(id => api("PUT", "/api/uporabniki/" + id, { geslo: "drugogeslo12345" }).then(() => 200, e => e.status), u.od);
  ok(g === 403, "svetovalec ne more nastaviti gesla odgovorni osebi (" + g + ")");
  const sl = await pg.evaluate(id => api("PUT", "/api/uporabniki/" + id, { geslo: "drugogeslo12345" }).then(() => api("GET", "/api/revizijska-sled?n=20")), u.od);
  ok((sl.vnosi || []).some(e => e.akcija === "geslo-nastavljeno"), "nastavitev gesla je v revizijski sledi");

  // 6) nastavitve e-pošte: geslo ne gre na drug strežnik; izklop obvestil se shrani
  const ns = await pg.evaluate(async () => { const st = b => api("PUT", "/api/nastavitve", b).then(() => 200, e => e.status);
    const a = await st({ streznik: "smtp.prvi.si", vrata: 587, uporabnik: "u", geslo: "skrivnost1", od: "a@t.si" });
    const b = await st({ streznik: "smtp.tuji.si", vrata: 587, uporabnik: "u", geslo: "********", od: "a@t.si" });
    const c = await st({ vklopljeno: false, streznik: "smtp.prvi.si", vrata: 587, uporabnik: "u", geslo: "********", od: "a@t.si" });
    return { a, b, c, vk: (await api("GET", "/api/nastavitve")).vklopljeno }; });
  ok(ns.a === 200 && ns.b === 400, "menjava strežnika brez ponovnega gesla zavrnjena (" + ns.b + ")");
  ok(ns.c === 200 && ns.vk === false, "izklop pošiljanja obvestil se shrani");
  await pg.goto(B + "/#/admin"); await pg.waitForSelector("#n_vk", { state: "attached" }); ok(!(await pg.isChecked("#n_vk")), "stikalo »Pošiljanje vklopljeno« prikaže izklop");

  // 7) letni pregled: dva vnosa v istem dnevu štejeta kot en opravljen interval
  const rd = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Rednost d.o.o." }), dan = 864e5, zdaj = Date.now();
    const d = i => new Date(zdaj - i * dan); const ymd = t => t.getFullYear() + "-" + String(t.getMonth() + 1).padStart(2, "0") + "-" + String(t.getDate()).padStart(2, "0");
    for (let i = 1; i <= 5; i++) for (const h of [8, 20]) { const t = d(i); t.setHours(h, 0, 0, 0); await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "H", vrednost: 3, min: 0, max: 4, cas: t.toISOString() }); }
    const orig = D.list; D.list = (c, q) => c === "urnik" ? Promise.resolve([{ vrsta: "temperatura", frekvenca_ur: 24, ustvarjeno: d(10).toISOString() }]) : orig.call(D, c, q);
    try { const V = await verifikacijaPodatki({ stranka_id: s.id, stranka: s }, ymd(d(10)), ymd(d(0))); return V.rednost[0]; } finally { D.list = orig; } });
  ok(rd && rd.opravljeno === 5 && rd.delez < 60, "rednost: 5 dni z vnosi od " + (rd && rd.pricakovano) + " (" + (rd && rd.delez) + " %)");

  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
