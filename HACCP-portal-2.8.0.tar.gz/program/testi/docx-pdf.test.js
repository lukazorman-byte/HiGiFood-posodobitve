// Word (.docx) usklajen s PDF-jem: isti HACCP načrt (Kavarna Sonce, različica 1.1) v PDF in DOCX; DOCX → PDF (LibreOffice):
// število strani ±10 %, slike strani (PNG) za vizualni pregled; v XML: Arial (brez Calibri), pravi seznami (brez »•\t«), tabele brez
// navpičnih črt in z glavo na vsaki strani, napisi s keepNext, polje TOC, noga Arial 8 pt #666666 z različico dokumenta.
const B = process.env.BASE, OUT = process.env.OUT, PRIM = process.env.PRIMERJAVA_DIR;
const { chromium } = require("./pw.js"), fs = require("fs"), path = require("path"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const zip = (f, n) => { const r = cp.spawnSync("python3", ["-c", "import zipfile,sys\nz=zipfile.ZipFile(sys.argv[1])\nn=sys.argv[2]\nprint('\\n'.join(z.namelist()) if n=='*' else z.read(n).decode())", f, n], { encoding: "utf8", maxBuffer: 1 << 28 }); return r.stdout || ""; };
const strani = f => { const r = cp.spawnSync("pdfinfo", [f], { encoding: "utf8" }); return +((r.stdout || "").match(/Pages:\s+(\d+)/) || [])[1] || 0; };
(async () => {
  if (cp.spawnSync("soffice", ["--version"]).error) { console.log("LibreOffice ni nameščen – preskočeno"); process.exit(77); }
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kavarna Sonce", dejavnost: "Gostinstvo (restavracija, gostilna)", pravna_oblika: "s.p.", odgovorna_oseba: "Zeljije Aljiti", naslov: "Sončna ulica 1, Ljubljana", opis_dejavnosti: "Kavarna s toplo kuhinjo, sladoledom in pecivom." });
    const o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce", opis_prostorov: "Kuhinja, točilni pult, skladišče." });
    const imena = ["Prevzem", "Skladiščenje v hladilniku", "Skladiščenje zamrznjeno", "Odtajanje", "Priprava zelenjave", "Priprava mesa", "Toplotna obdelava", "Hlajenje", "Regeneracija", "Ohranjanje toplote", "Hladna priprava", "Sladoled", "Točilni pult", "Kava", "Led", "Pecivo", "Pomivanje", "Odpadki", "Izdaja", "Dostava"];
    const koraki = imena.map((n, i) => ({ id: "k" + i, naziv: n })), nevarnosti = [], kontrole = {};
    imena.forEach((n, i) => nevarnosti.push({ id: "h" + i, korak_id: "k" + i, tip: "B", nevarnost: "Rast ali preživetje mikroorganizmov pri koraku " + n.toLowerCase(), verjetnost: 3, teza: 4, potrjeno: true }));
    imena.forEach((n, i) => { const v = ["Toplotna obdelava", "Regeneracija", "Sladoled"].includes(n) ? "CCP" : i % 3 === 0 ? "OPRP" : ""; if (v) kontrole["h" + i] = { hid: "h" + i, vrsta: v, kaj: "temperatura – " + n.toLowerCase(), mejna: "≥ 72 °C v središču", mejna_vir: "smernica", evidenca: "temperatura", verifikacija: "tedensko pregled evidenc", spremljanje: "vbodni termometer", pogostost: "vsaka serija", odgovoren: "kuhar", korektivni: "nadaljuj segrevanje do mejne vrednosti; če ni mogoče, živilo zavrzi" }; });
    const t = await D.add("tlorisi", { stranka_id: s.id, obrat_id: o.id, naziv: "Tloris obrata", sirina_m: 8, visina_m: 6, elementi: [{ t: "soba", id: "a", x: 0, y: 0, w: 5, h: 6, tip: "kuhinja / priprava", ime: "Kuhinja" }, { t: "soba", id: "b", x: 5, y: 0, w: 3, h: 6, tip: "skladišče", ime: "Skladišče" }, { t: "pot", id: "p", vrsta: "čista pot", pts: [[1, 5.5], [1, 1], [4, 1]] }, { t: "vrata", id: "v", x: 5, y: 3, rot: 90 }] });
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "Kavarna Sonce", status: "osnutek", verzija_oznaka: "1.0", razlicice: [{ oznaka: "1.0", datum: "2026-01-10", opis: "Prva izdaja" }, { oznaka: "1.1", datum: "2026-06-01", opis: "Dodan sladoled" }],
      vsebina: { koraki, nevarnosti, kontrole, zivila: [{ naziv: "Sladoled", alergeni: "mleko", alergeni_potrjeni: true }, { naziv: "Piščančja prsa", alergeni_potrjeni: true }], zbiranje: { hacc_ekipa: "Zeljije Aljiti", tlorisi: [{ vrsta: "narisan", id: t.id, naslov: "Tloris obrata" }] } } });
    return { n: n.id };
  });
  await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector(".stepper button"); await pg.click(".stepper button >> nth=6"); await pg.waitForSelector("#xpdf");
  let [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#xpdf")]); const fp = path.join(OUT, "HACCP-Kavarna-Sonce.pdf"); await dl.saveAs(fp);
  [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#xdoc")]); const fd = path.join(OUT, "HACCP-Kavarna-Sonce.docx"); await dl.saveAs(fd);
  await br.close();

  // ---- XML ----
  const imena = zip(fd, "*").split("\n").filter(Boolean), doc = zip(fd, "word/document.xml"), sty = zip(fd, "word/styles.xml"), ftr = zip(fd, "word/footer1.xml");
  for (const n of ["word/numbering.xml", "word/fontTable.xml", "docProps/core.xml", "docProps/app.xml"]) ok(imena.includes(n), "paket vsebuje " + n);
  const vse = imena.filter(n => /\.(xml|rels)$/.test(n)).map(n => zip(fd, n)).join("");
  ok(!/Calibri/.test(vse), "nikjer pisava Calibri");
  ok(/<w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"\/>[\s\S]*?<w:sz w:val="19"\/>[\s\S]*?<w:lang w:val="sl-SI"/.test(sty), "privzeto Arial 9,5 pt, sl-SI");
  ok(/w:styleId="Heading1"[\s\S]*?<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="4" w:color="2F6F4F"\/>[\s\S]*?<w:sz w:val="32"\/>/.test(sty), "Naslov 1: 16 pt z zeleno črto pod naslovom");
  const besedilo = (doc.match(/<w:t[^>]*>[^<]*<\/w:t>/g) || []).map(x => x.replace(/<[^>]+>/g, "")).join("\n");
  ok(!/•\t|^•/m.test(besedilo), "brez ročnih alinej »•« v besedilu");
  ok(/<w:numPr><w:ilvl w:val="0"\/><w:numId w:val="1"\/><\/w:numPr>/.test(doc), "alineje kot pravi seznam (numbering.xml)");
  const tabele = doc.match(/<w:tbl>[\s\S]*?<\/w:tbl>/g) || [], prva = t => (t.match(/<w:tr>[\s\S]*?<\/w:tr>/) || [""])[0], podatkovne = tabele.filter(t => !/tblpPr/.test(t) && /w:fill="2F6F4F"/.test(prva(t)) && /w:color w:val="FFFFFF"/.test(prva(t)));
  ok(tabele.every(t => !/<w:insideV w:val="(?!nil)/.test(t)), "nobena tabela nima navpičnih črt (insideV)");
  ok(podatkovne.length >= 8 && podatkovne.every(t => /^<w:tr><w:trPr><w:cantSplit\/><w:tblHeader\/><\/w:trPr>/.test(prva(t))), "vse tabele s podatki imajo glavo, ki se ponovi na vsaki strani (" + podatkovne.length + ")");
  ok(podatkovne.every(t => /<w:tblCellMar><w:top w:w="50" w:type="dxa"\/><w:left w:w="100"/.test(t) && /<w:tblW w:w="9638"/.test(t)), "tabele: širina 9638, odmiki celic 100/50");
  ok(/TOC \\o "1-1" \\h \\z \\u/.test(doc) && /w:styleId="TOC1"[\s\S]*?w:leader="dot" w:pos="9638"/.test(sty), "polje kazala TOC s pikčasto vodilno črto");
  const toc = (doc.match(/<w:pStyle w:val="TOC1"\/>[\s\S]*?<\/w:p>/g) || []).map(p => (p.match(/<w:t[^>]*>([^<]*)<\/w:t>/g) || []).map(x => x.replace(/<[^>]+>/g, "")).join("|"));
  ok(toc.length >= 10 && toc.every(x => /\|\d+$/.test(x)), "kazalo ima vnaprej vpisane številke strani (" + toc.slice(0, 3).join("; ") + ")");
  const napisi = doc.match(/<w:p><w:pPr><w:pStyle w:val="Napis"\/>[\s\S]*?<\/w:p>/g) || [];
  ok(napisi.length >= 1 && napisi.every(p => /Tloris \d+:/.test(p)) && /w:styleId="Napis"[\s\S]*?<w:keepNext\/>/.test(sty), "napis tlorisa v slogu Napis s keepNext");
  ok(!/>Tloris obrata<\/w:t><\/w:r><\/w:p>/.test(doc.replace(/<w:p><w:pPr><w:pStyle w:val="Napis"\/>[\s\S]*?<\/w:p>/g, "")), "brez drugega napisa pod tlorisom");
  ok(/<w:tblpPr[^>]*w:vertAnchor="page"[^>]*w:tblpY="0"\/>[\s\S]*?w:fill="2F6F4F"[\s\S]*?HiGiFood/.test(doc), "naslovnica: zeleni pas na vrhu strani z »HiGiFood«");
  const runi = ftr.match(/<w:r>[\s\S]*?<\/w:r>/g) || [];
  ok(runi.length >= 10 && runi.every(r => /<w:sz w:val="16"\/>/.test(r) && /<w:color w:val="666666"\/>/.test(r)), "noga: vsi runi (tudi PAGE, NUMPAGES, » / «) Arial 8 pt #666666");
  ok(/\| v1\.1 \|/.test(ftr) && /\| v1\.1 \|/.test(cp.spawnSync("pdftotext", [fp, "-"], { encoding: "utf8" }).stdout || ""), "različica v nogi = različica dokumenta (1.1) v Wordu in PDF");
  ok(/<dc:title>HACCP načrt: Kavarna Sonce<\/dc:title>/.test(zip(fd, "docProps/core.xml")) && /<Company>HiGiFood<\/Company>/.test(zip(fd, "docProps/app.xml")), "lastnosti datoteke (naslov, podjetje)");

  // ---- DOCX → PDF (LibreOffice), število strani, slike strani ----
  const lo = cp.spawnSync("soffice", ["--headless", "-env:UserInstallation=file://" + path.join(OUT, "lo-profil"), "--convert-to", "pdf", "--outdir", path.join(OUT, "word"), fd], { encoding: "utf8", timeout: 180000 });
  const fw = path.join(OUT, "word", "HACCP-Kavarna-Sonce.pdf"), sp = strani(fp), sw = strani(fw);
  ok(fs.existsSync(fw), "DOCX pretvorjen v PDF (LibreOffice) " + (lo.stderr || "").slice(0, 120));
  ok(sw && Math.abs(sw - sp) / sp <= 0.1, `število strani: PDF ${sp}, Word ${sw} (razlika ≤ 10 %)`);
  for (const [f, p] of [[fp, "pdf"], [fw, "word"]]) cp.spawnSync("pdftoppm", ["-r", "60", "-png", f, path.join(OUT, "stran-" + p)]);
  ok(fs.readdirSync(OUT).filter(f => /^stran-(pdf|word)-\d+\.png$/.test(f)).length >= sp + sw, "vse strani obeh izrisane v PNG");
  if (PRIM) { fs.mkdirSync(PRIM, { recursive: true }); for (const f of fs.readdirSync(OUT)) if (/\.(png|pdf|docx)$/.test(f)) fs.copyFileSync(path.join(OUT, f), path.join(PRIM, f)); for (const f of fs.readdirSync(path.join(OUT, "word"))) fs.copyFileSync(path.join(OUT, "word", f), path.join(PRIM, "word-" + f)); }
  console.log("napake", errs); if (errs.length) fails++; console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
