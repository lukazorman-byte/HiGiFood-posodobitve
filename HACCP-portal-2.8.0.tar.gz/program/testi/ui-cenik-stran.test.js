// Spletna stran → Cenik in paketi: urejanje imena, opisa in cene paketov ob predogledu; spremembe takoj na javnem ceniku;
// shranjevanje pogojev ne ponastavi drugih nastavitev cenika (rok plačila); zavihek je tudi na strani bloga.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), pg = await (await br.newContext()).newPage(); const errs = []; pg.on("pageerror", e => errs.push(String(e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  await pg.evaluate(() => api("PUT", "/api/narocnine/nastavitve", { cenik: { rok_dni: 21, opozorilo_dni: 10, popust_obrat: 10, brezplacni_meseci: 0, ddv: 22 } }));
  await pg.goto(B + "/#/blog"); await pg.waitForSelector(".ss-tabs"); ok(await pg.locator(".ss-tabs a:has-text('Cenik in paketi')").count() === 1, "zavihek »Cenik in paketi« na strani bloga");
  await pg.click(".ss-tabs a:has-text('Cenik in paketi')"); await pg.waitForSelector("#cs_t tr[data-cs]");
  const n = await pg.locator("#cs_t tr[data-cs]").count(); ok(n >= 2, "paketi v tabeli: " + n);
  ok(await pg.locator("#cs_pred .cs-k").count() === n, "predogled cenika s " + n + " paketi");
  // urejanje prvega paketa: predogled se osveži med tipkanjem, po shranjevanju je sprememba na javnem ceniku
  const tr = pg.locator("#cs_t tr[data-cs] >> nth=0"), id = await tr.getAttribute("data-cs");
  await tr.locator("[data-k=ime]").fill("Osnovni Plus"); await tr.locator("[data-k=opis]").fill("Evidence, opomniki in čiščenje za en obrat"); await tr.locator("[data-k=cena]").fill("24,90");
  ok(/Osnovni Plus[\s\S]*24,90/.test(await pg.textContent("#cs_pred")), "predogled pokaže novo ime in ceno med tipkanjem");
  await tr.locator("[data-css]").click(); await pg.waitForSelector(".toast.show:has-text('shranjen')");
  const jc = await pg.evaluate(() => fetch("/api/javno/cenik").then(r => r.json())), p = jc.paketi.find(x => x.id === id);
  ok(p && p.ime === "Osnovni Plus" && p.cena === 24.9 && p.opis === "Evidence, opomniki in čiščenje za en obrat", "javni cenik (spletna stran): " + JSON.stringify(p));
  const pk = await pg.evaluate(id => api("GET", "/api/narocnine").then(d => d.paketi.find(x => x.id === id)), id);
  ok(pk && pk.moduli && pk.moduli.length > 0, "funkcije paketa ostanejo (" + (pk && pk.moduli.length) + ")");
  // napačna cena: jasna napaka, nič se ne shrani
  await pg.locator("#cs_t tr[data-cs] >> nth=0").locator("[data-k=cena]").fill("-5"); await pg.locator("#cs_t tr[data-cs] >> nth=0").locator("[data-css]").click();
  await pg.waitForSelector(".toast.show:has-text('Neveljavna cena')"); ok(true, "negativna cena zavrnjena");
  // pogoji pod cenikom: popust se shrani, rok plačila in opozorilo ostaneta
  await pg.goto(B + "/#/spletna-stran/cenik"); await pg.waitForSelector("[data-cp=popust_obrat]");
  await pg.fill("[data-cp=popust_obrat]", "15"); ok((await pg.textContent("#cs_op")).includes("Vsak dodatni obrat 15 % ceneje."), "predogled pogojev");
  await pg.click("#cs_pog"); await pg.waitForSelector(".toast.show:has-text('Pogoji shranjeni')");
  const c = await pg.evaluate(() => api("GET", "/api/narocnine").then(d => d.cenik));
  ok(c.popust_obrat === 15 && c.rok_dni === 21 && c.opozorilo_dni === 10 && c.ddv === 22, "pogoji shranjeni, rok plačila in opozorilo ostaneta: " + JSON.stringify(c));
  const c2 = await pg.evaluate(() => api("PUT", "/api/narocnine/nastavitve", { cenik: { ddv: 9.5 } }).then(() => api("GET", "/api/narocnine")).then(d => d.cenik));
  ok(c2.ddv === 9.5 && c2.rok_dni === 21 && c2.popust_obrat === 15, "strežnik: delni zapis cenika ne ponastavi ostalih vrednosti " + JSON.stringify(c2));
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
