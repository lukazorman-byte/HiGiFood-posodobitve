// Nova polja v čarovniku HACCP: registracija in SKD 2025, način prodaje, kultura varnosti hrane, HACCP skupina z vlogami,
// podrobnosti živila (stanje alergenov), veja procesa (preimenovanje ne ponastavi potrditve), polja ukrepa, interni rok; čiščenje dvakrat dnevno.
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Polja d.o.o." }), ob = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja" });
    await D.add("osebje", { stranka_id: s.id, ime: "Ana Kos", funkcija: "vodja kuhinje" });
    const W = { koraki: [{ id: "k1", naziv: "Prevzem" }, { id: "k2", naziv: "Kuhanje" }], zivila: [{ id: "z1", naziv: "Juha", alergeni: "zelena" }], nevarnosti: [{ id: "h1", korak_id: "k2", nevarnost: "Preživetje patogenov", tip: "B", verjetnost: 3, teza: 4, potrjeno: true }], kontrole: {} };
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: ob.id, naziv: "Načrt", vsebina: W }); return { s: s.id, n: n.id }; });
  await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector(".stepper");
  // 1. korak
  await pg.fill("[data-k=registracija]", "Reg. št. 123, UVHVVR"); await pg.fill("[data-k=skd]", "56.101");
  ok(/SKD 2025/.test(await pg.textContent("#skd_op")), "SKD: opozorilo na star šifrant");
  await pg.check("[data-np=s_seboj]"); await pg.fill("[data-k=kultura_zaveza]", "Vodstvo zagotavlja vire in čas za usposabljanje.");
  await pg.click("#c_os"); await pg.waitForSelector("#clani tr[data-c]");
  ok(await pg.inputValue("#clani tr[data-c] [data-k=vloga]") === "vodja kuhinje", "HACCP skupina: zaposleni prevzeti z vlogo");
  // 2. korak: podrobnosti živila
  await pg.click(".stepper button >> nth=1"); await pg.waitForSelector("[data-zp]");
  ok(/alergeni nepotrjeni/.test(await pg.textContent("[data-zp]")), "živilo: oznaka »alergeni nepotrjeni«");
  await pg.click("[data-zp]"); await pg.fill("dialog[open] [data-k=sestava]", "zelenjava, voda"); await pg.check("dialog[open] [data-k=alergeni_potrjeni]"); await pg.click("dialog[open] #dlg-f .btn"); await pg.waitForSelector("[data-zp]");
  ok(!/nepotrjeni/.test(await pg.textContent("[data-zp]")), "živilo: alergeni potrjeni v podrobnostih");
  // 3. korak: veja, preimenovanje ohrani potrditev nevarnosti
  await pg.click(".stepper button >> nth=2"); await pg.waitForSelector(".krow [data-k=veja]");
  await pg.fill(".krow >> nth=1 >> [data-k=veja]", "kuhinja");
  const ime = pg.locator(".krow >> nth=1 >> input[data-k=naziv]"); await ime.focus(); await ime.fill("Kuhanje juhe"); await ime.press("Tab");
  // 5. korak: polja ukrepa
  await pg.click(".stepper button >> nth=4"); await pg.waitForSelector("[data-o]"); await pg.click("[data-o] >> nth=0"); await pg.waitForSelector("dialog[open] [data-k=vrsta]");
  await pg.selectOption("dialog[open] [data-k=vrsta]", "CCP");
  for (const [k, v] of [["naziv", "Kuhanje juhe"], ["mejna", "≥ 75 °C v jedru"], ["temperatura", "75 °C"], ["cas", "30 s"], ["validacija", "Meritve 10 serij, 2026"]]) await pg.fill("dialog[open] [data-k=" + k + "]", v);
  await pg.selectOption("dialog[open] [data-k=mejna_vir_vrsta]", "smernica");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForTimeout(300);
  // 6. korak: interni rok
  await pg.click(".stepper button >> nth=5"); await pg.waitForSelector("[data-k=interni_rok]"); await pg.fill("[data-k=interni_rok]", "2027-06-30"); await pg.fill("[data-k=interni_rok_utemeljitev]", "letni pregled");
  await pg.click("#wsave"); await pg.waitForTimeout(800);
  const W = await pg.evaluate(async x => (await D.list("nacrti", { stranka_id: x.s })).find(n => n.id === x.n).vsebina, ids);
  const c = W.kontrole.h1 || {};
  ok(W.zbiranje.registracija === "Reg. št. 123, UVHVVR" && W.zbiranje.nacin_prodaje.includes("s_seboj") && /Vodstvo/.test(W.zbiranje.kultura_zaveza) && W.zbiranje.clani[0].ime === "Ana Kos", "shranjeno: registracija, način prodaje, kultura, skupina");
  ok(W.zivila[0].alergeni_potrjeni === true && W.zivila[0].sestava === "zelenjava, voda", "shranjeno: podrobnosti živila");
  ok(W.koraki[1].veja === "kuhinja" && W.koraki[1].naziv === "Kuhanje juhe" && W.nevarnosti[0].potrjeno === true && !W.nevarnosti[0].preveri_korak, "preimenovanje koraka ne ponastavi potrditve nevarnosti; veja shranjena");
  ok(c.naziv === "Kuhanje juhe" && c.mejna_vir_vrsta === "smernica" && c.temperatura === "75 °C" && c.cas === "30 s" && /Meritve/.test(c.validacija), "shranjeno: enolični naziv, vir meje, temperatura, čas, validacija " + JSON.stringify(c));
  ok(W.pregled.interni_rok === "2027-06-30" && W.pregled.interni_rok_utemeljitev === "letni pregled", "shranjeno: interni rok z utemeljitvijo");
  // čiščenje dvakrat dnevno: po enem izvajanju je opravilo še na vrsti
  const cis = await pg.evaluate(async sid => { const n = await D.add("ciscenje_nacrt", { stranka_id: sid, opravilo: "Pult", pogostost_dni: 1, krat_na_dan: "2", koncentracija: "2 %", kontaktni_cas: "5 min", zacetek: today() });
    const e1 = [{ vrsta: "ciscenje", nacrt_id: n.id, izvedeno: true, cas: new Date().toISOString() }]; const a = ciscenjeStanje([n], e1)[0].danes; const b = ciscenjeStanje([n], e1.concat(e1))[0].danes; return { a, b }; }, ids.s);
  ok(cis.a === true && cis.b === false, "čiščenje dvakrat dnevno: po prvem izvajanju še na vrsti, po drugem ne");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
