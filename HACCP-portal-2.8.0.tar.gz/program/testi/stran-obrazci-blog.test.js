// Blog: svetovalec piše osnutek in ga pošlje v pregled (ne more objaviti), administrator objavi; javne strani /blog/ (HTML iz strežnika,
// varno oblikovanje), slika, zadnji članki na vstopni strani, pošiljanje članka potrjenim naročnikom (s povezavo za odjavo), umik.
const http = require("http");
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const POSTA = [];
  const mock = http.createServer((q, r) => { let b = ""; q.on("data", c => b += c); q.on("end", () => { POSTA.push(JSON.parse(b || "{}")); r.writeHead(200, { "Content-Type": "application/json" }); r.end('{"id":"1"}'); }); }).listen(4955, "127.0.0.1");
  const req = async (m, p, b, ck) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, ck ? { Cookie: ck } : {}), body: b ? JSON.stringify(b) : undefined }); const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch {} return { s: r.status, j, t, ct: r.headers.get("content-type"), ck: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  await req("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "Luka Zorman", geslo: "dolgogeslo123" }); const A = (await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" })).ck;
  await req("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_x", od: "HiGiFood <obvestila@higifood.si>" }, A);
  await req("POST", "/api/uporabniki", { email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", ime: "Mojca Svet", stranke: [] }, A);
  await req("POST", "/api/uporabniki", { email: "o@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", ime: "Ana", stranka_id: (await req("POST", "/api/d/stranke", { naziv: "S d.o.o." }, A)).j.id }, A);
  const SV = (await req("POST", "/api/auth/prijava", { email: "sv@t.si", geslo: "dolgogeslo123" })).ck, O = (await req("POST", "/api/auth/prijava", { email: "o@t.si", geslo: "dolgogeslo123" })).ck;
  ok((await req("GET", "/api/blog-urednik", null, O)).s === 403, "odgovorna oseba nima dostopa do urednika bloga");
  // svetovalec: osnutek, ne more objaviti, pošlje v pregled
  let r = await req("POST", "/api/blog-urednik", { naslov: "Čiščenje hladilnika: 5 korakov", povzetek: "Kako pravilno očistiti hladilnik.", besedilo: "## Zakaj\n\nZaradi **listerije**. Več na [NIJZ](https://www.nijz.si).\n\n- izpraznite\n- operite\n\n<img src=x onerror=alert(1)>" }, SV);
  const c = r.j; ok(r.s === 200 && c.stanje === "osnutek" && c.slug === "ciscenje-hladilnika-5-korakov", "svetovalec ustvari osnutek (povezava brez šumnikov)");
  ok((await req("PUT", "/api/blog-urednik/" + c.id, { stanje: "objavljen" }, SV)).s === 403, "svetovalec ne more objaviti");
  ok((await req("PUT", "/api/blog-urednik/" + c.id, { stanje: "za pregled" }, SV)).s === 200, "svetovalec pošlje v pregled");
  const drugi = (await req("POST", "/api/blog-urednik", { naslov: "Osnutek administratorja" }, A)).j;
  ok(!(await req("GET", "/api/blog-urednik", null, SV)).j.clanki.some(x => x.id === drugi.id), "svetovalec ne vidi tujih osnutkov");
  ok((await req("GET", "/stran/blog/" + c.slug)).s === 404 && !(await req("GET", "/api/javno/blog")).j.length, "neobjavljen članek ni javen");
  // administrator: obvestilo na nadzorni plošči, urednik s predogledom, objava
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  await pg.waitForSelector("#blog_pregled"); ok(/1 članek čaka na pregled/.test(await pg.textContent("#blog_pregled")), "nadzorna plošča: članek čaka na pregled");
  await pg.goto(B + "/#/blog/" + c.id); await pg.waitForSelector("#bl_pred h2");
  ok(/Zakaj/.test(await pg.textContent("#bl_pred h2")) && await pg.$("#bl_pred strong") && !(await pg.$("#bl_pred img")), "urednik: predogled z oblikovanjem, brez vstavljenega HTML");
  // slika (JPEG iz platna) in objava z gumbom
  await pg.evaluate(async () => { const cv = document.createElement("canvas"); cv.width = 800; cv.height = 450; const g = cv.getContext("2d"); g.fillStyle = "#0f5f63"; g.fillRect(0, 0, 800, 450); const blob = await new Promise(r => cv.toBlob(r, "image/png")); const dt = new DataTransfer(); dt.items.add(new File([blob], "s.png", { type: "image/png" })); const inp = document.getElementById("bl_slika"); inp.files = dt.files; inp.dispatchEvent(new Event("change")); });
  await pg.waitForSelector(".toast.show:has-text('Slika pripravljena')");
  await pg.click("[data-st=objavljen]"); await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('objavljen')");
  const pub = (await req("GET", "/api/javno/blog")).j; ok(pub.length === 1 && pub[0].slika && pub[0].avtor === "Mojca Svet", "objavljen članek s sliko na javnem seznamu");
  const sl = await req("GET", "/api/javno/blog/slika/" + c.id); ok(sl.s === 200 && /image\/jpeg/.test(sl.ct), "slika članka (JPEG)");
  ok((await req("PUT", "/api/blog-urednik/" + c.id, { naslov: "Spremenjeno" }, SV)).s === 403, "svetovalec ne ureja objavljenega članka");
  // javne strani (HTML iz strežnika)
  const li = await req("GET", "/stran/blog/"), cl = await req("GET", "/stran/blog/" + c.slug);
  ok(li.s === 200 && /text\/html/.test(li.ct) && li.t.includes('href="ciscenje-hladilnika-5-korakov"'), "/stran/blog/: seznam člankov");
  ok(cl.s === 200 && /<h1>Čiščenje hladilnika: 5 korakov<\/h1>/.test(cl.t) && /<meta name="description" content="Kako pravilno očistiti hladilnik.">/.test(cl.t) && /<h2>Zakaj<\/h2>/.test(cl.t) && /<a href="https:\/\/www\.nijz\.si" rel="noopener">NIJZ<\/a>/.test(cl.t) && !/<img src=x/.test(cl.t) && /&lt;img src=x/.test(cl.t), "članek: naslov, opis za iskalnike, oblikovanje, ubežan HTML");
  ok(/frame-ancestors 'none'/.test((await fetch(B + "/stran/blog/" + c.slug)).headers.get("content-security-policy") || ""), "članek ima varnostne glave");
  await pg.goto(B + "/stran/blog/" + c.slug); await pg.waitForSelector(".bl-slika"); ok(await pg.evaluate(() => document.querySelector(".bl-slika").naturalWidth === 800) && !!(await pg.$("#piskotki-pasica")), "stran članka: slika naložena, pasica za piškotke");
  await pg.goto(B + "/stran/"); await pg.waitForSelector("#blog-zadnji:not([hidden]) .bl-k"); ok(/Čiščenje hladilnika/.test(await pg.textContent("#blog-seznam")), "vstopna stran: zadnji članki");
  // pošiljanje naročnikom: potrjen naročnik prek obrazca in povezave
  await req("POST", "/api/javno/novice/prijava", { email: "bralec@kavarna.si", soglasje: true }); const pt = /potrdi=([\w-]+)/.exec(POSTA.find(m => JSON.stringify(m.to).includes("bralec")).text)[1];
  ok(/http:\/\/higifood\.test\/novice\.html\?potrdi=/.test(POSTA.find(m => JSON.stringify(m.to).includes("bralec")).text), "povezave v e-pošti na naslov strani (HACCP_SPLETNA_URL)");
  await req("POST", "/api/javno/novice/potrdi", { t: pt });
  ok((await req("POST", "/api/blog-urednik/" + c.id + "/novice", null, SV)).s === 403, "svetovalec ne pošilja naročnikom");
  POSTA.length = 0; r = await req("POST", "/api/blog-urednik/" + c.id + "/novice", null, A);
  ok(r.s === 200 && r.j.poslano === 1 && POSTA.length === 1 && /Preberite celoten članek: http:\/\/higifood\.test\/blog\/ciscenje-hladilnika-5-korakov/.test(POSTA[0].text) && /Odjava: http:\/\/higifood\.test\/novice\.html\?odjava=/.test(POSTA[0].text) && POSTA[0].subject === "Čiščenje hladilnika: 5 korakov", "članek poslan naročniku s povezavo za odjavo");
  // slike v besedilu: gumb »Vstavi sliko« v uredniku, predogled, javna stran, brisanje neuporabljenih
  ok((await req("POST", "/api/blog-urednik/" + c.id + "/slike", { slika: "AAAA" }, SV)).s === 403, "svetovalec ne dodaja slik v objavljen članek");
  ok((await req("POST", "/api/blog-urednik/" + c.id + "/slike", { slika: Buffer.from("<svg>").toString("base64") }, A)).s === 400, "samo JPEG");
  await pg.goto(B + "/#/nadzorna"); await pg.goto(B + "/#/blog/" + c.id); await pg.waitForSelector("#bl_vstavi");
  await pg.evaluate(async () => { const ta = document.getElementById("bl_besedilo"); ta.setSelectionRange(ta.value.indexOf("## Zakaj"), ta.value.indexOf("## Zakaj")); const cv = document.createElement("canvas"); cv.width = 640; cv.height = 360; cv.getContext("2d").fillRect(0, 0, 640, 360); const blob = await new Promise(r => cv.toBlob(r, "image/png")); const dt = new DataTransfer(); dt.items.add(new File([blob], "a.png", { type: "image/png" })); const inp = document.getElementById("bl_vsl"); inp.files = dt.files; inp.dispatchEvent(new Event("change")); });
  await pg.waitForSelector(".toast.show:has-text('Slika vstavljena')"); await pg.keyboard.type("Pravilno hlajen hladilnik <b>");
  const bes = await pg.inputValue("#bl_besedilo"); ok(/!\[Pravilno hlajen hladilnik <b>\]\(slika:[\w-]+\)\n\n## Zakaj/.test(bes), "slika vstavljena na mesto kazalca, opis vpisan");
  await pg.waitForFunction(() => { const i = document.querySelector("#bl_pred figure img"); return i && i.naturalWidth === 640; }); ok(/\/api\/blog-urednik\//.test(await pg.getAttribute("#bl_pred figure img", "src")), "predogled prikaže sliko iz urednika");
  await pg.click("#bl_shrani"); await pg.waitForSelector(".toast.show:has-text('Shranjeno')");
  let cl2 = await req("GET", "/stran/blog/" + c.slug); const sm = /<img src="(\/api\/javno\/blog\/slika\/[\w-]+\/[\w-]+)" alt="Pravilno hlajen hladilnik &lt;b&gt;"/.exec(cl2.t);
  ok(!!sm && /<figcaption>Pravilno hlajen hladilnik &lt;b&gt;<\/figcaption>/.test(cl2.t), "javna stran: slika z opisom (ubežan)");
  ok(sm && (await req("GET", sm[1])).s === 200, "javna slika v besedilu dosegljiva");
  ok((await req("GET", "/api/javno/blog/slika/" + c.id + "/neobstaja")).s === 404, "tuja ali neobstoječa slika ni dosegljiva");
  const nova = (await req("POST", "/api/blog-urednik/" + c.id + "/slike", { slika: (await req("GET", sm[1].replace("/api/javno/blog/slika/", "/api/blog-urednik/").replace(/\/([\w-]+)$/, "/slike/$1"), null, A)).t ? Buffer.from(await (await fetch(B + sm[1])).arrayBuffer()).toString("base64") : "" }, A)).j;
  ok(nova && nova.id, "druga slika naložena");
  await req("PUT", "/api/blog-urednik/" + c.id, { besedilo: bes.replace(/!\[[^\]]*\]\(slika:[\w-]+\)/, "") }, A);
  ok((await req("GET", sm[1])).s === 404 && (await req("GET", "/api/blog-urednik/" + c.id + "/slike/" + nova.id, null, A)).s === 404, "neuporabljene slike se ob shranjevanju izbrišejo");
  // orodna vrstica: krepko, ležeče, podčrtano (ovij in odstrani), bližnjice, seznam, citat, povezava
  const t3 = (await req("POST", "/api/blog-urednik", { naslov: "Orodja", besedilo: "prva vrstica\ndruga vrstica\n\nbeseda" }, A)).j;
  await pg.goto(B + "/#/nadzorna"); await pg.goto(B + "/#/blog/" + t3.id); await pg.waitForSelector(".bl-orodja [data-o=u]");
  const izberi = (a2, b2) => pg.evaluate(([a2, b2]) => { const ta = document.getElementById("bl_besedilo"); const i = ta.value.indexOf(a2); ta.focus(); ta.setSelectionRange(i, i + (b2 || a2).length); }, [a2, b2]);
  const val = () => pg.inputValue("#bl_besedilo");
  await izberi("beseda"); await pg.click("[data-o=u]"); ok((await val()).endsWith("__beseda__"), "podčrtano: izbor ovit z __");
  await pg.click("[data-o=u]"); ok((await val()).endsWith("\n\nbeseda"), "ponoven klik odstrani podčrtano");
  await izberi("beseda"); await pg.keyboard.press("Control+b"); ok((await val()).endsWith("**beseda**"), "Ctrl+B: krepko");
  await izberi("beseda"); await pg.keyboard.press("Control+i"); ok((await val()).endsWith("***beseda***"), "Ctrl+I: ležeče (skupaj s krepkim)");
  await izberi("prva vrstica", "prva vrstica\ndruga vrstica"); await pg.click("[data-o=ol]"); ok((await val()).startsWith("1. prva vrstica\n2. druga vrstica"), "oštevilčen seznam iz izbranih vrstic");
  await izberi("prva vrstica", "prva vrstica\n2. druga vrstica"); await pg.click("[data-o=q]"); ok((await val()).startsWith("> prva vrstica\n> druga vrstica"), "citat (zamenja oznako seznama)");
  await pg.evaluate(() => { const ta = document.getElementById("bl_besedilo"); ta.value += "\n\nNIJZ"; ta.setSelectionRange(ta.value.length - 4, ta.value.length); });
  await pg.click("[data-o=a]"); await pg.waitForSelector("#lk_u"); ok(await pg.inputValue("#lk_t") === "NIJZ", "povezava: izbrano besedilo predizpolnjeno");
  await pg.fill("#lk_u", "javascript:alert(1)"); await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('https://')"); ok(await pg.$("#lk_u"), "povezava: javascript: zavrnjen");
  await pg.fill("#lk_u", "https://www.nijz.si"); await pg.click("dialog[open] #dlg-f .btn:last-child"); ok((await val()).endsWith("[NIJZ](https://www.nijz.si)"), "povezava vstavljena");
  await pg.waitForFunction(() => document.querySelector("#bl_pred a[href=\"https://www.nijz.si\"]") && document.querySelector("#bl_pred blockquote") && document.querySelector("#bl_pred em strong, #bl_pred strong em"));
  ok(true, "predogled: citat, krepko in ležeče, povezava");
  await req("DELETE", "/api/blog-urednik/" + t3.id, null, A);
  // umik s strani
  ok((await req("PUT", "/api/blog-urednik/" + c.id, { stanje: "osnutek" }, A)).s === 200 && (await req("GET", "/stran/blog/" + c.slug)).s === 404 && (await req("GET", "/api/javno/blog/slika/" + c.id)).s === 404, "umaknjen članek ni več javen (tudi slika)");
  ok((await req("DELETE", "/api/blog-urednik/" + drugi.id, null, SV)).s === 404 && (await req("DELETE", "/api/blog-urednik/" + drugi.id, null, A)).s === 200, "brisanje: svetovalec tujega ne, administrator da");
  ok(!errs.length, "brez napak JavaScript " + errs.join("; "));
  await br.close(); mock.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
