// Baza naprav (temperaturni režimi in protokoli čiščenja) in prenos naprav obrata v opremo, urnik meritev in načrt čiščenja – brez podvajanja.
const B = process.env.BASE; const { chromium } = require("./pw.js"), NAP = require("../baza/naprave.json");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  // baza: vsaka naprava ima protokol čiščenja; hladilne naprave imajo meje in vir
  ok(NAP.length >= 30 && NAP.every(n => n.id && n.naziv && Array.isArray(n.ciscenje) && n.ciscenje.length && n.ciscenje.every(c => c.opravilo && +c.pogostost_dni > 0 && c.metoda)), "baza naprav: " + NAP.length + " naprav, vsaka s protokolom čiščenja");
  const h = NAP.find(n => n.id === "hladilnik"), z = NAP.find(n => n.id === "zamrzovalnik"), f = NAP.find(n => n.id === "friteza");
  ok(h.meja_min === 0 && h.meja_max === 4 && /853\/2004/.test(h.vir) && z.meja_max === -18 && /37\/2005/.test(z.vir) && f.meja_max === 175 && /2017\/2158/.test(f.vir), "temperaturni režimi z virom (hladilnik 0–4 °C, zamrzovalnik ≤ -18 °C, olje ≤ 175 °C)");
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Naprave d.o.o." });
    await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna", naprave: [{ ime: "Hladilnik", opis: "2 kosa" }, { ime: "Zamrzovalnik", opis: "" }, { ime: "Friteza", opis: "8 l" }, { ime: "Barvne deske za rezanje", opis: "" }, { ime: "Lonec za palačinke", opis: "" }] });
    return s.id; });
  await pg.goto(B + "/#/stranka/" + sid + "/obrati"); await pg.waitForSelector("#ob_nv"); await pg.click("#ob_nv"); await pg.waitForSelector("[data-nv]");
  const vrst = await pg.$$eval("#nv_b tr", r => r.map(x => x.textContent.replace(/\s+/g, " ").trim()));
  ok(vrst.some(t => /Oprema \(meje\).*Hladilnik 1.*0 do 4 °C/.test(t)) && vrst.some(t => /Hladilnik 2/.test(t)) && vrst.some(t => /Urnik meritev.*Zamrzovalnik.*24 h/.test(t)) && vrst.some(t => /ni v bazi.*Lonec za palačinke/.test(t)), "predlog: dva hladilnika (iz »2 kosa«), urnik, naprava brez baze označena");
  ok(!vrst.some(t => /Oprema \(meje\).*Barvne deske/.test(t)) && vrst.some(t => /Načrt čiščenja.*Barvne deske/.test(t)), "pribor brez meril ne gre v opremo, ima pa protokol čiščenja");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  const r = await pg.evaluate(async sid => ({ o: await D.list("oprema", { stranka_id: sid }), c: await D.list("ciscenje_nacrt", { stranka_id: sid }), u: await D.list("urnik", { stranka_id: sid }) }), sid);
  const h1 = r.o.find(x => x.naziv === "Hladilnik 1"), zz = r.o.find(x => x.naziv === "Zamrzovalnik"), fr = r.c.find(x => x.podrocje === "Friteza" && /Menjava olja/.test(x.opravilo));
  ok(h1 && h1.meja_min === 0 && h1.meja_max === 4 && h1.tip === "hladilnik" && /predlog iz baze znanja/.test(h1.opomba) && zz.meja_max === -18, "oprema ustvarjena z mejami iz baze");
  ok(r.u.length === 3 && r.u.every(u => u.frekvenca_ur === 24 && u.obrat_id) && r.u.some(u => u.naprava === "Hladilnik 2"), "urnik meritev za vsak hladilnik in zamrzovalnik (" + r.u.length + ")");
  ok(fr && fr.pogostost_dni === 7 && /proizvajalca/.test(fr.koncentracija) && r.c.length === 7, "načrt čiščenja iz protokolov (" + r.c.length + " opravil)");
  // ponovni zagon: nič novega (brez podvajanja)
  await pg.click("#ob_nv"); await pg.waitForSelector("#nv_b table");
  ok(await pg.locator("[data-nv]:checked").count() === 0 && /Novih postavk: 0/.test(await pg.textContent("#nv_b")), "ponovni zagon: vse že obstaja, nič se ne podvoji");
  await pg.evaluate(() => document.querySelector("dialog[open]").close());
  // obrazec opreme: meje iz baze po vrsti
  await pg.goto(B + "/#/stranka/" + sid + "/oprema"); await pg.waitForSelector("#ladd"); await pg.click("#ladd"); await pg.waitForSelector("#f_tip"); await pg.waitForTimeout(300);
  await pg.fill("#f_naziv", "Skrinja"); await pg.selectOption("#f_tip", "zamrzovalnik"); await pg.waitForTimeout(200);
  ok(await pg.inputValue("#f_meja_max") === "-18", "obrazec opreme: meja iz baze naprav po vrsti (zamrzovalnik ≤ -18 °C)");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
