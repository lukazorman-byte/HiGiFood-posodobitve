// Popravki S3b (čarovnik, PDF, QR): priloga predpisov po oznakah dejavnosti, prilagojena besedila vseh poglavij,
// potrditev iz zapisa načrta, prelom dolgih naslovov/kazala/naslovnice, odgovorna oseba v generatorju, nalepke QR.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pdfText = f => { const r = cp.spawnSync("pdftotext", ["-layout", f, "-"], { encoding: "utf8" }); return r.error ? null : r.stdout; };
// največji desni rob besed na strani (pdftotext -bbox) – besedilo ne sme čez rob lista
const pdfMaxX = f => { const r = cp.spawnSync("pdftotext", ["-bbox", f, "-"], { encoding: "utf8" }); if (r.error) return null; let m = 0, w = 0; for (const x of r.stdout.matchAll(/<page width="([\d.]+)"|xMax="([\d.]+)"/g)) { if (x[1]) w = +x[1]; else m = Math.max(m, +x[2] - w); } return m; };
(async () => {
  const br = await chromium.launch(), errs = []; fs.mkdirSync(OUT, { recursive: true });
  const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const dolgo = "Zelo dolgo poimenovano poglavje o posebnostih predelave domačih likerjev in žganih pijač na turistični kmetiji ob reki";
  const b64 = await pg.evaluate(async dolgo => {
    const s = await D.add("stranke", { naziv: "Kmetija Likerček z zelo dolgim uradnim imenom, ki ne gre v eno vrstico, d.o.o.", odgovorna_oseba: "Eva Bečan" }); const o = await D.add("obrati", { stranka_id: s.id, naziv: "Destilarna" });
    const W = { branza: "liker", zivila: [{ id: "z1", naziv: "Orehov liker" }], koraki: [{ id: "k1", naziv: "Prevzem" }], nevarnosti: [{ id: "h1", korak_id: "k1", tip: "K", nevarnost: "Metanol", verjetnost: "3", teza: "5", potrjeno: true }], kontrole: { h1: { hid: "h1", vrsta: "CCP" } },
      besedila_pogl: { podjetje: "Lastno uvodno besedilo o podjetju." }, poglavja: [["podjetje", "Podatki o podjetju"], ["dejavnost", dolgo], ["priloga", "Priloga"]].map(([id, naslov]) => ({ id, naslov, on: true })) };
    const rec = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "Liker", vsebina: W }); rec.status = "potrjeno"; rec.potrdil = "dr. Ana Strokovna"; rec.datum_potrditve = "2026-10-01";
    const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), s, [o], [], await baza(), []);
    const u = new Uint8Array(await blob.arrayBuffer()); let r = ""; for (let i = 0; i < u.length; i += 8192) r += String.fromCharCode(...u.subarray(i, i + 8192)); return btoa(r);
  }, dolgo);
  const f = path.join(OUT, "nacrt.pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = pdfText(f);
  if (t === null) console.log("(pdftotext ni na voljo – preverjanje besedila PDF preskočeno)");
  else {
    const flat = t.replace(/\s+/g, " ");
    ok(/2019\/787/.test(flat), "priloga: Uredba (EU) 2019/787 za likerje (oznaka dejavnosti »alcohol«)");
    ok(/Lastno uvodno besedilo o podjetju/.test(flat), "prilagojeno besedilo poglavja »podjetje« v PDF");
    ok(/dr\. Ana Strokovna/.test(flat) && /1\. 10\. 2026|01\.10\.2026|1\.10\.2026/.test(flat), "potrditev iz zapisa načrta (potrdil, datum)");
    ok(/ob reki/.test(flat) && /ne gre v eno/.test(flat), "dolg naslov poglavja in ime stranke sta v celoti v dokumentu (prelom)");
    const mx = pdfMaxX(f); ok(mx !== null && mx < 5, "nobeno besedilo ne gre čez desni rob strani (" + (mx && mx.toFixed(1)) + ")");
  }
  const rz = await pg.evaluate(async () => { const r = (await baza()).rezimi; return [rezimOpis(r.find(x => x.id === "kuh")), rezimOpis({ do: 4 }), rezimOpis({ od: 0, do: 4 })]; });
  ok(rz[0] === "≥ 74 °C" && rz[1] === "≤ 4 °C" && rz[2] === "0 do 4 °C", "režimi: enostranske meje z ≥ / ≤ (" + rz.join(", ") + ")");
  // generator: odgovorna oseba izbrane stranke
  await pg.goto(B + "/generator/"); await pg.waitForSelector("#stranka option:nth-child(2)", { state: "attached" });
  const sv = await pg.$eval("#stranka", s => [...s.options].find(o => /Likerček/.test(o.textContent)).value); await pg.selectOption("#stranka", sv);
  ok(await pg.evaluate(() => (window.GEN_ST || []).some(s => s.odgovorna_oseba === "Eva Bečan")), "generator pozna odgovorno osebo stranke");
  // QR nalepke: dolgo ime stranke ostane v nalepki, neveljaven začetek → opozorilo
  await pg.goto(B + "/"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Gostilna s prav zelo dolgim imenom Pri veselem lovcu in ribiču d.o.o." }); await D.add("oprema", { stranka_id: s.id, naziv: "Hladilnik", tip: "hladilnik" }); return s.id; });
  await pg.goto(B + "/#/qr/" + sid); await pg.waitForSelector("#qn_pdf");
  await pg.selectOption("#qn_f", "majhne"); await pg.fill("#qn_z", "41"); await pg.click("#qn_pdf"); await pg.waitForSelector(".toast.show:has-text('med 1 in 40')"); ok(true, "začetek 41 pri 40 nalepkah: opozorilo");
  await pg.fill("#qn_z", "4"); const [d] = await Promise.all([pg.waitForEvent("download"), pg.click("#qn_pdf")]); const fq = path.join(OUT, "qr.pdf"); await d.saveAs(fq);
  const r = cp.spawnSync("pdftotext", ["-bbox", fq, "-"], { encoding: "utf8" });
  if (!r.error) { // 4. nalepka v 1. vrsti: desni rob = širina lista
    const xs = [...r.stdout.matchAll(/xMax="([\d.]+)"[^>]*>([^<]*)</g)]; const mx = Math.max(...xs.map(x => +x[1]));
    ok(mx <= 595.3 && xs.some(x => /…/.test(x[2])), "ime stranke skrajšano s »…« in znotraj nalepke (" + mx.toFixed(1) + ")");
  }
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
