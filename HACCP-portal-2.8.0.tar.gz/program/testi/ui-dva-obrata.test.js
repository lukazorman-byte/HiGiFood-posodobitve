// Stranka z dvema obratoma: enako imenovani hladilniki z različnimi mejami, urnik po obratih, hiter vnos, »Vnesi« iz seznama manjkajočih,
// čiščenje po obratih, zaposleni enega obrata, poročilo PDF.
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Dva obrata d.o.o." });
    const a = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja Center" }), b = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja Bežigrad" });
    await D.add("oprema", { stranka_id: s.id, obrat_id: a.id, naziv: "Hladilnik 1", tip: "hladilnik", meja_min: 0, meja_max: 4 });
    await D.add("oprema", { stranka_id: s.id, obrat_id: b.id, naziv: "Hladilnik 1", tip: "hladilnik", meja_min: 0, meja_max: 5 });
    for (const o of [a, b]) { await D.add("urnik", { stranka_id: s.id, obrat_id: o.id, vrsta: "temperatura", naprava: "Hladilnik 1", frekvenca_ur: 24 }); await D.add("ciscenje_nacrt", { stranka_id: s.id, obrat_id: o.id, podrocje: "Tla", opravilo: "Pranje tal", pogostost_dni: 1, zacetek: addDays(today(), -1) }); }
    await api("POST", "/api/uporabniki", { ime: "Zala", email: "z@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id, stranke: [] });
    return { s: s.id, a: a.id, b: b.id };
  });
  await pg.evaluate(id => sessionStorage.setItem("danes_sid", id), ids.s);
  await pg.goto(B + "/#/danes"); await pg.waitForSelector(".hitro-t");
  const sel = await pg.$$eval("#dn_s option", o => o.map(x => x.value)).catch(() => []); if (sel.includes(ids.s)) { await pg.selectOption("#dn_s", ids.s); await pg.waitForTimeout(500); }
  const oznake = await pg.$$eval(".ht-vr label", l => l.map(x => x.textContent));
  ok(oznake.length === 2 && oznake.some(t => /Hladilnik 1.*Kuhinja Center/.test(t)) && oznake.some(t => /Hladilnik 1.*Kuhinja Bežigrad/.test(t)), "hiter vnos: hladilnika z istim imenom ločena po obratu " + JSON.stringify(oznake));
  const man = await pg.$$eval("#dn_m tr", r => r.map(x => x.textContent));
  ok(man.length === 2 && man.some(t => /\(Kuhinja Center\)/.test(t)) && man.some(t => /\(Kuhinja Bežigrad\)/.test(t)), "manjkajoči vnosi z imenom obrata " + JSON.stringify(man));
  const cis = await pg.textContent("#dn_c"); ok(/Tla \(Kuhinja Center\)/.test(cis) && /Tla \(Kuhinja Bežigrad\)/.test(cis), "čiščenje: opravila ločena po obratu");
  // hiter vnos za Center (meja 4): 3 °C
  const iC = oznake.findIndex(t => /Center/.test(t)); await pg.fill("#ht_" + iC, "3"); await pg.click(`[data-ht="${iC}"]`); await pg.waitForSelector(`#htr_${iC} .badge`);
  const man2 = await pg.$$eval("#dn_m tr", r => r.map(x => x.textContent)).catch(() => []);
  ok(man2.length === 1 && /Bežigrad/.test(man2[0]), "po vnosu v Centru ostane manjkajoč samo Bežigrad " + JSON.stringify(man2));
  // »Vnesi« za Bežigrad: obrat in naprava izbrana, meje 0–5; 4,8 °C je skladno (meja Centra bi bila odstopanje)
  await pg.click("#dn_m [data-m]"); await pg.waitForSelector("#f_oprema");
  const f = await pg.evaluate(() => ({ ob: $("#f_obrat_id").value, op: $("#f_oprema").value, min: $("#f_min").value, max: $("#f_max").value, n: [...$("#f_oprema").options].filter(o => o.value === "Hladilnik 1").length }));
  ok(f.ob === ids.b && f.op === "Hladilnik 1" && f.min === "0" && f.max === "5" && f.n === 1, "»Vnesi«: obrat Bežigrad, naprava in njene meje (0–5), naprava enkrat na seznamu " + JSON.stringify(f));
  await pg.fill("#f_vrednost", "4,8"); await pg.waitForTimeout(200); ok(/skladno z mejami/.test(await pg.textContent("#ocena")), "4,8 °C v Bežigradu je skladno");
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  // zamenjava obrata v obrazcu: meje se prenesejo iz naprave izbranega obrata
  const zam = await pg.evaluate(async c => { evForm(null, await evCtx({ stranka_id: c.s, obrati: mapOf(await D.list("obrati", { stranka_id: c.s })) }), () => {}, "temperatura"); await new Promise(r => setTimeout(r, 100)); const ob = $("#f_obrat_id"), op = $("#f_oprema"); op.value = "Hladilnik 1"; op.dispatchEvent(new Event("change")); const r1 = [ob.value, $("#f_max").value]; ob.value = c.b; ob.dispatchEvent(new Event("change")); const r2 = [ob.value, $("#f_max").value]; document.querySelector("dialog[open]").close(); return { r1, r2 }; }, ids);
  ok(zam.r1[0] !== "" && zam.r2[0] === ids.b && zam.r2[1] === "5", "izbira naprave določi obrat; menjava obrata prenese meje prave naprave " + JSON.stringify(zam));
  const ev = await pg.evaluate(id => D.list("evidence", { stranka_id: id }), ids.s);
  ok(ev.length === 2 && ev.find(e => e.obrat_id === ids.a).vrednost === 3 && ev.find(e => e.obrat_id === ids.b).vrednost === 4.8 && ev.every(e => e.skladno === true), "zapisa shranjena z obratom in skladnostjo");
  await pg.reload(); await pg.waitForSelector("#dn"); await pg.waitForTimeout(800); ok(/Vsi redni vnosi so opravljeni/.test(await pg.textContent("#dn")), "po vnosih v obeh obratih ni manjkajočih");
  // zaposleni stranke
  const z = await (await br.newContext()).newPage(); z.on("pageerror", e => errs.push(String(e.stack || e)));
  await z.goto(B + "/"); await z.fill("#le", "z@t.si"); await z.fill("#lp", "dolgogeslo123"); await z.click("#lf button"); await z.waitForSelector("#shell:not([hidden])");
  await z.goto(B + "/#/danes"); await z.waitForSelector(".hitro-t"); ok((await z.$$(".ht-vr")).length === 2, "zaposleni vidi hiter vnos za oba obrata");
  // poročilo evidenc v PDF
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.waitForTimeout(1200);
  const pdf = await pg.evaluate(async () => { const b = pdfBuild({ naslov: "Evidence", stranka: "Dva obrata d.o.o.", plain: true }, d => { d.p("Kuhinja Center, Kuhinja Bežigrad"); }); return b.size; });
  ok(pdf > 500, "PDF se izdela (" + pdf + " B)");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
