// Sklop C – en vir podatkov in validacija: številke v opisu/korektivnih ukrepih vs meja in pogostost, evidenca »Drugo« z nazivom,
// vir meje (predpis iz baze s členom, smernica ločeno), nova zakonodaja in filter priloge po dejavnosti, alergeni obrata iz živil
// in opozorila (sulfiti, zelena), opomba ločeno od alergenov + potrditev (ime, datum), nizka tveganja v strnjeni tabeli, razdeli navodilo.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pdfTxt = f => (cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }).stdout || "").replace(/\s+/g, " ");
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kavarna Sonce", dejavnost: "Gostinstvo (restavracija, gostilna)" }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce" });
    const W = { branza: "jedi", koraki: [{ id: "k1", naziv: "Toplotna obdelava" }, { id: "k2", naziv: "Hlajenje" }, { id: "k3", naziv: "Skladiščenje" }],
      nevarnosti: [{ id: "h1", korak_id: "k1", tip: "B", nevarnost: "Preživetje patogenov", verjetnost: 3, teza: 5, potrjeno: true }, { id: "h2", korak_id: "k2", tip: "B", nevarnost: "Rast bakterij", verjetnost: 3, teza: 4, potrjeno: true }, { id: "h3", korak_id: "k3", tip: "F", nevarnost: "Tujki iz embalaže", verjetnost: 1, teza: 2, potrjeno: true }],
      kontrole: { h1: { hid: "h1", vrsta: "CCP", kaj: "temperatura v jedru", mejna: "≥ 72 °C", mejna_vir: "smernica", ukrep: "Temperaturo v jedru merimo dvakrat dnevno.", pogostost: "1× dnevno", korektivni: "Ponovno segreti na 75 °C.", evidenca: "temperatura", verifikacija: "tedensko" } },
      zivila: [{ naziv: "Rižota z vinom", sestava: "riž, vino, parmezan", alergeni: "Mleko, priprava v skupni kuhinji", alergeni_potrjeni: false }, { naziv: "Zelenjavna juha", sestava: "zelenjava, jušna osnova", alergeni: "ni alergenov", alergeni_potrjeni: true }], zbiranje: { hacc_ekipa: "Ana" } };
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP Kavarna Sonce", status: "osnutek", verzija_oznaka: "1.0", vsebina: W });
    await D.add("navodila", { stranka_id: s.id, naslov: "Toplotna obdelava, ohranjanje toplote in hlajenje", vrsta: "Delovno navodilo", status: "osnutek", teme: ["toplotna_obdelava", "hlajenje"], verzija_oznaka: "1.0", vsebina: "Toplotna obdelava, ohranjanje toplote in hlajenje\n1. NAMEN\nVarna obdelava.\n4. TOPLOTNA OBDELAVA\nSegrejemo na 75 °C.\n5. HLAJENJE\nS 60 °C na pod 10 °C v 90 min.\n6. EVIDENCE\nZapisi v evidenci." });
    return { s: s.id, n: n.id }; });
  const porocilo = () => pg.evaluate(async ids => { const rec = await api("GET", "/api/d/nacrti/" + ids.n), st = await api("GET", "/api/d/stranke/" + ids.s), ob = await api("GET", "/api/d/obrati?stranka_id=" + ids.s); return porociloNacrta(rec, vsebinaNacrta(rec), st, ob, [], await baza(), []).porocilo.map(x => x.tip + ": " + x.txt).join("\n"); }, ids);
  let P = await porocilo();
  // 13
  ok(/CCP1 \(Toplotna obdelava\): korektivni ukrepi navaja 75 °C, mejna vrednost je »≥ 72 °C«/.test(P), "korektivni ukrep 75 °C vs meja ≥ 72 °C");
  ok(/pogostost »1× dnevno« \(1× dnevno\), opis ukrepa pa 2× dnevno/.test(P), "»1× dnevno« vs »dvakrat dnevno«");
  // 17
  ok(/»Rižota z vinom« omenja vino, kis ali suho sadje – alergen »Žveplov dioksid\/sulfiti« ni označen/.test(P) && /»Zelenjavna juha« omenja jušno osnovo/.test(P), "opozorili: sulfiti (vino) in zelena (jušna osnova)");
  // 19: nizko tveganje ni opozorilo »nobena ni nizka«; stikalo »namerno izpuščena«
  ok(!/Nobena nevarnost ni ocenjena kot nizka/.test(P), "nizko tveganje obstaja – brez opozorila");
  // 18: migracija – opomba ločeno od alergenov
  const z0 = await pg.evaluate(async id => vsebinaNacrta(await api("GET", "/api/d/nacrti/" + id)).zivila[0], ids.n);
  ok(z0.alergeni === "Mleko" && z0.alergeni_opomba === "priprava v skupni kuhinji", "migracija: »priprava v skupni kuhinji« prenesena v opombo (" + JSON.stringify([z0.alergeni, z0.alergeni_opomba]) + ")");
  // UI: 14 evidenca »Drugo«, 15 vir meje iz baze, 18 potrditev alergenov
  await pg.evaluate(nid => sessionStorage.setItem("wstep:" + nid, "1"), ids.n); await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector("[data-zp='0']");
  await pg.click("[data-zp='0']"); await pg.waitForSelector("[data-k=alergeni_potrjeni]"); await pg.check("[data-k=alergeni_potrjeni]"); await pg.click("dialog[open] #dlg-f .btn:last-child");
  await pg.click(".stepper button >> nth=4"); await pg.waitForSelector("tr[data-h] [data-o]");
  await pg.click("tr[data-h='h1'] [data-o]"); await pg.waitForSelector("[data-k=evidenca]");
  await pg.selectOption("[data-k=evidenca]", "drugo"); await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('naziv evidence')");
  ok(!!(await pg.$("dialog[open] [data-k=evidenca]")), "evidenca »Drugo« brez naziva se ne shrani");
  ok(await pg.isHidden(".vir-pr select"), "izbira predpisa skrita, dokler vir ni »predpis«");
  await pg.selectOption("[data-k=mejna_vir_vrsta]", "predpis"); ok(await pg.isVisible(".vir-pr select"), "vir »predpis«: izbira predpisa iz baze zakonodaje");
  await pg.selectOption("[data-k=mejna_vir_predpis]", "Uredba (ES) št. 852/2004"); await pg.fill("[data-k=mejna_vir_clen]", "Priloga II, pogl. IX"); await pg.fill("[data-k=evidenca_naziv]", "Zapis temperature jedi");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  await pg.click(".stepper button >> nth=3"); await pg.waitForSelector("#niz_izp"); await pg.click("#wsave"); await pg.waitForSelector(".toast.show");
  const b64 = await pg.evaluate(async ids => { const rec = await api("GET", "/api/d/nacrti/" + ids.n), st = await api("GET", "/api/d/stranke/" + ids.s), ob = await api("GET", "/api/d/obrati?stranka_id=" + ids.s); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, ids);
  const f = path.join(OUT, "c.pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = pdfTxt(f);
  ok(/Predpis: Uredba \(ES\) št\. 852\/2004, Priloga II, pogl\. IX – smernica/.test(t), "izvoz: vir meje – predpis s členom");
  const vr = (t.match(/Rižota z vinom riž.{0,200}/) || [""])[0]; ok(/Mleko \(potrjeno:/.test(vr) && /Luka Zorman, \d+\./.test(vr) && /priprava v/.test(vr) && /skupni/.test(vr) && !/Mleko, priprava/.test(t), "izvoz: alergeni s potrditvijo (ime, datum), opomba v ločenem stolpcu " + (t.match(/Rižota z vinom riž.{0,300}/) || [""])[0]);
  ok(/Alergeni v obratu \(izračunano iz živil\): Mleko\./.test(t), "izvoz: alergeni obrata izračunani iz živil");
  ok(/Nizka tveganja \(obvladujejo se s predpogojnimi programi\)/.test(t) && /Tujki iz embalaže/.test(t), "izvoz: nizka tveganja v strnjeni tabeli");
  ok(/Smernice dobre higienske prakse in uporabe načel HACCP v gostinstvu.*\(smernica, ni predpis\)/.test(t) && /87\/14/.test(t) && /37\/2005/.test(t) && /70\/08/.test(t) && /2021\/382/.test(t), "priloga: nova zakonodaja in smernice DHP (označene kot smernica)");
  ok(!/2019\/625/.test(t) && !/Euratom/.test(t), "priloga gostinstva: brez Del. uredbe 2019/625 in Euratom 2016/52");
  // 20: razdeli navodilo
  await pg.goto(B + "/#/stranka/" + ids.s + "/navodila"); await pg.waitForSelector("#nraz"); await pg.click("#nraz"); await pg.waitForSelector("input[name=rz]");
  const rz = await pg.$$eval("input[name=rz]", x => x.map(i => i.parentElement.textContent.trim())); const iH = rz.findIndex(x => /HLAJENJE/.test(x));
  await pg.check(`input[name=rz][value="${iH}"]`); ok(await pg.inputValue("#rz_t") === "Hlajenje" && await pg.isChecked("#rz_tm input[value=hlajenje]"), "razdeli: naslov in tema predlagana iz razdelka");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('razdeljeno')");
  const nav = await pg.evaluate(sid => api("GET", "/api/d/navodila?stranka_id=" + sid), ids.s); const novo = nav.find(n => n.naslov === "Hlajenje"), izv = nav.find(n => /^Toplotna/.test(n.naslov));
  ok(novo && /S 60 °C na pod 10 °C v 90 min/.test(novo.vsebina) && novo.teme.includes("hlajenje") && /5\. HLAJENJE\nGlej navodilo »Hlajenje«\./.test(izv.vsebina) && !/90 min/.test(izv.vsebina) && /4\. TOPLOTNA OBDELAVA\nSegrejemo na 75 °C/.test(izv.vsebina), "novo navodilo z razdelkom, v izvirniku sklic, ostali razdelki nespremenjeni");
  ok((izv.revizije || []).some(r => /prenesen v navodilo »Hlajenje«/.test(r.razlog || "")), "sprememba izvirnika v zgodovini z razlogom");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
