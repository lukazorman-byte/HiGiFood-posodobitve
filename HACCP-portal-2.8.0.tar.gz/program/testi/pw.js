// Poišče Playwright (lokalno, globalno ali prek NODE_PATH) in Chromium.
const cp = require("child_process"), fs = require("fs");
let pw;
for (const f of [() => require("playwright"), () => require(cp.execSync("npm root -g", { stdio: ["ignore", "pipe", "ignore"] }).toString().trim() + "/playwright")]) { try { pw = f(); break; } catch {} }
if (!pw) { console.log("PRESKOČENO: Playwright ni nameščen (npm i -g playwright)"); process.exit(77); }
const own = (() => { try { return pw.chromium.executablePath(); } catch { return null; } })(); // Playwrightov lasten Chromium ima prednost
const exe = process.env.PW_CHROMIUM || [own, "/opt/pw-browsers/chromium", "/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/google-chrome"].find(p => p && fs.existsSync(p));
// Če test zahteva pot do brskalnika, ki na tem računalniku ne obstaja (npr. v GitHub Actions), jo prezri.
const opts = o => { o = Object.assign({}, o || {}); if (o.executablePath && !fs.existsSync(o.executablePath)) delete o.executablePath; return Object.assign({}, exe ? { executablePath: exe } : {}, o); };
// Aplikacija namesto window.confirm/alert/prompt uporablja lastna okna (<dialog class="cdlg">). Da testi ostanejo enaki, poslušalci
// page.on("dialog") / page.once("dialog") prejmejo tudi ta okna – z enakim vmesnikom (message(), type(), accept(v), dismiss()).
// Če poslušalca ni, okno ostane odprto (test ga lahko upravlja sam).
const OPAZUJ = () => {
  const go = () => new MutationObserver(() => {
    for (const d of document.querySelectorAll("dialog.cdlg[open]:not([data-pw])")) {
      d.dataset.pw = Math.random().toString(36).slice(2);
      window.__pwDlg({ id: d.dataset.pw, tip: d.dataset.tip || "confirm", msg: (d.querySelector(".cdlg-m") || {}).textContent || "" });
    }
  }).observe(document.documentElement || document, { subtree: true, childList: true, attributes: true, attributeFilter: ["open"] });
  if (document.documentElement) go(); else document.addEventListener("DOMContentLoaded", go);
};
async function lastnaOkna(pg) {
  const L = [], on0 = pg.on.bind(pg), off0 = pg.off.bind(pg), odstrani = e => { const i = L.indexOf(e); if (i >= 0) L.splice(i, 1); };
  pg.on = pg.addListener = (ev, f) => { if (ev === "dialog") L.push({ f }); return on0(ev, f); };
  pg.once = (ev, f) => {
    if (ev !== "dialog") return on0(ev, function w(...a) { off0(ev, w); f(...a); });
    const e = { f: d => { if (e.porabljen) return; e.porabljen = true; odstrani(e); off0("dialog", e.f); f(d); } };
    L.push(e); return on0("dialog", e.f);
  };
  pg.off = pg.removeListener = (ev, f) => { if (ev === "dialog") L.filter(e => e.f === f).forEach(odstrani); return off0(ev, f); };
  await pg.exposeBinding("__pwDlg", (src, info) => {
    const klik = (ok, v) => pg.evaluate(([id, ok, v]) => {
      const d = document.querySelector('dialog.cdlg[data-pw="' + id + '"]'); if (!d) return;
      const i = d.querySelector(".cdlg-i"); if (ok && i && v !== undefined) i.value = v;
      (d.querySelector(ok ? ".cdlg-ok" : ".cdlg-no") || d.querySelector(".cdlg-ok")).click();
    }, [info.id, ok, v]).catch(() => {});
    const dlg = { message: () => info.msg, type: () => info.tip, defaultValue: () => "", accept: v => klik(true, v), dismiss: () => klik(false) };
    for (const e of L.slice()) { try { e.f(dlg); } catch (x) { console.log("napaka v poslušalcu okna:", x); } }
  });
  await pg.addInitScript(OPAZUJ);
  return pg;
}
const ovij = br => {
  const np = br.newPage.bind(br), nc = br.newContext.bind(br);
  br.newPage = async o => lastnaOkna(await np(o));
  br.newContext = async o => { const c = await nc(o), cp0 = c.newPage.bind(c); c.newPage = async () => lastnaOkna(await cp0()); return c; };
  return br;
};
module.exports = { chromium: { launch: async o => ovij(await pw.chromium.launch(opts(o))) } };
