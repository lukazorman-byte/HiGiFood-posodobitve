// Predlog alergenov iz sestavin (portal/alergeni.js): skloni in pridevniške oblike se ujamejo, besede z enakim začetkom ne.
const B = process.env.BASE; const ALERGENI = require("../portal/alergeni.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const f = t => ALERGENI.najdi(t).map(x => x.alergen);
const DA = {
  "Žita z glutenom": ["ovseni kosmiči", "ovsena kaša", "oves", "pšenični zdrob", "pšenična moka", "zdrob", "kus kus", "kuskus", "bulgur", "seitan", "ržen kruh", "pirina moka", "drobtine"],
  "Raki": ["rakci", "rakovice", "kozice", "rak"],
  "Ribe": ["inćuni", "inčuni", "sardele", "slanik", "skuša", "tuna", "losos", "ribji file"],
  "Arašidi": ["kikiriki", "arašidi", "arašidovo maslo"],
  "Soja": ["tofu", "edamame", "tempeh", "miso", "sojina omaka", "soja"],
  "Oreščki": ["mandlji", "mandelj", "mandljeva moka", "lešniki", "orehi", "indijski oreščki", "pistacije"],
  "Sezam": ["tahini", "sezamovo seme"],
  "Mleko": ["mleko", "maslo", "sladka smetana", "trdi sir", "parmezan", "skuta", "mlečna čokolada"],
  "Jajca": ["jajca", "jajčni rumenjak", "majoneza"],
  "Zelena": ["gomolj zelene", "zelena"],
  "Gorčica": ["gorčica"], "Mehkužci": ["školjke", "lignji", "klapavice"], "Žveplov dioksid/sulfiti": ["belo vino", "suho sadje"]
};
const NE = {
  "Raki": ["rakija", "slivova rakija"], "Jajca": ["jajčevci", "pečeni jajčevci"],
  "Mleko": ["kakavovo maslo", "arašidovo maslo", "kokosovo mleko", "sojino mleko", "olivno olje", "masline"],
  "Oreščki": ["muškatni orešček", "muškatni oreh", "kokosov oreh"],
  "Žita z glutenom": ["koruzna moka", "riževa moka", "ajdova moka", "brezglutenska moka", "moka", "koruzni zdrob"],
  "Zelena": ["zelena solata", "zelene olive"], "Ribe": ["ribez"]
};
for (const [a, l] of Object.entries(DA)) for (const t of l) ok(f(t).includes(a), "zazna »" + t + "« → " + a + " (" + f(t).join(", ") + ")");
for (const [a, l] of Object.entries(NE)) for (const t of l) ok(!f(t).includes(a), "ne zazna »" + t + "« kot " + a + " (" + f(t).join(", ") + ")");
ok(JSON.stringify(f("pšenični zdrob, kakavovo maslo, tofu, rakija")) === JSON.stringify(["Žita z glutenom", "Soja"]), "seznam sestavin z vejicami: " + f("pšenični zdrob, kakavovo maslo, tofu, rakija"));
(async () => {
  // obrazec jedi: gumb »Predlagaj alergene iz sestavin« (tudi baza sestavin: »Maslo« ne velja za »kakavovo maslo«)
  const { chromium } = require("./pw.js"), br = await chromium.launch(), pg = await (await br.newContext()).newPage(), errs = []; pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => (await D.add("stranke", { naziv: "Alergeni d.o.o." })).id);
  await pg.goto(B + "/#/stranka/" + sid + "/alergeni"); await pg.waitForTimeout(800);
  await pg.evaluate(sid => openForm("jedi", null, { stranka_id: sid }, () => {}), sid); await pg.waitForSelector("#f_sestavine");
  await pg.fill("#f_sestavine", "ovseni kosmiči, kakavovo maslo, tofu, jajčevci, muškatni orešček, koruzna moka, rakija");
  await pg.click("text=Predlagaj alergene iz sestavin"); await pg.waitForTimeout(500);
  const izb = await pg.$$eval("#f_alergeni input:checked", l => l.map(x => x.value));
  ok(izb.sort().join() === ["Soja", "Žita z glutenom"].sort().join(), "obrazec jedi: predlagana samo gluten (ovseni) in soja (tofu): " + izb.join(", "));
  ok(!errs.length, "brez napak JavaScript " + errs.join(";")); await br.close();
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
