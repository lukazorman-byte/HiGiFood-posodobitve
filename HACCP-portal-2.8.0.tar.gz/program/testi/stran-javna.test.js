// Javna spletna stran na domeni platforme (higifood.si/stran/): privzeto zaprta za iskalnike (predogled); ko administrator
// vklopi »javna stran«, jo iskalniki indeksirajo (brez noindex, s canonical, robots.txt in sitemap), neprijavljen obiskovalec
// vstopne strani pride na spletno stran, povezave iz e-pošte (#/…) in /?portal pa odprejo platformo.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const get = async p => { const r = await fetch(B + p, { redirect: "manual" }); return { s: r.status, h: r.headers, t: await r.text() }; };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // privzeto: predogled, zaprt za iskalnike
  let r = await get("/stran/"), rb = await get("/robots.txt");
  ok(/noindex/.test(r.h.get("x-robots-tag") || "") && /<meta name="robots" content="noindex/.test(r.t) && /Disallow: \/\n/.test(rb.t) && !/Allow: \/stran\//.test(rb.t), "privzeto: /stran/ je predogled (noindex), robots.txt zapre vse");
  const anon = await (await br.newContext()).newPage();
  await anon.goto(B + "/"); await anon.waitForSelector("#le"); ok(new URL(anon.url()).pathname === "/", "privzeto: vstopna stran ostane prijava");
  // vklop javne strani (administrator)
  await pg.evaluate(() => api("PUT", "/api/seo-admin", { strani: {}, javna_stran: true }));
  r = await get("/stran/"); rb = await get("/robots.txt"); const blog = await get("/stran/blog/"), sm = await get("/stran/sitemap.xml");
  ok(!r.h.get("x-robots-tag") && /<meta name="robots" content="index, follow/.test(r.t) && r.t.includes(`<link rel="canonical" href="${B}/stran/">`), "javna: /stran/ brez noindex, canonical na /stran/");
  ok(!blog.h.get("x-robots-tag") && /<meta name="robots" content="index, follow/.test(blog.t) && blog.t.includes(`<link rel="canonical" href="${B}/stran/blog/">`) && /<title>[^<]{10,}<\/title>/.test(blog.t) && /<meta name="description" content="[^"]{30,}"/.test(blog.t), "javna: /stran/blog/ indeksiran, naslov in opis, canonical");
  ok(/Allow: \/stran\//.test(rb.t) && /Disallow: \/\n/.test(rb.t) && rb.t.includes(`Sitemap: ${B}/stran/sitemap.xml`), "robots.txt: /stran/ dovoljena, platforma zaprta, kazalo strani");
  ok(sm.s === 200 && sm.t.includes(`${B}/stran/blog/`), "sitemap.xml vsebuje blog");
  ok(r.t.includes('data-prijava href="/?portal"') && !r.t.includes('data-prijava href="/"'), "gumb Prijava vodi v platformo (/?portal)");
  // neprijavljen obiskovalec: / → /stran/; /?portal in povezava iz e-pošte ostaneta v platformi; prijavljen ostane v platformi
  const a2 = await (await br.newContext()).newPage();
  await a2.goto(B + "/"); await a2.waitForURL(/\/stran\/$/, { timeout: 10000 }).catch(() => {}); ok(new URL(a2.url()).pathname === "/stran/", "neprijavljen obiskovalec vstopne strani pride na spletno stran (" + a2.url() + ")");
  await a2.goto(B + "/?portal"); await a2.waitForSelector("#le"); ok(new URL(a2.url()).pathname === "/", "/?portal odpre prijavo v platformo");
  const a3 = await (await br.newContext()).newPage(); await a3.goto(B + "/#/geslo/neveljaven-zeton"); await a3.waitForTimeout(1500); ok(new URL(a3.url()).pathname === "/", "povezava iz e-pošte (#/geslo/…) ni preusmerjena");
  await pg.goto(B + "/"); await pg.waitForSelector("#shell:not([hidden])"); ok(new URL(pg.url()).pathname === "/", "prijavljen uporabnik ostane v platformi");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
