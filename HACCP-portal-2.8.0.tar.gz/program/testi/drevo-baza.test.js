// Baza za odločitveno drevo: profili živil (temperaturni režimi) in pravila po fazah – samodejna izpolnitev živil v čarovniku (korak 2)
// in predlog razvrstitve PRP/OPRP/CCP z odgovori V1–V4 in mejnimi vrednostmi (korak 5); ročno izbrani ukrepi se ne prepišejo.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  // baza: oblika in sklici na režime
  const rd = f => JSON.parse(fs.readFileSync(path.join(__dirname, "..", "baza", f + ".json"), "utf8"));
  const P = rd("drevo_profili"), F = rd("drevo_faze"), Rz = new Set(rd("rezimi").map(r => r.id));
  ok(P.length >= 20 && P.every(p => p.id && Rz.has(p.rezim) && (!p.toplotna || Rz.has(p.toplotna))), "profili živil: " + P.length + ", vsi režimi obstajajo");
  ok(F.length >= 15 && F.every(r => ["CCP", "OPRP", "PRP"].includes(r.vrsta) && Array.isArray(r.drevo) && (!/^[a-z]\w*$/.test(r.mejna || "") || Rz.has(r.mejna))) && F.some(r => r.tip === "*"), "pravila po fazah: " + F.length + ", splošno pravilo obstaja");
  // odgovori V1–V4 se ujemajo z razvrstitvijo (enako pravilo kot v obrazcu kontrolnega ukrepa)
  // Codex CXC 1-1969 (rev. 2022), Priloga IV, tabela 1: V1 da → ni CCP; V2 ne → ni CCP; V3 da → ni CCP (naslednji korak); V4 da → CCP
  const izDrevesa = a => { a = a.concat(["", "", "", ""]); return a[0] === "d" ? "ne" : a[0] !== "n" ? "?" : a[1] === "n" ? "ne" : a[1] !== "d" ? "?" : a[2] === "d" ? "ne" : a[2] !== "n" ? "?" : a[3] === "d" ? "CCP" : "?"; };
  const nesk = F.filter(r => (izDrevesa(r.drevo) === "CCP") !== (r.vrsta === "CCP") || izDrevesa(r.drevo) === "?").map(r => r.id);
  ok(!nesk.length, "odgovori V1–V4 v vseh pravilih ustrezajo razvrstitvi " + nesk.join(","));
  // paketi posodobitev ne smejo povoziti privzete baze s starejšo vsebino (zamenjani in dodani vnosi = trenutna baza)
  const KLJ = { rezimi: "id", drevo_profili: "id", drevo_faze: "id", branze: "id", naprave: "id", sestavine: "naziv", zakonodaja: "predpis" }, nesk2 = [];
  // paketi se izvedejo po vrsti (ime datoteke): za vsak vnos velja zadnji paket, ki ga vsebuje
  const zadnji = {};
  for (const f of fs.readdirSync(path.join(__dirname, "..", "posodobitve")).filter(f => f.endsWith(".json")).sort()) { const pk = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "posodobitve", f), "utf8"));
    for (const [c, k] of Object.entries(KLJ)) { if (!pk[c] || f < "2026-11") continue; for (const e of [...(pk[c].zamenjaj || []), ...(pk[c].dodaj || [])]) zadnji[c + "\u0000" + e[k]] = [f, c, k, e]; } }
  for (const [f, c, k, e] of Object.values(zadnji)) { const cur = rd(c).find(x => x[k] === e[k]); if (JSON.stringify(cur) !== JSON.stringify(e)) nesk2.push(f + ":" + c + ":" + e[k]); }
  ok(!nesk2.length, "paketi posodobitev se ujemajo s privzeto bazo " + nesk2.slice(0, 5).join(", "));
  // vrednosti, preverjene v uradnih virih (Uredba 853/2004, Uredba 2073/2005, Uredba 2023/915, Smernice DHP za gostinstvo / NIJZ 2014)
  const Rm = Object.fromEntries(rd("rezimi").map(r => [r.id, r])), Pm = Object.fromEntries(P.map(p => [p.id, p]));
  ok(Rm.vro.od === 63 && Rm.pon.od === 74 && Rm.kuh.od === 74 && Rm.kuh63.od === 63 && Rm.kuh68.od === 68 && Rm.kuh82.od === 82 && Rm.hlaj.od === 5 && Rm.hlaj.do === 63 && !Rm.kuh75, "režimi po Smernicah DHP za gostinstvo (63 / 74 / 68 / 82 °C, ohlajevanje 63 → 20 → 5 °C)");
  ok(Pm.meso_surovo.prevzem_max === 7 && Pm.drobovina.prevzem_max === 3 && Pm.perutnina.prevzem_max === 4 && Pm.meso_mleto.prevzem_max === 2 && Pm.mleko_surovo.prevzem_max === 10 && Pm.skoljke_zive && Pm.skoljke_zive.rezim === "skz" && Rm.jaj.od === undefined, "prevzem po Uredbi 853/2004 (meso 7, drobovina 3, perutnina 4, mleto 2, surovo mleko 10 °C), žive školjke in jajca brez izmišljenih temperatur");
  const mik = rd("branze").flatMap(b => b.mikro || []), vr = t => (mik.find(m => m[0].startsWith(t)) || [])[2] || "";
  ok(/1\.11$/.test(vr("Salmonella v siru")) && /1\.24$/.test(vr("Cronobacter")) && /1\.25$/.test(vr("E. coli v živih školjkah")) && /2\.3\.1$/.test(vr("Enterobacteriaceae v jajčnih")) && !mik.some(m => /500 µg\/kg/.test(m[1])), "mikrobiološka merila: pravilne vrstice Uredbe 2073/2005, DON 400 µg/kg");
  ok(!rd("zakonodaja").some(z => z.predpis === "Uredba (EU) 2018/213") && rd("zakonodaja").some(z => z.predpis === "Uredba (EU) 2024/3190"), "BPA: razveljavljena Uredba 2018/213 zamenjana z 2024/3190");
  ok(F.every(r => { try { new RegExp(r.vzorec, "i"); return true; } catch { return false; } }) && P.every(p => { try { new RegExp(p.vzorec || "", "i"); return true; } catch { return false; } }), "vsi vzorci so veljavni regularni izrazi");
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1400, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kavarna Sonce", dejavnost: "Gostinstvo (restavracija, gostilna)", odgovorna_oseba: "Zeljije Aljiti" }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce" });
    const imena = ["Prevzem", "Skladiščenje v hladilniku", "Skladiščenje zamrznjeno", "Suho skladišče", "Priprava mesa", "Toplotna obdelava", "Hlajenje", "Regeneracija", "Ohranjanje toplote", "Sladoled", "Pomivanje"];
    const koraki = imena.map((n, i) => ({ id: "k" + i, naziv: n })), nevarnosti = imena.map((n, i) => ({ id: "h" + i, korak_id: "k" + i, tip: "B", nevarnost: "Rast ali preživetje mikroorganizmov", verjetnost: 3, teza: 4, potrjeno: true }));
    nevarnosti.push({ id: "hA", korak_id: "k4", tip: "A", nevarnost: "Navzkrižni stik z alergeni", verjetnost: 3, teza: 4, potrjeno: true }, { id: "hN", korak_id: "k10", tip: "B", nevarnost: "Ostanki na posodi", verjetnost: 1, teza: 2, potrjeno: true });
    const kontrole = { h7: { hid: "h7", vrsta: "OPRP", utemeljitev: "Ročna odločitev svetovalca.", drevo: ["d", "n", "n", ""] } };
    const zivila = ["Sladoled", "Piščančja prsa", "Mleto meso", "Moka", "Mleko"].map((n, i) => ({ id: "z" + i, naziv: n }));
    zivila[4].shranjevanje = "hladilnik pri šanku";
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP Kavarna Sonce", status: "osnutek", vsebina: { koraki, nevarnosti, kontrole, zivila, zbiranje: { hacc_ekipa: "Zeljije Aljiti" } } });
    return { s: s.id, n: n.id }; });
  // korak 2: režimi iz baze
  await pg.evaluate(id => sessionStorage.setItem("wstep:" + id, "1"), ids.n); await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector("#zrez");
  ok(/hlajeno 0 do 2 °C · prevzem ≤ 2 °C .*· toplotna obdelava ≥ 68 °C/.test(await pg.textContent("tr[data-i='2'] .zrez")), "tabela živil: režim iz baze za mleto meso – " + await pg.textContent("tr[data-i='2'] .zrez"));
  await pg.click("#zrez"); await pg.waitForSelector("#zrez");
  const zv = await pg.$$eval("tr[data-i]", tr => tr.map(t => [t.querySelector("[data-k=skupina]").value, t.querySelector("[data-k=shranjevanje]").value, t.querySelector("[data-k=rte]").checked]));
  ok(/≤ −18 °C/.test(zv[0][1]) && zv[0][2] === true && /0 do 4 °C/.test(zv[1][1]) && /0 do 2 °C/.test(zv[2][1]) && /suho skladišče/.test(zv[3][1]) && zv[4][1] === "hladilnik pri šanku", "živila izpolnjena (vpisano shranjevanje ostane): " + JSON.stringify(zv.map(z => z[1])));
  ok(zv[1][0] && zv[3][0], "skupina izpolnjena: " + zv.map(z => z[0]).join(" | "));
  // samodejno ob vpisu naziva novega živila
  await pg.click("#zadd"); await pg.waitForSelector("tr[data-i='5']"); await pg.fill("tr[data-i='5'] [data-k=naziv]", "Losos"); await pg.press("tr[data-i='5'] [data-k=naziv]", "Tab");
  ok(/0 do 2 °C/.test(await pg.inputValue("tr[data-i='5'] [data-k=shranjevanje]")) && /prevzem ≤ 2 °C/.test(await pg.textContent("tr[data-i='5'] .zrez")), "novo živilo (Losos): režim izpolnjen ob vpisu naziva");
  // korak 5: predlog razvrstitve
  await pg.click(".stepper button >> nth=4"); await pg.waitForSelector("#drevo_b"); await pg.click("#drevo_b"); await pg.waitForSelector("#drevo_b");
  await pg.click("#wsave"); await pg.waitForFunction(() => /Shranjeno/.test((document.querySelector("#toast") || {}).textContent || ""));
  const W = (await pg.evaluate(id => api("GET", "/api/d/nacrti/" + id), ids.n)).vsebina, K = W.kontrole, v = h => (K[h] || {}).vrsta;
  ok(v("h5") === "CCP" && /≥ 74 °C v središču, vsaj 15 s/.test(K.h5.mejna) && K.h5.drevo.join("") === "ndnd" && K.h5.drevo_ver === "2022" && K.h5.evidenca === "toplotna", "toplotna obdelava: CCP, ≥ 74 °C 15 s (perutnina – najstrožje živilo načrta), drevo 2022: V1 ne, V2 da, V3 ne, V4 da " + K.h5.mejna);
  ok(K.h5.temperatura === "≥ 74 °C v središču, vsaj 15 s" && K.h5.cas === "vsaj 15 s", "toplotna obdelava: temperatura »" + K.h5.temperatura + "«, čas »" + K.h5.cas + "«");
  ok(K.h6.temperatura === "63 → 20 °C v ≤ 2 h, nato 20 → 5 °C v nadaljnjih ≤ 4 h" && /do 20 °C v ≤ 2 h/.test(K.h6.cas) && K.h8.temperatura === "≥ 63 °C" && /do serviranja/.test(K.h8.cas) && /Mleto meso ≤ 2 °C/.test(K.h0.temperatura) && /takoj po dostavi/.test(K.h0.cas), "hlajenje, ohranjanje toplote, prevzem: temperatura in čas izpolnjena");
  ok(v("h6") === "CCP" && /63 → 20 °C v ≤ 2 h, nato 20 → 5 °C/.test(K.h6.mejna) && K.h6.drevo.join(",") === "n,d,n,d", "hlajenje: CCP (V4 = da) " + K.h6.mejna);
  ok(v("h0") === "OPRP" && /Sladoled ≤ [-−]18 °C/.test(K.h0.mejna) && /Mleto meso ≤ 2 °C/.test(K.h0.mejna) && /Piščančja prsa ≤ 4 °C/.test(K.h0.mejna), "prevzem: OPRP, temperatura za vsako živilo " + K.h0.mejna.slice(0, 120));
  ok(v("h1") === "OPRP" && /0 do 2 °C/.test(K.h1.mejna) && v("h2") === "OPRP" && /[-−]18/.test(K.h2.mejna), "skladiščenje hlajeno (najstrožje 0–2 °C) in zamrznjeno: OPRP");
  ok(v("h3") === "PRP" && !K.h3.mejna && v("h4") === "PRP" && v("hA") === "PRP", "suho skladišče, priprava in alergeni: PRP");
  ok(v("h8") === "OPRP" && /≥ 63 °C/.test(K.h8.mejna) && v("h9") === "OPRP" && /[-−]18/.test(K.h9.mejna), "ohranjanje toplote OPRP ≥ 63 °C, sladoled OPRP z zamrznjenim režimom");
  ok(v("h7") === "OPRP" && K.h7.utemeljitev === "Ročna odločitev svetovalca." && !K.h7.predlog_drevo, "ročno izbran ukrep ni prepisan");
  ok(!K.hN, "nizko tveganje ni razvrščeno s predlogom");
  ok(Object.values(K).filter(c => c.predlog_drevo && ["CCP", "OPRP"].includes(c.vrsta)).every(c => c.mejna_predlog && /potrebna strokovna potrditev/.test(c.mejna_vir) && c.spremljanje && c.korektivni), "predlogi CCP/OPRP: mejna označena kot predlog z virom, spremljanje in korektivni ukrepi");
  // posamezna nevarnost: »Izpolni iz baze« v obrazcu
  await pg.click("tr[data-h='h7'] [data-o]").catch(async () => { await pg.click("[data-o='h7']"); }); await pg.waitForSelector("#dt_baza");
  ok(/rev\. 2003/.test(await pg.textContent("#dt_ver")) && !!(await pg.$("#dt_nov")) && /že obstaja ukrep/.test(await pg.textContent("#dt")), "obstoječi odgovori ostanejo po drevesu Codex 2003, ponujen prehod na 2022");
  await pg.click("#dt_nov"); await pg.waitForSelector("#dt_ver:has-text('rev. 2022')");
  ok(/predpogojnimi programi/.test(await pg.textContent("#dt")) && (await pg.$$eval("[data-q]", s => s.map(x => x.value).join(""))) === "", "prehod na drevo Codex 2022: nova vprašanja, odgovori izbrisani");
  await pg.selectOption("[data-q='0']", "n"); await pg.selectOption("[data-q='1']", "d"); await pg.selectOption("[data-q='2']", "n"); await pg.selectOption("[data-q='3']", "n");
  ok(/spremenite korak, proces ali izdelek/.test(await pg.textContent("#dtres")), "drevo 2022: V4 = ne → spremenite proces");
  await pg.click("#dt_baza"); ok((await pg.inputValue("[data-k=vrsta]")) === "CCP" && /≥ 74 °C v središču/.test(await pg.inputValue("[data-k=mejna]")) && /Pravilo: Ponovno segrevanje/.test(await pg.textContent("#dt_baza_r")), "obrazec: Izpolni iz baze (regeneracija → CCP ≥ 74 °C)");
  ok(await pg.inputValue("[data-k=temperatura]") === "≥ 74 °C v središču, vsaj 15 s" && (await pg.inputValue("[data-k=cas]")) === "vsaj 15 s", "obrazec: temperatura in čas izpolnjena iz režima");
  await pg.click("#dlg-f .btn:first-child");
  // poročilo preverjanja in izvoz PDF
  await pg.click(".stepper button >> nth=5"); await pg.waitForFunction(() => { const l = document.querySelector("#pr_list"); return l && !/Preverjam načrt/.test(l.textContent); }); // poročilo se izriše z zamikom
  const por = await pg.textContent("#pr_list"); ok(/predlog iz baze/i.test(por), "preverjanje opozori, da so mejne vrednosti predlog iz baze");
  ok(!/uskladite/.test(por), "predlogi iz baze ne sprožijo neskladij med mejno vrednostjo in ukrepi " + (por.match(/[^.]{0,120}uskladite/) || [""])[0]);
  const b64 = await pg.evaluate(async id => { const rec = await api("GET", "/api/d/nacrti/" + id), st = await api("GET", "/api/d/stranke/" + rec.stranka_id), ob = await api("GET", "/api/d/obrati?stranka_id=" + rec.stranka_id); await naloziIzdelovalca(rec.stranka_id); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, ids.n);
  const f = path.join(OUT, "drevo.pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = (cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }).stdout || "").replace(/\s+/g, " ");
  ok(/≥ 74 °C v središču/.test(t) && /CCP1/.test(t) && /Toplotna obdelava/.test(t), "izvoz: CCP z mejno vrednostjo iz baze");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
