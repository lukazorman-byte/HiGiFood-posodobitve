// Predloge pogodb v razdelku »Storitve« stranke: strokovni nadzor in pomoč pri odpravi pomanjkljivosti po inšpekciji (Word);
// iz ugotovitev inšpektorja se odprejo neskladnosti z rokom.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), fs = require("fs"), path = require("path"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const besedilo = f => { const r = cp.spawnSync("python3", ["-c", "import zipfile,sys,re;x=zipfile.ZipFile(sys.argv[1]).read('word/document.xml').decode();print(re.sub(r'<[^>]+>','',x.replace('</w:p>','\\n')))", f], { encoding: "utf8" }); return r.stdout || ""; };
const veljaven = f => /XML_OK/.test(cp.spawnSync("python3", ["-c", "import zipfile,sys\nfrom lxml import etree\nz=zipfile.ZipFile(sys.argv[1])\nfor n in z.namelist():\n  n.endswith('.xml') and etree.fromstring(z.read(n))\nprint('XML_OK')", f], { encoding: "utf8" }).stdout || "");
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Gostilna Lipa d.o.o.", naslov: "Glavna 1, Ljubljana", odgovorna_oseba: "Mojca Lipa" });
    const o = await D.add("obrati", { stranka_id: s.id, naziv: "Gostilna Lipa" }); return { sid: s.id, oid: o.id }; });

  // 1) pogodba o strokovnem nadzoru
  await pg.goto(B + `/#/stranka/${ids.sid}/storitve`); await pg.waitForSelector("#pog_n");
  await pg.click("#pog_n"); await pg.waitForSelector("#pg_c");
  await pg.fill("#pg_in", "Svetovanje Zorman s.p."); await pg.fill("#pg_iz", "Luka Zorman"); await pg.fill("#pg_c", "120"); await pg.fill("#pg_ur", "40"); await pg.fill("#pg_so", "Ljubljani");
  let [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#dlg-f .btn:last-child")]); let f = path.join(OUT, "nadzor.docx"); await dl.saveAs(f);
  let t = besedilo(f); ok(veljaven(f), "Word datoteka je veljavna (XML)");
  ok(dl.suggestedFilename().startsWith("pogodba-nadzor-"), "prenesena pogodba o nadzoru (" + dl.suggestedFilename() + ")");
  for (const x of ["Pogodbeni stranki", "Gostilna Lipa d.o.o.", "Mojca Lipa", "Svetovanje Zorman s.p.", "Obseg storitev", "120,00 EUR mesečno", "40,00 EUR", "17. člen Uredbe (ES) št. 178/2002", "sodišče v Ljubljani", "Gostilna Lipa"]) ok(t.includes(x), "pogodba o nadzoru vsebuje »" + x + "«");

  // 2) podatki izvajalca se zapomnijo; pogodba po inšpekciji z ugotovitvami in neskladnostmi
  await pg.click("#pog_i"); await pg.waitForSelector("#pg_ug");
  ok(await pg.inputValue("#pg_in") === "Svetovanje Zorman s.p." && await pg.inputValue("#pg_ur") === "40", "podatki izvajalca so zapomnjeni");
  await pg.selectOption("#pg_or", { index: 0 }); await pg.fill("#pg_dn", "2026-11-05"); await pg.fill("#pg_st", "06102-123/2026"); await pg.selectOption("#pg_obr", ids.oid);
  await pg.fill("#pg_ug", "1. Ni evidence temperature hladilnika za oktober\n- Poškodovane stenske ploščice v kuhinji");
  // brez roka ni mogoče odpreti neskladnosti
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(200);
  ok(/rok za odpravo/i.test(await pg.textContent("#ferr")), "brez roka za odpravo: opozorilo");
  await pg.fill("#pg_rk", "2026-12-05");
  [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#dlg-f .btn:last-child")]); f = path.join(OUT, "inspekcija.docx"); await dl.saveAs(f);
  t = besedilo(f); ok(veljaven(f), "Word datoteka po inšpekciji je veljavna (XML)");
  for (const x of ["Podatki o uradnem nadzoru", "UVHVVR", "06102-123/2026", "5. 12. 2026", "Ni evidence temperature hladilnika za oktober", "Poškodovane stenske ploščice v kuhinji", "ne zastopa", "po urni postavki 40,00 EUR"]) ok(t.replace(/\s+/g, " ").includes(x.replace(/\s+/g, " ")) || t.includes(x), "pogodba po inšpekciji vsebuje »" + x + "«");
  ok(!t.includes("1. Ni evidence"), "oštevilčenje ugotovitev odstranjeno");
  await pg.waitForTimeout(500);
  const caps = await pg.evaluate(sid => api("GET", "/api/d/capa?stranka_id=" + sid), ids.sid);
  ok(caps.length === 2 && caps.every(c => c.rok === "2026-12-05" && c.status === "odprto" && c.obrat_id === ids.oid && /06102-123\/2026/.test(c.opis)), "odprti dve neskladnosti z rokom in virom (" + caps.length + ")");

  // 3) zaposleni kartice ne vidi
  await pg.evaluate(sid => api("POST", "/api/uporabniki", { ime: "Zap", email: "zap@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: sid }), ids.sid);
  const p2 = await (await br.newContext()).newPage(); await p2.goto(B + "/"); await p2.fill("#le", "zap@t.si"); await p2.fill("#lp", "dolgogeslo123"); await p2.click("#lf button"); await p2.waitForSelector("#shell:not([hidden])");
  await p2.goto(B + `/#/stranka/${ids.sid}/storitve`); await p2.waitForTimeout(800);
  ok(await p2.locator("#pog").count() === 0, "odgovorna oseba ne vidi predlog pogodb");

  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
