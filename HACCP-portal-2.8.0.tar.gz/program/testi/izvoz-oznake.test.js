// Sklop B – zastareli podatki v izvozu (Kavarna Sonce, 3 CCP in 17 OPRP): sveži podatki stranke ob izvozu, oznake {{CCP:…}} v prostem
// besedilu, zaklenjene številke CCP/OPRP (premik korakov jih ne spremeni), preverjanje številk v prostem besedilu, generiran stavek
// »Število CCP«, baza znanja brez številk CCP, različice dokumenta (1.0, 1.1) ločeno od interne številke zapisa.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pdfTxt = (f) => (cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }).stdout || "").replace(/\s+/g, " ");
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  // 11: baza znanja ne sme vsebovati oštevilčenih CCP/OPRP
  const baza = fs.readdirSync(path.join(__dirname, "..", "baza")).filter(f => f.endsWith(".json")).map(f => [f, fs.readFileSync(path.join(__dirname, "..", "baza", f), "utf8")]);
  const st = baza.filter(([, t]) => /(?<![\p{L}{:])(CCP|OPRP) ?\d/u.test(t)).map(([f]) => f); ok(!st.length, "baza znanja brez oštevilčenih CCP/OPRP " + st.join(","));
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kavarna Sonce", dejavnost: "Gostinstvo", pravna_oblika: "s.p.", odgovorna_oseba: "Zeljije Aljiti", opis_dejavnosti: "Kavarna s toplo kuhinjo." }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce", opis_prostorov: "Kuhinja in točilni pult." });
    const imena = ["Prevzem", "Skladiščenje v hladilniku", "Skladiščenje zamrznjeno", "Odtajanje", "Priprava zelenjave", "Priprava mesa", "Toplotna obdelava", "Hlajenje", "Regeneracija", "Ohranjanje toplote", "Hladna priprava", "Sladoled", "Točilni pult", "Kava", "Led", "Pecivo", "Pomivanje", "Odpadki", "Izdaja", "Dostava"];
    const koraki = imena.map((n, i) => ({ id: "k" + i, naziv: n })), nevarnosti = [], kontrole = {};
    imena.forEach((n, i) => { const id = "h" + i; nevarnosti.push({ id, korak_id: "k" + i, tip: "B", nevarnost: "Nevarnost pri " + n.toLowerCase(), verjetnost: 3, teza: 4, potrjeno: true }); });
    const ccp = ["Toplotna obdelava", "Regeneracija", "Sladoled"], oprp = imena.filter(n => !ccp.includes(n)).slice(0, 17);
    imena.forEach((n, i) => { const v = ccp.includes(n) ? "CCP" : oprp.includes(n) ? "OPRP" : ""; if (v) kontrole["h" + i] = { hid: "h" + i, vrsta: v, kaj: n, mejna: "≥ 72 °C", mejna_vir: "smernica", evidenca: "temperatura", verifikacija: "tedensko", spremljanje: "termometer", pogostost: "vsaka serija", odgovoren: "kuhar", korektivni: "ponovno segrej" }; });
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP Kavarna Sonce", status: "osnutek", verzija_oznaka: "1.0", vsebina: { koraki, nevarnosti, kontrole, zivila: [{ naziv: "Sladoled", alergeni: "mleko", alergeni_potrjeni: true }], zbiranje: { hacc_ekipa: "Zeljije Aljiti" },
      besedila_pogl: { ccp: "Število kritičnih kontrolnih točk (CCP) v obratu: 1 – CCP1 (Kava). Za vsako CCP so določene meje." } } });
    return { s: s.id, o: o.id, n: n.id }; });
  // 9: zaklenjene številke (migracija ohrani prikazane); premik korakov jih ne spremeni
  const oz = await pg.evaluate(async id => { const rec = await api("GET", "/api/d/nacrti/" + id), W = vsebinaNacrta(rec); const a = ccpOznake(W); W.koraki.reverse(); const b = ccpOznake(W); return { a, b, n: Object.values(a).filter(x => /^CCP/.test(x)).length, o: Object.values(a).filter(x => /^OPRP/.test(x)).length }; }, ids.n);
  ok(oz.n === 3 && oz.o === 17 && JSON.stringify(oz.a) === JSON.stringify(oz.b), "3 CCP in 17 OPRP; številke se ob obratu vrstnega reda korakov ne spremenijo");
  ok(oz.a.h6 === "CCP1" && oz.a.h8 === "CCP2" && oz.a.h11 === "CCP3", "CCP1 toplotna obdelava, CCP2 regeneracija, CCP3 sladoled");
  // 8: prosto besedilo z napačno številko → odprto vprašanje
  await pg.evaluate(async id => { const s = await api("GET", "/api/d/stranke/" + id); await api("PUT", "/api/d/stranke/" + id, { opis_dejavnosti: "Kavarna s toplo kuhinjo. Hlajenje nadzorujemo kot CCP2.", _ver: s.spremenjeno || s.ustvarjeno }); }, ids.s);
  await pg.evaluate(nid => sessionStorage.setItem("wstep:" + nid, "5"), ids.n); await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector("#pr_odp");
  ok(/CCP2 je faza »Regeneracija«, ne »Hlajenje«/.test(await pg.textContent("#pr_odp")), "preverjanje: številka v prostem besedilu ne ustreza fazi");
  // 7: sprememba podatkov stranke po odprtju čarovnika (mimo predpomnilnika) se pokaže v izvozu brez ponovnega nalaganja
  await pg.click(".stepper button >> nth=6"); await pg.waitForSelector("#xpdf");
  await pg.evaluate(async id => { const s = await api("GET", "/api/d/stranke/" + id); await api("PUT", "/api/d/stranke/" + id, { opis_dejavnosti: "Topla kuhinja: {{CCP:Toplotna obdelava}} in {{CCP:Regeneracija}}; skupaj {{stevilo_CCP}} CCP ({{seznam_CCP}}). Opomba: {{CCP:Neobstoječa faza}}", _ver: s.spremenjeno || s.ustvarjeno }); }, ids.s);
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#xpdf")]); const f = path.join(OUT, "kavarna.pdf"); await dl.saveAs(f); const t = pdfTxt(f);
  ok(/Topla kuhinja: CCP1 in CCP2; skupaj 3 CCP \(CCP1 \(Toplotna obdelava\), CCP2 \(Regeneracija\), CCP3 \(Sladoled\)\)/.test(t), "izvoz: sveži opis dejavnosti, oznake {{CCP:…}}, {{stevilo_CCP}}, {{seznam_CCP}} zamenjane");
  ok(/\[MANJKA: CCP za »Neobstoječa faza« ne obstaja\]/.test(t) && /oznaka \{\{CCP:Neobstoječa faza\}\} – CCP za »Neobstoječa faza« ne obstaja/.test(t), "neobstoječa oznaka označena in javljena");
  // 10: stavek o številu CCP generiran (ne iz prilagojenega besedila)
  ok(/Število CCP: 3 – CCP1 \(Toplotna obdelava\), CCP2 \(Regeneracija\), CCP3 \(Sladoled\)\./.test(t) && !/v obratu: 1 – CCP1 \(Kava\)/.test(t), "stavek »Število CCP« generiran v poglavjih (prilagojen stari stavek odstranjen)");
  ok((t.match(/Število CCP: 3/g) || []).length >= 2, "stavek v poglavju diagrama in nadzornega lista");
  // 12: različice dokumenta ob potrditvi (1.0, nato 1.1), brez internih številk v dokumentu
  const potrdi = async (stanje, razlog) => { await pg.goto(B + "/#/stranka/" + ids.s + "/nacrti"); await pg.waitForSelector("td:has-text('HACCP Kavarna Sonce')"); await pg.click("td:has-text('HACCP Kavarna Sonce')"); await pg.click("dialog[open] button:has-text('Osnovni podatki')"); await pg.waitForSelector("#f_status");
    await pg.selectOption("#f_status", stanje); if (stanje === "potrjeno") { await pg.fill("#f_potrdil", "Luka Zorman"); await pg.fill("#f_datum_potrditve", "2026-11-05"); } if (await pg.$("#f__razlog")) await pg.fill("#f__razlog", razlog); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]")); };
  await potrdi("potrjeno", "Prva izdaja načrta"); let r = await pg.evaluate(id => api("GET", "/api/d/nacrti/" + id), ids.n);
  ok(r.razlicice && r.razlicice.length === 1 && r.razlicice[0].oznaka === "1.0" && r.razlicice[0].potrdil === "Luka Zorman", "prva potrditev: različica 1.0");
  await potrdi("osnutek", "Dodan sladoled"); await potrdi("potrjeno", "Dodan sladoled (CCP3)"); r = await pg.evaluate(id => api("GET", "/api/d/nacrti/" + id), ids.n);
  ok(r.razlicice.length === 2 && r.razlicice[1].oznaka === "1.1" && r.verzija_oznaka === "1.1" && /sladoled/.test(r.razlicice[1].opis) && r.verzija > 2, "ponovna potrditev: različica 1.1 z opisom (interna številka " + r.verzija + ")");
  const b64 = await pg.evaluate(async ids => { const rec = await api("GET", "/api/d/nacrti/" + ids.n), st = await api("GET", "/api/d/stranke/" + ids.s), ob = await api("GET", "/api/d/obrati?stranka_id=" + ids.s); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, ids);
  const f2 = path.join(OUT, "kavarna2.pdf"); fs.writeFileSync(f2, Buffer.from(b64, "base64")); const t2 = pdfTxt(f2);
  ok(/Evidenca različic dokumenta.*1\.0 5\. 11\. 2026 Prva izdaja načrta Luka Zorman.*1\.1 5\. 11\. 2026 Dodan sladoled \(CCP3\) Luka Zorman/.test(t2) && !/rev\. \d{1,3}(?!\d)/.test(t2) && !/Interna revizija/.test(t2), "dokument: samo različice dokumenta (1.0, 1.1) z datumom in opisom, brez internih številk " + (t2.match(/Evidenca različic.{0,400}/) || [""])[0] + " | rev: " + (t2.match(/.{40}rev\. \d.{20}/) || [""])[0]);
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
