// Sklop A – lažna opozorila v preverjanju: besedilo za izpolnjevalca (šumniki, DOLOČITI, [MANJKA: …]), vrednosti iz razdelka teme
// (75 °C toplotne obdelave ne sproži opozorila za OPRP hlajenja), več tem navodila (obvezno, predlog iz naslova), »Obravnavano«
// z utemeljitvijo, korak 6 in izvoz z istim preverjanjem.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kavarna Sonce", dejavnost: "Gostinstvo" }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce" });
    const n1 = await D.add("navodila", { stranka_id: s.id, naslov: "Toplotna obdelava, ohranjanje toplote in hlajenje", vrsta: "Delovno navodilo", status: "osnutek", verzija_oznaka: "1.0",
      vsebina: "Toplotna obdelava, ohranjanje toplote in hlajenje\n1. NAMEN\nVarna toplotna obdelava in hlajenje jedi.\n\n4. POSTOPEK\nToplotna obdelava: jedi segrejemo na najmanj 75 °C v jedru. Hlajenje: s 60 °C na pod 10 °C v 90 min.\nRok za ponovni pregled je treba določiti skupaj z vodjo kuhinje.\nJedi z oznako [MANJKA] v jedilniku je treba potrditi pred prodajo." });
    const n2 = await D.add("navodila", { stranka_id: s.id, naslov: "Odpadki", vrsta: "Delovno navodilo", status: "osnutek", verzija_oznaka: "1.0", teme: ["odpadki"], vsebina: "Odpadki\n4. POSTOPEK\nPraznjenje posod: DOLOČITI\n[MANJKA: izvajalec odvoza]" });
    const W = { koraki: [{ id: "k1", naziv: "Toplotna obdelava" }, { id: "k2", naziv: "Hlajenje" }], nevarnosti: [{ id: "h1", korak_id: "k2", tip: "B", nevarnost: "Rast bakterij pri počasnem hlajenju", verjetnost: 3, teza: 4, potrjeno: true }],
      kontrole: { h1: { hid: "h1", vrsta: "OPRP", kaj: "hlajenje", mejna: "60 °C na pod 10 °C v 90 min", mejna_vir: "smernica", evidenca: "hlajenje", verifikacija: "tedensko" } },
      zivila: [{ naziv: "Tiramisu", alergeni: "jajca, mleko", alergeni_potrjeni: true, priprava: "s surovimi jajci" }], zbiranje: { hacc_ekipa: "Ana" } };
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP Kavarna Sonce", status: "osnutek", verzija_oznaka: "1.0", vsebina: W });
    return { s: s.id, o: o.id, n: n.id, n1: n1.id, n2: n2.id }; });
  const porocilo = () => pg.evaluate(async ids => { const rec = await api("GET", "/api/d/nacrti/" + ids.n), st = (await D.list("stranke")).find(x => x.id === ids.s), ob = await D.list("obrati", { stranka_id: ids.s }), nav = await D.list("navodila", { stranka_id: ids.s }); return porociloNacrta(rec, vsebinaNacrta(rec), st, ob, nav, await baza(), []).porocilo; }, ids);
  let P = await porocilo(), txt = P.map(x => x.tip + ": " + x.txt).join("\n");
  // 1, 2: besedilo za izpolnjevalca
  ok(!/Toplotna obdelava, ohranjanje toplote in hlajenje«: nedokončano/.test(txt), "»določiti« in omenjena oznaka [MANJKA] v stavku nista nedokončano besedilo");
  ok(/»Odpadki«: nedokončano besedilo \(»Praznjenje posod: DOLOČITI«, »\[MANJKA: izvajalec odvoza\]«\)/.test(txt), "»DOLOČITI« in »[MANJKA: …]« sta nedokončano besedilo");
  // 3: vrednosti samo iz razdelka / stavkov teme
  ok(!/vrednosti uskladite/.test(txt), "75 °C (toplotna obdelava) ne sproži opozorila za OPRP hlajenja (60 °C na pod 10 °C v 90 min)\n" + txt);
  await pg.evaluate(async id => { const n = await api("GET", "/api/d/navodila/" + id); await D.set("navodila", id, { vsebina: n.vsebina.replace("v 90 min", "v 120 min"), _razlog: "test", _ver: n.spremenjeno || n.ustvarjeno }); }, ids.n1);
  P = await porocilo(); ok(P.some(x => /\(hlajenje\) navaja 120min.*vrednosti uskladite/.test(x.txt)), "dejansko neskladje v stavku o hlajenju je še zaznano");
  // 4: več tem, predlog iz naslova
  const tm = await pg.evaluate(async id => { const n = await api("GET", "/api/d/navodila/" + id); return { t: temeNavodila(n), p: temePredlog(n) }; }, ids.n1);
  ok(["toplotna_obdelava", "ohranjanje_toplote", "hlajenje"].every(t => tm.t.includes(t)) && tm.p, "teme iz naslova: toplotna obdelava, ohranjanje toplote, hlajenje (predlog)");
  ok(P.some(x => x.tip === "opozorilo" && /Teme protokola niso potrjene.*Toplotna obdelava, ohranjanje/.test(x.txt)), "opozorilo: teme navodila le predlagane");
  const iz = await pg.evaluate(async sid => { const nav = await D.list("navodila", { stranka_id: sid }); nav.push({ id: "pr", naslov: "Hlajenje (predloga)", predloga: "hlajenje", status: "osnutek" }); const r = izberiNavodila(nav); return r.izbrana.map(n => n.naslov + ":" + n._teme.join("+")); }, ids.s);
  ok(iz.length === 2 && iz.some(x => /^Toplotna obdelava.*hlajenje/.test(x)) && !iz.some(x => /predloga/.test(x)), "navodilo z več temami nadomesti predlogo za hlajenje in se izpiše enkrat: " + iz.join(", "));
  // obrazec: teme obvezne, predlog predizpolnjen
  await pg.goto(B + "/#/stranka/" + ids.s + "/navodila"); await pg.waitForSelector("table.t");
  await pg.click("td:has-text('Toplotna obdelava, ohranjanje toplote in hlajenje')"); await pg.waitForSelector("#f_teme");
  ok(await pg.isChecked("#f_teme input[value=hlajenje]") && await pg.isChecked("#f_teme input[value=toplotna_obdelava]"), "obrazec: predlagane teme predizpolnjene");
  if (await pg.$("#f__razlog")) await pg.fill("#f__razlog", "potrditev tem protokola"); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok((await pg.evaluate(async id => (await api("GET", "/api/d/navodila/" + id)).teme, ids.n1) || []).includes("toplotna_obdelava"), "teme shranjene (potrjene)");
  await pg.click("#ladd"); await pg.waitForSelector("#f_naslov"); await pg.fill("#f_naslov", "Novo navodilo brez teme"); await pg.click("#dlg-f .btn:last-child");
  ok(/Izpolnite polje »Teme protokola«/.test(await pg.textContent("dialog[open]")) && !!(await pg.$("dialog[open]")), "novo navodilo brez teme: polje Teme protokola je obvezno (ni shranjeno)");
  await pg.evaluate(() => document.querySelector("dialog[open]").close());
  // 5, 6: korak 6 = isto poročilo; »Obravnavano« z utemeljitvijo
  await pg.evaluate(nid => sessionStorage.setItem("wstep:" + nid, "5"), ids.n); await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector("#pr_odp, #pr_ok");
  P = await porocilo(); const nOdp = P.filter(x => x.tip === "odprto").length;
  ok(/Odprta vprašanja \(\d+\)/.test(await pg.textContent("#pr_list")) && (await pg.textContent("#pr_odp")).includes(`(${nOdp})`), "korak 6 in izvoz: enako število odprtih vprašanj (" + nOdp + ")");
  await pg.click("[data-obr=surova_jajca]"); await pg.fill("#obr_u", "kratko"); await pg.click("#dlg-f .btn:last-child"); ok(await pg.$("#obr_u"), "utemeljitev je obvezna (vsaj 10 znakov)");
  await pg.fill("#obr_u", "Uporabljamo samo pasterizirana jajca dobavitelja Jajca d.o.o."); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector("details.pr-obr"); ok(!(await pg.$("[data-obr=surova_jajca]")), "opozorilo izgine, prikazano med obravnavanimi");
  await pg.click("#wsave"); await pg.waitForSelector(".toast.show");
  const b64 = await pg.evaluate(async ids => { const rec = await api("GET", "/api/d/nacrti/" + ids.n), st = (await D.list("stranke")).find(x => x.id === ids.s), ob = await D.list("obrati", { stranka_id: ids.s }), nav = await D.list("navodila", { stranka_id: ids.s }); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, nav, await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, ids);
  const f = path.join(OUT, "a.pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = (cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }).stdout || "").replace(/\s+/g, " ");
  ok(/Obravnavana strokovna opozorila/.test(t) && /Surova jajca – Uporabljamo samo pasterizirana jajca/.test(t) && !/Opozorilo: Surova jajca: preverite/.test(t), "izvoz: utemeljitev izpisana, opozorilo ni v poročilu");
  ok(!/vrednosti uskladite/.test(t.replace(/120min[^.]*uskladite/, "")) || /120min/.test(t), "izvoz: brez lažnega opozorila o vrednostih");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
