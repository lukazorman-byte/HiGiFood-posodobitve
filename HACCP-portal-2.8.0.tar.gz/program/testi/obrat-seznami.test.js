// Obrat: prostori ter naprave in pribor s kljukicami (opis pri izbrani postavki, lastne postavke), shranjevanje,
// preverjanje na strežniku in izpis v HACCP načrtu (poglavje Dejavnost).
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => (await D.add("stranke", { naziv: "Seznami d.o.o." })).id);
  await pg.goto(B + "/#/stranka/" + sid + "/obrati"); await pg.waitForSelector("#ladd"); await pg.click("#ladd"); await pg.waitForSelector("#f_prostori");
  ok(await pg.locator("#f_prostori .kl-row").count() >= 20 && await pg.locator("#f_naprave .kl-row").count() >= 25, "obrazec obrata: seznama prostorov in naprav");
  await pg.fill("#f_naziv", "Kavarna");
  const kl = (sez, ime) => pg.locator(`#f_${sez} .kl-row:has(input[value="${ime}"])`);
  await kl("prostori", "Kuhinja").locator("input[type=checkbox]").check();
  ok(await kl("prostori", "Kuhinja").locator(".kl-opis").isVisible() && !(await kl("prostori", "Hladilnica").locator(".kl-opis").isVisible()), "opis se pokaže samo pri izbranem prostoru");
  await kl("prostori", "Kuhinja").locator(".kl-opis").fill("topla in hladna priprava, 25 m²");
  await kl("prostori", "Točilni pult").locator("input[type=checkbox]").check();
  await pg.fill("#f_prostori .kl-nov", "Vinska klet"); await pg.click("#f_prostori [data-kl-dodaj]"); await pg.locator("#f_prostori .kl-lastne .kl-opis").fill("12 °C");
  await kl("naprave", "Friteza").locator("input[type=checkbox]").check(); await kl("naprave", "Friteza").locator(".kl-opis").fill("2 bazena, 8 l");
  await kl("naprave", "Termometer / vbodna sonda").locator("input[type=checkbox]").check();
  await pg.fill("#f_naprave .kl-nov", "Mlinček za kavo"); await pg.click("#f_naprave [data-kl-dodaj]");
  await pg.fill("#f_opis_prostorov", "Čiste in nečiste poti so ločene.");
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  const ob = await pg.evaluate(async sid => (await D.list("obrati", { stranka_id: sid }))[0], sid);
  ok(JSON.stringify(ob.prostori) === JSON.stringify([{ ime: "Kuhinja", opis: "topla in hladna priprava, 25 m²" }, { ime: "Točilni pult", opis: "" }, { ime: "Vinska klet", opis: "12 °C" }]), "shranjeni prostori z opisi in lastno postavko " + JSON.stringify(ob.prostori));
  ok(ob.naprave.map(x => x.ime).join("|") === "Friteza|Termometer / vbodna sonda|Mlinček za kavo" && ob.naprave[0].opis === "2 bazena, 8 l", "shranjene naprave in pribor " + JSON.stringify(ob.naprave));
  // ponovno odpiranje: izbrane postavke in opisi ostanejo
  await pg.click("#lb tr[data-id]"); await pg.waitForSelector("#f_prostori");
  ok(await kl("prostori", "Kuhinja").locator("input[type=checkbox]").isChecked() && await kl("prostori", "Kuhinja").locator(".kl-opis").inputValue() === "topla in hladna priprava, 25 m²" && await pg.locator("#f_prostori .kl-lastne input[value='Vinska klet']").isChecked(), "ponovno odpiranje: izbire in opisi ostanejo");
  await pg.evaluate(() => document.querySelector("dialog[open]").close());
  // strežnik: neveljaven seznam zavrnjen
  const e = await pg.evaluate(sid => D.add("obrati", { stranka_id: sid, naziv: "X", prostori: "Kuhinja" }).then(() => "OK", x => x.message), sid);
  ok(/Prostori.*seznam postavk/.test(e), "strežnik: neveljaven seznam prostorov zavrnjen (" + e + ")");
  // HACCP načrt: poglavje Dejavnost
  const txt = await pg.evaluate(async ({ sid, ob }) => { const db = await baza(), s = (await D.list("stranke")).find(x => x.id === sid), n = await D.add("nacrti", { stranka_id: sid, obrat_id: ob.id, naziv: "N", vsebina: { koraki: [], zivila: [], nevarnosti: [], kontrole: {} } });
    let t = ""; const d = { h: (l, x) => { t += x + "\n"; }, p: x => { t += x + "\n"; }, table: (g, r) => { t += r.map(x => x.join(" | ")).join("\n") + "\n"; }, bullets: l => { t += l.join("\n") + "\n"; }, box: x => { t += x + "\n"; }, flow: () => {}, img: () => {}, gap: () => {} };
    buildHaccpPdf(n, vsebinaNacrta(n), s, [ob], [], db, [], "fill", {})(d); return t; }, { sid, ob });
  ok(/Prostori \| Kuhinja \(topla in hladna priprava, 25 m²\); Točilni pult; Vinska klet \(12 °C\)\. Čiste in nečiste poti so ločene\./.test(txt) && /Naprave in pribor \| Friteza \(2 bazena, 8 l\); Termometer \/ vbodna sonda; Mlinček za kavo/.test(txt), "HACCP načrt: prostori ter naprave in pribor v poglavju Dejavnost");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
