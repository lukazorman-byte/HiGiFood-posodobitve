// E-pošta (točka 16): pošiljanje prek HTTPS API (Resend, Brevo), berljive napake s statusom 400 (ne 502),
// časovna omejitev 10 s pri strežniku SMTP, ki se ne odzove, zapis v »Zadnje napake strežnika«, preverjanje odhodnih vrat.
const http = require("http"), net = require("net");
const B = process.env.BASE;
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const PREJ = []; let kljucOK = "re_dober";
  const api = http.createServer((q, r) => { let b = ""; q.on("data", c => b += c); q.on("end", () => { const j = JSON.parse(b || "{}"), kl = q.headers.authorization ? q.headers.authorization.replace("Bearer ", "") : q.headers["api-key"]; PREJ.push({ url: q.url, kl, j });
    if (kl !== kljucOK) { r.writeHead(401, { "Content-Type": "application/json" }); return r.end(JSON.stringify({ message: "API key is invalid" })); }
    if (/nepotrjena/.test(JSON.stringify(j))) { r.writeHead(403, { "Content-Type": "application/json" }); return r.end(JSON.stringify({ message: "The nepotrjena.si domain is not verified." })); }
    r.writeHead(200, { "Content-Type": "application/json" }); r.end('{"id":"1"}'); }); }).listen(4955, "127.0.0.1");
  const tiho = net.createServer(s => { s.on("error", () => {}); }).listen(4956, "127.0.0.1"); // sprejme povezavo, nikoli ne odgovori
  const req = async (m, p, b, ck) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, ck ? { Cookie: ck } : {}), body: b ? JSON.stringify(b) : undefined }); let j = null; try { j = await r.json(); } catch {} return { s: r.status, j, ck: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  await req("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "A", geslo: "dolgogeslo123" }); const ck = (await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" })).ck;
  // Resend
  await req("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_dober", od: "HiGiFood <obvestila@higifood.si>" }, ck);
  const g = await req("GET", "/api/nastavitve", null, ck); ok(g.j.nacin === "resend" && g.j.api_kljuc === "********", "ključ API shranjen in skrit");
  let r = await req("POST", "/api/obvestila/test", { komu: "luka@t.si" }, ck);
  const p1 = PREJ.at(-1); ok(r.s === 200 && p1.url === "/emails" && p1.j.from === "HiGiFood <obvestila@higifood.si>" && p1.j.to[0] === "luka@t.si" && /testno/.test(p1.j.subject), "Resend: testno sporočilo poslano prek HTTPS");
  await req("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "********", od: "HiGiFood <obvestila@higifood.si>" }, ck);
  r = await req("POST", "/api/obvestila/test", { komu: "luka@t.si" }, ck); ok(r.s === 200 && PREJ.at(-1).kl === "re_dober", "shranjevanje z »********« obdrži ključ");
  await req("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_napacen", od: "obvestila@higifood.si" }, ck);
  r = await req("POST", "/api/obvestila/test", { komu: "luka@t.si" }, ck); ok(r.s === 400 && /Resend je zavrnil ključ API \(401\)/.test(r.j.napaka), "napačen ključ: 400 z razlago (" + r.j.napaka + ")");
  // Brevo
  kljucOK = "xkeysib"; await req("PUT", "/api/nastavitve", { nacin: "brevo", api_kljuc: "xkeysib", od: "Higi <info@nepotrjena.si>" }, ck);
  r = await req("POST", "/api/obvestila/test", { komu: "luka@t.si" }, ck); ok(r.s === 400 && /Brevo je zavrnil sporočilo \(403\).*not verified/.test(r.j.napaka) && PREJ.at(-1).j.sender.email === "info@nepotrjena.si", "Brevo: nepotrjena domena – 400 z odgovorom ponudnika");
  // SMTP, ki se ne odzove: ~10 s, nato 400 (ne 502 ali visenje); časovnik vtičnice se pod obremenitvijo lahko sproži do ~1 s prej
  await req("PUT", "/api/nastavitve", { nacin: "smtp", streznik: "127.0.0.1", vrata: 4956, varnost: "ssl", uporabnik: "u@t.si", geslo: "x", od: "u@t.si" }, ck);
  const t0 = performance.now(); r = await req("POST", "/api/obvestila/test", { komu: "luka@t.si" }, ck); const ms = Math.round(performance.now() - t0);
  ok(r.s === 400 && /ETIMEDOUT/.test(r.j.napaka) && ms >= 8000 && ms < 16000, "SMTP brez odziva: po ~10 s 400 z ETIMEDOUT (" + ms + " ms): " + r.j.napaka);
  await req("PUT", "/api/nastavitve", { nacin: "smtp", streznik: "127.0.0.1", vrata: 4957, varnost: "ssl", uporabnik: "u@t.si", geslo: "x", od: "u@t.si" }, ck);
  r = await req("POST", "/api/obvestila/test", { komu: "luka@t.si" }, ck); ok(r.s === 400 && /127\.0\.0\.1:4957 ni uspela \(ECONNREFUSED\).*HTTPS API/.test(r.j.napaka), "zaprta vrata: predlog HTTPS API");
  const sis = await req("GET", "/api/sistem", null, ck); const nap = (sis.j.napake || []).map(n => n.sporocilo).join(" | ");
  ok(/E-pošta \(Resend\): Resend je zavrnil ključ/.test(nap) && /E-pošta \(127\.0\.0\.1:4956\).*ETIMEDOUT/.test(nap), "napake e-pošte zapisane v Zadnje napake strežnika");
  r = await req("POST", "/api/obvestila/vrata", { streznik: "localhost" }, ck);
  ok(r.s === 200 && r.j.rezultati.length === 2 && r.j.rezultati.every(x => x.vrata && typeof x.odprta === "boolean"), "preverjanje odhodnih vrat 465 in 587 " + JSON.stringify(r.j.rezultati));
  r = await req("POST", "/api/obvestila/vrata", { streznik: "a b;rm" }, ck); ok(r.s === 400, "neveljavno ime strežnika zavrnjeno");
  api.close(); tiho.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
