// Podatkovna baza SQLite: prenos obstoječih datotek JSON (stara namestitev) brez ponovnega vnosa, zapis samo sprememb,
// kopija v obliki JSON, obnova iz kopije, način JSON kot rezerva, prijava z obstoječim geslom po prenosu.
const fs = require("fs"), os = require("os"), path = require("path"), crypto = require("crypto"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const ROOT = path.join(__dirname, "..");
(async () => {
  const shramba = require("../shramba.js");
  // 1) prenos iz datotek JSON
  const d = fs.mkdtempSync(path.join(os.tmpdir(), "shr-"));
  fs.writeFileSync(path.join(d, "stranke.json"), JSON.stringify([{ id: "s1", naziv: "Prva" }, { id: "s2", naziv: "Druga" }]));
  fs.writeFileSync(path.join(d, "evidence.json"), JSON.stringify(Array.from({ length: 3000 }, (_, i) => ({ id: "e" + i, stranka_id: "s1", vrsta: "temperatura", vrednost: i % 7 }))));
  let S = shramba(d);
  ok(S.nacin === "sqlite", "način: SQLite");
  const st = S.preberi("stranke"), ev = S.preberi("evidence");
  ok(st.length === 2 && st[1].naziv === "Druga" && ev.length === 3000 && ev[2999].id === "e2999", "obstoječe stranke in 3000 evidenc preneseni (vrstni red ohranjen)");
  ok(!fs.existsSync(path.join(d, "stranke.json")) && fs.existsSync(path.join(d, "stranke.json.v-bazi")), "izvirna datoteka ostane kot .v-bazi");
  ev.push({ id: "nov", stranka_id: "s2", vrsta: "x" }); ev[5].vrednost = 99; st.splice(0, 1);
  const t0 = Date.now(); S.zapisi("evidence", ev); S.zapisi("stranke", st); const ms = Date.now() - t0;
  S.zapri(); S = shramba(d);
  const ev2 = S.preberi("evidence"), st2 = S.preberi("stranke");
  ok(ev2.length === 3001 && ev2[5].vrednost === 99 && ev2[3000].id === "nov" && st2.length === 1 && st2[0].id === "s2", "spremembe ohranjene po ponovnem zagonu (dodan, spremenjen, izbrisan zapis; " + ms + " ms)");
  const iz = S.izvozi(); const ie = iz.find(x => x.name === "podatki/evidence.json");
  ok(ie && JSON.parse(ie.data).length === 3001 && iz.some(x => x.name === "podatki/stranke.json"), "kopija vsebuje zbirke v obliki JSON");
  fs.writeFileSync(path.join(d, "stranke.json"), JSON.stringify([{ id: "o", naziv: "Iz kopije" }]));
  ok(S.uvoziDatoteke(["stranke"]) === 1 && S.preberi("stranke")[0].naziv === "Iz kopije", "obnova: datoteka iz kopije zamenja vsebino baze");
  const brez = [{ naziv: "brez id" }, { naziv: "še eden" }]; S.zapisi("_kos", brez); ok(S.preberi("_kos").length === 2, "zapisi brez id se ohranijo");
  S.ponastavi(); ok(S.preberi("evidence").length === 0, "ponastavitev (testni način) izprazni bazo"); S.zapri();
  // 1b) nastavitve in stanja (_nastavitve.json, _narocnine.json …) v bazi, zrcalna datoteka za vrnitev na prejšnjo različico
  const dn = fs.mkdtempSync(path.join(os.tmpdir(), "shrn-")), pn = f => path.join(dn, f);
  fs.writeFileSync(pn("_nastavitve.json"), JSON.stringify({ smtp_host: "posta.si" })); fs.writeFileSync(pn("_seje.json"), "[]");
  let N = shramba(dn);
  ok(N.beri(pn("_nastavitve.json")).smtp_host === "posta.si", "obstoječa datoteka z nastavitvami prenesena v bazo");
  N.pisi(pn("_nastavitve.json"), { smtp_host: "nova.si" }); N.pisi(pn("_umiki.json"), [{ id: "u" }]);
  ok(JSON.parse(fs.readFileSync(pn("_nastavitve.json"), "utf8")).smtp_host === "nova.si", "zrcalna datoteka posodobljena (prejšnja različica jo prebere)");
  let napaka = ""; try { N.beri(pn("_gdpr.json")); } catch (e) { napaka = e.code; } ok(napaka === "ENOENT" && N.beri(pn("_gdpr.json"), 7) === 7, "manjkajoča nastavitev: privzeta vrednost ali napaka kot pri datoteki");
  fs.unlinkSync(pn("_umiki.json")); ok(N.beri(pn("_umiki.json"))[0].id === "u", "podatki so v bazi tudi brez datoteke");
  const izn = N.izvozi().map(x => x.name); ok(izn.includes("podatki/_nastavitve.json") && izn.includes("podatki/_umiki.json") && !izn.includes("podatki/_seje.json"), "kopija: nastavitve iz baze, brez sej " + izn.join(","));
  N.zapri();
  // starejša različica (po vrnitvi) spremeni datoteko → ob ponovni posodobitvi ima prednost
  await new Promise(r => setTimeout(r, 1100)); fs.writeFileSync(pn("_nastavitve.json"), JSON.stringify({ smtp_host: "iz-stare.si" }));
  N = shramba(dn); ok(N.beri(pn("_nastavitve.json")).smtp_host === "iz-stare.si", "datoteka, ki jo je spremenila prejšnja različica, ima prednost pred bazo");
  fs.writeFileSync(pn("_vidnost.json"), JSON.stringify({ privzeto: { x: 1 } })); ok(N.uvoziDatoteke([]) >= 1 && N.beri(pn("_vidnost.json")).privzeto.x === 1, "obnova: nastavitve iz kopije v bazo");
  N.ponastavi(); fs.unlinkSync(pn("_nastavitve.json")); ok(N.beri(pn("_nastavitve.json"), null) === null, "ponastavitev izprazni tudi nastavitve"); N.zapri();
  // 2) rezerva: datoteke JSON
  process.env.HACCP_SHRAMBA = "json"; const dj = fs.mkdtempSync(path.join(os.tmpdir(), "shrj-")); const J = shramba(dj); delete process.env.HACCP_SHRAMBA;
  J.zapisi("stranke", [{ id: "a" }]); ok(J.nacin === "json" && JSON.parse(fs.readFileSync(path.join(dj, "stranke.json"), "utf8"))[0].id === "a", "način JSON (HACCP_SHRAMBA=json) deluje kot prej");
  // 3) cel program: stara namestitev (samo datoteke JSON) → zagon → prijava z obstoječim geslom, stranke so tu
  const data = fs.mkdtempSync(path.join(os.tmpdir(), "shrs-")), pod = path.join(data, "podatki"); fs.mkdirSync(pod, { recursive: true });
  const salt = crypto.randomBytes(16).toString("hex"), hash = salt + ":" + crypto.scryptSync("staro-geslo-123", salt, 64).toString("hex");
  fs.writeFileSync(path.join(pod, "uporabniki.json"), JSON.stringify([{ id: "u1", email: "star@t.si", ime: "Stari admin", vloga: "admin", geslo: hash, aktiven: true, stranke: [] }]));
  fs.writeFileSync(path.join(pod, "stranke.json"), JSON.stringify([{ id: "s9", naziv: "Obstoječa stranka d.o.o.", ustvarjeno: "2026-01-01T00:00:00.000Z" }]));
  const port = 4600 + Math.floor(Math.random() * 300), srv = cp.spawn(process.execPath, [path.join(ROOT, "server.js"), "--tiho"], { env: Object.assign({}, process.env, { PORT: String(port), HACCP_DATA: data, HOST: "127.0.0.1" }), stdio: "ignore" });
  const B = "http://127.0.0.1:" + port; for (let i = 0; i < 50; i++) { try { if ((await fetch(B + "/api/health")).ok) break; } catch {} await new Promise(r => setTimeout(r, 200)); }
  const pr = await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "application/json", Origin: B }, body: JSON.stringify({ email: "star@t.si", geslo: "staro-geslo-123" }) });
  const c = (pr.headers.get("set-cookie") || "").split(";")[0];
  const sl = await (await fetch(B + "/api/d/stranke", { headers: { Cookie: c } })).json();
  ok(pr.status === 200 && Array.isArray(sl) && sl[0].naziv === "Obstoječa stranka d.o.o.", "po posodobitvi: prijava z obstoječim geslom, stranka je tu (brez ponovnega vnosa)");
  const sis = await (await fetch(B + "/api/sistem", { headers: { Cookie: c } })).json();
  ok(/SQLite/.test(sis.shramba) && fs.existsSync(path.join(pod, "haccp.db")), "sistem: " + sis.shramba);
  const kop = Buffer.from(await (await fetch(B + "/api/kopija", { headers: { Cookie: c } })).arrayBuffer());
  ok(kop.includes(Buffer.from("podatki/stranke.json")) && kop.includes(Buffer.from("podatki/uporabniki.json")) && !kop.includes(Buffer.from("haccp.db")), "prenesena kopija: zbirke JSON, brez datoteke baze");
  const pz = await (await fetch(B + "/api/kopija/preizkus", { method: "POST", headers: { Cookie: c, Origin: B } })).json();
  ok(pz.ok, "preizkus obnove uspešen: " + (pz.podrobnosti || [pz.napaka]).slice(0, 2).join("; "));
  srv.kill("SIGTERM"); await new Promise(r => srv.on("exit", r));
  // 4) ponastavitev gesla iz ukazne vrstice deluje z bazo
  const r = cp.spawnSync(process.execPath, [path.join(ROOT, "server.js"), "--ponastavi-geslo"], { env: Object.assign({}, process.env, { HACCP_DATA: data }), input: "star@t.si\nnovo-geslo-4567\nnovo-geslo-4567\n", encoding: "utf8", timeout: 30000 });
  const S3 = shramba(pod), u = S3.preberi("uporabniki")[0]; S3.zapri();
  const [sl2, h2] = u.geslo.split(":"); ok(/spremenjeno/.test(r.stdout) && crypto.scryptSync("novo-geslo-4567", sl2, 64).toString("hex") === h2, "ponastavitev gesla (--ponastavi-geslo) zapiše v bazo");
  // 5) vrnitev na prejšnjo različico (brez baze): --vrni-json zapiše zbirke v datoteke JSON, nova različica jih znova prenese
  const v = cp.spawnSync(process.execPath, [path.join(ROOT, "server.js"), "--vrni-json"], { env: Object.assign({}, process.env, { HACCP_DATA: data }), encoding: "utf8", timeout: 30000 });
  const uj = JSON.parse(fs.readFileSync(path.join(pod, "uporabniki.json"), "utf8")), sj = JSON.parse(fs.readFileSync(path.join(pod, "stranke.json"), "utf8"));
  ok(v.status === 0 && uj[0].geslo === u.geslo && sj[0].naziv === "Obstoječa stranka d.o.o." && !fs.existsSync(path.join(pod, "haccp.db")) && !fs.readdirSync(pod).some(f => /\.v-bazi$/.test(f)), "--vrni-json: uporabniki in stranke v datotekah JSON za prejšnjo različico, baza umaknjena");
  const S4 = shramba(pod); ok(S4.preberi("stranke")[0].naziv === "Obstoječa stranka d.o.o.", "ponovna posodobitev: podatki znova preneseni v bazo"); S4.zapri();
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
