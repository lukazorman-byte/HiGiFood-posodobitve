// Prevzem blaga: več fotografij ob vnosu, stran prevzema s QR kodo, nalepka za tisk, dodajanje fotografij (tudi drug uporabnik prek QR),
// potrjen prevzem samo za odgovorno osebo, tuje fotografije zavrnjene.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; fs.mkdirSync(OUT, { recursive: true });
  const mk = async () => { const p = await (await br.newContext({ acceptDownloads: true })).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const pg = await mk(), foto = path.join(__dirname, "fixtures", "foto.jpg");
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Prevzemna kuhinja d.o.o." }), t = await D.add("stranke", { naziv: "Tuja stranka" });
    await D.add("dobavitelji", { stranka_id: s.id, naziv: "Mesarija Čuk" });
    await api("POST", "/api/uporabniki", { ime: "Zana", email: "zana@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id });
    await api("POST", "/api/uporabniki", { ime: "Odg", email: "odgp@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s.id });
    const tuja = await api("POST", "/api/priloga", { stranka_id: t.id, ime: "x.png", tip: "image/png", podatki: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==" });
    return { s: s.id, tuja: tuja.id };
  });
  // vnos prevzema z dvema fotografijama
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.waitForSelector("#enew"); await pg.click("#enew"); await pg.click("button[data-v=prevzem]"); await pg.waitForSelector("#f_izdelek");
  ok(await pg.locator("#f_rok_uporabe").count() === 1 && await pg.getAttribute("#f_slika", "multiple") !== null, "obrazec prevzema: rok uporabe in več fotografij");
  await pg.selectOption("#f_dobavitelj", { label: "Mesarija Čuk" }).catch(() => pg.selectOption("#f_dobavitelj", "Mesarija Čuk"));
  await pg.fill("#f_izdelek", "Goveje stegno"); await pg.fill("#f_sarza", "LOT-2026-417"); await pg.fill("#f_rok_uporabe", "2026-11-12"); await pg.fill("#f_vrednost", "3,5"); await pg.fill("#f_max", "4");
  await pg.check("#f_embalaza_ok"); await pg.check("#f_dokumenti_ok"); await pg.setInputFiles("#f_slika", [foto, foto]);
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => /^#\/prevzem\//.test(location.hash), null, { timeout: 20000 });
  const pid = await pg.evaluate(() => location.hash.split("/")[2]); await pg.waitForSelector("#pv_qr svg");
  const t = await pg.textContent("#view");
  ok(/LOT-2026-417/.test(t) && /12\. 11\. 2026/.test(t) && /Mesarija Čuk/.test(t) && /3[.,]5 °C/.test(t), "po shranjevanju se odpre stran prevzema s podatki (LOT, rok, dobavitelj, temperatura)");
  ok(await pg.locator("#pv_sl img.thumb").count() === 2, "obe fotografiji sta pri prevzemu");
  ok(await pg.evaluate(id => { const M = QR.encode(location.origin + "/#/prevzem/" + id, "M"); return !!M && document.querySelector("#pv_qr svg path, #pv_qr svg rect") !== null; }, pid), "QR koda prevzema je izrisana");
  // nalepka
  await pg.selectOption("#pv_f", "velike"); await pg.fill("#pv_k", "2");
  const [d] = await Promise.all([pg.waitForEvent("download"), pg.click("#pv_pdf")]); const f = path.join(OUT, "nalepka.pdf"); await d.saveAs(f);
  const tt = cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" });
  if (!tt.error) ok((tt.stdout.match(/Goveje stegno/g) || []).length === 2 && /LOT LOT-2026-417/.test(tt.stdout) && /Skenirajte za podatke prevzema/.test(tt.stdout), "nalepka PDF: 2 kosa, izdelek, LOT, poziv");
  // seznam evidenc: povezava QR
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.waitForSelector(`a[href="#/prevzem/${pid}"]`); ok(true, "v seznamu evidenc je povezava QR pri prevzemu");
  // zaposleni prek QR doda fotografijo
  const z = await mk(); await z.goto(B + "/"); await z.fill("#le", "zana@t.si"); await z.fill("#lp", "dolgogeslo123"); await z.click("#lf button"); await z.waitForSelector("#shell:not([hidden])"); await z.waitForSelector("#dlg[open]"); await z.click("#dlg-f .btn.ghost"); // začasno geslo: »Kasneje«
  await z.goto(B + "/#/prevzem/" + pid); await z.waitForSelector("#pv_up"); await z.setInputFiles("#pv_up", foto); await z.click("#pv_shrani"); await z.waitForSelector(".toast.show:has-text('Dodanih fotografij: 1')");
  await z.waitForFunction(() => document.querySelectorAll("#pv_sl img.thumb").length === 3); ok(true, "zaposleni prek QR strani doda fotografijo (3 skupaj)");
  const rev = await pg.evaluate(async id => { const r = await api("GET", "/api/d/evidence/" + id); return [r.verzija, r.revizije.slice(-1)[0].razlog]; }, pid);
  ok(rev[0] === 2 && /dodane fotografije/.test(rev[1]), "dodajanje fotografij je v zgodovini zapisa (" + rev + ")");
  ok(/ne pripada/.test(await z.evaluate(([id, t]) => api("POST", "/api/d/evidence/" + id + "/slike", { slike: [t] }).then(() => "", e => e.message), [pid, ids.tuja])), "fotografija druge stranke zavrnjena");
  // potrjen prevzem: zaposleni ne more dodajati, odgovorna lahko
  await pg.evaluate(id => api("POST", "/api/d/evidence/_potrdi", { ids: [id] }), pid);
  await z.goto(B + "/#/nadzorna"); await z.goto(B + "/#/prevzem/" + pid); await z.waitForSelector("#pv_qr svg");
  ok(await z.locator("#pv_up").count() === 0 && /potrjen/.test(await z.textContent("#view")), "potrjen prevzem: zaposleni vidi obvestilo, nalaganja ni");
  ok(await z.evaluate(id => api("POST", "/api/d/evidence/" + id + "/slike", { slike: ["x"] }).then(() => 200, e => e.status), pid) === 403, "potrjen prevzem: strežnik zavrne zaposlenega");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
