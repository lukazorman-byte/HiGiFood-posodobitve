// Dodatki k Moji podatki: elektronska odobritev načrta (z geslom, velja do spremembe), stranke brez svetovalca (nadzorna, profil),
// opomnik za nepopolne podatke, letna revizija in pregled po spremembi obrata, poročilo po obisku, mesečni samodejni preizkus obnove, logotip izdelovalca.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const prijava = async (br, email, errs) => { const pg = await (await br.newContext({ acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); await pg.goto(B + "/"); await pg.fill("#le", email); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])"); const k = await pg.waitForSelector("dialog[open] button:has-text('Kasneje')", { timeout: 3000 }).catch(() => null); if (k) { await k.click(); await pg.waitForFunction(() => !document.querySelector("dialog[open]")); } return pg; };
const post = (pg, url, body, method) => pg.evaluate(({ url, body, method }) => fetch(url, { method: method || "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(async x => ({ s: x.status, j: await x.json().catch(() => null) })), { url, body, method });
const pdfNacrta = async (pg, nid, ime) => { const b64 = await pg.evaluate(async nid => { const rec = (await D.list("nacrti")).find(x => x.id === nid), st = (await D.list("stranke")).find(x => x.id === rec.stranka_id), ob = await D.list("obrati", { stranka_id: rec.stranka_id }); await naloziIzdelovalca(rec.stranka_id); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, nid);
  const f = path.join(OUT, ime + ".pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); return { f, t: cp.spawnSync("pdftotext", ["-layout", "-f", "1", "-l", "1", f, "-"], { encoding: "utf8" }).stdout || "" }; };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Admin"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Kavarna Sonce d.o.o." }), s2 = await D.add("stranke", { naziv: "Pekarna Brez d.o.o." }); const o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna Sonce", naprave: [{ ime: "Hladilnik", opis: "" }] });
    const sv = await api("POST", "/api/uporabniki", { email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", ime: "Luka Zorman", stranke: [s.id] });
    await api("POST", "/api/uporabniki", { email: "ana@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", ime: "Ana Kos", stranka_id: s.id }); return { s: s.id, s2: s2.id, o: o.id, sv: sv.id }; });
  // 2: nadzorna plošča administratorja – stranka brez svetovalca
  await pg.goto(B + "/#/stranke"); await pg.goto(B + "/#/nadzorna"); await pg.waitForSelector("#brez_sv");
  const bs = await pg.textContent("#brez_sv"); ok(/1 stranka nima dodeljenega svetovalca/.test(bs) && /Pekarna Brez/.test(bs) && !/Kavarna Sonce/.test(bs), "nadzorna: stranke brez svetovalca " + bs);
  // 3: opomnik za nepopolne Moji podatki (svetovalec brez izobrazbe), po shranjevanju izgine
  const sv = await prijava(br, "sv@t.si", errs); await sv.goto(B + "/#/stranke"); await sv.goto(B + "/#/nadzorna"); await sv.waitForSelector("#mp_opomnik");
  ok(/izobrazba/.test(await sv.textContent("#mp_opomnik")), "opomnik: manjka izobrazba");
  await sv.goto(B + "/#/moji-podatki"); await sv.waitForSelector("#mp_ime"); await sv.fill("#mp_izobrazba", "univ. dipl. inž. živilske tehnologije"); await sv.fill("#mp_podjetje", "Svetovanje Zorman s.p."); await sv.click("#mp_s"); await sv.waitForSelector(".toast.show:has-text('Shranjeno')");
  // 7: logotip izdelovalca (PNG iz platna)
  const lg = await sv.evaluate(async () => { const c = document.createElement("canvas"); c.width = 120; c.height = 40; const g = c.getContext("2d"); g.fillStyle = "#c33"; g.fillRect(0, 0, 120, 40); const d = c.toDataURL("image/png").split(",")[1]; return fetch("/api/izdelovalec-logo/" + ME.u.id, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tip: "image/png", podatki: d }) }).then(r => r.status); });
  ok(lg === 200, "logotip izdelovalca naložen");
  await sv.goto(B + "/#/nadzorna"); await sv.goto(B + "/#/moji-podatki"); await sv.waitForSelector("#ml_del"); ok(true, "Moji podatki: logotip prikazan (gumb Odstrani)");
  await sv.goto(B + "/#/nadzorna"); await sv.waitForTimeout(800); ok(!(await sv.$("#mp_opomnik")), "opomnik izgine po dopolnitvi");
  // drug svetovalec ne more spremeniti tujega logotipa; odgovorna ga lahko bere (ker je svetovalec njene stranke)
  const ana = await prijava(br, "ana@t.si", errs); 
  ok((await ana.evaluate(id => fetch("/api/izdelovalec-logo/" + id).then(r => r.status), ids.sv)) === 200 && (await post(ana, "/api/izdelovalec-logo/" + ids.sv, { tip: "image/png", podatki: "AAAA" })).s === 403, "logotip: odgovorna bere, ne spreminja");
  // 2: profil stranke prikaže svetovalca
  await ana.goto(B + "/#/stranka/" + ids.s + "/podatki"); await ana.waitForSelector("#st_sv"); ok(/Luka Zorman, univ\. dipl\. inž\./.test(await ana.textContent("#st_sv")), "profil stranke: svetovalec");
  // 1: elektronska odobritev
  const nid = await ana.evaluate(o => D.add("nacrti", { naziv: "HACCP Kavarna", obrat_id: o, verzija_oznaka: "1.0", status: "osnutek", vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }], nevarnosti: [], kontrole: {}, zivila: [], zbiranje: {} } }).then(x => x.id), ids.o);
  ok((await post(ana, "/api/potrdi", { zbirka: "nacrti", id: nid, odobritev: true, geslo: "napacno" })).s === 400, "odobritev z napačnim geslom zavrnjena");
  ok((await post(sv, "/api/potrdi", { zbirka: "nacrti", id: nid, odobritev: true, geslo: "dolgogeslo123" })).s === 403, "svetovalec ne odobri namesto odgovorne osebe");
  await ana.evaluate(nid => sessionStorage.setItem("wstep:" + nid, "6"), nid); await ana.goto(B + "/#/carovnik/" + nid); await ana.waitForSelector("#eo_b"); await ana.click("#eo_b"); await ana.fill("#eo_g", "dolgogeslo123"); await ana.click("dialog[open] #dlg-f .btn:last-child");
  await ana.waitForSelector("#eo_st"); ok(/Odobreno elektronsko: Ana Kos/.test(await ana.textContent("#eo_st")), "čarovnik: odobreno elektronsko");
  let p1 = await pdfNacrta(ana, nid, "odobren");
  ok(/Odobreno elektronsko \d+\. \d+\. \d{4}/.test(p1.t) && (p1.t.match(/Podpis: _+/g) || []).length === 1, "naslovnica: elektronska odobritev namesto podpisa\n" + p1.t);
  const slik = f => (cp.spawnSync("pdfimages", ["-list", "-f", "1", "-l", "1", f], { encoding: "utf8" }).stdout || "").trim().split("\n").length - 2;
  ok(slik(p1.f) >= 2, "naslovnica: logotip izdelovalca poleg logotipa HiGiFood (" + slik(p1.f) + " slik)");
  // sprememba načrta: odobritev ni več veljavna
  ok((await post(sv, "/api/d/nacrti/" + nid, { opomba: "dopolnjeno", _razlog: "Dopolnitev" }, "PUT")).s === 200, "svetovalec spremeni načrt");
  const osvezi = async () => { await ana.reload(); await ana.waitForSelector("#shell:not([hidden])"); };
  await osvezi(); p1 = await pdfNacrta(ana, nid, "spremenjen"); ok(!/Odobreno elektronsko/.test(p1.t) && (p1.t.match(/Podpis: _+/g) || []).length === 2, "po spremembi naslovnica spet zahteva podpis");
  await ana.goto(B + "/#/nadzorna"); await ana.goto(B + "/#/carovnik/" + nid); await ana.waitForSelector("#eo_st"); ok(/ni več veljavna/.test(await ana.textContent("#eo_st")), "čarovnik: odobritev ni več veljavna");
  // 4: sprememba naprav obrata → pregled načrta; letna revizija potrjenega načrta
  await pg.evaluate(async ids => { const o = (await D.list("obrati", { stranka_id: ids.s }))[0]; await D.set("obrati", o.id, { naprave: [{ ime: "Hladilnik", opis: "" }, { ime: "Friteza", opis: "" }], _ver: o.spremenjeno || o.ustvarjeno }); }, ids);
  const ob = await pg.evaluate(async ids => (await D.list("obrati", { stranka_id: ids.s }))[0], ids);
  ok(!!ob.sprememba_opreme, "sprememba naprav obrata zabeležena");
  await pg.evaluate(async nid => { const n = (await D.list("nacrti")).find(x => x.id === nid); await D.add("nacrti", { stranka_id: n.stranka_id, naziv: "Star potrjen", status: "potrjeno", potrdil: "Luka Zorman", datum_potrditve: "2025-10-01", verzija_oznaka: "1.0" }); }, nid);
  await pg.reload(); await pg.waitForSelector("#shell:not([hidden])");
  const roki = await pg.evaluate(async () => collectDeadlines(await loadAll()).map(x => x.datum + " " + x.naslov));
  ok(roki.some(t => /^2026-10-01 Letna revizija HACCP načrta: Star potrjen/.test(t)) && roki.some(t => /po spremembi naprav ali prostorov obrata Kavarna Sonce: HACCP Kavarna/.test(t)), "roki: letna revizija in pregled po spremembi obrata " + JSON.stringify(roki.filter(t => /HACCP/.test(t))));
  await osvezi(); await ana.goto(B + "/#/carovnik/" + nid); await ana.waitForSelector("#wbody"); ok(/Naprave ali prostori obrata »Kavarna Sonce« so bili spremenjeni/.test(await ana.evaluate(() => document.body.innerText)), "čarovnik: opozorilo o spremembi obrata");
  // 5: poročilo po obisku (svetovalec, zavihek Inšpekcija)
  await sv.goto(B + "/#/stranka/" + ids.s + "/inspekcija"); await sv.waitForSelector("#i_obisk:not([disabled])"); await sv.click("#i_obisk"); await sv.waitForSelector("#po_p"); await sv.fill("#po_p", "Ana Kos"); await sv.fill("#po_u", "Dopolnite evidence temperatur.\nZamenjajte tesnilo hladilnika."); await sv.fill("#po_n", "2026-12-10");
  const [dl] = await Promise.all([sv.waitForEvent("download"), sv.click("dialog[open] #dlg-f .btn:last-child")]); const fp = path.join(OUT, "obisk.pdf"); await dl.saveAs(fp);
  const tp = cp.spawnSync("pdftotext", ["-layout", fp, "-"], { encoding: "utf8" }).stdout || "";
  ok(/Poročilo o obisku svetovalca/.test(tp) && /Prejel \(odgovorna oseba\)/.test(tp) && /Zamenjajte tesnilo hladilnika/.test(tp) && /Predvideni naslednji obisk: 10\. 12\. 2026/.test(tp) && /Stanje dokumentacije/.test(tp) && /Izdelal: Luka Zorman, univ\. dipl\./.test(tp), "poročilo po obisku (PDF)");
  await sv.waitForSelector(".toast.show:has-text('obisk zabeležen')");
  const st = await sv.evaluate(sid => D.list("storitve", { stranka_id: sid }), ids.s); ok(st.length === 1 && st[0].vrsta === "Obisk na lokaciji" && st[0].naslednji_pregled === "2026-12-10", "obisk zabeležen med storitve");
  // 6: mesečni samodejni preizkus obnove (v testu po 5 s)
  await pg.waitForTimeout(3000); const sis = await pg.evaluate(() => api("GET", "/api/sistem"));
  ok(!sis.opozorila.some(o => /še ni bila preizkušena/.test(o)), "samodejni preizkus obnove opravljen " + JSON.stringify(sis.opozorila));
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
