// Certifikacija in Inšpekcija uporabljata isto oceno področij (ocenaPodrocij): usposobljenost, potrjen HACCP načrt, dobavitelji, oprema.
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Ocene d.o.o." });
    await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja" });
    const os = await D.add("osebje", { stranka_id: s.id, ime: "Ana", higienski_do: "2026-01-01", zdravniski_do: "2030-01-01" });
    const up = await D.add("usposabljanja", { stranka_id: s.id, tema: "HACCP", datum: "2024-01-01", veljavno_do: "2025-01-01" });
    const n = await D.add("nacrti", { stranka_id: s.id, naziv: "Načrt", status: "osnutek" });
    const db = await D.add("dobavitelji", { stranka_id: s.id, naziv: "Mesar", ocena: "pogojno odobren" });
    await D.add("dobavitelji", { stranka_id: s.id, naziv: "Pek", ocena: "odobren" });
    await D.add("oprema", { stranka_id: s.id, naziv: "H1", tip: "hladilnik", naslednji_servis: "2030-01-01" });
    return { s: s.id, os: os.id, up: up.id, n: n.id, db: db.id }; });
  const stanje = async () => {
    await pg.goto(B + "/#/stranka/" + ids.s + "/certifikacija"); await pg.reload(); await pg.waitForSelector("#c_s");
    const cert = await pg.evaluate(() => Object.fromEntries([...document.querySelectorAll("tr")].filter(t => t.querySelector("select[data-k]")).map(t => [t.querySelector("select").dataset.k, t.children[1].textContent.trim()])));
    const pokr = await pg.evaluate(() => +(/(\d+) % pokritosti/.exec(document.body.textContent) || [])[1]);
    const insp = await pg.evaluate(async sid => Object.fromEntries((await inspData({ stranka_id: sid })).check.map(c => [c.p, c.st])), ids.s);
    return { cert, pokr, insp };
  };
  const a = await stanje();
  ok(/^manjka/.test(a.cert.usposabljanja) && /pretečenim izobraževanjem/.test(a.cert.usposabljanja) && /poteklo usposabljanje/.test(a.cert.usposabljanja), "certifikacija: usposobljenost manjka (pretečeno izobraževanje, poteklo usposabljanje): " + a.cert.usposabljanja);
  ok(/^manjka/.test(a.cert.haccp) && /osnutek/.test(a.cert.haccp), "certifikacija: samo osnutek načrta ni »ustrezno«: " + a.cert.haccp);
  ok(/^delno/.test(a.cert.dobavitelji) && /pogojno/.test(a.cert.dobavitelji), "certifikacija: pogojno odobren dobavitelj = delno: " + a.cert.dobavitelji);
  ok(a.insp["Zaposleni: izobraževanje, zdravniški pregled, usposabljanja"] === "bad" && a.insp["Potrjen HACCP načrt"] === "bad" && a.insp["Dobavitelji"] === "warn" && a.insp["Oprema in merilni instrumenti"] === "ok", "inšpekcija: enake ocene (manjka/manjka/delno/ustrezno) " + JSON.stringify(a.insp));
  // popravki podatkov → ustrezno na obeh straneh, pokritost se poveča
  await pg.evaluate(async x => { await D.set("osebje", x.os, { higienski_do: "2030-01-01" }); await D.set("usposabljanja", x.up, { veljavno_do: "2030-01-01" }); await D.set("nacrti", x.n, { status: "potrjeno" }); await D.set("dobavitelji", x.db, { ocena: "odobren" }); }, ids);
  const b = await stanje();
  ok(/^ustrezno/.test(b.cert.usposabljanja) && /^ustrezno/.test(b.cert.haccp) && /^ustrezno/.test(b.cert.dobavitelji) && b.insp["Dobavitelji"] === "ok" && b.insp["Potrjen HACCP načrt"] === "ok" && b.insp["Zaposleni: izobraževanje, zdravniški pregled, usposabljanja"] === "ok", "po popravkih: ustrezno na obeh straneh");
  ok(b.pokr > a.pokr, "pokritost se poveča: " + a.pokr + " % → " + b.pokr + " %");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
