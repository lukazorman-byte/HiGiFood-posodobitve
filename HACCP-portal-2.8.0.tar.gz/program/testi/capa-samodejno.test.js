// Samodejna neskladnost: zapis evidence z odstopanjem odpre neskladnost (CAPA) s korektivnim ukrepom iz HACCP načrta,
// zapis in neskladnost sta povezana, odgovorna oseba in svetovalec prejmeta e-pošto, vse je v revizijski sledi.
const http = require("http");
const B = process.env.BASE;
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pocakaj = async (fn, ms = 5000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (fn()) return true; await new Promise(r => setTimeout(r, 100)); } return false; };
(async () => {
  const POSTA = [];
  const api = http.createServer((q, r) => { let b = ""; q.on("data", c => b += c); q.on("end", () => { POSTA.push(JSON.parse(b || "{}")); r.writeHead(200, { "Content-Type": "application/json" }); r.end('{"id":"1"}'); }); }).listen(4955, "127.0.0.1");
  const req = async (m, p, b, ck) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, ck ? { Cookie: ck } : {}), body: b ? JSON.stringify(b) : undefined }); let j = null; try { j = await r.json(); } catch {} return { s: r.status, j, ck: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  await req("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "Admin", geslo: "dolgogeslo123" }); const ck = (await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" })).ck;
  const st = (await req("POST", "/api/d/stranke", { naziv: "Bistro Pod Lipo d.o.o." }, ck)).j, sid = st.id;
  const ob = (await req("POST", "/api/d/obrati", { stranka_id: sid, naziv: "Kuhinja" }, ck)).j;
  const UKREP = "Živila takoj prestavi v delujoč hladilnik, preveri temperaturo v jedru; nad 8 °C več kot 2 h – zavrzi.";
  const n = await req("POST", "/api/d/nacrti", { stranka_id: sid, obrat_id: ob.id, naziv: "HACCP načrt", status: "osnutek",
    vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }, { id: "k2", naziv: "Skladiščenje v hladilniku" }], nevarnosti: [{ id: "h1", korak_id: "k1" }, { id: "h2", korak_id: "k2" }],
      kontrole: { h1: { vrsta: "OPRP", korektivni: "Zavrni pošiljko." }, h2: { vrsta: "CCP", oznaka: "CCP1", naziv: "Hlajeno skladiščenje", korektivni: UKREP } } } }, ck);
  ok(n.s === 200, "HACCP načrt s kontrolno točko za skladiščenje");
  await req("POST", "/api/uporabniki", { ime: "Olga Odgovorna", email: "o@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: sid }, ck);
  await req("POST", "/api/uporabniki", { ime: "Simon Svetovalec", email: "s@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", stranke: [sid] }, ck);
  await req("POST", "/api/uporabniki", { ime: "Zoran Zaposleni", email: "z@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: sid }, ck);
  await req("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_test", od: "obvestila@higifood.si", naslov_aplikacije: "https://app.higifood.si" }, ck);
  // zaposleni vpiše temperaturo nad mejo
  let zk = (await req("POST", "/api/auth/prijava", { email: "z@t.si", geslo: "dolgogeslo123" })).ck;
  await req("POST", "/api/auth/zamenjaj-geslo", { staro: "dolgogeslo123", novo: "novogeslo12345" }, zk).catch(() => {});
  { const r = await req("POST", "/api/auth/prijava", { email: "z@t.si", geslo: "novogeslo12345" }); if (r.ck) zk = r.ck; }
  let e1 = await req("POST", "/api/d/evidence", { stranka_id: sid, obrat_id: ob.id, vrsta: "temperatura", oprema: "Hladilnik 2", vrednost: 8.5, min: 0, max: 4 }, zk);
  const kdo = e1.s === 200 ? zk : ck; if (e1.s !== 200) { console.log("ok: zaposleni ni mogel vpisati (" + e1.s + "), vpiše administrator"); e1 = await req("POST", "/api/d/evidence", { stranka_id: sid, obrat_id: ob.id, vrsta: "temperatura", oprema: "Hladilnik 2", vrednost: 8.5, min: 0, max: 4 }, ck); }
  ok(e1.s === 200 && e1.j.skladno === false && !!e1.j.capa_id, "odstopanje: zapis dobi povezavo na neskladnost (capa_id)");
  const caps = (await req("GET", "/api/d/capa?stranka_id=" + sid, null, ck)).j, c1 = caps.find(c => c.id === e1.j.capa_id);
  ok(caps.length === 1 && c1 && c1.vir_zapisa === e1.j.id && c1.samodejno === true && c1.status === "odprto", "neskladnost odprta samodejno in povezana z zapisom");
  ok(c1 && c1.takojsnji_ukrep === UKREP && /CCP1/.test(c1.ukrep_vir), "korektivni ukrep iz HACCP načrta (ustrezna faza: skladiščenje, " + (c1 && c1.ukrep_vir) + ")");
  ok(c1 && /izmerjeno 8,5 °C, dovoljeno 0 do 4 °C/.test(c1.opis) && /Hladilnik 2/.test(c1.opis), "opis odstopanja: " + (c1 && c1.opis));
  const jutri = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Ljubljana" }).format(new Date(Date.now() + 864e5));
  ok(c1 && c1.rok === jutri && c1.nujnost === "nujna", "rok ukrepa jutri (" + (c1 && c1.rok) + ")");
  // e-pošta odgovorni osebi in svetovalcu
  ok(await pocakaj(() => POSTA.length >= 2), "poslani 2 e-poštni sporočili (" + POSTA.length + ")");
  const prejemniki = POSTA.map(p => [].concat(p.to)[0]).sort();
  ok(JSON.stringify(prejemniki) === JSON.stringify(["o@t.si", "s@t.si"]), "prejemniki: odgovorna oseba in svetovalec stranke (" + prejemniki.join(", ") + ")");
  const m = POSTA[0] || {};
  ok(/^Odstopanje: Temperatura hladilnika/.test(m.subject || "") && (m.text || "").includes(UKREP) && (m.text || "").includes("https://app.higifood.si/#/neskladnost/" + e1.j.capa_id), "sporočilo: zadeva, korektivni ukrep in povezava");
  // skladen zapis: brez neskladnosti
  const e2 = await req("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 3, min: 0, max: 4 }, kdo);
  ok(e2.s === 200 && e2.j.skladno === true && !e2.j.capa_id, "skladen zapis ne odpre neskladnosti");
  // popravek, ki zapis spremeni v neskladnega: neskladnost se odpre ob popravku
  const e3 = await req("PUT", "/api/d/evidence/" + e2.j.id, { vrednost: 6, _razlog: "napačno prepisana vrednost" }, ck);
  ok(e3.s === 200 && e3.j.skladno === false && !!e3.j.capa_id, "popravek v odstopanje odpre neskladnost");
  // odjemalec ne more prepisati povezave
  const e4 = await req("PUT", "/api/d/evidence/" + e3.j.id, { capa_id: "drugo", opomba: "x", _razlog: "dodana opomba" }, ck);
  ok(e4.s === 200 && e4.j.capa_id === e3.j.capa_id, "povezave na neskladnost ni mogoče prepisati");
  ok((await req("GET", "/api/d/capa?stranka_id=" + sid, null, ck)).j.length === 2, "nov popravek že povezanega zapisa ne odpre druge neskladnosti");
  // korektivni ukrep za fazo, ki je v načrtu ni: neskladnost brez ukrepa
  const e5 = await req("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "toplotna", izdelek: "Piščanec", vrednost: 60, min: 74 }, ck);
  const c5 = (await req("GET", "/api/d/capa?stranka_id=" + sid, null, ck)).j.find(c => c.id === e5.j.capa_id);
  ok(c5 && c5.takojsnji_ukrep === "" && c5.tveganje === "visoko", "brez ukrepa v načrtu: neskladnost brez predlaganega ukrepa, tveganje visoko");
  // stranka z izklopljenimi opomniki: brez e-pošte
  ok(await pocakaj(() => POSTA.length >= 6), "e-pošta za vsako od 3 neskladnosti (" + POSTA.length + " sporočil)"); const pred = POSTA.length;
  // ponovljeno odstopanje na istem hladilniku (24 h): doda se k odprti neskladnosti, brez nove neskladnosti in e-pošte
  const e1b = await req("POST", "/api/d/evidence", { stranka_id: sid, obrat_id: ob.id, vrsta: "temperatura", oprema: "Hladilnik 2", vrednost: 7.8, min: 0, max: 4 }, ck);
  const c1b = (await req("GET", "/api/d/capa?stranka_id=" + sid, null, ck)).j.find(c => c.id === e1.j.capa_id);
  await new Promise(r => setTimeout(r, 600));
  ok(e1b.j.capa_id === e1.j.capa_id && c1b.ponovitve && c1b.ponovitve.length === 1 && /7,8 °C/.test(c1b.ponovitve[0].opis) && POSTA.length === pred, "ponovitev na istem hladilniku: ista neskladnost, brez nove e-pošte");
  // stranka z izklopljenimi opomniki: brez e-pošte
  await req("PUT", "/api/d/stranke/" + sid, { opomniki_izklop: true }, ck);
  const e6 = await req("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "Hladilnik 4", vrednost: 9, min: 0, max: 4 }, ck);
  await new Promise(r => setTimeout(r, 800)); ok(!!e6.j.capa_id && POSTA.length === pred, "izklopljeni opomniki stranke: neskladnost da, e-pošta ne");
  const sl = (await req("GET", "/api/revizijska-sled?n=60", null, ck)).j.vnosi.map(e => e.akcija);
  ok(sl.filter(a => a === "capa-samodejno").length === 4 && sl.includes("capa-ponovitev") && sl.includes("capa-obvestilo"), "revizijska sled: samodejne neskladnosti, ponovitev in obvestila");
  // nastavitve obvestil (Moj račun): svetovalec izklopi odstopanja → dobi jih samo odgovorna oseba
  await req("PUT", "/api/d/stranke/" + sid, { opomniki_izklop: false }, ck);
  const sk = (await req("POST", "/api/auth/prijava", { email: "s@t.si", geslo: "dolgogeslo123" })).ck;
  const no = await req("POST", "/api/auth/opomniki", { pogostost: "dnevno", roki: true, vnosi: true, odstopanja: false, povprasevanja: true }, sk);
  ok(no.s === 200 && no.j.opomniki.odstopanja === false && no.j.opomniki.povprasevanja === true, "svetovalec shrani nastavitve obvestil: " + JSON.stringify(no.j && no.j.opomniki));
  const pred2 = POSTA.length;
  await req("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "Hladilnik 3", vrednost: 10, min: 0, max: 4 }, ck);
  ok(await pocakaj(() => POSTA.length >= pred2 + 1), "odstopanje: e-pošta odgovorni osebi");
  await new Promise(r => setTimeout(r, 600));
  const prej2 = POSTA.slice(pred2).map(p => [].concat(p.to)[0]);
  ok(prej2.length === 1 && prej2[0] === "o@t.si", "svetovalec z izklopljenimi odstopanji ne dobi e-pošte (" + prej2.join(", ") + ")");
  // povpraševanje s spletne strani: naslov izdajatelja + svetovalec, ki je obvestila vklopil; odgovorna oseba jih ne more vklopiti
  const oo = await req("POST", "/api/auth/prijava", { email: "o@t.si", geslo: "dolgogeslo123" });
  const on = await req("POST", "/api/auth/opomniki", { pogostost: "dnevno", povprasevanja: true }, oo.ck);
  ok(on.s === 200 && on.j.opomniki.povprasevanja === false, "odgovorna oseba ne more vklopiti obvestil o povpraševanjih");
  const pred3 = POSTA.length;
  const pv = await req("POST", "/api/javno/povprasevanje", { ime: "Ana Kupec", email: "ana@kupec.si", podjetje: "Okrepčevalnica Ana", sporocilo: "Zanima me paket Standard.", soglasje: true });
  ok(pv.s === 200, "povpraševanje oddano");
  ok(await pocakaj(() => POSTA.slice(pred3).some(p => [].concat(p.to)[0] === "s@t.si")), "svetovalec z vklopljenimi povpraševanji dobi e-pošto");
  await new Promise(r => setTimeout(r, 400));
  ok(!POSTA.slice(pred3).some(p => [].concat(p.to)[0] === "o@t.si"), "odgovorna oseba ne dobi povpraševanja");
  // zaščita pred poplavo: največ 10 obvestil o odstopanjih na stranko na uro (neskladnosti se odprejo vse)
  for (let i = 0; i < 9; i++) await req("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "Naprava " + i, vrednost: 12, min: 0, max: 4 }, ck);
  await new Promise(r => setTimeout(r, 800));
  const sl2 = (await req("GET", "/api/revizijska-sled?n=200", null, ck)).j.vnosi.map(e => e.akcija);
  const odp = (await req("GET", "/api/d/capa?stranka_id=" + sid, null, ck)).j.filter(c => /Naprava \d/.test(c.opis)).length;
  ok(odp === 9 && sl2.filter(a => a === "capa-obvestilo").length === 10 && sl2.includes("capa-obvestilo-omejeno"), "največ 10 obvestil o odstopanjih na uro, neskladnosti se odprejo vse (" + odp + ", obvestil " + sl2.filter(a => a === "capa-obvestilo").length + ")");
  api.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
