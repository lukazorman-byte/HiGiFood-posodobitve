// Čarovnik HACCP – celoten potek na »HACCP – Božični liker (test)« (stranka Moj Likerček): predloga za liker, preimenovanje in premik
// korakov (puščice in vlečenje), sprotni diagram, ročno shranjevanje z osvežitvijo različice, nevarnosti ostanejo na svojih korakih
// (tudi po ponovnem nalaganju), izbris koraka s prestavitvijo / izbrisom / označitvijo nevarnosti, skupna prestavitev, enoten status,
// CCP1/CCP2 po vrstnem redu korakov v koraku 5, diagramu in izvozu PDF, postavitev seznam levo – diagram desno.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1360, height: 900 } })).newPage();
  pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Moj Likerček d.o.o.", odgovorna_oseba: "Ana Novak" }); const o = await D.add("obrati", { stranka_id: s.id, naziv: "Destilarna" }); const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP – Božični liker (test)", verzija_oznaka: "1.0", status: "osnutek", vsebina: {} }); return { s: s.id, n: n.id }; });
  const vsebina = () => pg.evaluate(async id => (await api("GET", "/api/d/nacrti/" + id)).vsebina, ids.n);
  // korak, na katerem je posamezna nevarnost (po imenu koraka)
  const vezave = W => Object.fromEntries(W.nevarnosti.map(h => [h.nevarnost, (W.koraki.find(k => k.id === h.korak_id) || {}).naziv || "(brez koraka)"]));
  const korak = n => pg.click(`.stepper button >> nth=${n}`);
  await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector(".stepper");
  ok(await pg.evaluate(() => { const b = [...document.querySelectorAll(".stepper button")].map(x => x.getBoundingClientRect().top); return new Set(b.map(Math.round)).size === 1; }), "koračnik v eni vrsti (7 korakov)");
  // 1) predloga za liker
  await korak(1); await pg.waitForSelector("#wb"); await pg.selectOption("#wb", "liker"); await pg.click("#wload"); await pg.waitForSelector("#klist .krow");
  let W = null; await pg.click("#wsave"); await pg.waitForSelector(".toast.show"); W = await vsebina();
  const prvotno = vezave(W), kor0 = W.koraki.map(k => k.naziv);
  ok(W.koraki.length === 9 && W.nevarnosti.length >= 10 && W.nevarnosti.every(h => W.koraki.some(k => k.id === h.korak_id)), `predloga liker: ${W.koraki.length} korakov, ${W.nevarnosti.length} nevarnosti, vse vezane na ID koraka`);
  // 2) korak 3: postavitev, preimenovanje, premik s puščico in z vlečenjem, sprotni diagram
  await korak(2); await pg.waitForSelector(".krow");
  const bx = await pg.evaluate(() => { const a = document.querySelector("#klist").getBoundingClientRect(), b = document.querySelector("#kflow").getBoundingClientRect(); return [a.left, a.right, b.left]; });
  ok(bx[2] >= bx[1] - 1, "širok zaslon: seznam korakov levo, diagram desno");
  const iMac = kor0.findIndex(x => /Maceracija/.test(x)); const imeMac = kor0[iMac];
  await pg.locator(".krow input[data-k=naziv]").nth(iMac).fill("Maceracija sadja in začimb");
  ok(/Maceracija sadja in začimb/.test(await pg.textContent("#kflow")), "diagram se osveži sproti ob preimenovanju");
  await pg.locator(".krow input[data-k=naziv]").nth(iMac).press("Tab");
  await pg.click(`[data-up="${iMac}"]`); await pg.waitForSelector(".krow");
  const red1 = await pg.$$eval(".krow input[data-k=naziv]", i => i.map(x => x.value));
  ok(red1[iMac - 1] === "Maceracija sadja in začimb" && (await pg.textContent("#kflow")).indexOf("Maceracija sadja") < (await pg.textContent("#kflow")).indexOf(kor0[iMac - 1]), "premik s puščico ↑: seznam in diagram v novem vrstnem redu");
  // vlečenje: zadnji korak na prvo mesto
  await pg.evaluate(() => { const r = [...document.querySelectorAll(".krow")], dt = new DataTransfer(); r[r.length - 1].dispatchEvent(new DragEvent("dragstart", { dataTransfer: dt, bubbles: true })); r[0].dispatchEvent(new DragEvent("dragover", { dataTransfer: dt, bubbles: true, cancelable: true })); r[0].dispatchEvent(new DragEvent("drop", { dataTransfer: dt, bubbles: true, cancelable: true })); });
  const red2 = await pg.$$eval(".krow input[data-k=naziv]", i => i.map(x => x.value));
  ok(red2[0] === kor0[kor0.length - 1] && /^1\. /.test((await pg.$$eval("#kflow .n", n => n.map(x => x.textContent)))[0]) && (await pg.$$eval("#kflow .n", n => n[0].textContent)).includes(kor0[kor0.length - 1]), "premik z vlečenjem: zadnji korak je prvi (tudi v diagramu)");
  // 3) ročno shranjevanje: oznaka različice se osveži takoj
  const v0 = await pg.textContent("#wver"); await pg.click("#wsave"); await pg.waitForFunction(v => document.querySelector("#wver").textContent !== v, v0);
  ok(true, "ročno shranjevanje osveži oznako različice takoj (" + v0.trim() + " → " + (await pg.textContent("#wver")).trim() + ")");
  // 4) po ponovnem nalaganju: nevarnosti na istih (preimenovanih, premaknjenih) korakih
  await pg.reload(); await pg.waitForSelector(".stepper"); W = await vsebina(); const zdaj = vezave(W);
  const pricak = Object.fromEntries(Object.entries(prvotno).map(([n, k]) => [n, k === imeMac ? "Maceracija sadja in začimb" : k]));
  ok(JSON.stringify(zdaj) === JSON.stringify(pricak), "nevarnosti ostanejo na pravih korakih po preimenovanju in premiku (tudi po ponovnem nalaganju)");
  ok(W.nevarnosti.every(h => !h.preveri_korak), "preimenovanje in premik ne označita nevarnosti za preverjanje");
  // 5) izbris koraka: prestavi nevarnosti na drug korak
  await korak(2); await pg.waitForSelector(".krow");
  const vez = n => Object.entries(vezave(W)).filter(([, k]) => k === n).map(([h]) => h);
  const kIzb = W.koraki.find(k => vez(k.naziv).length && k.naziv !== "Maceracija sadja in začimb"), hsIzb = vez(kIzb.naziv), iIzb = W.koraki.indexOf(kIzb);
  await pg.click(`[data-x="${iIzb}"]`); await pg.waitForSelector("input[name=kx]");
  ok(/Kaj naj se zgodi/.test(await pg.textContent("dialog[open]")) && await pg.locator("input[name=kx]").count() === 3, "izbris koraka: izbira prestavi / pusti za preverjanje / izbriši");
  await pg.selectOption("#kx_k", { label: (await pg.$$eval("#kx_k option", o => o.map(x => x.textContent))).find(t => /Maceracija sadja/.test(t)) });
  ok(await pg.isChecked("input[name=kx][value=prestavi]"), "izbira ciljnega koraka označi »prestavi«");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('prestavljenih')");
  await pg.click("#wsave"); await pg.waitForSelector(".toast.show"); W = await vsebina();
  ok(hsIzb.every(h => vezave(W)[h] === "Maceracija sadja in začimb") && hsIzb.every(h => { const x = W.nevarnosti.find(y => y.nevarnost === h); return x.urejeno && !x.potrjeno; }), `prestavljenih ${hsIzb.length} nevarnosti na »Maceracija sadja in začimb«, status »uredil uporabnik – potrdi«`);
  // 6) izbris koraka z izbrisom nevarnosti
  const kIz2 = W.koraki.find(k => vez(k.naziv).length && k.naziv !== "Maceracija sadja in začimb"); const hsIz2 = vez(kIz2.naziv);
  await pg.click(`[data-x="${W.koraki.indexOf(kIz2)}"]`); await pg.waitForSelector("input[name=kx]"); await pg.check("input[name=kx][value=izbrisi]"); await pg.click("dialog[open] #dlg-f .btn:last-child");
  await pg.click("#wsave"); await pg.waitForSelector(".toast.show"); W = await vsebina();
  ok(hsIz2.every(h => !W.nevarnosti.some(x => x.nevarnost === h)), "izbris koraka z izbrisom nevarnosti (" + hsIz2.length + ")");
  // 7) izbris koraka »pusti za preverjanje« in skupna prestavitev iz opozorila v koraku 4
  const kIz3 = W.koraki.find(k => vez(k.naziv).length && k.naziv !== "Maceracija sadja in začimb"); const hsIz3 = vez(kIz3.naziv);
  await pg.click(`[data-x="${W.koraki.indexOf(kIz3)}"]`); await pg.waitForSelector("input[name=kx]"); await pg.click("dialog[open] #dlg-f .btn:last-child");
  await pg.waitForSelector("#kb_pr"); ok(/vezan/.test(await pg.textContent("#k_prev")), "korak 3: opozorilo »… vezanih na spremenjen ali izbrisan korak – preverite«");
  await korak(3); await pg.waitForSelector("#hb_pr"); const brezK = await pg.locator("tr[data-h]:has(.badge:has-text('korak spremenjen – preveri'))").count(); ok(brezK === hsIz3.length && await pg.locator(".badge:has-text('brez koraka')").count() === 1, "korak 4: " + hsIz3.length + " nevarnosti označenih za preverjanje, združenih pod »brez koraka« (" + brezK + ")");
  await pg.selectOption("#hb_k", { index: 0 }); const cilj = await pg.$eval("#hb_k", s => s.options[s.selectedIndex].textContent.replace(/^\d+\. /, ""));
  await pg.click("#hb_pr"); await pg.waitForSelector(".toast.show:has-text('prestavljen')");
  ok(!(await pg.$("#hb_pr")) && await pg.locator(".badge:has-text('brez koraka')").count() === 0, "skupna prestavitev: ni več nevarnosti brez koraka (na »" + cilj + "«)");
  // 8) enoten status: ročno dodana brez kljukice ni potrjena
  await pg.click("#hadd"); await pg.selectOption("[data-k=korak_id]", { index: 1 }); await pg.fill("[data-k=nevarnost]", "Kumarin iz cejlonskega cimeta (ročno)"); await pg.click("#dlg-f .btn:last-child");
  ok(await pg.locator("tr:has-text('Kumarin iz cejlonskega cimeta (ročno)') .badge:has-text('nepotrjeno')").count() === 1, "ročno dodana nevarnost brez kljukice: nepotrjeno");
  // ocena in potrditev: dve visoki tveganji na različnih korakih → CCP
  W = await (async () => { await pg.click("#wsave"); await pg.waitForSelector(".toast.show"); return vsebina(); })();
  const poRedu = W.nevarnosti.slice().sort((a, b) => W.koraki.findIndex(k => k.id === a.korak_id) - W.koraki.findIndex(k => k.id === b.korak_id));
  const prva = poRedu[0], zadnja = poRedu.filter(h => h.korak_id !== prva.korak_id).pop();
  for (const h of [zadnja, prva]) { await pg.click(`tr[data-h="${h.id}"]`); await pg.selectOption("[data-k=verjetnost]", "3"); await pg.selectOption("[data-k=teza]", "5"); await pg.check("[data-k=potrjeno]"); await pg.click("#dlg-f .btn:last-child"); }
  ok(await pg.locator(`tr[data-h="${prva.id}"] .badge:has-text('potrjeno')`).count() === 1, "s kljukico: potrjeno");
  // 9) korak 5: CCP po vrstnem redu korakov (CCP1 na prejšnjem koraku), značke, drevo na vrhu
  await korak(4); await pg.waitForSelector("tr[data-h]");
  for (const h of [zadnja, prva]) { await pg.click(`tr[data-h="${h.id}"] [data-o]`); await pg.waitForSelector("[data-k=vrsta]"); ok(await pg.locator("details.odl-drevo[open]").count() === 1, "dialog ukrepa: odločitveno drevo odprto"); await pg.selectOption("[data-k=vrsta]", "CCP"); await pg.fill("[data-k=mejna]", "metanol ≤ 30 g/hl a.a."); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(150); }
  // številka se zaklene ob potrditvi ukrepa (prvi potrjeni = CCP1), »Preštevilči« jih s predogledom uredi po vrstnem redu korakov
  ok(await pg.locator(`tr[data-h="${zadnja.id}"] .badge:has-text('CCP1')`).count() === 1 && await pg.locator(`tr[data-h="${prva.id}"] .badge:has-text('CCP2')`).count() === 1, "številka zaklenjena ob potrditvi (prvi potrjeni ukrep = CCP1)");
  await pg.click("#prest"); await pg.waitForSelector("#prest_t"); ok((await pg.$$("#prest_t tr")).length === 3, "Preštevilči: predogled dveh sprememb");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('Preštevilčeno')");
  ok(await pg.locator(`tr[data-h="${prva.id}"] .badge:has-text('CCP1')`).count() === 1 && await pg.locator(`tr[data-h="${zadnja.id}"] .badge:has-text('CCP2')`).count() === 1, "po preštevilčenju: CCP1 pred CCP2 po vrstnem redu korakov");
  await korak(2); await pg.waitForSelector("#kflow"); const fl = await pg.textContent("#kflow"); ok(/CCP1/.test(fl) && /CCP2/.test(fl) && fl.indexOf("CCP1") < fl.indexOf("CCP2"), "diagram: CCP1 in CCP2");
  // 10) izvoz PDF: oštevilčeni CCP
  await pg.click("#wsave"); await pg.waitForSelector(".toast.show");
  const b64 = await pg.evaluate(async id => { const rec = await api("GET", "/api/d/nacrti/" + id), st = (await D.list("stranke")).find(x => x.id === rec.stranka_id), ob = await D.list("obrati", { stranka_id: rec.stranka_id }); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, ids.n);
  const f = path.join(OUT, "bozicni-liker.pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = cp.spawnSync("pdftotext", ["-layout", f, "-"], { encoding: "utf8" }).stdout || "";
  ok(/CCP1/.test(t) && /CCP2/.test(t) && /Maceracija sadja in začimb/.test(t) && /HACCP – Božični liker \(test\)/.test(t), "izvoz PDF: CCP1, CCP2, preimenovan korak, naslov načrta");
  if (process.env.KOPIJA) fs.copyFileSync(f, process.env.KOPIJA);
  // 11) korak 6: brez tipkarske napake
  await korak(5); await pg.waitForSelector("#wbody .card"); ok(!/neprevrjen/.test(await pg.textContent("#wbody")), "korak 6: »nepreverjenih« (brez tipkarske napake)");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
