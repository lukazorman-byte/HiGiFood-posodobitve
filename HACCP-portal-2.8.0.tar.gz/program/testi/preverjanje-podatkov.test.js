// Preverjanje obstoječih podatkov (Vzdrževanje): zapisi, shranjeni pred uvedbo pravil (simulirano z obnovo kopije),
// se izpišejo z razlogom in povezavo na razdelek stranke; opozorilo za nepreverjene predpise na nadzorni plošči.
const zlib = require("zlib"), B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const crc = b => { let c = ~0; for (const x of b) { c ^= x; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1; } return ~c >>> 0; };
// kopija je zip brez stiskanja: preberi datoteke in jih spet zapiši
const zipBeri = buf => { const out = []; let i = 0; while (buf.readUInt32LE(i) === 0x04034b50) { const n = buf.readUInt16LE(i + 26), e = buf.readUInt16LE(i + 28), sz = buf.readUInt32LE(i + 18), name = buf.subarray(i + 30, i + 30 + n).toString(); out.push({ name, data: buf.subarray(i + 30 + n + e, i + 30 + n + e + sz) }); i += 30 + n + e + sz; } return out; };
const zipPisi = files => { const loc = [], cen = []; let off = 0; for (const f of files) { const nm = Buffer.from(f.name), c = crc(f.data), h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt32LE(c, 14); h.writeUInt32LE(f.data.length, 18); h.writeUInt32LE(f.data.length, 22); h.writeUInt16LE(nm.length, 26); loc.push(h, nm, f.data); const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt32LE(c, 16); ch.writeUInt32LE(f.data.length, 20); ch.writeUInt32LE(f.data.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt32LE(off, 42); cen.push(ch, nm); off += 30 + nm.length + f.data.length; } const cd = Buffer.concat(cen), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16); return Buffer.concat([...loc, cd, end]); };
void zlib;
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Stari podatki d.o.o." }); await D.add("oprema", { stranka_id: s.id, naziv: "Stari hladilnik", tip: "hladilnik", meja_min: 0, meja_max: 4 }); await D.add("dogodki", { stranka_id: s.id, naslov: "Obisk", datum: "2026-12-01", ura: "10:00" }); return s.id; });
  let r = await pg.evaluate(() => api("GET", "/api/sistem/preverjanje-podatkov")); ok(r.zapisov === 0, "veljavni podatki: brez napak");
  // simulacija starih podatkov: kopija z zapisi, ki jih današnja pravila zavrnejo
  const kop = Buffer.from(await pg.evaluate(async () => { const b = new Uint8Array(await (await fetch("/api/kopija")).arrayBuffer()); let s = ""; for (const c of b) s += String.fromCharCode(c); return btoa(s); }), "base64");
  const files = zipBeri(kop).map(f => { if (f.name === "podatki/oprema.json") { const a = JSON.parse(f.data); a[0].meja_min = 8; a[0].meja_max = 2; a[0].interval_dni = -5; return { name: f.name, data: Buffer.from(JSON.stringify(a)) }; } if (f.name === "podatki/dogodki.json") { const a = JSON.parse(f.data); a[0].ura = "25:99"; return { name: f.name, data: Buffer.from(JSON.stringify(a)) }; } return f; });
  ok(await pg.evaluate(b64 => fetch("/api/obnovi", { method: "POST", headers: { "Content-Type": "text/plain" }, body: b64 }).then(x => x.status), zipPisi(files).toString("base64")) === 200, "obnova kopije s starimi (napačnimi) podatki");
  r = await pg.evaluate(() => api("GET", "/api/sistem/preverjanje-podatkov"));
  const op = r.napake.find(x => x.zbirka === "oprema"), dg = r.napake.find(x => x.zbirka === "dogodki");
  ok(r.zapisov === 2 && op && op.stranka === "Stari podatki d.o.o." && op.napake.some(t => /Dovoljeno do/.test(t)) && op.napake.some(t => /celo število/.test(t)) && dg && /HH:MM/.test(dg.napake[0]), "poročilo: oprema (meje, interval) in dogodek (ura) " + JSON.stringify(r.napake));
  await pg.goto(B + "/#/vzdrzevanje"); await pg.waitForSelector("#pp_b"); await pg.click("#pp_b"); await pg.waitForSelector("#pp_r table");
  ok(/2 zapisa ne ustrezata/.test(await pg.textContent("#pp_r")) && await pg.getAttribute("#pp_r a[href*='/oprema']", "href") === "#/stranka/" + sid + "/oprema", "Vzdrževanje: seznam z razlogi in povezavo na razdelek stranke");
  // predpisi brez preverjanja v zadnjih 12 mesecih: opozorilo v stanju sistema
  const fs = require("fs"), zp = require("path").join(process.env.TMP, "baza", "zakonodaja.json");
  // izhodišče: predpisi v bazi, ki še niso preverjeni (npr. na novo dodani brez datuma preverjanja), nato še dva neveljavno preverjena
  const star = z => z.status !== "razveljavljen" && (!z.preverjeno || Date.now() - new Date(z.preverjeno).getTime() > 365 * 864e5);
  let pricak = 0; if (fs.existsSync(zp)) { const z = JSON.parse(fs.readFileSync(zp, "utf8")); const i = z.findIndex(x => !star(x)), j = z.findIndex((x, k) => k > i && !star(x)); z[i].preverjeno = "2024-01-01"; z[j].preverjeno = ""; pricak = z.filter(star).length; fs.writeFileSync(zp, JSON.stringify(z)); }
  const mn = n => { const m = n % 100; return m === 1 ? " predpis" : m === 2 ? " predpisa" : m === 3 || m === 4 ? " predpisi" : " predpisov"; };
  const st = await pg.evaluate(() => api("GET", "/api/sistem"));
  ok(fs.existsSync(zp) && pricak >= 2 && (st.opozorila || []).some(t => t.startsWith(pricak + mn(pricak) + " v bazi znanja (preverjeno pred več kot 12 meseci")), "opozorilo za nepreverjene predpise " + JSON.stringify(st.opozorila));
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
