// Tloris: napisi se ne prekrivajo, se umaknejo napravam, se prelomijo in ostanejo v svojem okvirju (prostor, naprava).
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), pg = await (await br.newContext()).newPage(); const errs = []; pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const T = { sirina_m: 12, visina_m: 7, elementi: [
    { id: "s1", t: "soba", x: 0, y: 0, w: 6, h: 4, ime: "Kuhinja in topla priprava jedi", tip: "kuhinja / priprava" },
    { id: "s2", t: "soba", x: 6, y: 0, w: 2.5, h: 4, ime: "Skladišče suhih živil in embalaže", tip: "skladišče" },
    { id: "s4", t: "soba", x: 0, y: 4, w: 12, h: 3, ime: "Jedilnica", tip: "drugo" },
    { id: "o1", t: "oprema", x: 2.2, y: 1.6, w: 1.6, h: 0.8, ikona: "delovna miza", ime: "Delovna miza iz nerjavnega jekla" }, // čez sredino kuhinje (ime prostora)
    { id: "o2", t: "oprema", x: 0.25, y: 0.25, w: 0.7, h: 0.7, ikona: "hladilnik", ime: "Hladilnik za mlečne izdelke" },
    { id: "o5", t: "oprema", x: 3, y: 5.2, w: 2, h: 0.8, ikona: "drugo", ime: "Točilni pult" },
    { id: "b1", t: "besedilo", x: 3.1, y: 5.6, text: "Vhod za goste", vel: 14 }, // naprava čez besedilo
    { id: "b2", t: "besedilo", x: 6.2, y: 3.5, text: "Temperatura do 20 °C, vsak dan preveri in zapiši v evidenco", vel: 13 } ] }; // daljše od prostora
  await pg.setContent(`<body style="margin:0">${await pg.evaluate(t => tlorisSvg(t, {}), T)}</body>`);
  const R = await pg.evaluate(() => { const S = 50, bb = el => { const b = el.getBBox(); return { x: b.x / S, y: b.y / S, w: b.width / S, h: b.height / S }; };
    const t = {}; for (const el of document.querySelectorAll("text[data-nid]")) (t[el.dataset.nid] = t[el.dataset.nid] || []).push(Object.assign(bb(el), { s: el.textContent })); return t; });
  const pres = (a, b) => Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  const v = (a, o, d = 0.02) => a.x >= o.x - d && a.y >= o.y - d && a.x + a.w <= o.x + o.w + d && a.y + a.h <= o.y + o.h + d;
  const el = id => T.elementi.find(e => e.id === id), opr = T.elementi.filter(e => e.t === "oprema");
  for (const id of ["s1", "s2", "s4"]) ok(R[id].every(r => v(r, el(id))), "ime prostora " + id + " ostane v prostoru: " + R[id].map(r => r.s).join(" | "));
  ok(R.s2.length >= 3, "dolgo ime ozkega prostora je prelomljeno (" + R.s2.length + " vrstice)");
  for (const id of ["o1", "o2", "o5"]) ok(R[id].every(r => v(r, el(id), 0.03)), "napis naprave " + id + " ostane v napravi: " + R[id].map(r => r.s).join(" | "));
  ok(R.o1.length >= 2 && R.o2.length >= 2, "dolgo ime naprave je prelomljeno");
  ok(["s1", "s4", "b1", "b2"].every(id => R[id].every(r => opr.every(o => pres(r, o) < 0.001))), "napisi prostorov in besedila se umaknejo napravam");
  ok(R.b2.length >= 2 && R.b2.every(r => v(r, el("s2"))), "predolgo besedilo se prelomi in ostane v prostoru, kamor je postavljeno");
  const vsi = Object.entries(R).flatMap(([id, rs]) => rs.map(r => Object.assign({ id }, r))); let prek = 0;
  for (let i = 0; i < vsi.length; i++) for (let j = i + 1; j < vsi.length; j++) if (vsi[i].id !== vsi[j].id && pres(vsi[i], vsi[j]) > 0.001) prek++;
  ok(prek === 0, "napisi se med seboj ne prekrivajo (prekrivanj: " + prek + ")");
  ok(T.elementi.find(e => e.id === "b1").x === 3.1, "položaj besedila v podatkih ostane nespremenjen");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
