// E-poštni opomniki: nastavitev pogostosti in vrst za uporabnika (Moj račun), izklop po stranki, sporočilo po skupinah.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const mk = async () => { const p = await (await br.newContext()).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Opomnik d.o.o." });
    await D.add("osebje", { stranka_id: s.id, ime: "Ana Kuharica", higienski_do: new Date(Date.now() - 5 * 864e5).toLocaleDateString("sv-SE", { timeZone: "Europe/Ljubljana" }) });
    await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", naprava: "Hladilnik 1", frekvenca_ur: 24 });
    for (const [ime, email, vloga] of [["Olga", "o@t.si", "odgovorna"], ["Sven", "s@t.si", "svetovalec"]]) await api("POST", "/api/uporabniki", { ime, email, geslo: "dolgogeslo123", vloga, stranka_id: vloga === "odgovorna" ? s.id : null, stranke: vloga === "svetovalec" ? [s.id] : [] });
    return s.id;
  });
  const pred = async () => { const r = await pg.evaluate(() => api("POST", "/api/obvestila/zdaj", {})); return Object.fromEntries(r.predogled.map(x => [x.komu, x])); };
  let p = await pred();
  ok(p["o@t.si"] && /ROKI V ZAMUDI \(1\)/.test(p["o@t.si"].besedilo) && /MANJKAJOČI VNOSI EVIDENC \(1\)/.test(p["o@t.si"].besedilo) && /zamuda 5 d/.test(p["o@t.si"].besedilo) && /Manjka vnos »Temperatura hladilnika \/ zamrzovalnika« – Hladilnik 1/.test(p["o@t.si"].besedilo) && /Moj račun/.test(p["o@t.si"].besedilo), "sporočilo po skupinah: roki v zamudi, manjkajoči vnosi (ime vrste evidence), navodilo za nastavitev");
  ok(p["s@t.si"] && p["s@t.si"].postavk === 2 && p["o@t.si"].pogostost === "dnevno", "svetovalec prejme opomnike svoje stranke; privzeto dnevno");
  // odgovorna oseba: tedensko, brez manjkajočih vnosov (Moj račun)
  const o = await mk(); await o.goto(B + "/"); await o.fill("#le", "o@t.si"); await o.fill("#lp", "dolgogeslo123"); await o.click("#lf button"); await o.waitForSelector("#shell:not([hidden])");
  await o.waitForSelector("#p0"); await o.fill("#p0", "dolgogeslo123"); await o.fill("#p1", "novogeslo12345"); await o.click("#dlg-f .btn:last-child"); await o.waitForFunction(() => !document.querySelector("dialog[open]"));
  await o.click("#whoami"); await o.waitForSelector("#op_p"); ok(await o.inputValue("#op_p") === "dnevno" && await o.isChecked("#op_v"), "Moj račun: nastavitve opomnikov (privzeto dnevno, vse vrste)");
  await o.selectOption("#op_p", "tedensko"); await o.uncheck("#op_v"); await o.click("#op_s"); await o.waitForSelector(".toast.show:has-text('obvestil')");
  p = await pred(); ok(p["o@t.si"].pogostost === "tedensko" && p["o@t.si"].postavk === 1 && !/MANJKAJOČI/.test(p["o@t.si"].besedilo), "odgovorna: tedensko, brez manjkajočih vnosov");
  await o.reload(); await o.waitForSelector("#shell:not([hidden])"); await o.click("#whoami"); await o.waitForSelector("#op_p"); ok(await o.inputValue("#op_p") === "tedensko" && !(await o.isChecked("#op_v")), "nastavitev ostane po ponovni prijavi");
  const ne = await o.evaluate(async id => { try { await D.set("stranke", id, { opomniki_izklop: true }); } catch (e) { return e.message; } return (await D.list("stranke"))[0].opomniki_izklop; }, sid);
  ok(ne !== true, "odgovorna ne more izklopiti opomnikov stranke (" + ne + ")");
  const bad = await o.evaluate(() => api("POST", "/api/auth/opomniki", { pogostost: "vsako-uro" }).then(() => "sprejeto", e => e.message)); ok(/Neveljavna/.test(bad), "neveljavna pogostost zavrnjena");
  // svetovalec: izklop za stranko v obrazcu stranke
  await pg.evaluate(async id => openForm("stranke", (await D.list("stranke")).find(x => x.id === id), null, () => {}), sid); await pg.waitForSelector("#f_opomniki_izklop");
  await pg.check("#f_opomniki_izklop"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  p = await pred(); ok(!p["o@t.si"] && !p["s@t.si"], "izklop za stranko: nihče ne prejme opomnikov te stranke");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
