// Sklop D – uporabnost: razlog ob shranjevanju po spremembi naprav/prostorov obrata (lastno okno, zgodovina, pas se skrije),
// SKD, pravna oblika in nosilec s.p. iz registra po davčni številki, opozorilo za več odgovornih oseb pri s.p.,
// lastna okna namesto window.confirm/alert/prompt.
const B = process.env.BASE; const { chromium } = require("./pw.js"), fs = require("fs"), path = require("path");
const { preveriDavcno, pravnaOblika, nosilecSp } = require("../register.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  // 24: v aplikaciji ni več window.confirm/alert/prompt
  const kor = path.join(__dirname, ".."), dat = [...fs.readdirSync(path.join(kor, "portal")).filter(f => f.endsWith(".js")).map(f => "portal/" + f), "app/index.html", "baza-admin/index.html"];
  const ost = dat.filter(f => /(?<![\w$.])(?:window\.)?(?:confirm|alert|prompt)\(/.test(fs.readFileSync(path.join(kor, f), "utf8").replace(/\/\/[^\n]*/g, "")));
  ok(!ost.length, "brez window.confirm/alert/prompt " + ost.join(", "));
  // 22: pravna oblika in nosilec iz naziva
  ok(pravnaOblika("KAVARNA SONCE, ZELJIJE ALJITI S.P.") === "s.p." && pravnaOblika("Gostilna pri Lipi d.o.o.") === "d.o.o." && pravnaOblika("Kmetija Kovač") === "", "pravna oblika iz naziva");
  ok(nosilecSp("KAVARNA SONCE, ZELJIJE ALJITI S.P.") === "Zeljije Aljiti" && nosilecSp("Zeljije Aljiti s.p.") === "Zeljije Aljiti" && nosilecSp("Gostinstvo Janez Novak s.p.") === "Janez Novak" && nosilecSp("Ana Marija Kos s.p., Kavarna") === "Ana Marija Kos", "nosilec s.p. iz naziva");
  let D1 = ""; for (let i = 3000000; !D1; i++) for (let k = 0; k < 10 && !D1; k++) if (preveriDavcno(String(i) + k)) D1 = String(i) + k;
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // seznam FURS z enim s.p.
  const csv = `"Zavezanec za DDV";"Davčna številka";"Matična številka";"Datum registracije";"Šifra dejavnosti";"Naziv";"Naslov";"Finančni urad"\n"";"${D1}";"9876543000";"2020-01-01";"I56.300";"KAVARNA SONCE, ZELJIJE ALJITI S.P.";"SONČNA ULICA 1, 1000 LJUBLJANA";"10"\n`;
  await pg.evaluate(b => api("POST", "/api/zavezanci/uvozi", b), Buffer.from(csv).toString("base64"));
  await pg.evaluate(() => openForm("stranke", null, null, () => {})); await pg.waitForSelector("#f_vies");
  await pg.fill("#f_davcna", D1); await pg.click("#f_vies"); await pg.waitForFunction(() => /Izpolnjeno/.test(document.querySelector("#vies_r").textContent));
  const v = await pg.evaluate(() => Object.fromEntries(["naziv", "skd", "pravna_oblika", "nosilec", "odgovorna_oseba", "dejavnost"].map(k => [k, document.querySelector("#f_" + k).value])));
  ok(v.skd === "I56.300" && v.pravna_oblika === "s.p." && v.nosilec === "Zeljije Aljiti" && v.odgovorna_oseba === "Zeljije Aljiti" && /Gostinstvo/.test(v.dejavnost), "po davčni številki: SKD, pravna oblika, nosilec s.p. in odgovorna oseba " + JSON.stringify(v));
  // 23: s.p. z več odgovornimi osebami → lastno okno z opozorilom; preklic ne shrani
  await pg.fill("#f_odgovorna_oseba", "Zeljije Aljiti, Ana Novak"); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector("dialog.cdlg[open]"); const msg = await pg.textContent("dialog.cdlg .cdlg-m");
  ok(/s\.p\./.test(msg) && /2 oseb/.test(msg) && /Ana Novak/.test(msg), "opozorilo: več odgovornih oseb pri s.p. – " + msg.slice(0, 120));
  await pg.click("dialog.cdlg .cdlg-no"); await pg.waitForFunction(() => !document.querySelector("dialog.cdlg"));
  ok(await pg.evaluate(() => document.querySelector("#dlg").open) && !(await pg.evaluate(async () => (await api("GET", "/api/d/stranke")).length)), "preklic: obrazec ostane odprt, stranka ni shranjena");
  await pg.fill("#f_odgovorna_oseba", "Zeljije Aljiti"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("#dlg").open);
  const s = (await pg.evaluate(() => api("GET", "/api/d/stranke")))[0];
  ok(s && s.skd === "I56.300" && s.nosilec === "Zeljije Aljiti" && s.pravna_oblika === "s.p.", "ena odgovorna oseba: shranjeno brez opozorila, s SKD in nosilcem");
  // 24: lastno okno za brisanje zapisa (Prekliči ohrani zapis)
  const ids = await pg.evaluate(async sid => { const o = await D.add("obrati", { stranka_id: sid, naziv: "Kavarna Sonce", naprave: [{ ime: "Hladilnik" }] }); const n = await D.add("nacrti", { stranka_id: sid, obrat_id: o.id, naziv: "HACCP Kavarna Sonce", status: "osnutek", vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }] } }); return { o: o.id, n: n.id }; }, s.id);
  await pg.evaluate(id => api("GET", "/api/d/obrati/" + id).then(r => openForm("obrati", r, null, () => {})), ids.o); await pg.waitForSelector("#dlg[open]");
  await pg.click("#dlg-f .btn.danger"); await pg.waitForSelector("dialog.cdlg[open]");
  ok(/Res izbrišem zapis/.test(await pg.textContent("dialog.cdlg")) && await pg.evaluate(() => document.querySelector("#dlg").open), "brisanje: lastno okno nad obrazcem");
  await pg.keyboard.press("Escape"); await pg.waitForFunction(() => !document.querySelector("dialog.cdlg"));
  ok(await pg.evaluate(id => api("GET", "/api/d/obrati/" + id).then(r => !!r.id), ids.o), "Escape v oknu za potrditev: zapis ni izbrisan");
  await pg.evaluate(() => document.querySelector("#dlg").close());
  // 21: sprememba naprav obrata → pas v čarovniku; samodejno shranjevanje ga ne skrije, ročno vpraša za razlog
  await pg.evaluate(async id => { const o = await api("GET", "/api/d/obrati/" + id); await api("PUT", "/api/d/obrati/" + id, { naprave: [{ ime: "Hladilnik" }, { ime: "Konvektomat" }], _ver: o.spremenjeno || o.ustvarjeno }); }, ids.o);
  await pg.goto(B + "/#/carovnik/" + ids.n); await pg.waitForSelector("#wspr");
  ok(/so bili spremenjeni/.test(await pg.textContent("#wspr")), "pas o spremembi naprav ali prostorov");
  await pg.fill("[data-k=zaposleni]", "4"); await pg.click(".stepper button >> nth=1"); await pg.waitForFunction(() => /Shranjeno samodejno/.test((document.querySelector("#toast") || {}).textContent || ""));
  await pg.reload(); await pg.waitForSelector("#wsave"); ok(!!(await pg.$("#wspr")), "samodejno shranjevanje pasu ne skrije");
  await pg.click("#wsave"); await pg.waitForSelector("dialog.cdlg[open] .cdlg-i");
  await pg.fill("dialog.cdlg .cdlg-i", "ok"); await pg.click("dialog.cdlg .cdlg-ok");
  ok(await pg.isVisible("dialog.cdlg .cdlg-e"), "prekratek razlog: opozorilo, okno ostane odprto");
  await pg.fill("dialog.cdlg .cdlg-i", "Dodan konvektomat – pregledana toplotna obdelava"); await pg.click("dialog.cdlg .cdlg-ok");
  await pg.waitForFunction(() => !document.querySelector("#wspr") && !document.querySelector("dialog.cdlg"));
  const n = await pg.evaluate(id => api("GET", "/api/d/nacrti/" + id), ids.n), ob = await pg.evaluate(id => api("GET", "/api/d/obrati/" + id), ids.o);
  ok(n.pregled_opreme === ob.sprememba_opreme && (n.revizije || []).some(r => /Pregled po spremembi naprav ali prostorov obrata: Dodan konvektomat/.test(r.razlog || "")), "razlog v zgodovini, pregled zabeležen " + JSON.stringify((n.revizije || []).map(r => r.razlog)));
  await pg.reload(); await pg.waitForSelector("#wsave"); ok(!(await pg.$("#wspr")), "po shranjevanju z razlogom pasu ni več");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
