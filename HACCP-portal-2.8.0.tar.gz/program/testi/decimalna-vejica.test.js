// Decimalna vejica: vnosna polja prikažejo »3,5«, vnos z vejico se shrani kot število, seznami in PDF izvozi z vejico.
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Kavarna Sonce" }); const o = await D.add("obrati", { stranka_id: s.id, naziv: "Kavarna", povrsina: 125.5 });
    await D.add("evidence", { stranka_id: s.id, obrat_id: o.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 3.5, max: 4.5, cas: new Date().toISOString().slice(0, 16) }); return { s: s.id, o: o.id }; });
  // obrazec obrata: »125,5«; vnos »12,75« se shrani kot število
  await pg.evaluate(id => api("GET", "/api/d/obrati/" + id).then(r => openForm("obrati", r, null, () => {})), ids.o); await pg.waitForSelector("#f_povrsina");
  ok(await pg.inputValue("#f_povrsina") === "125,5", "vnosno polje: " + await pg.inputValue("#f_povrsina"));
  await pg.fill("#f_povrsina", "12,75"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("#dlg").open);
  ok((await pg.evaluate(id => api("GET", "/api/d/obrati/" + id), ids.o)).povrsina === 12.75, "vnos z vejico shranjen kot število 12.75");
  await pg.goto(B + "/#/stranka/" + ids.s + "/obrati"); await pg.waitForSelector("td:has-text('m²')"); ok(/12,75 m²/.test(await pg.textContent("#main")), "seznam obratov: 12,75 m²");
  // obrazec evidence
  await pg.evaluate(async sid => { const r = (await api("GET", "/api/d/evidence?stranka_id=" + sid))[0]; evForm(r, await evCtx({ stranka_id: sid }), () => {}); }, ids.s).catch(() => {});
  const ev = await pg.$$eval("#dlg input", a => a.map(i => i.value)).catch(() => []);
  ok(ev.includes("3,5") && ev.includes("4,5") && !ev.some(v => /^\d+\.\d+$/.test(v)), "obrazec evidence: " + ev.filter(v => /\d[.,]\d/.test(v)).join(" "));
  await pg.evaluate(() => { const d = document.querySelector("#dlg"); if (d.open) d.close(); });
  // PDF evidenc
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.waitForSelector("#main button:has-text('PDF')");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#main button:has-text('PDF') >> nth=0")]); const f = path.join(OUT, "ev.pdf"); await dl.saveAs(f);
  const t = (cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }).stdout || "").replace(/\s+/g, " ");
  ok(/Hladilnik 1 3,5/.test(t) && !/3\.5/.test(t), "PDF evidenc: 3,5 " + (t.match(/Hladilnik.{0,20}/) || [""])[0]);
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
