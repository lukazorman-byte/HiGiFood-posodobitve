// Čarovnik HACCP – popravki iz pregleda: vezava nevarnosti na korak z opozorilom ob spremembi/izbrisu, enoten status potrditve,
// predloge za alkoholne pijače, okno ob nalaganju predloge, merila in evidence za analize, nizka tveganja, alergeni, zaposleni,
// koračnik s stanjem, sprotni diagram, samodejno shranjevanje, oznake CCP1, gumb Čarovnik v seznamu načrtov.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Moj Likerček d.o.o." }); await D.add("obrati", { stranka_id: s.id, naziv: "Destilarna" }); for (const [ime, f] of [["Ana Novak", "vodja proizvodnje"], ["Bor Kos", "tehnolog"]]) await D.add("osebje", { stranka_id: s.id, ime, funkcija: f }); return s.id; });
  // O10: + Dodaj → ponudba »Odpri čarovnik«; gumb Čarovnik v vrstici
  await pg.goto(B + `/#/stranka/${sid}/nacrti`); await pg.waitForSelector("#ladd"); await pg.click("#ladd"); await pg.waitForSelector("#f_naziv");
  await pg.fill("#f_naziv", "HACCP – Božični liker (test)"); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector("dialog[open] >> text=Odpri čarovnik"); ok(true, "po dodajanju načrta: ponudba »Odpri čarovnik«");
  await pg.click("#dlg-f .btn:has-text('Pozneje')"); await pg.waitForSelector("#lb a:has-text('Čarovnik')");
  await pg.click("#lb a:has-text('Čarovnik')"); await pg.waitForSelector(".stepper");
  ok(!(await pg.locator("dialog[open]").count()), "gumb »Čarovnik« v vrstici odpre čarovnik (brez vmesnega okna)");
  // O1: koračnik z enim gumbom na korak in stanjem
  ok(await pg.locator(".stepper button").count() === 7 && await pg.locator(".stepper button.on .st-t").textContent() === "Podatki", "koračnik: 7 korakov s kratkimi imeni");
  // V9: zaposleni iz profila stranke
  ok(await pg.inputValue("[data-k=zaposleni]") === "2", "število zaposlenih prevzeto iz zavihka Zaposleni");
  await pg.click("#os_ek"); ok(/Ana Novak – vodja proizvodnje\nBor Kos – tehnolog/.test(await pg.inputValue("[data-k=hacc_ekipa]")), "HACCP skupina prevzeta iz zaposlenih");
  // V2: ločene predloge
  await pg.click(".stepper button >> nth=1"); await pg.waitForSelector("#wb");
  const opc = await pg.$$eval("#wb option", o => o.map(x => x.value)); ok(["liker", "vino", "pivo", "zganje", "sokovi", "alko"].every(x => opc.includes(x)), "predloge: liker, vino, pivo, žganje, sokovi (+ splošna)");
  // V8: izbirni seznam alergenov
  await pg.click("#zadd"); await pg.fill("tr[data-i] input[data-k=naziv]", "Orehov liker"); await pg.click(".al-izb");
  ok(await pg.locator("[data-a]").count() === 14, "14 alergenov EU v izbiri");
  await pg.check("[data-a='Oreščki']"); await pg.check("[data-a='Mleko']"); await pg.check("#al_pr"); await pg.click("#dlg-f .btn:last-child");
  ok(await pg.textContent(".al-izb") === "Mleko, Oreščki (preveriti)", "izbrani alergeni + »preveriti«: " + await pg.textContent(".al-izb"));
  await pg.click(".al-izb"); await pg.check("#al_ni"); ok(!(await pg.isChecked("[data-a='Mleko']")), "»Ni alergenov« počisti izbiro"); await pg.click("#dlg-f .btn:last-child");
  ok(/^ni alergenov/.test(await pg.textContent(".al-izb")), "ni alergenov");
  // V3: nalaganje predloge
  await pg.selectOption("#wb", "liker"); await pg.click("#wload"); await pg.waitForSelector("#klist .krow");
  const nk = await pg.locator(".krow").count(); ok(nk === 9, "predloga liker: " + nk + " korakov");
  await pg.click(".stepper button >> nth=1"); await pg.click("#wload"); await pg.waitForSelector("dialog[open] >> text=Dodaj k obstoječim");
  ok(await pg.locator("#dlg-f .btn").allTextContents().then(t => t.join("|")) === "Prekliči|Dodaj k obstoječim|Zamenjaj", "okno: Zamenjaj / Dodaj k obstoječim / Prekliči");
  await pg.click("#dlg-f .btn:has-text('Dodaj k obstoječim')"); await pg.waitForSelector("#klist");
  const st = await pg.evaluate(() => [document.querySelectorAll(".krow").length]); ok(st[0] === 9, "dodaj k obstoječim: koraki se ne podvojijo");
  await pg.click(".stepper button >> nth=1"); await pg.click("#wload"); await pg.click("#dlg-f .btn:has-text('Zamenjaj')"); await pg.waitForSelector("#klist .krow");
  // V10: baza pozna kumarin, japonski zvezdasti janež, metanol v alkoholni osnovi
  await pg.click(".stepper button >> nth=3"); await pg.waitForSelector("tr[data-h]"); const txt = await pg.textContent(".nev-t");
  ok(/Kumarin/.test(txt) && /japonskim zvezdastim janežem/.test(txt) && /Metanol/.test(txt), "nevarnosti: kumarin, japonski zvezdasti janež, metanol");
  ok(await pg.locator(".rmat").count() === 1, "matrika tveganja nad tabelo");
  // O4: korak le enkrat na skupino
  const kc = await pg.$$eval(".nev-t tbody tr", r => r.map(x => x.querySelector("td").textContent.trim()));
  ok(kc.filter(Boolean).length < kc.length && kc.filter(Boolean).length === new Set(kc.filter(Boolean)).size, "vrstice združene po koraku");
  // preimenovanje istega koraka: nevarnosti ostanejo potrjene (le obvestilo); izbris koraka jih označi za preverjanje
  await pg.click(".stepper button >> nth=2"); await pg.waitForSelector(".krow");
  const iMac = await pg.$$eval(".krow input[data-k=naziv]", i => i.findIndex(x => x.value === "Maceracija"));
  const ime = pg.locator(".krow input[data-k=naziv]").nth(iMac); await ime.fill("Hlajenje mešanice");
  ok(/Hlajenje mešanice/.test(await pg.textContent("#kflow")), "O2: diagram se osveži sproti (pred shranjevanjem)");
  await ime.press("Tab"); await pg.waitForSelector(".toast.show"); ok(/ostane potrjenih/.test(await pg.textContent("#toast")) && !(await pg.locator("#k_prev .note").count()), "preimenovanje koraka: obvestilo, nevarnosti niso označene kot spremenjene");
  // izbris koraka z nevarnostmi
  const iPol = await pg.$$eval(".krow input[data-k=naziv]", i => i.findIndex(x => x.value === "Polnjenje")); await pg.click(`[data-x="${iPol}"]`);
  await pg.waitForSelector("dialog[open] input[name=kx][value=preveri]:checked"); await pg.click("#dlg-f .btn:last-child"); // privzeto: pusti za preverjanje
  await pg.click(".stepper button >> nth=3"); await pg.waitForSelector(".nev-t");
  ok(await pg.locator(".badge:has-text('korak spremenjen – preveri')").count() === 1 && await pg.locator(".badge:has-text('brez koraka')").count() === 1, "korak 4: samo nevarnost izbrisanega koraka je označena za preverjanje");
  await pg.click("#h_flt"); ok(await pg.locator(".nev-t tbody tr").count() === 1, "filter: samo nevarnosti za preverjanje");
  await pg.click("tr[data-h] >> nth=0"); await pg.waitForSelector("dialog[open]"); ok(/Korak te nevarnosti je bil/.test(await pg.textContent("#dlg-b")), "obrazec nevarnosti: opozorilo o spremenjenem koraku");
  await pg.keyboard.press("Escape"); await pg.click("#h_flt");
  // V4 / N3: enoten status – ročno dodana brez kljukice ni potrjena; urejen predlog → »uredil uporabnik – potrdi«; s kljukico potrjeno
  await pg.click("#hadd"); await pg.selectOption("[data-k=korak_id]", { index: 1 }); await pg.fill("[data-k=nevarnost]", "Ročno dodana nevarnost"); await pg.click("#dlg-f .btn:last-child");
  ok(await pg.locator("tr:has-text('Ročno dodana nevarnost') .badge:has-text('nepotrjeno')").count() === 1, "ročno dodana brez kljukice: nepotrjeno");
  await pg.click("tr:has-text('Plesni in kvasovke na svežem')"); await pg.fill("[data-k=nevarnost]", "Plesni in kvasovke na svežem sadju (popravljeno)"); await pg.selectOption("[data-k=verjetnost]", "1"); await pg.selectOption("[data-k=teza]", "2"); await pg.click("#dlg-f .btn:last-child");
  ok(await pg.locator("tr:has-text('(popravljeno)') .badge:has-text('uredil uporabnik – potrdi')").count() === 1, "urejen predlog brez kljukice: »uredil uporabnik – potrdi«");
  await pg.click("tr:has-text('(popravljeno)')"); await pg.check("[data-k=potrjeno]"); await pg.click("#dlg-f .btn:last-child");
  ok(await pg.locator("tr:has-text('(popravljeno)') .badge:has-text('potrjeno')").count() === 1, "s kljukico: potrjeno");
  // ocena tveganja: ena visoka (CCP), ena nizka
  await pg.click("tr:has-text('Metanol in druge')"); await pg.selectOption("[data-k=verjetnost]", "3"); await pg.selectOption("[data-k=teza]", "5"); await pg.check("[data-k=potrjeno]"); await pg.click("#dlg-f .btn:last-child");
  ok(await pg.locator(".rmat td.rm-visoko:has-text('1')").count() === 1, "matrika tveganja šteje oceno 3×5");
  // O8: samodejno shranjevanje ob menjavi koraka, različica se osveži
  const v0 = await pg.textContent("#wver"); await pg.click(".stepper button >> nth=4"); await pg.waitForSelector(".toast.show:has-text('Shranjeno samodejno')");
  await pg.waitForFunction(v => document.querySelector("#wver").textContent !== v, v0); ok(true, "samodejno shranjeno ob menjavi koraka, oznaka različice osvežena: " + await pg.textContent("#wver"));
  // V7: nizka tveganja vidna in PRP vsem
  ok(await pg.locator("details.nizka summary:has-text('1 nizko tveganje – PRP')").count() === 1, "nizka tveganja prikazana zloženo");
  await pg.click("details.nizka summary"); await pg.click("#nprp"); ok(await pg.locator("tr[data-hn] .badge:has-text('PRP')").count() === 1, "»Vsem brez ukrepa dodeli PRP«");
  // O6 / O7 / V5 / V6: dialog kontrolnega ukrepa
  await pg.click("tr[data-h] [data-o]"); await pg.waitForSelector("[data-k=vrsta]");
  ok(await pg.locator("details.odl-drevo[open]").count() === 1 && await pg.locator("#ccpf").isHidden(), "odločitveno drevo odprto, polja CCP skrita");
  await pg.selectOption("[data-k=vrsta]", "PRP"); ok(await pg.locator("#ccpf").isHidden(), "PRP: polja CCP skrita");
  await pg.selectOption("[data-k=vrsta]", "CCP"); ok(await pg.locator("#ccpf").isVisible(), "CCP: polja vidna");
  const og = await pg.$$eval("#regsel optgroup", g => g.map(x => x.label + ":" + x.children.length)); ok(og.length === 2 && /Druga merila/.test(og[1]), "predlogi meril: temperatura + druga merila (" + og.join(", ") + ")");
  await pg.selectOption("#regsel", "metanol_osnova"); ok(/30 g\/hl/.test(await pg.inputValue("[data-k=mejna]")) && /2019\/787/.test(await pg.inputValue("[data-k=mejna_vir]")), "predlog meje: metanol z virom");
  const ev = await pg.$$eval("[data-k=evidenca] option", o => o.map(x => x.value)); ok(["analiza", "meritev_serije", "pregled_embalaze"].every(x => ev.includes(x)), "povezane evidence: analiza, meritev serije, pregled embalaže");
  await pg.selectOption("[data-k=evidenca]", "analiza"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(200);
  ok(await pg.locator("tr[data-h] .badge.vu-ccp:has-text('CCP1')").count() === 1, "CCP oštevilčen (CCP1)");
  await pg.click(".stepper button >> nth=2"); await pg.waitForSelector("#kflow"); ok(/CCP1/.test(await pg.textContent("#kflow")), "diagram: oznaka CCP1 pri koraku");
  // V11 / pregled
  await pg.click(".stepper button >> nth=5"); await pg.waitForSelector("#wbody .card");
  await pg.waitForFunction(() => { const l = document.querySelector("#pr_list"); return l && !/Preverjam načrt/.test(l.textContent); }); // poročilo preverjanja se izriše z zamikom
  const pr = await pg.textContent("#wbody");
  ok(!/neprevrjen/.test(pr) && /vezanih na spremenjen ali izbrisan korak/.test(pr) && /CCP1/.test(pr), "pregled: brez tipkarske napake, opozorilo o korakih, CCP1 v povzetku");
  ok(await pg.locator(".stepper .st-polno").count() >= 2, "koračnik: izpolnjeni koraki označeni (" + await pg.locator(".stepper .st-polno").count() + ")");
  // izvoz Word: CCP1 v dokumentu
  await pg.click(".stepper button >> nth=6"); await pg.waitForSelector("#xdoc");
  const doc = await pg.evaluate(async () => { const W = (await D.list("nacrti"))[0].vsebina; return String(Object.values(ccpOznake(W))); });
  ok(doc === "CCP1", "shranjena vsebina: " + doc);
  // nove evidence: ocena skladnosti
  const oc = await pg.evaluate(() => [ocena("analiza", { vrednost: 20, max: 30 }), ocena("meritev_serije", { alkohol: 14, alkohol_min: 15 }), ocena("pregled_embalaze", { ciste_ok: true, zapiralo_ok: true, etiketa_ok: true })]);
  ok(oc[0] === true && oc[1] === false && oc[2] === true, "ocena novih evidenc: " + oc.join(","));
  // neshranjene spremembe: ob odhodu na drugo stran se shranijo
  await pg.click(".stepper button >> nth=5"); await pg.fill("[data-k=potrdil]", "Strokovnjak Test"); await pg.goto(B + `/#/stranka/${sid}/nacrti`); await pg.waitForTimeout(800);
  ok((await pg.evaluate(async () => (await D.list("nacrti"))[0].vsebina.pregled.potrdil)) === "Strokovnjak Test", "odhod iz čarovnika: spremembe samodejno shranjene");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
