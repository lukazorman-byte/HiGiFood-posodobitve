// Vstopna stran: logotip, soglasje za piškotke (nujni / vsi / nastavitve), povpraševanje (soglasje, past za robote, e-pošta skrbniku,
// omejitev zahtevkov), novice z dvojno potrditvijo in odjava (s povezavo in z e-naslovom), politika zasebnosti, skrbniški pregled.
const http = require("http");
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const POSTA = [];
  const mock = http.createServer((q, r) => { let b = ""; q.on("data", c => b += c); q.on("end", () => { POSTA.push(JSON.parse(b || "{}")); r.writeHead(200, { "Content-Type": "application/json" }); r.end('{"id":"1"}'); }); }).listen(4955, "127.0.0.1");
  const req = async (m, p, b, ck) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, ck ? { Cookie: ck } : {}), body: b ? JSON.stringify(b) : undefined }); let j = null; try { j = await r.json(); } catch {} return { s: r.status, j, ck: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  await req("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "A", geslo: "dolgogeslo123" }); const ck = (await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" })).ck;
  await req("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_x", od: "HiGiFood <obvestila@higifood.si>" }, ck);
  await req("PUT", "/api/narocnine/nastavitve", { izdajatelj: { naziv: "HiGiFood d.o.o.", naslov: "Slovenska cesta 1, Ljubljana", email: "info@higifood.si", telefon: "041 123 456", davcna: "", trr: "", banka: "" } }, ck);
  const br = await chromium.launch(), errs = []; const ctx = await br.newContext(), pg = await ctx.newPage(); pg.on("pageerror", e => errs.push(String(e)));
  // logotip in pasica za piškotke
  await pg.goto(B + "/stran/"); await pg.waitForSelector("#piskotki-pasica");
  ok(await pg.isVisible(".hero-logo img.s") && /nujne piškotke/.test(await pg.textContent("#piskotki-pasica")), "vstopna stran: logotip in pasica za piškotke");
  await pg.click("#piskotki-pasica [data-pk=nujni]"); await pg.waitForFunction(() => !document.getElementById("piskotki-pasica"));
  let sog = await pg.evaluate(() => JSON.parse(localStorage.getItem("hf_piskotki")));
  ok(sog.nujni === true && sog.analitika === false && sog.v === 1, "»Samo nujni« shrani zavrnitev analitike");
  await pg.reload(); await pg.waitForTimeout(300); ok(!(await pg.$("#piskotki-pasica")), "po izbiri se pasica ne prikaže več");
  await pg.click("footer [data-piskotki]"); await pg.waitForSelector("#piskotki-nast[open]"); ok(!(await pg.isChecked("#pk-an")), "nastavitve: analitika izklopljena");
  await pg.click("#piskotki-nast button[value=vsi]"); await pg.waitForFunction(() => JSON.parse(localStorage.getItem("hf_piskotki")).analitika === true); ok(true, "nastavitve: »Sprejmi vse« shrani soglasje za analitiko");
  // povpraševanje: brez soglasja ne gre
  await pg.fill("#pv [name=ime]", "Ana Kos"); await pg.fill("#pv [name=email]", "ana@kavarna.si"); await pg.click("#pv button[type=submit]");
  ok(/soglasje/.test(await pg.textContent("#pv_r")), "povpraševanje brez soglasja zavrnjeno (v brskalniku)");
  ok((await req("POST", "/api/javno/povprasevanje", { ime: "X", email: "x@x.si" })).s === 400, "strežnik zavrne povpraševanje brez soglasja");
  await pg.fill("#pv [name=podjetje]", "Kavarna Sonce d.o.o."); await pg.selectOption("#pv [name=dejavnost]", { index: 2 }); await pg.fill("#pv [name=obratov]", "2"); await pg.fill("#pv [name=sporocilo]", "Zanima me predstavitev.");
  await pg.check("#pv [name=soglasje]"); await pg.check("#pv [name=novice]"); await pg.click("#pv button[type=submit]");
  await pg.waitForFunction(() => /Hvala/.test(document.getElementById("pv_r").textContent));
  ok(/potrdite povezavo/.test(await pg.textContent("#pv_r")), "povpraševanje oddano, z prijavo na novice: " + await pg.textContent("#pv_r"));
  await new Promise(r => setTimeout(r, 300));
  const zaSkrbnika = POSTA.find(m => JSON.stringify(m.to).includes("info@higifood.si")), potrditev = POSTA.find(m => JSON.stringify(m.to).includes("ana@kavarna.si"));
  ok(zaSkrbnika && /Novo povpraševanje: Kavarna Sonce/.test(zaSkrbnika.subject) && /Zanima me predstavitev/.test(zaSkrbnika.text), "skrbnik dobi e-pošto s povpraševanjem");
  const pov = potrditev && /(http\S+novice\.html\?potrdi=\S+)/.exec(potrditev.text);
  ok(!!pov && /\/stran\/novice\.html/.test(pov[1]), "potrditvena e-pošta s povezavo na stran " + (pov && pov[1]));
  // past za robote: odgovor uspešen, zapis se ne shrani
  ok((await req("POST", "/api/javno/povprasevanje", { ime: "Bot", email: "b@b.si", soglasje: true, spletna_stran: "http://spam" })).s === 200, "past za robote: navidezno uspešno");
  let adm = (await req("GET", "/api/javno-admin", null, ck)).j;
  ok(adm.povprasevanja.length === 1 && adm.povprasevanja[0].podjetje === "Kavarna Sonce d.o.o." && adm.povprasevanja[0].soglasje && adm.novice.length === 1 && adm.novice[0].stanje === "caka", "shranjeno: 1 povpraševanje s soglasjem, 1 nepotrjen naročnik (robot ni shranjen)");
  ok(!JSON.stringify(adm).includes("potrdi_h"), "skrbnik ne vidi žetona za potrditev");
  ok((await req("GET", "/api/javno-admin")).s === 401, "skrbniški pregled brez prijave ni dostopen");
  // potrditev prijave s povezavo iz e-pošte
  await pg.goto(pov[1].replace(/^https?:\/\/[^/]+/, B)); await pg.waitForFunction(() => /potrjena/.test(document.getElementById("novice-stanje").textContent));
  ok(!/potrdi=/.test(pg.url()), "žeton se odstrani iz naslova strani");
  adm = (await req("GET", "/api/javno-admin", null, ck)).j; const n = adm.novice[0];
  ok(n.stanje === "potrjen" && n.potrjeno && n.odjava && /novice/.test(n.soglasje.besedilo), "naročnik potrjen, zapisano soglasje");
  ok((await req("POST", "/api/javno/novice/potrdi", { t: "napacen" })).s === 400, "neveljavna potrditev zavrnjena");
  // odjava s povezavo
  await pg.goto(B + "/stran/novice.html?odjava=" + n.odjava); await pg.waitForFunction(() => /Odjavljeni ste/.test(document.getElementById("novice-stanje").textContent));
  adm = (await req("GET", "/api/javno-admin", null, ck)).j; ok(adm.novice.length === 0, "odjava s povezavo izbriše naslov");
  // prijava z obrazcem novic in odjava z e-naslovom
  await pg.goto(B + "/stran/#novice"); await pg.fill("#nv [name=email]", "bor@pekarna.si"); await pg.check("#nv [name=soglasje]"); await pg.click("#nv button[type=submit]");
  await pg.waitForFunction(() => /Poslali smo vam e-pošto/.test(document.getElementById("nv_r").textContent)); ok(true, "prijava na novice z obrazcem");
  await pg.goto(B + "/stran/novice.html#odjava"); await pg.fill("#od [name=email]", "bor@pekarna.si"); await pg.click("#od button[type=submit]");
  await pg.waitForFunction(() => /odjavili/.test(document.getElementById("od_r").textContent));
  adm = (await req("GET", "/api/javno-admin", null, ck)).j; ok(adm.novice.length === 0, "odjava z e-naslovom izbriše naslov");
  ok((await req("POST", "/api/javno/novice/odjava", { email: "nikoli@prijavljen.si" })).s === 200, "odjava neznanega naslova: enak odgovor (brez razkrivanja)");
  // politika zasebnosti: podatki upravljavca iz platforme
  await pg.goto(B + "/stran/zasebnost.html"); await pg.waitForFunction(() => /info@higifood\.si/.test(document.querySelector("[data-upravljavec]").textContent));
  ok(/Informacijskem pooblaščencu/.test(await pg.textContent("main")), "politika zasebnosti: upravljavec in pravice");
  await pg.goto(B + "/stran/piskotki.html"); ok(/analitični piškotki\./.test(await pg.textContent("#piskotki-stanje")), "stran o piškotkih prikaže trenutno izbiro");
  // telefon: brez vodoravnega drsenja
  const tel = await (await br.newContext({ viewport: { width: 390, height: 844 } })).newPage(); await tel.goto(B + "/stran/"); await tel.waitForSelector("#piskotki-pasica");
  ok(await tel.evaluate(() => document.documentElement.scrollWidth <= innerWidth), "telefon (390 px): brez vodoravnega drsenja");
  // skrbniški pregled v platformi
  const ad = await (await br.newContext()).newPage(); ad.on("pageerror", e => errs.push(String(e))); await ad.goto(B + "/"); await ad.fill("#le", "a@t.si"); await ad.fill("#lp", "dolgogeslo123"); await ad.click("#lf button"); await ad.waitForSelector("#shell:not([hidden])");
  await ad.waitForSelector("#nova_pov"); ok(/1 novo povpraševanje/.test(await ad.textContent("#nova_pov")), "nadzorna plošča: novo povpraševanje");
  await ad.goto(B + "/#/spletna-stran"); await ad.waitForSelector("[data-pst]"); await ad.selectOption("[data-pst]", "zaključeno"); await ad.waitForSelector(".toast.show:has-text('Stanje shranjeno')");
  ok((await req("GET", "/api/javno-admin", null, ck)).j.povprasevanja[0].stanje === "zaključeno", "skrbnik spremeni stanje povpraševanja");
  // omejitev: največ 5 povpraševanj na uro z istega naslova IP
  let zadnji = 0; for (let i = 0; i < 6; i++) zadnji = (await req("POST", "/api/javno/povprasevanje", { ime: "T" + i, email: "t" + i + "@t.si", soglasje: true })).s;
  ok(zadnji === 429, "omejitev zahtevkov na naslov IP");
  ok(!errs.length, "brez napak JavaScript " + errs.join("; "));
  await br.close(); mock.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
