// Sklop E – administrator je lahko tudi svetovalec: migracija vloga → vloge (stara namestitev), stikalo »Tudi svetovalec«,
// zadnji administrator, profil s podpisom, seznam svetovalcev (tudi administratorji), vloga v dnevniku sprememb,
// izvoz »Izdelal (svetovalec)«, posnetek izdelovalca ob potrditvi, uporabnik z eno vlogo deluje kot prej.
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), os = require("os"), path = require("path"), crypto = require("crypto");
const { hasRole, veljavneVloge, nastaviVloge } = require("../vloge.js");
const OUT = process.env.OUT || os.tmpdir(), ROOT = path.join(__dirname, "..");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pdfTxt = f => (cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }).stdout || "").replace(/\s+/g, " ");
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  ok(hasRole({ vloga: "admin" }, "admin") && hasRole({ vloge: ["admin", "svetovalec"] }, "svetovalec") && !hasRole({ vloge: ["svetovalec"] }, "admin"), "hasRole: stari zapis (vloga) in novi (vloge)");
  ok(veljavneVloge(["admin", "svetovalec"]) && !veljavneVloge(["odgovorna", "svetovalec"]) && !veljavneVloge([]) && nastaviVloge({}, ["svetovalec", "admin"]).vloga === "admin", "dovoljene kombinacije, glavna vloga");
  // stara namestitev: uporabniki samo z »vloga«
  const data = fs.mkdtempSync(path.join(os.tmpdir(), "vlog-")), pod = path.join(data, "podatki"); fs.mkdirSync(pod, { recursive: true });
  const hp = g => { const s = crypto.randomBytes(16).toString("hex"); return s + ":" + crypto.scryptSync(g, s, 64).toString("hex"); };
  const U = [["a1", "admin@t.si", "Luka Zorman", "admin", null, []], ["s1", "sv@t.si", "Sara Svet", "svetovalec", null, []], ["o1", "odg@t.si", "Zeljije Aljiti", "odgovorna", "s9", []]];
  fs.writeFileSync(path.join(pod, "uporabniki.json"), JSON.stringify(U.map(([id, email, ime, vloga, stranka_id, stranke]) => ({ id, email, ime, vloga, stranka_id, stranke, geslo: hp("dolgogeslo123"), aktiven: true }))));
  fs.writeFileSync(path.join(pod, "stranke.json"), JSON.stringify([{ id: "s9", naziv: "Kavarna Sonce", dejavnost: "Gostinstvo (restavracija, gostilna)", odgovorna_oseba: "Zeljije Aljiti", ustvarjeno: "2026-01-01T00:00:00.000Z" }, { id: "s8", naziv: "Druga stranka", ustvarjeno: "2026-01-01T00:00:00.000Z" }]));
  const port = 4300 + Math.floor(Math.random() * 200), srv = cp.spawn(process.execPath, [path.join(ROOT, "server.js"), "--tiho"], { env: Object.assign({}, process.env, { PORT: String(port), HACCP_DATA: data, HOST: "127.0.0.1" }), stdio: "ignore" });
  const B = "http://127.0.0.1:" + port; for (let i = 0; i < 50; i++) { try { if ((await fetch(B + "/api/health")).ok) break; } catch {} await new Promise(r => setTimeout(r, 200)); }
  const prijava = async e => { const r = await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "application/json", Origin: B }, body: JSON.stringify({ email: e, geslo: "dolgogeslo123" }) }); return (r.headers.get("set-cookie") || "").split(";")[0]; };
  const A = (c, m, u, b) => fetch(B + u, { method: m, headers: Object.assign({ Cookie: c, Origin: B }, b ? { "Content-Type": "application/json" } : {}), body: b ? JSON.stringify(b) : undefined }).then(async r => ({ s: r.status, j: await r.json().catch(() => null) }));
  try {
    const ca = await prijava("admin@t.si"), cs = await prijava("sv@t.si"), co = await prijava("odg@t.si");
    const us = (await A(ca, "GET", "/api/uporabniki")).j;
    ok(us.length === 3 && us.every(u => Array.isArray(u.vloge) && u.vloge.length === 1 && u.vloge[0] === u.vloga), "migracija: vsak uporabnik ima vloge = [vloga] " + JSON.stringify(us.map(u => u.vloge)));
    // (e) ena vloga deluje kot prej
    const svS = await A(cs, "GET", "/api/d/stranke"); ok(svS.s === 200 && svS.j.length === 0, "svetovalec brez dodeljenih strank ne vidi strank");
    ok((await A(co, "GET", "/api/d/stranke")).j.map(s => s.id).join() === "s9" && (await A(co, "GET", "/api/uporabniki")).s === 200 && (await A(co, "GET", "/api/svetovalci")).s === 403, "odgovorna oseba: samo svoja stranka, brez seznama svetovalcev");
    // 26: »Tudi svetovalec« (administrator sebi) z dodeljeno stranko
    let r = await A(ca, "PUT", "/api/uporabniki/a1", { tudi_svetovalec: true, stranke: ["s9"] });
    ok(r.s === 200 && r.j.vloge.join() === "admin,svetovalec" && r.j.vloga === "admin" && r.j.stranke.join() === "s9", "administrator vklopi »Tudi svetovalec« in si dodeli stranko");
    r = await A(ca, "PUT", "/api/uporabniki/a1", { vloga: "svetovalec" }); ok(r.s === 200 && r.j.vloge.includes("admin"), "lastna vloga administrator ostane (sebi je ni mogoče odvzeti)");
    r = await A(cs, "PUT", "/api/uporabniki/a1", { tudi_svetovalec: false }); ok(r.s === 404, "svetovalec ne more spreminjati vlog administratorja");
    const sv2 = await A(ca, "POST", "/api/uporabniki", { ime: "Ana Admin", email: "a2@t.si", vloga: "admin", tudi_svetovalec: true, geslo: "dolgogeslo123" });
    ok(sv2.s === 200 && sv2.j.vloge.join() === "admin,svetovalec", "nov administrator s »Tudi svetovalec«");
    r = await A(ca, "PUT", "/api/uporabniki/" + sv2.j.id, { aktiven: false }); ok(r.s === 200, "drugi administrator onemogočen");
    // 27: profil svetovalca
    r = await A(ca, "POST", "/api/auth/izdelovalec", { naziv: "mag.", ime: "Luka Zorman", izobrazba: "univ. dipl. inž. živilske tehnologije", funkcija: "svetovalec za varnost živil", podjetje: "HiGiFood d.o.o.", naslov: "Tržaška 1, Ljubljana", email: "luka@higifood.si", telefon: "041 123 456" });
    ok(r.s === 200 && r.j.moje.podjetje === "HiGiFood d.o.o.", "profil: naziv, izobrazba, podjetje, naslov, e-pošta, telefon");
    // 28: seznam svetovalcev vsebuje administratorja
    let sl = (await A(ca, "GET", "/api/svetovalci")).j; ok(sl.some(z => z.id === "a1" && z.admin && z.izobrazba) && sl.some(z => z.id === "s1") && !sl.some(z => z.email), "seznam svetovalcev: tudi administrator (brez e-naslovov)");
    ok((await A(cs, "GET", "/api/svetovalci")).s === 200, "svetovalec vidi seznam svetovalcev");
    // 29: vloga v dnevniku – sprememba dodeljene stranke kot svetovalec, uporabniki kot administrator
    const st = (await A(ca, "GET", "/api/d/stranke/s9")).j; r = await A(ca, "PUT", "/api/d/stranke/s9", { opis_dejavnosti: "Kavarna s toplo kuhinjo.", _ver: st.spremenjeno || st.ustvarjeno });
    const s8 = (await A(ca, "GET", "/api/d/stranke/s8")).j; await A(ca, "PUT", "/api/d/stranke/s8", { opis_dejavnosti: "Druga.", _ver: s8.spremenjeno || s8.ustvarjeno });
    const sled = (await A(ca, "GET", "/api/revizijska-sled?n=50")).j.vnosi;
    const v = (akc, id) => (sled.find(e => e.akcija === akc && e.id === id) || {}).vloga;
    ok(v("spremeni", "s9") === "svetovalec" && v("spremeni", "s8") === "admin" && v("uporabnik-spremenjen", sv2.j.id) === "admin", "revizijska sled: vloga, v kateri je uporabnik ukrepal " + JSON.stringify(sled.slice(0, 6).map(e => [e.akcija, e.id, e.vloga])));
    const ob = (await A(ca, "POST", "/api/d/obrati", { stranka_id: "s9", naziv: "Kavarna Sonce" })).j;
    const n = (await A(ca, "POST", "/api/d/nacrti", { stranka_id: "s9", obrat_id: ob.id, naziv: "HACCP Kavarna Sonce", status: "osnutek", vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }] } })).j;
    r = await A(ca, "PUT", "/api/d/nacrti/" + n.id, { opomba: "x", _razlog: "dopolnitev", _ver: n.spremenjeno || n.ustvarjeno });
    ok((r.j.revizije || []).slice(-1)[0].vloga === "svetovalec", "zgodovina zapisa: vloga svetovalec");
    // (c) izvoz: »Izdelal (svetovalec)« s podatki administratorja-svetovalca, podpis na naslovnici
    const br = await chromium.launch(), errs = []; const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
    await pg.goto(B + "/"); await pg.fill("#le", "admin@t.si"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
    ok(/Administrator.* in .*svetovalec/i.test(await pg.textContent("#whoami")), "prikaz vlog v glavi: " + (await pg.textContent("#whoami")));
    await pg.evaluate(async () => { const c = document.createElement("canvas"); c.width = 200; c.height = 60; const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, 200, 60); x.strokeStyle = "#123"; x.lineWidth = 3; x.beginPath(); x.moveTo(10, 40); x.bezierCurveTo(50, 0, 90, 70, 190, 20); x.stroke(); await api("POST", "/api/izdelovalec-podpis/" + ME.u.id, { tip: "image/png", podatki: c.toDataURL("image/png").split(",")[1] }); });
    ok((await A(ca, "GET", "/api/auth/izdelovalec")).j.moje.podpis === true, "podpis naložen");
    const izvoz = async (ime) => { const b64 = await pg.evaluate(async id => { IZDELOVALEC.podpis = {}; IZDELOVALEC.logo = {}; const rec = await api("GET", "/api/d/nacrti/" + id), st = await api("GET", "/api/d/stranke/" + rec.stranka_id), ob = await api("GET", "/api/d/obrati?stranka_id=" + rec.stranka_id); await naloziIzdelovalca(rec.stranka_id); await naloziPodpis(izdelovalecNacrta(rec)); const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), st, ob, [], await baza(), [], undefined, {}); const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s); }, n.id); const f = path.join(OUT, ime); fs.writeFileSync(f, Buffer.from(b64, "base64")); return { t: pdfTxt(f), raw: fs.readFileSync(f, "latin1") }; };
    let x = await izvoz("vloge1.pdf");
    ok(/Izdelal \(svetovalec\)/.test(x.t) && /mag\. Luka Zorman/.test(x.t) && /HiGiFood d\.o\.o\./.test(x.t), "izvoz: Izdelal (svetovalec) z nazivom in podjetjem " + (x.t.match(/Izdelal \(svetovalec\).{0,120}/) || [""])[0]);
    ok(/Podpis:/.test(x.t) && (x.raw.match(/\/Subtype \/Image/g) || []).length >= 1, "naslovnica s sliko podpisa");
    ok(/mag\. Luka Zorman, univ\. dipl\. inž\. živilske tehnologije, HiGiFood d\.o\.o\./.test(x.t), "noga dokumenta s podatki svetovalca");
    // (b) v izbiri svetovalcev pri stranki
    await pg.goto(B + "/#/stranka/s9"); await pg.waitForSelector("#sv-card"); ok(/Luka Zorman[\s\S]*administrator/.test(await pg.textContent("#sv-card")), "pri stranki: administrator med svetovalci");
    // »Strokovno potrdil«: predlogi svetovalcev
    await pg.evaluate(id => sessionStorage.setItem("wstep:" + id, "5"), n.id); await pg.goto(B + "/#/carovnik/" + n.id); await pg.waitForSelector("#svl_potrdil option", { state: "attached" });
    ok((await pg.$$eval("#svl_potrdil option", o => o.map(x => x.value))).some(v => /^mag\. Luka Zorman, univ\. dipl\./.test(v)), "Strokovno potrdil: predlogi iz svetovalcev");
    // (d) potrditev → posnetek; izklop »Tudi svetovalec« in sprememba profila ne spremenita izdanega dokumenta
    const nn = (await A(ca, "GET", "/api/d/nacrti/" + n.id)).j;
    r = await A(ca, "PUT", "/api/d/nacrti/" + n.id, { status: "potrjeno", potrdil: "mag. Luka Zorman", datum_potrditve: "2026-11-05", _razlog: "Prva izdaja", _ver: nn.spremenjeno || nn.ustvarjeno });
    ok(r.s === 200 && r.j.izdelal_posnetek && r.j.izdelal_posnetek.podjetje === "HiGiFood d.o.o.", "ob potrditvi shranjeni podatki izdelovalca");
    r = await A(ca, "PUT", "/api/uporabniki/a1", { tudi_svetovalec: false }); ok(r.s === 200 && r.j.vloge.join() === "admin", "izklop »Tudi svetovalec«");
    await A(ca, "POST", "/api/auth/izdelovalec", { naziv: "", ime: "Luka Zorman", izobrazba: "", podjetje: "Drugo podjetje s.p." });
    sl = (await A(ca, "GET", "/api/svetovalci")).j; ok(!sl.some(z => z.id === "a1") && sl.some(z => z.id === "s1"), "po izklopu ga ni več med svetovalci");
    ok((await A(ca, "GET", "/api/auth/izdelovalec?stranka_id=s9")).j.za.svetovalec === null, "stranka nima več dodeljenega svetovalca");
    x = await izvoz("vloge2.pdf");
    ok(/mag\. Luka Zorman/.test(x.t) && /HiGiFood d\.o\.o\./.test(x.t) && !/Drugo podjetje/.test(x.t), "izdan (potrjen) dokument ostane nespremenjen " + (x.t.match(/Izdelal.{0,200}/) || [""])[0]);
    // dnevnik v Administraciji prikaže vlogo
    await pg.goto(B + "/#/admin"); await pg.waitForSelector("h2:has-text('Revizijska sled')", { state: "attached" }); ok(/<th>Vloga<\/th>/.test(await pg.content()), "revizijska sled v Administraciji: stolpec Vloga");
    ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
    await br.close();
  } finally { srv.kill("SIGTERM"); await new Promise(r => srv.on("exit", r)); fs.rmSync(data, { recursive: true, force: true }); }
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
