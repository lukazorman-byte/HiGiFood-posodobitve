// Popravki po pregledu (1. skupina): vrsta brez povezave (začasne napake, dvojniki, avtor), polja samo za strežnik (capa_id),
// hkratno urejanje HACCP načrta (409 namesto tihega prepisa).
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Kuhinja d.o.o." }); const o = await D.add("obrati", { stranka_id: s.id, naziv: "Obrat" });
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP", vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }] } }); return { sid: s.id, nid: n.id, uid: ME.u.id }; });
  // polja samo za strežnik: »capa_id« v novem zapisu ne prepreči samodejne neskladnosti
  const e1 = await pg.evaluate(sid => D.add("evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "H1", vrednost: 9, min: 0, max: 4, capa_id: "ponaredek" }), ids.sid);
  ok(e1.capa_id && e1.capa_id !== "ponaredek", "capa_id iz zahteve prezrt, samodejna neskladnost odprta (" + e1.capa_id + ")");
  // isti ključ _qid dvakrat: en zapis (izgubljen odgovor, dva zavihka)
  const dv = await pg.evaluate(async sid => { const a = await api("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "H2", vrednost: 3, min: 0, max: 4, _qid: "q123.4" }); const b = await api("POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", oprema: "H2", vrednost: 3, min: 0, max: 4, _qid: "q123.4" }); const vs = (await api("GET", "/api/d/evidence?stranka_id=" + sid)).filter(x => x.oprema === "H2"); return { a: a.id, b: b.id, n: vs.length }; }, ids.sid);
  ok(dv.a === dv.b && dv.n === 1, "ponovno poslan zapis z istim ključem ne naredi dvojnika");
  // vrsta brez povezave: začasna napaka strežnika (502) zapisa ne zavrže; zapis drugega uporabnika ostane
  await pg.evaluate(a => localStorage.setItem("haccp_offq", JSON.stringify([
    { t: 101, c: "evidence", uid: a.uid, body: { stranka_id: a.sid, vrsta: "temperatura", oprema: "H3", vrednost: 2, min: 0, max: 4, cas: new Date().toISOString(), _qid: "101" } },
    { t: 102, c: "evidence", uid: "drug-uporabnik", body: { stranka_id: a.sid, vrsta: "temperatura", oprema: "H4", vrednost: 2, min: 0, max: 4, cas: new Date().toISOString(), _qid: "102" } }])), ids);
  await pg.route("**/api/d/evidence", r => r.request().method() === "POST" ? r.fulfill({ status: 502, contentType: "text/html", body: "Bad Gateway" }) : r.continue());
  await pg.evaluate(() => syncOffQueue(true)); await pg.waitForTimeout(300);
  ok(await pg.evaluate(() => JSON.parse(localStorage.getItem("haccp_offq")).length) === 2, "502 med posodobitvijo strežnika: zapis ostane v vrsti");
  await pg.unroute("**/api/d/evidence");
  await pg.evaluate(() => syncOffQueue(true)); await pg.waitForTimeout(500);
  const q = await pg.evaluate(() => JSON.parse(localStorage.getItem("haccp_offq")));
  ok(q.length === 1 && q[0].uid === "drug-uporabnik", "po povezavi poslan zapis tega uporabnika, zapis drugega ostane");
  const h3 = await pg.evaluate(sid => api("GET", "/api/d/evidence?stranka_id=" + sid).then(a => a.filter(x => x.oprema === "H3")), ids.sid);
  ok(h3.length === 1 && h3[0].ustvaril === ids.uid, "zapis iz vrste shranjen enkrat, s pravim avtorjem");
  // zavrnjen zapis (400) se odstrani
  await pg.evaluate(a => localStorage.setItem("haccp_offq", JSON.stringify([{ t: 103, c: "evidence", uid: a.uid, body: { stranka_id: a.sid, vrsta: "temperatura", vrednost: "ni število", _qid: "103" } }])), ids);
  await pg.evaluate(() => syncOffQueue(true)); await pg.waitForTimeout(400);
  ok(await pg.evaluate(() => JSON.parse(localStorage.getItem("haccp_offq")).length) === 0, "zapis, ki ga strežnik zavrne (400), se odstrani iz vrste");
  await pg.evaluate(() => localStorage.removeItem("haccp_offq"));
  // hkratno urejanje načrta: drug uporabnik shrani vmes → 409 z vprašanjem, brez tihega prepisa
  await pg.goto(B + "/#/carovnik/" + ids.nid); await pg.waitForSelector("#wsave");
  await pg.evaluate(async nid => { const n = (await D.list("nacrti")).find(x => x.id === nid); await api("PUT", "/api/d/nacrti/" + nid, { naziv: "HACCP (spremenil drug)", _ver: n.spremenjeno || n.ustvarjeno, _razlog: "drug uporabnik" }); }, ids.nid);
  await pg.evaluate(() => { const i = document.querySelector("#view input[data-k]"); if (i) { i.value = "sprememba"; i.dispatchEvent(new Event("input", { bubbles: true })); } });
  let vpr = ""; pg.once("dialog", d => { vpr = d.message(); d.dismiss(); });
  await pg.click("#wsave"); await pg.waitForTimeout(800);
  ok(/medtem/.test(vpr) && /Naložim shranjeno različico/.test(vpr), "shranjevanje načrta po tuji spremembi: vprašanje namesto prepisa (" + vpr.slice(0, 80) + ")");
  const nv = await pg.evaluate(nid => D.list("nacrti").then(a => a.find(x => x.id === nid)), ids.nid);
  ok(nv.naziv === "HACCP (spremenil drug)", "tuja sprememba ni prepisana");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
