// Strežnik v Dockerju (HACCP_STRAN_JAVNA=1): spletna stran na /stran/ je javna brez nastavljanja; administrator jo lahko izklopi.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  let r = await fetch(B + "/stran/"); ok(!r.headers.get("x-robots-tag") && /index, follow/.test(await r.text()), "privzeto (okolje): /stran/ je javna");
  const a = await (await br.newContext()).newPage(); await a.goto(B + "/"); await a.waitForURL(/\/stran\/$/, { timeout: 10000 }).catch(() => {});
  ok(new URL(a.url()).pathname === "/stran/", "neprijavljen obiskovalec pride na spletno stran");
  await pg.goto(B + "/#/spletna-stran/seo"); await pg.waitForSelector("#seo_j"); ok(await pg.isChecked("#seo_j"), "stikalo v SEO prikazuje vklop");
  await pg.uncheck("#seo_j"); await pg.click("#seo_s"); await pg.waitForTimeout(500);
  r = await fetch(B + "/stran/"); ok(/noindex/.test(r.headers.get("x-robots-tag") || ""), "administrator izklopi: /stran/ spet predogled");
  const b = await (await br.newContext()).newPage(); await b.goto(B + "/"); await b.waitForSelector("#le"); ok(new URL(b.url()).pathname === "/", "po izklopu vstopna stran ostane prijava");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
