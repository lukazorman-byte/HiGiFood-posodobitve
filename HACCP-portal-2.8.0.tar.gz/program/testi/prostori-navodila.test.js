// Prostori obrata → protokoli čiščenja; koraki in nevarnosti iz naprav (čarovnik); navodilo »Čiščenje« iz načrta čiščenja.
const B = process.env.BASE; const { chromium } = require("./pw.js"), PR = require("../baza/prostori.json");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  ok(PR.length >= 20 && PR.every(p => p.id && p.naziv && p.ciscenje.length && p.ciscenje.every(c => c.opravilo && +c.pogostost_dni > 0 && c.metoda)) && !/[Ѐ-ӿ]/.test(JSON.stringify(PR)), "baza prostorov: " + PR.length + " prostorov s protokoli, brez cirilice");
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Prostori d.o.o." });
    await D.add("obrati", { stranka_id: s.id, naziv: "Bistro", prostori: [{ ime: "Kuhinja", opis: "" }, { ime: "Sanitarije za goste", opis: "" }], naprave: [{ ime: "Hladilnik", opis: "" }] }); return s.id; });
  await pg.goto(B + "/#/stranka/" + sid + "/obrati"); await pg.waitForSelector("#ob_nv"); await pg.click("#ob_nv"); await pg.waitForSelector("[data-nv]");
  const vrst = await pg.$$eval("#nv_b tr", r => r.map(x => x.textContent.replace(/\s+/g, " ").trim()));
  ok(vrst.some(t => /Načrt čiščenja.*Kuhinja.*Napa in filtri/.test(t)) && vrst.some(t => /Sanitarije za goste.*2× dnevno/.test(t)), "predlog vsebuje protokole prostorov (kuhinja, sanitarije 2× dnevno)");
  await pg.click("dialog[open] #dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  const c = await pg.evaluate(sid => D.list("ciscenje_nacrt", { stranka_id: sid }), sid);
  ok(c.some(x => x.podrocje === "Kuhinja" && x.opravilo === "Tla in odtoki") && c.some(x => x.podrocje === "Sanitarije za goste" && x.krat_na_dan === "2"), "načrt čiščenja vsebuje prostore (" + c.length + ")");
  // navodilo iz načrta čiščenja: ustvari, nato posodobi (brez podvajanja)
  await pg.goto(B + "/#/stranka/" + sid + "/evidence"); await pg.waitForTimeout(300);
  await pg.evaluate(sid => navodiloCiscenjaIzNacrta({ stranka_id: sid, stranka: { naziv: "Prostori d.o.o." } }), sid);
  await pg.evaluate(sid => navodiloCiscenjaIzNacrta({ stranka_id: sid, stranka: { naziv: "Prostori d.o.o." } }), sid);
  const nav = await pg.evaluate(sid => D.list("navodila", { stranka_id: sid }), sid);
  ok(nav.length === 1 && nav[0].tema === "ciscenje" && nav[0].iz_nacrta_ciscenja && /\n- Kuhinja: Tla in odtoki – dnevno; detergent za tla/.test(nav[0].vsebina) && /Sanitarije za goste: .*2× dnevno/.test(nav[0].vsebina) && !/\\n/.test(nav[0].vsebina), "navodilo Čiščenje iz načrta (eno, posodobljeno) " + JSON.stringify(nav.map(n => [n.tema, n.iz_nacrta_ciscenja, n.vsebina.slice(0, 400)])));
  // čarovnik: koraki in nevarnosti iz naprav obrata
  const r = await pg.evaluate(async () => { const db = await baza(), W = { koraki: [{ id: "k1", naziv: "Skladiščenje v hladilniku", tip: "skladiščenje" }], nevarnosti: [] }; const ob = { naprave: [{ ime: "Hladilnik" }, { ime: "Friteza" }] }; const a = korakiIzNaprav(W, db, ob), b = korakiIzNaprav(W, db, ob); return { a, b, W }; });
  ok(r.a.nh.length >= 1 && r.b.nk.length === 0 && r.b.nh.length === 0 && r.W.nevarnosti.every(h => h.predlog && !h.potrjeno), "koraki/nevarnosti iz naprav: predlog, drugič brez podvajanja " + JSON.stringify(r.a));
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
