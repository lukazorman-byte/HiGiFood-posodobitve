// Izvoz osebnih podatkov (čl. 15 in 20 GDPR): ZIP s poročilom (PDF, HTML), CSV, podatki.json in prilogami; brez gesel, TOTP, ključev,
// naslovov vedra in brez podatkov drugih oseb; vsak izvoz v revizijski sledi. Izvoz podatkov stranke je ločen.
const fs = require("fs"), path = require("path"), cp = require("child_process"), crypto = require("crypto");
const B = process.env.BASE, OUT = process.env.OUT || require("os").tmpdir(); fs.mkdirSync(OUT, { recursive: true });
const { chromium } = require("./pw.js"), beriZip = require("./zip.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const dec = s => { let bits = 0, val = 0; const out = []; for (const ch of s.toUpperCase().replace(/[^A-Z2-7]/g, "")) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); };
const totp = (key, ctr) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); const h = crypto.createHmac("sha1", key).update(b).digest(), o = h[h.length - 1] & 15; return String(((h.readUInt32BE(o) & 0x7fffffff) % 1e6)).padStart(6, "0"); };
const PNG = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
(async () => {
  const br = await chromium.launch(); const errs = [];
  const ctx = await br.newContext({ acceptDownloads: true }), pg = await ctx.newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "mojca@t.si"); await pg.fill("#ln", "Mojca Šušteršič"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // podatki: lastni zapisi, zapisi z drugimi osebami, priloga, nastavitve oblaka (naslov vedra in ključ), drug uporabnik
  const s = await pg.evaluate(async png => {
    const st = await D.add("stranke", { naziv: "Gostilna Pri Čebelici d.o.o.", odgovorna_oseba: "Boris Drugi" }), ob = await D.add("obrati", { stranka_id: st.id, naziv: "Kuhinja Šentvid" });
    await D.add("osebje", { stranka_id: st.id, ime: "Mojca Šušteršič", funkcija: "Svetovalka", email: "mojca@t.si" });
    await D.add("osebje", { stranka_id: st.id, ime: "Boris Drugi", funkcija: "Kuhar", email: "boris@drugi.si", zdravniski_do: "2027-01-01" });
    await D.add("usposabljanja", { stranka_id: st.id, tema: "Higiena živil", datum: "2026-10-01", udelezenci: "Mojca Šušteršič, Boris Drugi" });
    await D.add("dobavitelji", { stranka_id: st.id, naziv: "=HYPERLINK(\"http://napad.test\",\"klik\")", kategorija: "+1-2", ocena: "odobren" }); // formula v CSV
    await D.add("dobavitelji", { stranka_id: st.id, naziv: "Mesnica Žnidaršič", kontakt: "Boris Drugi, 041 111 222", ocena: "odobren" });
    let nacrt = null;
    try {
      nacrt = await D.add("nacrti", { stranka_id: st.id, obrat_id: ob.id, naziv: "HACCP načrt kuhinje", status: "osnutek", verzija_oznaka: "1.0",
        vsebina: { koraki: [{ id: "k1", naziv: "Prevzem" }, { id: "k2", naziv: "Kuhanje" }], nevarnosti: [{ id: "h1", korak_id: "k2", nevarnost: "Salmonela" }], kontrole: { h1: { vrsta: "CCP" } },
          zbiranje: { clani: [{ ime: "Mojca Šušteršič", vloga: "vodja HACCP skupine" }, { ime: "Boris Drugi", vloga: "član" }] } } });
      await D.set("nacrti", nacrt.id, { naziv: "HACCP načrt kuhinje Šentvid", _razlog: "dopolnjena analiza" });
    } catch (e) { nacrt = { napaka: e.message }; }
    await api("POST", "/api/priloga", { stranka_id: st.id, ime: "tloris kuhinje.png", tip: "image/png", podatki: png });
    await api("PUT", "/api/kopija/nastavitve", { mapa: "", geslo: "sifra12345" });
    await api("PUT", "/api/kopija/oblak", { endpoint: "https://abc123def.r2.cloudflarestorage.com", regija: "auto", vedro: "skrito-vedro-42", kljuc_id: "KLJUCID99", skrivnost: "TAJNIKLJUC123", predpona: "" });
    await api("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_SKRIVNIKLJUC77", od: "obvestila@higifood.si" });
    await api("POST", "/api/uporabniki", { ime: "Zala Druga", email: "zala@drugi.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: st.id });
    return { sid: st.id, nacrt };
  }, PNG);
  ok(s.nacrt && !s.nacrt.napaka, "HACCP načrt ustvarjen " + JSON.stringify(s.nacrt && s.nacrt.napaka || ""));
  const tlv = await pg.evaluate(async id => { const r = []; for (const t of [[{ vrsta: "slika", id: "../../api/uporabniki" }], [{ vrsta: "x", id: "abc" }], [{ vrsta: "slika", id: "abc_DEF-12", naslov: "Klet" }]]) r.push(await D.add("nacrti", { stranka_id: id, naziv: "Preizkus tlorisov", vsebina: { zbiranje: { tlorisi: t } } }).then(x => D.del("nacrti", x.id).then(() => "ok"), e => "napaka")); return r; }, s.sid);
  ok(tlv.join(",") === "napaka,napaka,ok", "strežnik zavrne neveljaven seznam tlorisov v načrtu (pot, vrsta): " + tlv.join(","));
  // dvostopenjska prijava: skrivnost in rezervne kode ne smejo v izvoz
  const z = await pg.evaluate(() => api("POST", "/api/auth/2fa/zacni", {}));
  const kljuc = dec(z.skrivnost), rez = await pg.evaluate(k => api("POST", "/api/auth/2fa/potrdi", { koda: k }), totp(kljuc, Math.floor(Date.now() / 30000)));
  ok(rez.rezervne && rez.rezervne.length === 8, "2FA vklopljena");
  const seja = (await ctx.cookies()).map(c => c.value).filter(v => v.length > 15);
  // izvoz prek strani Varstvo osebnih podatkov
  await pg.goto(B + "/#/gdpr"); await pg.waitForSelector("#g_x");
  await pg.fill("#g_i", "Mojca Šušteršič"); await pg.fill("#g_e", "mojca@t.si"); await pg.fill("#g_zh", "Mojca Šušteršič (e-pošta 5. 11. 2026)");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#g_x")]);
  ok(/^izvoz-osebnih-podatkov-mojca-sustersic-\d{4}-\d\d-\d\d\.zip$/.test(dl.suggestedFilename()), "ime datoteke: " + dl.suggestedFilename());
  const zf = path.join(OUT, "izvoz.zip"); await dl.saveAs(zf); const zipBuf = fs.readFileSync(zf), Z = beriZip(zipBuf), imena = Object.keys(Z);
  await pg.waitForSelector("#g_npt:has-text('Prenesen')"); ok(await pg.locator("#g_npb").count() === 1, "indikator napredka: " + await pg.textContent("#g_npt"));
  ok(["porocilo.pdf", "porocilo.html", "podatki.json"].every(n => Z[n]) && imena.some(n => n.startsWith("csv/")) && imena.some(n => /^priloge\/.+\.png$/.test(n)), "ZIP vsebuje vse 4 dele: " + imena.join(", "));
  ok(zipBuf.length < 2e6, "velikost ZIP " + Math.round(zipBuf.length / 1024) + " kB (< 2 MB)");
  ok(Z[imena.find(n => n.startsWith("priloge/"))].slice(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])), "priloga je PNG datoteka (ne base64)");
  // PDF se odpre in ima berljivo vsebino
  const pf = path.join(OUT, "porocilo.pdf"); fs.writeFileSync(pf, Z["porocilo.pdf"]);
  const pt = cp.spawnSync("pdftotext", [pf, "-"], { encoding: "utf8" });
  if (pt.error) console.log("ok: pdftotext ni nameščen, branje PDF preskočeno"); else {
    const t = pt.stdout.replace(/\s+/g, " ");
    ok(pt.status === 0 && /^%PDF-1\.4/.test(Z["porocilo.pdf"].toString("latin1", 0, 8)), "PDF se odpre (pdftotext)");
    for (const x of ["Izvoz osebnih podatkov", "Moj račun", "Administrator HiGiFood", "vse stranke (administrator)", "Gostilna Pri Čebelici", "vklopljena", "Revizijska sled", "Vklop dvostopenjske prijave", "Varnostna kopija shranjena v oblak", "Informacijskem pooblaščencu", "vodja HACCP skupine", "dopolnjena analiza", "Zahtevo podal"])
      ok(t.includes(x), "PDF vsebuje »" + x + "«");
    ok(/\d{1,2}\. \d{1,2}\. \d{4}, \d\d:\d\d/.test(t), "PDF: čas v obliki »7. 11. 2026, 11:24«");
    ok(/ni zapisov/.test(t), "prazne zbirke: »ni zapisov«");
  }
  // CSV za Excel: BOM, ločilo »;«, slovenski stolpci, šumniki, datumi DD. MM. LLLL HH:MM
  const sled = Z["csv/revizijska-sled.csv"], racun = Z["csv/racun.csv"], usp = Z["csv/usposabljanja.csv"];
  ok(sled && racun && usp && [sled, racun, usp].every(b => b[0] === 0xEF && b[1] === 0xBB && b[2] === 0xBF), "CSV z UTF-8 BOM (Excel prikaže šumnike)");
  const ts = sled.toString("utf8");
  ok(/^\uFEFFDatum in čas;Dejanje;Opis;Zbirka;Izvedel;IP naslov\r\n/.test(ts), "CSV sledi: slovenski stolpci, ločilo »;«");
  ok(/\r\n\d\d\. \d\d\. \d{4} \d\d:\d\d;/.test(ts), "CSV datumi DD. MM. LLLL HH:MM");
  ok(racun.toString("utf8").includes("Mojca Šušteršič") && racun.toString("utf8").includes("Dvostopenjska prijava (2FA);vklopljena"), "CSV računa: šumniki, 2FA z besedo");
  ok(/Udeleženci;/.test(usp.toString("utf8")) || /Kje nastopate/.test(usp.toString("utf8")), "CSV usposabljanj: slovenski stolpci");
  { const dob = Z["csv/dobavitelji.csv"].toString("utf8"); ok(dob.includes("'=HYPERLINK(") && !/(^|;|")=HYPERLINK/m.test(dob) && dob.includes("'+1-2"), "CSV: vrednosti z = + - @ se ne izvedejo kot formula v Excelu"); }
  ok(!/\b(true|false)\b/.test(Object.entries(Z).filter(([n]) => n.endsWith(".csv")).map(([, b]) => b.toString("utf8")).join("")), "CSV: »da/ne« namesto true/false");
  // podatki.json: urejen, strojno berljiv, enaki ključi kot prej, priloge kot sklic
  const js = Z["podatki.json"].toString("utf8"), J = JSON.parse(js);
  ok(js.startsWith('{\n  "izvozeno"'), "podatki.json z zamikom 2 presledka");
  ok(["izvozeno", "oseba", "uporabniski_racuni", "zapisi", "revizijska_sled"].every(k => k in J), "podatki.json: ključi izvozeno, oseba, uporabniski_racuni, zapisi, revizijska_sled");
  ok(J.priloge.length === 1 && /^priloge\//.test(J.priloge[0].datoteka) && !("podatki" in J.priloge[0]) && !js.includes(PNG.slice(0, 40)), "priloge v JSON samo kot sklic na datoteko");
  ok(J.revizijska_sled.every(e => !("h" in e)), "brez polja h (hash verige)");
  ok(J.zapisi.nacrti && J.zapisi.nacrti[0].stevilo.ccp === 1 && J.zapisi.nacrti[0].haccp_skupina === "vodja HACCP skupine" && !("vsebina" in J.zapisi.nacrti[0]) && J.zapisi.nacrti[0].zgodovina.length >= 1, "HACCP načrt: povzetek (CCP, vloga v skupini, zgodovina), brez vsebine");
  // varnost in podatki drugih oseb: v nobeni datoteki
  const vse = Object.values(Z).map(b => b.toString("latin1")).join("\n") + "\n" + Object.values(Z).map(b => b.toString("utf8")).join("\n") + "\n" + (pt.stdout || "");
  const prepovedano = [["geslo (čisto)", "dolgogeslo123"], ["TOTP skrivnost", z.skrivnost.replace(/\s/g, "")], ["rezervna koda", rez.rezervne[0]], ["hash rezervne kode", crypto.createHash("sha256").update(rez.rezervne[0]).digest("hex")],
    ["naslov vedra", "r2.cloudflarestorage"], ["ime vedra", "skrito-vedro-42"], ["ključ oblaka", "KLJUCID99"], ["skrivnost oblaka", "TAJNIKLJUC123"], ["ključ API", "re_SKRIVNIKLJUC77"], ["geslo kopij", "sifra12345"],
    ["drug zaposleni", "Boris Drugi"], ["e-naslov drugega", "boris@drugi.si"], ["drug uporabnik", "Zala Druga"], ["e-naslov uporabnika", "zala@drugi.si"], ...seja.map(v => ["žeton seje", v])];
  for (const [opis, v] of prepovedano) ok(!vse.includes(v), "ni v izvozu: " + opis);
  ok(!/[0-9a-f]{32}:[0-9a-f]{128}/.test(vse), "ni v izvozu: hash gesla (scrypt)");
  ok(!/"(geslo|totp_skrivnost|totp_rezervne|totp_cakanje|api_kljuc|oblak_skrivnost)"/.test(js), "podatki.json brez polj z gesli in ključi");
  // revizijska sled: izvoz zabeležen
  const sl = await pg.evaluate(() => api("GET", "/api/revizijska-sled?n=5").then(r => r.vnosi.map(e => e.akcija)));
  ok(sl.includes("gdpr-izvoz"), "izvoz zabeležen v revizijski sledi");
  // izvoz podatkov stranke: ločena funkcija, vsebuje vse zapise stranke
  const [d2] = await Promise.all([pg.waitForEvent("download"), pg.click("#g_xs")]); const z2 = path.join(OUT, "stranka.zip"); await d2.saveAs(z2); const Z2 = beriZip(fs.readFileSync(z2));
  const J2 = JSON.parse(Z2["podatki.json"].toString("utf8"));
  ok(/^izvoz-podatkov-stranke-/.test(d2.suggestedFilename()) && J2.zapisi.osebje.length === 2 && Object.keys(Z2).some(n => n.startsWith("priloge/")) && !Z2["podatki.json"].toString("utf8").includes("TAJNIKLJUC123"), "izvoz podatkov stranke: vsi zaposleni, priloge, brez skrivnosti");
  ok(await pg.evaluate(() => api("GET", "/api/revizijska-sled?n=5").then(r => r.vnosi.some(e => e.akcija === "izvoz-stranke"))), "izvoz stranke zabeležen v sledi");
  // zaposleni nima dostopa
  ok(await pg.evaluate(sid => fetch("/api/gdpr/izvoz-stranke", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ stranka_id: sid }) }).then(r => r.status), s.sid) === 200, "izvoz stranke prek API (administrator)");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
