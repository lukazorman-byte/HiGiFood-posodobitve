// Dodatki po 2.7.0: letni pregled (verifikacija), trend temperature naprav, Danes za zaposlenega na telefonu, sledljivost nazaj/naprej,
// neskladnost na enem zaslonu (zaprtje), takojšnji opomnik ob zamudi neskladnosti, jezik vmesnika in prevod navodil.
const fs = require("fs"), path = require("path"), http = require("http"), cp = require("child_process");
const B = process.env.BASE, OUT = process.env.OUT || require("os").tmpdir(); fs.mkdirSync(OUT, { recursive: true });
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const pocakaj = async (fn, ms = 6000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await new Promise(r => setTimeout(r, 150)); } return false; };
(async () => {
  const POSTA = [];
  const mail = http.createServer((q, r) => { let b = ""; q.on("data", c => b += c); q.on("end", () => { POSTA.push(JSON.parse(b || "{}")); r.writeHead(200, { "Content-Type": "application/json" }); r.end('{"id":"1"}'); }); }).listen(4955, "127.0.0.1");
  const deepl = http.createServer((q, r) => { let b = ""; q.on("data", c => b += c); q.on("end", () => { const j = JSON.parse(b || "{}"); r.writeHead(200, { "Content-Type": "application/json" }); r.end(JSON.stringify({ translations: (j.text || []).map(t => ({ text: "[" + j.target_lang + "] " + t })) })); }); }).listen(4953, "127.0.0.1");
  const br = await chromium.launch(); const errs = [];
  const nova = async opt => { const p = await (await br.newContext(Object.assign({ acceptDownloads: true }, opt || {}))).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const pg = await nova();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const dan = d => { const x = new Date(Date.now() + d * 864e5); return x.toISOString().slice(0, 10); }, cas = (d, h) => new Date(Date.now() + d * 864e5 + (h || 0) * 36e5).toISOString();
    const s = await D.add("stranke", { naziv: "Bistro Ob Reki d.o.o.", odgovorna_oseba: "Olga Novak" });
    const o = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja" });
    await D.add("oprema", { stranka_id: s.id, obrat_id: o.id, naziv: "Hladilnik A", tip: "hladilnik", meja_min: 0, meja_max: 4 });
    await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", naprava: "Hladilnik A", frekvenca_ur: 24 });
    // Hladilnik A se segreva: od 1,8 °C do 3,6 °C v 12 dneh (še v mejah)
    for (let i = 0; i <= 12; i++) await D.add("evidence", { stranka_id: s.id, obrat_id: o.id, vrsta: "temperatura", oprema: "Hladilnik A", vrednost: Math.round((1.8 + i * 0.15) * 10) / 10, min: 0, max: 4, cas: cas(i - 12, 8) });
    // Hladilnik B: ponavljajoča se odstopanja
    for (let i = 0; i < 3; i++) await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik B", vrednost: 6.5, min: 0, max: 4, cas: cas(-30 * (i + 1)) });
    // sledljivost: šarža, zapis prevzema, jed s to sestavino
    await D.add("sarze", { stranka_id: s.id, izdelek: "Piščančje meso", sarza: "LOT-77", dobavitelj: "Perutnina d.o.o.", datum_prevzema: dan(-2) });
    await D.add("evidence", { stranka_id: s.id, vrsta: "prevzem", izdelek: "Piščančje meso", sarza: "LOT-77", vrednost: 3, max: 4, embalaza_ok: true, dokumenti_ok: true, cas: cas(-2) });
    await D.add("jedi", { stranka_id: s.id, naziv: "Piščančja obara", sestavine: "piščančje meso, korenje, peteršilj" });
    const nav = await D.add("navodila", { stranka_id: s.id, naslov: "Umivanje rok", vrsta: "Delovno navodilo", vsebina: "Roke umijte s toplo vodo in milom." });
    const c = await D.add("capa", { stranka_id: s.id, opis: "Pokvarjen termometer v hladilnici", tveganje: "srednje", status: "odprto", rok: dan(-1) });
    const c2 = await D.add("capa", { stranka_id: s.id, opis: "Stara zamuda brez takojšnjega sporočila", tveganje: "nizko", status: "odprto", rok: dan(-20) });
    await api("POST", "/api/uporabniki", { ime: "Olga Novak", email: "o@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s.id });
    await api("POST", "/api/uporabniki", { ime: "Zoran Kovač", email: "z@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id });
    await api("PUT", "/api/nastavitve", { nacin: "resend", api_kljuc: "re_test", od: "obvestila@higifood.si", naslov_aplikacije: "https://app.higifood.si" });
    return { sid: s.id, capa: c.id, capa2: c2.id, nav: nav.id };
  });
  // 1) letni pregled (verifikacija): PDF z rednostjo, odstopanji, neskladnostmi in predlogi
  await pg.goto(B + `/#/stranka/${ids.sid}/inspekcija`); await pg.waitForSelector("#i_vf"); await pg.click("#i_vf"); await pg.waitForSelector("#vf_od");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#dlg-f .btn:last-child")]); const pf = path.join(OUT, "letni.pdf"); await dl.saveAs(pf);
  const pt = cp.spawnSync("pdftotext", [pf, "-"], { encoding: "utf8" });
  if (pt.error) console.log("ok: pdftotext ni nameščen"); else { const t = pt.stdout.replace(/\s+/g, " ");
    for (const x of ["Letni pregled HACCP sistema", "Rednost vnosov po urniku", "Ponavljajoča se odstopanja", "Hladilnik B", "Neskladnosti in korektivni ukrepi", "Sklepi in predlogi", "Potrditev pregleda"]) ok(t.includes(x), "letni pregled vsebuje »" + x + "«");
    ok(/Hladilnik B«: 3 odstopanj/.test(t), "predlog za napravo s ponavljajočimi se odstopanji");
    ok(/Temperatura hladilnika \/ zamrzovalnika Hladilnik A 24 h \d+ ?\/ ?\d+ \d+ %/.test(t), "rednost vnosov po urniku (Hladilnik A, 24 h): " + (t.match(/Hladilnik A 24 h [^%]*%/) || [""])[0]); ok(/v zamudi/.test(t), "predlog: neskladnost v zamudi"); }
  // 2) trend temperature: graf in opozorilo, da se Hladilnik A segreva
  await pg.goto(B + `/#/stranka/${ids.sid}/evidence`); await pg.waitForSelector("#trend_k svg polyline");
  ok(/Naprava se segreva/.test(await pg.textContent("#tr_o")), "trend: opozorilo za Hladilnik A (" + (await pg.textContent("#tr_o")).slice(0, 90) + ")");
  await pg.selectOption("#tr_n", "Hladilnik B"); await pg.waitForTimeout(200); ok(await pg.locator("#trend_k svg circle[fill='var(--bad)']").count() >= 1 || /ni meritev/.test(await pg.textContent("#tr_g")), "trend: odstopanja označena (ali brez meritev v obdobju)");
  await pg.goto(B + "/#/danes"); await pg.waitForSelector("#dn"); await pg.waitForSelector("[data-trend]"); ok((await pg.textContent("[data-trend]")).includes("Hladilnik A se segreva"), "Danes: opozorilo o segrevanju");
  // 3) sledljivost: zapis prevzema (nazaj) in jedi (naprej)
  await pg.goto(B + `/#/stranka/${ids.sid}/sledljivost`); await pg.waitForSelector("#od_q"); await pg.fill("#od_q", "LOT-77"); await pg.click("#od_i"); await pg.waitForSelector("#od_t");
  const st = await pg.textContent("#od_t"); ok(/3 °C – skladno/.test(st) && st.includes("Piščančja obara"), "sledljivost: zapis prevzema in jed s to sestavino");
  // 4) takojšnji opomnik ob zamudi neskladnosti (enkrat)
  await pg.evaluate(() => api("POST", "/api/obvestila/zdaj", {}));
  ok(await pocakaj(() => POSTA.some(p => /^Zamuda: neskladnost/.test(p.subject) && [].concat(p.to)[0] === "o@t.si")), "zamuda: e-pošta odgovorni osebi");
  const zm = POSTA.find(p => /^Zamuda: neskladnost/.test(p.subject)); ok(zm && zm.text.includes("https://app.higifood.si/#/neskladnost/" + ids.capa), "zamuda: povezava na neskladnost");
  const n1 = POSTA.filter(p => /^Zamuda/.test(p.subject)).length; await pg.evaluate(() => api("POST", "/api/obvestila/zdaj", {})); await new Promise(r => setTimeout(r, 500));
  ok(POSTA.filter(p => /^Zamuda/.test(p.subject)).length === n1, "zamuda: opomnik samo enkrat");
  ok(!POSTA.some(p => /^Zamuda/.test(p.subject || "") && /Stara zamuda/.test(p.text || "")) && POSTA.some(p => /Stara zamuda/.test(p.text || "")), "zamuda starejša od 7 dni: brez takojšnjega sporočila, je pa v dnevnem povzetku");
  // podaljšan rok, ki spet poteče: nov opomnik
  await pg.evaluate(async id => { const c = (await D.list("capa")).find(x => x.id === id); const d = new Date(Date.now() - 2 * 864e5).toISOString().slice(0, 10); await D.set("capa", id, { _ver: c.spremenjeno || c.ustvarjeno, rok: d, _razlog: "nov rok" }); }, ids.capa);
  await pg.evaluate(() => api("POST", "/api/obvestila/zdaj", {}));
  ok(await pocakaj(() => POSTA.filter(p => /^Zamuda/.test(p.subject)).length > n1), "zamuda: po spremembi roka in novi zamudi nov opomnik");
  // 5) neskladnost na enem zaslonu: zaprtje
  await pg.goto(B + "/#/neskladnost/" + ids.capa); await pg.waitForSelector("#nk_z");
  await pg.click("#nk_z"); ok((await pg.textContent("#nk_e")).includes("dolgoročni ukrep"), "zaprtje brez ukrepa zavrnjeno");
  await pg.fill("#nk_u", "Zamenjan termometer, umerjanje 1× letno"); await pg.fill("#nk_p", "Naslednjih 5 meritev v mejah"); await pg.click("#nk_z"); await pg.waitForSelector(".toast.show:has-text('Neskladnost zaprta')");
  const cz = await pg.evaluate(id => D.list("capa").then(a => a.find(x => x.id === id)), ids.capa); ok(cz.status === "zaprto" && cz.zaprl === "Luka Zorman" && cz.datum_zapiranja, "neskladnost zaprta z imenom in datumom");
  // 6) zaposleni na telefonu: začne na strani Danes; jezik vmesnika angleščina; prevod navodila
  const tel = await nova({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  await tel.goto(B + "/"); await tel.fill("#le", "z@t.si"); await tel.fill("#lp", "dolgogeslo123"); await tel.click("#lf button");
  await tel.waitForSelector("#p0"); await tel.fill("#p0", "dolgogeslo123"); await tel.fill("#p1", "novogeslo12345"); await tel.click("#dlg-f .btn:last-child"); await tel.waitForSelector("#dlg", { state: "hidden" });
  await tel.waitForSelector("#dn"); ok((await tel.textContent("#title")) === "Danes", "zaposleni na telefonu začne na strani Danes (" + (await tel.textContent("#title")) + ")");
  { const d = await nova(); await d.goto(B + "/"); await d.fill("#le", "z@t.si"); await d.fill("#lp", "novogeslo12345"); await d.click("#lf button"); await d.waitForSelector("#shell:not([hidden])"); await d.waitForTimeout(800);
    ok((await d.textContent("#title")) === "Nadzorna plošča", "zaposleni na računalniku ostane na nadzorni plošči"); await d.context().close(); }
  await tel.evaluate(() => api("POST", "/api/auth/jezik", { jezik: "en" })); await tel.reload(); await tel.waitForSelector("#dn h2");
  const dt = await tel.textContent("#view"); ok(/Entries to be made|Quick temperature entry/.test(dt) && !/Vnosi, ki jih je treba opraviti/.test(dt), "jezik vmesnika: Danes v angleščini");
  ok(dt.includes("Hladilnik A"), "vneseni podatki (ime naprave) ostanejo nespremenjeni");
  // izbire brez atributa value: prevedeno je besedilo, vrednost (shranjeno stanje) ostane slovenska
  await pg.evaluate(() => api("POST", "/api/auth/jezik", { jezik: "en" })); await pg.goto(B + `/#/stranka/${ids.sid}/evidence`); await pg.reload(); await pg.waitForSelector("#es");
  const op = await pg.evaluate(() => [...document.querySelectorAll("#es option")].map(o => o.value + "=" + o.textContent));
  ok(op.includes("vneseno=entered") && op.includes("potrjeno=confirmed"), "jezik: prevedena izbira obdrži slovensko vrednost (" + op.join(", ") + ")");
  await pg.selectOption("#es", "potrjeno"); await pg.waitForSelector("#es"); ok(await pg.evaluate(() => JSON.parse(sessionStorage.getItem("eflt") || "{}").s) === "potrjeno", "jezik: filter dela s slovensko vrednostjo");
  await pg.evaluate(() => { sessionStorage.removeItem("eflt"); return api("POST", "/api/auth/jezik", { jezik: "sl" }); });
  const pr = await tel.evaluate(() => api("POST", "/api/prevedi", { jezik: "en", besedila: ["Umivanje rok", "Roke umijte s toplo vodo in milom."] }));
  ok(pr.prevodi && pr.prevodi[0] === "[EN-GB] Umivanje rok", "prevod navodila prek DeepL (EN-GB): " + JSON.stringify(pr.prevodi));
  ok(await tel.evaluate(() => api("POST", "/api/prevedi", { jezik: "de", besedila: ["x"] }).then(() => false, () => true)), "neveljaven jezik prevoda zavrnjen");
  ok(await pg.evaluate(() => api("POST", "/api/auth/jezik", { jezik: "xx" }).then(() => false, () => true)), "neveljaven jezik vmesnika zavrnjen");
  console.log("napake", errs); if (errs.length) fails++; mail.close(); deepl.close(); await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
