// Shranjevanje zbirk (stranke, uporabniki, evidence …): podatkovna baza SQLite (vgrajena v Node.js 22) ali datoteke JSON.
// SQLite zapiše samo spremenjene zapise (hitro tudi pri veliko evidencah in uporabnikih); JSON je rezerva, če SQLite ni na voljo
// ali je izbrana s HACCP_SHRAMBA=json. Ob prvem zagonu z bazo se obstoječe datoteke <zbirka>.json samodejno prenesejo v bazo
// (izvirnik ostane kot <zbirka>.json.v-bazi). Varnostne kopije ostanejo v obliki JSON (enake kot prej), zato obnova in
// preizkus obnove delujeta z obema načinoma in s kopijami starejših različic.
// Nastavitve in stanja (_nastavitve.json, _narocnine.json, _umiki.json, seje …) so v isti bazi (tabela »datoteke«, ena vrstica na datoteko).
// Ob vsakem zapisu se zapiše tudi zrcalna datoteka _<ime>.json, da vrnitev na prejšnjo različico (do 2.4.x) ne izgubi nastavitev.
const fs = require("fs"), path = require("path");
// datoteke z nastavitvami in stanji v mapi s podatki, ki jih hrani baza (posodobitev programa ostane datoteka: bere jo že pred zagonom baze)
const DATOTEKE = new Set(["_seje.json", "_varnost.json", "_kopija-stanje.json", "_oblak-stanje.json", "_nastavitve.json", "_zetoni.json", "_umiki.json", "_umiki-viri.json", "_umiki-rasff.json", "_vidnost.json", "_obvestila.json", "_gdpr.json", "_preizkus-obnove.json", "_tisk.json", "_narocnine.json"]);
const BREZ_KOPIJE = new Set(["_seje.json", "_zetoni.json"]); // seje in žetoni ne sodijo v varnostno kopijo
const DB_DATOTEKE = /^haccp\.db(-wal|-shm|-journal)?$|\.json\.v-bazi$/; // ne gre v kopijo kot datoteka (kopija dobi JSON)

function nalozSqlite() {
  if (process.env.HACCP_SHRAMBA === "json") return null;
  const em = process.emitWarning; // SQLite je v Node 22 označen kot preizkusen: opozorilo ne sodi v dnevnik uporabnika
  process.emitWarning = function (w, ...a) { if (/SQLite/i.test(String(w && w.message || w))) return; return em.call(process, w, ...a); };
  try { return require("node:sqlite"); } catch { return null; } finally { process.emitWarning = em; }
}

module.exports = function shramba(DIR) {
  const jsonPot = n => path.join(DIR, n + ".json");
  const beriJson = n => { try { return JSON.parse(fs.readFileSync(jsonPot(n), "utf8")); } catch { return []; } };
  const pisiJson = (n, arr) => {
    const tmp = jsonPot(n) + ".tmp", fd = fs.openSync(tmp, "w");
    try { fs.writeSync(fd, Array.isArray(arr) && arr.length > 2000 ? JSON.stringify(arr) : JSON.stringify(arr, null, 1)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, jsonPot(n));
  };
  // nastavitve in stanja: pot do datoteke v mapi s podatki; brez privzete vrednosti manjkajoča datoteka sproži napako (kot JSON.parse(readFileSync))
  const upravljana = pot => path.dirname(path.resolve(pot)) === path.resolve(DIR) && DATOTEKE.has(path.basename(pot));
  const beriDat = pot => JSON.parse(fs.readFileSync(pot, "utf8"));
  const pisiDat = (pot, v) => { const tmp = pot + ".tmp", fd = fs.openSync(tmp, "w", 0o600); try { fs.writeSync(fd, JSON.stringify(v, null, 1)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); } fs.renameSync(tmp, pot); };
  const brezVrednosti = (pot, d) => { if (d === undefined) { const e = new Error("Ni podatkov: " + path.basename(pot)); e.code = "ENOENT"; throw e; } return d; };
  const sq = nalozSqlite();
  if (!sq) return { nacin: "json", preberi: beriJson, zapisi: pisiJson, izvozi: () => [], uvoziDatoteke: () => 0, ponastavi: () => {}, zapri: () => {}, DB_DATOTEKE, DATOTEKE,
    beri: (pot, d) => { try { return beriDat(pot); } catch (e) { return brezVrednosti(pot, d); } }, pisi: pisiDat };

  const db = new sq.DatabaseSync(path.join(DIR, "haccp.db"));
  db.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;");
  db.exec("CREATE TABLE IF NOT EXISTS zbirke (ime TEXT PRIMARY KEY, uvozeno TEXT)");
  db.exec("CREATE TABLE IF NOT EXISTS zapisi (zbirka TEXT NOT NULL, kljuc TEXT NOT NULL, poz INTEGER NOT NULL, podatki TEXT NOT NULL, PRIMARY KEY (zbirka, kljuc)) WITHOUT ROWID");
  db.exec("CREATE INDEX IF NOT EXISTS zapisi_poz ON zapisi (zbirka, poz)");
  db.exec("CREATE TABLE IF NOT EXISTS datoteke (ime TEXT PRIMARY KEY, podatki TEXT NOT NULL, cas TEXT NOT NULL)");
  const q = {
    meta: db.prepare("SELECT ime FROM zbirke WHERE ime = ?"), vseMeta: db.prepare("SELECT ime FROM zbirke ORDER BY ime"),
    dodajMeta: db.prepare("INSERT OR REPLACE INTO zbirke (ime, uvozeno) VALUES (?, ?)"),
    vrstice: db.prepare("SELECT kljuc, poz, podatki FROM zapisi WHERE zbirka = ? ORDER BY poz"),
    vpisi: db.prepare("INSERT OR REPLACE INTO zapisi (zbirka, kljuc, poz, podatki) VALUES (?, ?, ?, ?)"),
    brisi: db.prepare("DELETE FROM zapisi WHERE zbirka = ? AND kljuc = ?"), brisiZbirko: db.prepare("DELETE FROM zapisi WHERE zbirka = ?"),
    dat: db.prepare("SELECT podatki FROM datoteke WHERE ime = ?"), vseDat: db.prepare("SELECT ime, podatki FROM datoteke ORDER BY ime"),
    vpisiDat: db.prepare("INSERT OR REPLACE INTO datoteke (ime, podatki, cas) VALUES (?, ?, ?)")
  };
  // ob zagonu: datoteka, ki jo je po zadnjem zapisu v bazo spremenila starejša različica (vrnitev in ponovna posodobitev), ima prednost
  for (const ime of DATOTEKE) {
    try {
      const pot = path.join(DIR, ime), v = q.dat.get(ime); if (!v || !fs.existsSync(pot)) continue;
      const vs = db.prepare("SELECT cas FROM datoteke WHERE ime = ?").get(ime).cas, x = beriDat(pot), js = JSON.stringify(x);
      if (js !== v.podatki && fs.statSync(pot).mtimeMs > new Date(vs).getTime() + 1000) q.vpisiDat.run(ime, js, new Date().toISOString());
    } catch {}
  }
  // prvo branje: obstoječa datoteka se prenese v bazo (ostane kot zrcalna kopija)
  function beri(pot, d) {
    if (!upravljana(pot)) { try { return beriDat(pot); } catch { return brezVrednosti(pot, d); } }
    const ime = path.basename(pot), v = q.dat.get(ime);
    if (v) return JSON.parse(v.podatki);
    let x; try { x = beriDat(pot); } catch { return brezVrednosti(pot, d); }
    q.vpisiDat.run(ime, JSON.stringify(x), new Date().toISOString()); return x;
  }
  function pisi(pot, v) {
    if (!upravljana(pot)) return pisiDat(pot, v);
    q.vpisiDat.run(path.basename(pot), JSON.stringify(v), new Date().toISOString()); // zapis v bazo je atomičen
    try { pisiDat(pot, v); } catch (e) { console.error("Zrcalne datoteke " + path.basename(pot) + " ni mogoče zapisati: " + e.message); }
  }
  const posnetek = {}; // zbirka → Map(ključ → { poz, json }) zadnjega zapisanega stanja
  const transakcija = fn => { db.exec("BEGIN IMMEDIATE"); try { fn(); db.exec("COMMIT"); } catch (e) { try { db.exec("ROLLBACK"); } catch {} throw e; } };
  // ključ zapisa: id (enoličen v zbirki), sicer zaporedna številka
  function kljuci(arr) {
    const vid = new Map(), out = [];
    arr.forEach((r, i) => { let k = r && (typeof r.id === "string" || typeof r.id === "number") ? "i:" + r.id : "#" + i; const n = vid.get(k) || 0; vid.set(k, n + 1); if (n) k += "~" + n; out.push(k); });
    return out;
  }
  function zapisiDb(n, arr, celotno) {
    arr = Array.isArray(arr) ? arr : []; const ks = kljuci(arr), prej = celotno ? new Map() : (posnetek[n] || new Map()), nov = new Map();
    transakcija(() => {
      if (celotno) q.brisiZbirko.run(n);
      arr.forEach((r, i) => { const js = JSON.stringify(r), p = prej.get(ks[i]); nov.set(ks[i], { poz: i, json: js }); if (!p || p.poz !== i || p.json !== js) q.vpisi.run(n, ks[i], i, js); });
      if (!celotno) for (const k of prej.keys()) if (!nov.has(k)) q.brisi.run(n, k);
      q.dodajMeta.run(n, new Date().toISOString());
    });
    posnetek[n] = nov;
  }
  function preberi(n) {
    if (!q.meta.get(n)) { // prvič: prenos iz datoteke JSON (če obstaja)
      const arr = fs.existsSync(jsonPot(n)) ? beriJson(n) : [];
      zapisiDb(n, arr, true);
      if (fs.existsSync(jsonPot(n))) try { fs.renameSync(jsonPot(n), jsonPot(n) + ".v-bazi"); } catch {}
      return arr;
    }
    const m = new Map(), arr = [];
    for (const v of q.vrstice.all(n)) { m.set(v.kljuc, { poz: v.poz, json: v.podatki }); arr.push(JSON.parse(v.podatki)); }
    posnetek[n] = m; return arr;
  }
  return {
    nacin: "sqlite", DB_DATOTEKE, DATOTEKE, preberi, zapisi: (n, arr) => zapisiDb(n, arr, false), beri, pisi,
    // za varnostno kopijo: vsaka zbirka kot podatki/<zbirka>.json (enaka oblika kot pri datotekah)
    izvozi: () => [...q.vseMeta.all().map(({ ime }) => ({ name: "podatki/" + ime + ".json", data: Buffer.from("[" + q.vrstice.all(ime).map(v => v.podatki).join(",") + "]") })),
      ...q.vseDat.all().filter(v => !BREZ_KOPIJE.has(v.ime)).map(v => ({ name: "podatki/" + v.ime, data: Buffer.from(v.podatki) }))],
    // po obnovi iz kopije: datoteke <zbirka>.json zamenjajo vsebino v bazi
    uvoziDatoteke(imena) {
      let n = 0;
      for (const ime of new Set([...imena, ...q.vseMeta.all().map(x => x.ime)])) {
        if (!fs.existsSync(jsonPot(ime))) continue;
        zapisiDb(ime, beriJson(ime), true); try { fs.renameSync(jsonPot(ime), jsonPot(ime) + ".v-bazi"); } catch {} n++;
      }
      // nastavitve in stanja iz kopije (datoteka ostane kot zrcalna kopija)
      for (const ime of DATOTEKE) { const pot = path.join(DIR, ime); if (!fs.existsSync(pot)) continue; try { q.vpisiDat.run(ime, JSON.stringify(beriDat(pot)), new Date().toISOString()); n++; } catch {} }
      return n;
    },
    ponastavi() { transakcija(() => { db.exec("DELETE FROM zapisi"); db.exec("DELETE FROM zbirke"); db.exec("DELETE FROM datoteke"); }); for (const k of Object.keys(posnetek)) delete posnetek[k]; },
    zapri() { try { db.exec("PRAGMA wal_checkpoint(TRUNCATE)"); db.close(); } catch {} }
  };
};
