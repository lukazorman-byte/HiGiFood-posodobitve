// Vloge uporabnika. Podatkovni model: u.vloge (seznam, npr. ["admin", "svetovalec"]); u.vloga ostane kot glavna vloga
// (za prikaz, nastavitve vidnosti in združljivost s starejšimi različicami). Pravice so unija vseh vlog.
// Dovoljene kombinacije: ena vloga ali administrator + svetovalec. Enako logiko ima odjemalec (portal/core.js).
const VRSTNI_RED = ["admin", "svetovalec", "odgovorna", "zaposleni"];
const vlogeOf = u => !u ? [] : Array.isArray(u.vloge) && u.vloge.length ? u.vloge : u.vloga ? [u.vloga] : [];
const hasRole = (u, ...r) => { const v = vlogeOf(u); return r.some(x => v.includes(x)); };
const glavnaVloga = v => VRSTNI_RED.find(x => v.includes(x)) || "";
const veljavneVloge = v => Array.isArray(v) && v.length > 0 && v.every(x => VRSTNI_RED.includes(x)) && new Set(v).size === v.length && (v.length === 1 || (v.length === 2 && v.includes("admin") && v.includes("svetovalec")));
const nastaviVloge = (u, v) => { u.vloge = VRSTNI_RED.filter(x => v.includes(x)); u.vloga = glavnaVloga(u.vloge); return u; };
module.exports = { VRSTNI_RED, vlogeOf, hasRole, glavnaVloga, veljavneVloge, nastaviVloge };
