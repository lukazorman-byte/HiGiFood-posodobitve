# SSL in varnostne nastavitve (Cloudflare + strežnik)

Strežnik teče v Dockerju za Cloudflare Tunnel: aplikacija nima odprtih vrat na internet (`expose`, ne `ports`),
HTTPS uredi Cloudflare. DNS se tu ne spreminja.

## Kaj že naredi aplikacija

- varnostne glave na vseh odgovorih: CSP, `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`;
- HSTS (1 leto), ko zahteva pride prek HTTPS za posrednikom (`HACCP_PROXY=1` je v `docker-compose.yml`);
- piškotek seje: `HttpOnly`, `SameSite=Strict`, `Secure` pri HTTPS;
- omejitev poskusov prijave, dvostopenjska prijava (obvezna po vlogah: Administracija → Varnost);
- pisanje samo iz iste domene (preverjanje `Origin`);
- šifrirana gesla v nastavitvah (`HACCP_KLJUC` v `.env`), šifrirane varnostne kopije.

## Nastavitve v Cloudflare (dash.cloudflare.com → higifood.si)

| Kje | Nastavitev | Vrednost |
|---|---|---|
| SSL/TLS → Overview | Encryption mode | **Full (strict)** |
| SSL/TLS → Edge Certificates | Always Use HTTPS | **On** |
| | Automatic HTTPS Rewrites | On |
| | Minimum TLS Version | **TLS 1.2** |
| | TLS 1.3 | On |
| | HSTS | On, max-age 6 mesecev; *Include subdomains* samo, če so vse poddomene na HTTPS; *Preload* zaenkrat ne |
| Security → Settings | Security level | Medium |
| | Browser Integrity Check | On |
| Security → Bots | Bot Fight Mode | On (če kdo ne more do platforme, ga izklopite) |
| Security → WAF → Rate limiting rules | Omejitev prijav | URI Path *starts with* `/api/auth/` → 20 zahtev / 1 min na IP → Block 10 min |
| Security → WAF → Managed rules | Cloudflare Free Managed Ruleset | On |
| Caching → Configuration | Caching level | Standard (platforma pošilja `no-store`, zato se podatki ne shranjujejo v predpomnilnik) |
| Rules → Cache Rules | Platforma | `Hostname equals app.higifood.si` → **Bypass cache** |

Neobvezno, za dodatno zaščito skrbniških strani: Zero Trust → Access → aplikacija za `app.higifood.si/baza/*`
(baza znanja) s prijavo po e-pošti samo za vas.

## Strežnik

- `program/streznik/.env`: `HACCP_KLJUC` (dolg naključen niz, shranjen tudi v upravljalniku gesel), `TUNNEL_TOKEN`.
  Datoteke `.env` ne pošiljajte nikomur in je ne dajajte v git.
- Posodobitve sistema: `sudo apt update && sudo apt upgrade` enkrat na mesec; Docker slike se posodobijo ob namestitvi izdaje.
- Varnostne kopije: Administracija → Kopije; nastavite kopijo izven strežnika (S3) in enkrat na mesec *Preizkusi obnovo*.

## Preverjanje

- `https://www.ssllabs.com/ssltest/?d=higifood.si` – pričakovana ocena A ali A+.
- `https://securityheaders.com/?q=https://app.higifood.si` – glave CSP, HSTS, X-Frame-Options so prisotne.
