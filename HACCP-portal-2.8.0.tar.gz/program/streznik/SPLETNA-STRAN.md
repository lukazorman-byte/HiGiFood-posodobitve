# Nova spletna stran higifood.si (zamenjava stare strani)

Spletna stran je v mapi `program/spletna-stran/` in jo prikazuje isti strežnik (Docker) kot platformo.
Cenik in kontakt se berejo iz platforme (Administracija → Naročnine → cenik in izdajatelj). Ko tam spremenite
ceno ali telefon, se spremeni tudi na spletni strani.

DNS ostane, kot je. Spremeni se samo, kam Cloudflare Tunnel pošlje obiskovalce.

## 1. Predogled (ne spremeni ničesar)

Po posodobitvi strežnika odprite `https://<trenutni naslov platforme>/stran/`. Preverite besedila, cene in kontakt.

## 2. Odločitev: kje bo platforma

Stran in platforma ne moreta biti na istem naslovu. Priporočeno:

| Naslov | Kaj prikaže |
|---|---|
| `higifood.si`, `www.higifood.si` | spletna stran |
| `app.higifood.si` | platforma (prijava) |

## 3. Nastavitev strežnika

V `program/streznik/.env` dopišite:

```
HACCP_SPLETNA_STRAN=higifood.si,www.higifood.si
HACCP_APLIKACIJA_URL=https://app.higifood.si/
```

in znova zaženite: `docker compose up -d`.

## 4. Cloudflare Tunnel

Zero Trust → Networks → Tunnels → vaš tunel → Public Hostname:

1. Dodajte `app.higifood.si` → HTTP → `app:3000`.
   Cloudflare pri tem **sam** doda zapis DNS za `app` (ročno urejanje DNS ni potrebno).
2. Preverite, da `higifood.si` (in `www.higifood.si`, če ga uporabljate) kaže na HTTP → `app:3000`.

Ko je to narejeno, `higifood.si` prikaže novo spletno stran, `app.higifood.si` pa platformo.
Stara stran (pri prejšnjem ponudniku gostovanja) s tem ni več vidna; naročnino za gostovanje prekličite šele,
ko ste preverili, da nova stran deluje, in ste prenesli e-pošto, če je bila pri istem ponudniku.

## 5. Obvestite uporabnike

Uporabniki, ki so platformo odpirali na `higifood.si`, morajo po zamenjavi uporabljati `app.higifood.si`
(gumb »Prijava« na spletni strani jih pripelje tja). Besedilo obvestila: `program/objava/OBVESTILO-STRANKAM.md`.

## Vrnitev

Izbrišite vrstico `HACCP_SPLETNA_STRAN` v `.env` in `docker compose up -d` – vse domene spet kažejo platformo.
