// Podatki podjetja po davčni številki ali nazivu:
//  1) seznam davčnih zavezancev FURS (odprti podatki, osvežen dnevno): davčna in matična številka, dejavnost (SKD), naziv, naslov,
//     zavezanec za DDV – tudi podjetja in s.p., ki niso zavezanci za DDV. Program ga prenese enkrat na dan v podatki/_zavezanci.
//  2) register EU VIES (zavezanci za DDV), če podjetja ni v seznamu ali seznam še ni prenesen.
const fs = require("fs"), path = require("path"), https = require("https"), http = require("http"), zlib = require("zlib");
const PRIVZETI = "https://ec.europa.eu/taxation_customs/vies/rest-api/ms/SI/vat/";
const FURS_PRIVZETO = ["https://www.fu.gov.si/fileadmin/prenosi/DURS_zavezanci_PO_csv.zip"];

// slovenska davčna številka: 8 števk, kontrolna števka po modulu 11 (uteži 8 … 2)
function preveriDavcno(v) {
  const d = String(v || "").replace(/^SI/i, "").replace(/[\s.-]/g, "");
  if (!/^[1-9]\d{7}$/.test(d)) return null;
  const s = [...d.slice(0, 7)].reduce((a, c, i) => a + Number(c) * (8 - i), 0), k = 11 - (s % 11);
  if (k === 11 || (k === 10 ? 0 : k) !== Number(d[7])) return null;
  return d;
}

// šifra SKD → predlog vrste dejavnosti v obrazcu stranke
function dejavnostIzSkd(skd) {
  const s = String(skd || "").replace(/^[A-U]/i, "");
  const p = [[/^56\.2/, "Catering / priprava obrokov"], [/^56/, "Gostinstvo (restavracija, gostilna)"], [/^55/, "Gostinstvo (restavracija, gostilna)"],
    [/^10\.7/, "Pekarna / slaščičarna"], [/^47\.24/, "Pekarna / slaščičarna"], [/^10\.1/, "Mesnica / predelava mesa"], [/^47\.22/, "Mesnica / predelava mesa"], [/^10\.5/, "Mlekarna / sirarna"],
    [/^47\.(1|2)/, "Trgovina z živili"], [/^46\.3/, "Trgovina z živili"], [/^1[01]\./, "Proizvodnja živil"], [/^85\./, "Vrtec / šola / zavod"], [/^87\./, "Vrtec / šola / zavod"], [/^88\.91/, "Vrtec / šola / zavod"],
    [/^01\./, "Turistična kmetija / dopolnilna dejavnost"], [/^52\.1/, "Pakiranje / skladišče"], [/^82\.92/, "Pakiranje / skladišče"]];
  for (const [r, d] of p) if (r.test(s)) return d;
  return "";
}

// pravna oblika iz naziva (firme)
function pravnaOblika(naziv) {
  const n = " " + String(naziv || "").toLowerCase().replace(/\s+/g, " ") + " ";
  const p = [[/[\s,]s\.\s?p\.?[\s,]/, "s.p."], [/[\s,]d\.\s?o\.\s?o\.?[\s,]/, "d.o.o."], [/[\s,]d\.\s?d\.?[\s,]/, "d.d."], [/[\s,]k\.\s?d\.?[\s,]/, "k.d."], [/[\s,]d\.\s?n\.\s?o\.?[\s,]/, "d.n.o."], [/[\s,]so\.\s?p\.?[\s,]/, "so.p."], [/\bzavod\b/, "zavod"], [/\bdruštvo\b/, "društvo"]];
  for (const [r, o] of p) if (r.test(n)) return o;
  return "";
}
const DEJ_BESEDE = /^(gostinstvo|gostinske|gostilna|kavarna|pekarna|slaščičarna|picerija|okrepčevalnica|restavracija|trgovina|bar|bife|catering|storitve|mesarija|kmetija|turizem|turistična|prevozi|proizvodnja|predelava|prodaja|svetovanje|dejavnost|izdelava|peka)$/i;
// nosilec s.p.: ime in priimek tik pred »s.p.« (npr. »Kavarna Sonce, Zeljije Aljiti s.p.« → »Zeljije Aljiti«); velike tiskane črke → Ime Priimek
function nosilecSp(naziv) {
  const m = /(?:^|[,;–-]\s*)([^,;–-]*?)\s+s\.\s?p\.?(?=\s|,|$)/i.exec(String(naziv || "").replace(/\s+/g, " ").trim()); if (!m) return "";
  let b = m[1].trim().split(" ").filter(Boolean); if (!b.length) return "";
  while (b.length > 2 && DEJ_BESEDE.test(b[0])) b.shift(); // pred imenom je opis dejavnosti (»Gostinstvo Janez Novak s.p.«)
  if (b.length > 3) b = b.slice(-2);
  const vel = b.join(" ") === b.join(" ").toUpperCase();
  return b.map(w => vel ? w.charAt(0) + w.slice(1).toLowerCase() : w).join(" ");
}
const dopolni = z => z && z.naziv ? Object.assign(z, { pravna_oblika: z.pravna_oblika || pravnaOblika(z.naziv), nosilec: z.nosilec || (pravnaOblika(z.naziv) === "s.p." ? nosilecSp(z.naziv) : "") }) : z;

// ---------- branje datoteke FURS (zip s CSV ali TXT; ločila ; , tab | ali stolpci, ločeni s presledki) ----------
function zipVsebina(buf) {
  let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error("Datoteka ni zip.");
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error("Pokvarjen zip.");
    const met = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const ime = buf.slice(p + 46, p + 46 + nl).toString(), st = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), surovo = buf.slice(st, st + csize);
    if (!ime.endsWith("/")) out.push({ ime, data: met === 0 ? surovo : met === 8 ? zlib.inflateRawSync(surovo) : (() => { throw new Error("Nepodprt zip (" + met + ")."); })() });
    p += 46 + nl + xl + cl;
  }
  return out;
}
function besedilo(b) {
  if (b[0] === 0xef && b[1] === 0xbb && b[2] === 0xbf) b = b.slice(3);
  const u = b.toString("utf8");
  if (!u.includes("�")) return u;
  try { return new TextDecoder("windows-1250").decode(b); } catch { return b.toString("latin1"); }
}
const brezSumnikov = s => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
function razdeliVrstico(v, l) {
  if (l === "  ") return v.trim().split(/\s{2,}/);
  const out = []; let cur = "", nar = false;
  for (let i = 0; i < v.length; i++) { const c = v[i]; if (c === '"') { if (nar && v[i + 1] === '"') { cur += '"'; i++; } else nar = !nar; } else if (c === l && !nar) { out.push(cur); cur = ""; } else cur += c; }
  out.push(cur); return out.map(x => x.trim());
}
// prepozna stolpce po glavi ali po vsebini; vrne funkcijo vrstica → zapis
function razpoznaj(vrstice) {
  const vzorec = vrstice.slice(0, 50);
  const l = [";", "\t", "|", ","].map(c => [c, vzorec.filter(v => v.split(c).length >= 4).length]).sort((a, b) => b[1] - a[1])[0];
  const loc = l[1] >= vzorec.length * 0.8 ? l[0] : "  ";
  if (loc === "  ") return { glava: !vzorec[0].split(/\s+/).some(x => preveriDavcno(x)), zapis: presledki };
  const glava = razdeliVrstico(vrstice[0], loc).map(brezSumnikov), imaGlavo = !glava.some(x => /^\d{8}$/.test(x));
  const st = {};
  if (imaGlavo) glava.forEach((g, i) => {
    const k = /davc|tax/.test(g) && !/urad/.test(g) ? "davcna" : /matic|reg.*st/.test(g) ? "maticna" : /skd|dejav|nace/.test(g) ? "skd" : /naziv|ime|name|firma/.test(g) ? "naziv" : /ulica/.test(g) ? "ulica" : /hisn/.test(g) ? "hisna" : /post/.test(g) ? "posta" : /kraj|mesto/.test(g) ? "kraj" : /naslov|address/.test(g) ? "naslov" : /ddv|vat|zavez/.test(g) && !/datum/.test(g) ? "ddv" : "";
    if (k && st[k] === undefined) st[k] = i;
  });
  if (st.davcna === undefined || st.naziv === undefined) { // brez prepoznavne glave: po vsebini stolpcev
    for (const k of Object.keys(st)) delete st[k];
    const deli = vrstice.slice(imaGlavo ? 1 : 0, 200).map(v => razdeliVrstico(v, loc)), n = Math.max(...deli.map(d => d.length)), delez = f => [...Array(n)].map((_, i) => deli.filter(d => f(d[i] || "")).length / deli.length);
    const najvec = (a, izl) => a.map((x, i) => [x, i]).filter(([, i]) => !izl.includes(i)).sort((a, b) => b[0] - a[0])[0];
    const dv = najvec(delez(x => !!preveriDavcno(x)), []); if (dv[0] < 0.8) throw new Error("V datoteki ni stolpca z davčnimi številkami.");
    st.davcna = dv[1]; const zas = [dv[1]];
    const mt = najvec(delez(x => /^\d{7}(\d{3})?$/.test(x)), zas); if (mt && mt[0] >= 0.5) { st.maticna = mt[1]; zas.push(mt[1]); }
    const sk = najvec(delez(x => /^[A-U]?\d{2}\.\d{1,3}$/i.test(x)), zas); if (sk && sk[0] >= 0.5) { st.skd = sk[1]; zas.push(sk[1]); }
    const fl = najvec(delez(x => /^(\*|D|N|DA|NE|0|1)?$/i.test(x)), zas); if (fl && fl[0] >= 0.95 && deli.some(d => /^(\*|D|DA|1)$/i.test(d[fl[1]] || ""))) { st.ddv = fl[1]; zas.push(fl[1]); }
    const dol = [...Array(n)].map((_, i) => zas.includes(i) ? -1 : deli.reduce((a, d) => a + (/[a-zčšž]/i.test(d[i] || "") ? (d[i] || "").length : 0), 0) / deli.length);
    const t = dol.map((x, i) => [x, i]).filter(([x]) => x > 2).sort((a, b) => a[1] - b[1]); // besedilni stolpci po vrsti: naziv, naslov
    if (!t.length) throw new Error("V datoteki ni stolpca z nazivi.");
    st.naziv = t[0][1]; if (t[1]) st.naslov = t[1][1];
  }
  const g = (d, k) => st[k] === undefined ? "" : String(d[st[k]] || "").trim();
  return { glava: imaGlavo && st.davcna !== undefined && glava[st.davcna] !== undefined && !/^\d/.test(glava[st.davcna]), zapis: v => {
    const d = razdeliVrstico(v, loc), dv = preveriDavcno(g(d, "davcna")); if (!dv) return null;
    const naslov = g(d, "naslov") || [[g(d, "ulica"), g(d, "hisna")].filter(Boolean).join(" "), [g(d, "posta"), g(d, "kraj")].filter(Boolean).join(" ")].filter(Boolean).join(", ");
    const f = g(d, "ddv"); return { davcna: dv, maticna: g(d, "maticna"), skd: g(d, "skd"), naziv: g(d, "naziv").replace(/\s{2,}/g, " "), naslov: naslov.replace(/\s{2,}/g, " "), ddv: st.ddv === undefined ? null : /^(\*|D|DA|1)$/i.test(f) ? 1 : 0 };
  } };
}
// oblika s stolpci, poravnanimi s presledki (prazni stolpci niso označeni): vrstico razčlenimo po vrsti podatkov
function presledki(v) {
  const m = /^\s*(\*|[DN]\b)?\s*(\d{8})\b\s*(.*)$/.exec(v); if (!m) return null;
  const dv = preveriDavcno(m[2]); if (!dv) return null;
  let ost = m[3], maticna = "", skd = "";
  const mt = /^(\d{10}|\d{7})\b\s*/.exec(ost); if (mt) { maticna = mt[1]; ost = ost.slice(mt[0].length); }
  ost = ost.replace(/^(\d{4}-\d\d-\d\d|\d\d?\.\d\d?\.\d{4})\b\s*/, "");
  const sk = /^([A-U]?\d{2}\.\d{1,3})\b\s*/i.exec(ost); if (sk) { skd = sk[1]; ost = ost.slice(sk[0].length); }
  const deli = ost.trim().split(/\s{2,}/); if (deli.length > 2 && /^\d{1,3}$/.test(deli[deli.length - 1])) deli.pop(); // finančni urad
  return { davcna: dv, maticna, skd, naziv: deli[0] || "", naslov: deli.slice(1).join(", "), ddv: m[1] === undefined ? 0 : /^(\*|D)$/.test(m[1]) ? 1 : 0 };
}
function preberiSeznam(buf) {
  const datoteke = buf.readUInt32LE(0) === 0x04034b50 ? zipVsebina(buf).filter(f => /\.(csv|txt)$/i.test(f.ime)) : [{ ime: "seznam", data: buf }];
  const zapisi = [];
  for (const f of datoteke) {
    const vr = besedilo(f.data).split(/\r?\n/).filter(v => v.trim()); if (!vr.length) continue;
    const r = razpoznaj(vr); for (const v of vr.slice(r.glava ? 1 : 0)) { const z = r.zapis(v); if (z && z.naziv) zapisi.push(z); }
  }
  if (!zapisi.length) throw new Error("V datoteki ni prepoznanih zapisov (davčna številka, naziv).");
  return zapisi;
}

// ---------- shramba seznama (SQLite v podatki/_zavezanci) ----------
function seznam(DIR) {
  const MAPA = path.join(DIR, "_zavezanci"), DB = path.join(MAPA, "zavezanci.db"), STANJE = path.join(MAPA, "stanje.json");
  let sq = null; try { const em = process.emitWarning; process.emitWarning = () => {}; try { sq = require("node:sqlite"); } finally { process.emitWarning = em; } } catch {}
  let db = null;
  const odpri = () => { if (db || !sq || !fs.existsSync(DB)) return db; db = new sq.DatabaseSync(DB, { readOnly: true }); return db; };
  const stanje = () => { try { return JSON.parse(fs.readFileSync(STANJE, "utf8")); } catch { return {}; } };
  const zapisiStanje = s => { fs.mkdirSync(MAPA, { recursive: true }); fs.writeFileSync(STANJE, JSON.stringify(Object.assign(stanje(), s), null, 1)); };
  function uvozi(bufs, vir) {
    if (!sq) throw new Error("Seznam zavezancev potrebuje SQLite (Node.js 22).");
    const vsi = new Map(); for (const b of bufs) for (const z of preberiSeznam(b)) vsi.set(z.davcna, z);
    fs.mkdirSync(MAPA, { recursive: true }); const tmp = DB + ".nov"; try { fs.rmSync(tmp); } catch {}
    const n = new sq.DatabaseSync(tmp);
    n.exec("CREATE TABLE z (davcna TEXT PRIMARY KEY, maticna TEXT, skd TEXT, naziv TEXT, naslov TEXT, ddv INTEGER, iskanje TEXT) WITHOUT ROWID");
    const ins = n.prepare("INSERT OR REPLACE INTO z VALUES (?, ?, ?, ?, ?, ?, ?)");
    n.exec("BEGIN"); for (const z of vsi.values()) ins.run(z.davcna, z.maticna, z.skd, z.naziv, z.naslov, z.ddv, brezSumnikov(z.naziv)); n.exec("COMMIT"); n.close();
    if (db) { db.close(); db = null; }
    fs.renameSync(tmp, DB);
    zapisiStanje({ zapisov: vsi.size, osvezeno: new Date().toISOString(), vir, napaka: null });
    return vsi.size;
  }
  const izDb = r => r && dopolni({ davcna: r.davcna, maticna: r.maticna || "", skd: r.skd || "", naziv: r.naziv, naslov: r.naslov || "", zavezanec: r.ddv === null ? null : !!r.ddv, dejavnost: dejavnostIzSkd(r.skd), vir: "FURS" });
  return {
    na_voljo: () => !!sq,
    stanje: () => Object.assign({ zapisov: 0 }, stanje(), { na_voljo: !!sq }),
    zapisiStanje, uvozi,
    poDavcni(d) { const b = odpri(); return b ? izDb(b.prepare("SELECT * FROM z WHERE davcna = ?").get(d)) : null; },
    poNazivu(q, max) {
      const b = odpri(), t = brezSumnikov(String(q || "")).replace(/[%_]/g, " ").trim(); if (!b || t.length < 3) return [];
      const besede = t.split(/\s+/).slice(0, 4), pog = besede.map(() => "iskanje LIKE ?").join(" AND ");
      return b.prepare(`SELECT * FROM z WHERE ${pog} ORDER BY (iskanje LIKE ?) DESC, length(naziv) LIMIT ?`).all(...besede.map(x => "%" + x + "%"), besede[0] + "%", max || 10).map(izDb);
    },
    zapri() { if (db) { db.close(); db = null; } }
  };
}

// ---------- prenos (https, preusmeritve) ----------
function prenesi(u, max, korak) {
  return new Promise((ok, ne) => {
    const x = new URL(u); if (x.protocol !== "https:" && !(x.protocol === "http:" && ["127.0.0.1", "localhost"].includes(x.hostname))) return ne(new Error("Naslov mora biti https: " + u));
    const rq = (x.protocol === "http:" ? http : https).get(x, { headers: { "User-Agent": "HiGiFood" }, timeout: 120e3 }, r => {
      if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && (korak || 0) < 5) { r.resume(); return prenesi(new URL(r.headers.location, x).href, max, (korak || 0) + 1).then(ok, ne); }
      if (r.statusCode !== 200) { r.resume(); return ne(new Error("HTTP " + r.statusCode + " (" + u + ")")); }
      const deli = []; let n = 0; r.on("data", d => { n += d.length; if (n > max) rq.destroy(new Error("Datoteka je prevelika.")); else deli.push(d); }); r.on("end", () => ok(Buffer.concat(deli)));
    });
    rq.on("timeout", () => rq.destroy(new Error("Časovna omejitev prenosa."))); rq.on("error", ne);
  });
}

// ---------- VIES ----------
const NAPAKE = { MS_UNAVAILABLE: "Register FURS v VIES trenutno ni dosegljiv. Poskusite pozneje.", MS_MAX_CONCURRENT_REQ: "Register je preobremenjen. Poskusite čez minuto.", GLOBAL_MAX_CONCURRENT_REQ: "Register je preobremenjen. Poskusite čez minuto.", SERVICE_UNAVAILABLE: "Register VIES trenutno ni dosegljiv. Poskusite pozneje.", TIMEOUT: "Register se ni odzval. Poskusite pozneje." };
const cisto = s => { const t = String(s || "").replace(/\s*\n\s*/g, ", ").replace(/\s{2,}/g, " ").replace(/^[,\s]+|[,\s]+$/g, ""); return /^-+$/.test(t) ? "" : t; };
function poisci(davcna, baza) {
  const d = preveriDavcno(davcna);
  if (!d) return Promise.reject(Object.assign(new Error("Davčna številka ni veljavna (8 števk, preverite kontrolno števko)."), { koda: 400 }));
  const u = new URL((baza || process.env.HACCP_VIES_URL || PRIVZETI).replace(/\/?$/, "/") + d);
  return new Promise((ok, ne) => {
    const rq = (u.protocol === "http:" ? http : https).get(u, { headers: { Accept: "application/json", "User-Agent": "HiGiFood" }, timeout: 15e3 }, r => {
      const deli = []; r.on("data", x => deli.push(x)); r.on("end", () => {
        let j; try { j = JSON.parse(Buffer.concat(deli).toString("utf8")); } catch { return ne(Object.assign(new Error("Register VIES je vrnil nepričakovan odgovor (HTTP " + r.statusCode + ")."), { koda: 502 })); }
        const napaka = j.userError && j.userError !== "VALID" && j.userError !== "INVALID" ? j.userError : (j.errorWrappers && j.errorWrappers[0] && j.errorWrappers[0].error);
        if (napaka) return ne(Object.assign(new Error(NAPAKE[napaka] || "Register VIES: " + napaka), { koda: 502 }));
        if (!j.isValid) return ok({ davcna: d, zavezanec: false });
        ok(dopolni({ davcna: d, zavezanec: true, naziv: cisto(j.name), naslov: cisto(j.address), datum: j.requestDate || null, vir: "VIES" }));
      });
    });
    rq.on("timeout", () => rq.destroy(Object.assign(new Error(NAPAKE.TIMEOUT), { koda: 504 })));
    rq.on("error", e => ne(e.koda ? e : Object.assign(new Error("Povezava z registrom VIES ni uspela (" + (e.code || e.message) + ")."), { koda: 502 })));
  });
}
module.exports = { poisci, preveriDavcno, dejavnostIzSkd, pravnaOblika, nosilecSp, preberiSeznam, seznam, prenesi, PRIVZETI, FURS_PRIVZETO };
