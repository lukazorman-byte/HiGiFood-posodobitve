// Izvoz osebnih podatkov (čl. 15 in 20 GDPR): ZIP s poročilom (PDF in HTML), CSV po zbirkah, podatki.json in priloge.
// Podatke izbere in očisti strežnik (gdpr.js); tu se le pretvorijo v berljivo obliko (šifranti, imena, lokalni čas) in zapakirajo.
const GX_TZ = "Europe/Ljubljana";
const GX_ZB = { stranke: "Stranke", obrati: "Obrati", osebje: "Zaposleni (vaš zapis)", dobavitelji: "Dobavitelji", oprema: "Oprema", usposabljanja: "Usposabljanja", nacrti: "HACCP načrti", navodila: "Navodila",
  evidence: "Evidence", capa: "Neskladnosti (CAPA)", ciscenje_nacrt: "Načrt čiščenja", jedi: "Jedi", dogodki: "Dogodki", storitve: "Storitve", sarze: "Šarže", "koš (izbrisano)": "Koš (izbrisani zapisi)",
  vabe: "Vabe in pasti (DDD)", kemikalije: "Čistila in razkužila", tlorisi: "Tlorisi", urnik: "Urnik evidenc", priloge: "Priloge", certifikacija: "Certifikacija", uporabniki: "Uporabniki", potrditve: "Potrditve" };
const GX_RED = ["stranke", "obrati", "osebje", "dobavitelji", "oprema", "usposabljanja", "nacrti", "navodila", "evidence", "capa", "ciscenje_nacrt", "jedi", "dogodki", "storitve", "sarze", "koš (izbrisano)"];
const GX_DATOTEKA = { "koš (izbrisano)": "kos" };
// opisi dejanj v revizijski sledi
const GX_AKCIJE = {
  "prijava": "Prijava", "prijava-neuspela": "Neuspela prijava", "prijava-napacna-koda": "Prijava: napačna koda 2FA", "prijava-brez-stranke": "Prijava brez dodeljene stranke", "odjava": "Odjava",
  "sprememba-gesla": "Sprememba gesla", "geslo-pozabljeno": "Zahteva za novo geslo", "geslo-pozabljeno-napaka": "Zahteva za novo geslo (napaka)", "geslo-ponastavljeno": "Geslo ponastavljeno", "povabilo-poslano": "Povabilo poslano", "povabilo-sprejeto": "Povabilo sprejeto",
  "2fa-vklop": "Vklop dvostopenjske prijave", "2fa-izklop": "Izklop dvostopenjske prijave", "2fa-pozabi-naprave": "Pozabljene zaupanja vredne naprave", "varnost-2fa": "Nastavitve dvostopenjske prijave",
  "ustvari": "Nov zapis", "spremeni": "Sprememba zapisa", "izbris": "Izbris zapisa (v koš)", "izbris-trajno": "Trajni izbris iz koša", "obnovi": "Obnova zapisa iz koša", "arhiviraj": "Arhiviranje", "obnovi-arhiv": "Obnova iz arhiva",
  "potrdi": "Potrditev zapisa", "potrdi-zapise": "Potrditev zapisov", "odobritev-nacrta": "Odobritev HACCP načrta", "uvoz": "Uvoz podatkov", "fotografije": "Dodane fotografije", "priloga-nova": "Nova priloga",
  "uporabnik-nov": "Nov uporabnik", "uporabnik-spremenjen": "Sprememba uporabnika", "moji-podatki": "Sprememba »Moji podatki«", "logotip-izdelovalca-nov": "Nov logotip izdelovalca", "podpis-izdelovalca-nov": "Nov podpis",
  "logotip-nov": "Nov logotip", "logotip-odstranjen": "Logotip odstranjen", "logotip-stranke-nov": "Nov logotip stranke", "logotip-stranke-odstranjen": "Logotip stranke odstranjen",
  "kopija-zdaj": "Varnostna kopija", "kopija-prenos": "Prenos varnostne kopije", "kopija-prenos-sifrirana": "Prenos šifrirane varnostne kopije", "kopija-mapa": "Nastavitev mape varnostnih kopij", "kopija-oblak": "Varnostna kopija v oblak", "kopija-oblak-zdaj": "Varnostna kopija v oblak",
  "obnova": "Obnova iz varnostne kopije", "preizkus-obnove": "Preizkus obnove", "preizkus-obnove-samodejno": "Samodejni preizkus obnove", "posodobitev-programa": "Posodobitev programa", "posodobitev-naslov": "Naslov za posodobitve", "program-ustavljen": "Program ustavljen",
  "baza-posodobitev": "Posodobitev baze znanja", "baza-pisanje": "Sprememba baze znanja", "nastavitve": "Nastavitve", "nastavitev": "Nastavitev", "nastavitve-obvestil": "Nastavitve e-pošte", "nastavitve-opomnikov": "Nastavitve opomnikov", "nastavitve-tiska": "Nastavitve izpisov", "nastavitve-vidnosti": "Nastavitve vidnosti", "obvestila-poslana": "Obvestila poslana",
  "gdpr-izvoz": "Izvoz osebnih podatkov", "gdpr-anonimizacija": "Anonimizacija osebe", "gdpr-nastavitve": "Nastavitve varstva podatkov", "izvoz-stranke": "Izvoz podatkov stranke", "testno-ponastavitev": "Ponastavitev testnih podatkov",
  "umik-vnos": "Vnos umika živila", "umik-viri": "Viri umikov živil", "umik-rasff": "Umiki RASFF", "narocnina": "Naročnina", "narocnina-odstranjena": "Naročnina odstranjena", "narocnine-nastavitve": "Nastavitve naročnin",
  "paket-nov": "Nov paket", "paket-spremenjen": "Sprememba paketa", "paket-izbrisan": "Izbris paketa", "predracun-izdan": "Izdan predračun", "predracun-placan": "Predračun plačan", "predracun-storniran": "Predračun storniran",
  "povprasevanje": "Povpraševanje", "povprasevanje-stanje": "Stanje povpraševanja", "povprasevanje-izbris": "Izbris povpraševanja", "novice-prijava": "Prijava na novice", "novice-potrjeno": "Potrjena prijava na novice", "novice-odjava": "Odjava od novic", "novice-izbris": "Izbris prijave na novice",
  "seo-nastavitve": "Nastavitve spletne strani", "blog-nov": "Nov članek", "blog-urejanje": "Urejanje članka", "blog-objava": "Objava članka", "blog-v-pregled": "Članek v pregled", "blog-umik": "Umik članka", "blog-izbris": "Izbris članka", "blog-slika": "Slika članka", "blog-novice": "Članek poslan naročnikom"
};
const GX_POLJA = { stranka: "Stranka", obrat: "Obrat", ustvarjeno: "Ustvarjeno", ustvaril: "Ustvaril", spremenjeno: "Zadnja sprememba", spremenil: "Spremenil", nastopa: "Kje nastopate", haccp_skupina: "Vloga v HACCP skupini",
  ustvaril_n: "ustvaril zapis", spremenil_n: "zadnji spremenil", "zgodovina sprememb": "zgodovina sprememb", naziv: "Naziv", naslov: "Naslov", ime: "Ime", vrsta: "Vrsta", status: "Stanje", datum: "Datum", cas: "Čas", tip: "Vrsta", velikost: "Velikost (B)",
  pogostost_dni: "Pogostost (dni)", krat_na_dan: "Krat na dan", verzija_oznaka: "Različica", naprava: "Naprava", standard: "Standard", tocka: "Točka", ocena: "Ocena", oznaka: "Oznaka", udelezenci: "Udeleženci", odgovoren: "Odgovorna oseba" };
const gxParts = d => Object.fromEntries(new Intl.DateTimeFormat("sl-SI", { timeZone: GX_TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(d).map(p => [p.type, p.value]));
// čas: PDF/HTML »7. 11. 2026, 11:24«, CSV »07. 11. 2026 11:24« (lokalni čas Europe/Ljubljana)
function gxCas(v, csv) {
  if (!v) return "";
  const s = String(v), m = s.match(/^(\d{4})-(\d\d)-(\d\d)$/);
  if (m) return csv ? `${m[3]}. ${m[2]}. ${m[1]}` : `${+m[3]}. ${+m[2]}. ${m[1]}`;
  if (!/^\d{4}-\d\d-\d\dT/.test(s)) return s;
  const d = new Date(s); if (isNaN(d)) return s;
  const p = gxParts(d); return csv ? `${p.day}. ${p.month}. ${p.year} ${p.hour}:${p.minute}` : `${+p.day}. ${+p.month}. ${p.year}, ${p.hour}:${p.minute}`;
}
// šifranti: polja obrazcev (SPEC, evidence EV), baza znanja (režimi, profili, skupine …)
function gxSifranti(db) {
  const kode = {};
  for (const v of Object.values(db || {})) if (Array.isArray(v)) for (const x of v) if (x && typeof x === "object" && typeof x.id === "string" && x.naziv) kode[x.id] = x.naziv;
  const polja = {}, ctx = { obrati: {}, dobavitelji: {}, oprema: {}, osebje: {} };
  for (const [c, s] of Object.entries(typeof SPEC !== "undefined" ? SPEC : {})) {
    let ff = []; try { ff = typeof s.fields === "function" ? s.fields(ctx) || [] : []; } catch {}
    polja[c] = {}; for (const f of ff) if (f && f.k) { let o = []; try { o = typeof f.o === "function" ? f.o(ctx) : f.o || []; } catch {} polja[c][f.k] = { l: String(f.l || f.k).replace(/\s*\([^)]*\)\s*$/, ""), o: Object.fromEntries((o || []).filter(Array.isArray)) }; }
  }
  const ev = typeof EV !== "undefined" ? Object.fromEntries(Object.entries(EV).map(([k, v]) => [k, v.ime])) : {};
  return { kode, polja, ev };
}
const gxOznaka = (S, c, k) => GX_POLJA[k] && ["stranka", "obrat", "ustvarjeno", "ustvaril", "spremenjeno", "spremenil", "nastopa"].includes(k) ? GX_POLJA[k] : (S.polja[c] && S.polja[c][k] && S.polja[c][k].l) || GX_POLJA[k] || k.replace(/_/g, " ").replace(/^./, x => x.toUpperCase());
function gxVrednost(S, c, k, v, csv) {
  if (v === true) return "da"; if (v === false) return "ne"; if (v == null) return "";
  if (Array.isArray(v)) return v.map(x => gxVrednost(S, c, k, x, csv)).join(", ");
  if (typeof v === "object") return Object.entries(v).map(([a, b]) => a + ": " + gxVrednost(S, c, a, b, csv)).join(", ");
  if (typeof v === "number") return csv ? String(v).replace(".", ",") : fnum(v);
  const s = String(v);
  if (k === "vrsta" && (c === "evidence" || c === "urnik") && S.ev[s]) return S.ev[s];
  if (k === "zbirka") return GX_ZB[s] || s;
  const f = S.polja[c] && S.polja[c][k]; if (f && f.o[s] !== undefined) return String(f.o[s]);
  if (s === "d") return "da"; if (s === "n") return "ne";
  if (S.kode[s] && /^[a-z0-9_]+$/.test(s)) return S.kode[s];
  return gxCas(s, csv);
}
const gxNastopa = (S, c, arr) => (arr || []).map(k => k === "ustvaril" ? GX_POLJA.ustvaril_n : k === "spremenil" ? GX_POLJA.spremenil_n : k === "haccp_skupina" ? "HACCP skupina" : k === "zgodovina sprememb" ? k : gxOznaka(S, c, k).toLowerCase()).join(", ");
// tabela zbirke: stolpci po vrsti (stranka, obrat, opisna polja, kdo/kdaj, kje nastopate); ID-ji se ne prikažejo
const GX_SKRIJ = new Set(["id", "stranka_id", "obrat_id", "stevilo", "razlicice", "zgodovina", "haccp_skupina", "nastopa"]);
function gxTabela(S, c, zapisi, csv) {
  if (c === "koš (izbrisano)") return { glava: ["Zbirka", "Naziv", "Stranka", "Izbrisano", "Izbrisal"], vrste: zapisi.map(r => [GX_ZB[r.zbirka] || r.zbirka, r.naziv, r.stranka, gxCas(r.izbrisano, csv), r.izbrisal]) };
  if (c === "nacrti") return { glava: ["Naziv", "Stranka", "Obrat", "Stanje", "Različica", "Zadnja sprememba", "Spremenil", "Korakov", "Nevarnosti", "OPRP", "CCP", "Vloga v HACCP skupini", "Kje nastopate"],
    vrste: zapisi.map(r => [r.naziv, r.stranka, r.obrat, gxVrednost(S, c, "status", r.status, csv), (r.verzija_oznaka || "–") + (r.zgodovina && r.zgodovina.length ? " (rev. " + (r.zgodovina.length + 1) + ")" : ""), gxCas(r.spremenjeno || r.ustvarjeno, csv), r.spremenil || r.ustvaril, r.stevilo.koraki, r.stevilo.nevarnosti, r.stevilo.oprp, r.stevilo.ccp, r.haccp_skupina || "", gxNastopa(S, c, r.nastopa)]) };
  const kljuci = []; for (const r of zapisi) for (const k of Object.keys(r)) if (!GX_SKRIJ.has(k) && !kljuci.includes(k)) kljuci.push(k);
  const kon = ["ustvarjeno", "ustvaril", "spremenjeno", "spremenil"], zac = ["stranka", "obrat"].filter(k => kljuci.includes(k));
  const stolpci = zac.concat(kljuci.filter(k => !zac.includes(k) && !kon.includes(k)), kon.filter(k => kljuci.includes(k)));
  return { glava: stolpci.map(k => gxOznaka(S, c, k)).concat(["Kje nastopate"]), vrste: zapisi.map(r => stolpci.map(k => gxVrednost(S, c, k, r[k], csv)).concat([gxNastopa(S, c, r.nastopa)])) };
}
const gxSled = (S, sled, csv) => ({ glava: ["Datum in čas", "Dejanje", "Opis", "Zbirka", "Izvedel", "IP naslov"], vrste: sled.map(e => [gxCas(e.cas, csv), GX_AKCIJE[e.akcija] || e.akcija, e.opis, (e.zbirka === "osebje" ? "Zaposleni" : GX_ZB[e.zbirka]) || e.zbirka, e.izvedel === "drug uporabnik" || !e.izvedel ? (ROLE[e.vloga] || "drug uporabnik") : e.izvedel, e.ip]) });
const gxRacun = (u, csv) => [["Ime in priimek", u.ime], ["E-naslov", u.email], ["Vloge", (u.vloge || []).map(v => ROLE[v] || v).join(", ")], ["Dostop do strank", (u.stranke || []).map(s => s.naziv).join(", ") || ((u.vloge || []).includes("admin") ? "vse stranke (administrator)" : "–")],
  ["Račun aktiven", u.aktiven ? "da" : "ne"], ["Dvostopenjska prijava (2FA)", u.dvostopenjska_prijava ? "vklopljena" : "izklopljena"], ["Zadnja prijava", gxCas(u.zadnja_prijava, csv) || "–"], ["Račun ustvarjen", gxCas(u.ustvarjeno, csv) || "–"],
  ...Object.entries(u.moji_podatki || {}).map(([k, v]) => ["Moji podatki – " + ({ naziv: "naziv", izobrazba: "izobrazba", funkcija: "funkcija", podjetje: "podjetje", naslov: "naslov", email: "e-naslov", telefon: "telefon" }[k] || k), v])];
// CSV za Excel: UTF-8 z BOM, ločilo »;«, CRLF
// celica, ki se začne z = + - @ (ali tabulatorjem), bi jo Excel izvedel kot formulo (CSV injection): pred njo »'«, razen za navadna števila
const gxCelica = v => { const s = String(v == null ? "" : v); return /^[=+\-@\t\r]/.test(s) && !/^-?\d+(?:[.,]\d+)?$/.test(s) ? "'" + s : s; };
const gxCsv = (glava, vrste) => "﻿" + [glava, ...vrste].map(r => r.map(v => { const s = gxCelica(v); return /[;"\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(";")).join("\r\n") + "\r\n";
const gxSlug = s => String(s || "oseba").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "oseba";
const GX_KONC = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif", "application/pdf": "pdf", "text/plain": "txt" };
// ZIP z deflate (CompressionStream), če ga brskalnik podpira; sicer brez stiskanja
async function gxZip(files) {
  const parts = [], cen = []; let off = 0; const d = new Date(), dt = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), dd = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  const u16 = (v, a, o) => { a[o] = v & 255; a[o + 1] = v >> 8 & 255; }, u32 = (v, a, o) => { u16(v & 0xFFFF, a, o); u16(v >>> 16, a, o + 2); };
  for (const f of files) {
    let data = f.data, met = 0;
    if (typeof CompressionStream !== "undefined" && data.length > 64) try {
      const z = new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new CompressionStream("deflate-raw"))).arrayBuffer());
      if (z.length < data.length) { data = z; met = 8; }
    } catch {}
    const nm = utf8(f.name), c = crc32(f.data), h = new Uint8Array(30), e = new Uint8Array(46);
    u32(0x04034b50, h, 0); u16(20, h, 4); u16(0x0800, h, 6); u16(met, h, 8); u16(dt, h, 10); u16(dd, h, 12); u32(c, h, 14); u32(data.length, h, 18); u32(f.data.length, h, 22); u16(nm.length, h, 26);
    u32(0x02014b50, e, 0); u16(20, e, 4); u16(20, e, 6); u16(0x0800, e, 8); u16(met, e, 10); u16(dt, e, 12); u16(dd, e, 14); u32(c, e, 16); u32(data.length, e, 20); u32(f.data.length, e, 24); u16(nm.length, e, 28); u32(off, e, 42);
    parts.push(h, nm, data); cen.push(e, nm); off += 30 + nm.length + data.length;
  }
  const cl = cen.reduce((a, x) => a + x.length, 0), end = new Uint8Array(22);
  u32(0x06054b50, end, 0); u16(files.length, end, 8); u16(files.length, end, 10); u32(cl, end, 12); u32(off, end, 16);
  return new Blob([...parts, ...cen, end], { type: "application/zip" });
}
// vsebina poročila kot zaporedje blokov (enako za PDF in HTML)
function gxPorocilo(r, S, datoteke) {
  const B = [], h = (l, s) => B.push({ t: "h", l, s }), p = (s, o) => B.push({ t: "p", s, o: o || {} }), tab = (glava, vrste, sirine) => B.push({ t: "tab", glava, vrste, sirine }), ul = items => B.push({ t: "ul", items });
  const oseba = r.oseba.ime || (r.uporabniski_racuni[0] || {}).ime || r.oseba.email, upr = r.upravljavec || {};
  h(1, "Izvoz osebnih podatkov");
  tab(["Postavka", "Vrednost"], [["Oseba", oseba], ["E-naslov", r.oseba.email || (r.uporabniski_racuni[0] || {}).email || "–"], ["Datum in čas izvoza", gxCas(r.izvozeno)], ["Zahtevo podal", r.zahteval], ["Izvoz pripravil", r.izvozil.ime + (r.izvozil.vloga ? " (" + (ROLE[r.izvozil.vloga] || r.izvozil.vloga) + ")" : "")]], [30, 70]);
  p("To je kopija osebnih podatkov, ki jih o vas obdelujemo v aplikaciji HiGiFood (pravica do dostopa po 15. členu in pravica do prenosljivosti po 20. členu Splošne uredbe o varstvu podatkov). Poročilo vsebuje podatke vašega uporabniškega računa, zapise, v katerih nastopate (ustvarili ali spremenili ste jih ali ste v njih navedeni), in revizijsko sled vaših dejanj.");
  p("V paketu so še: mapa csv/ (ena preglednica na zbirko, za Excel), podatki.json (strojno berljiva kopija) in mapa priloge/ (datoteke, ki ste jih naložili). Podatki drugih oseb (npr. sodelavcev) niso vključeni; drugi uporabniki so navedeni samo z vlogo.", { col: "m" });
  h(1, "Moj račun");
  if (!r.uporabniski_racuni.length) p("Za to osebo v aplikaciji ni uporabniškega računa.");
  for (const u of r.uporabniski_racuni) tab(["Podatek", "Vrednost"], gxRacun(u), [30, 70]);
  h(1, "Podatki, ki ste jih vnesli ali v katerih nastopate");
  const zb = GX_RED.concat(Object.keys(r.zapisi).filter(c => !GX_RED.includes(c) && c !== "priloge")); // priloge: lasten razdelek spodaj
  for (const c of zb) {
    const z = r.zapisi[c] || []; h(2, (GX_ZB[c] || c) + " – " + mnx(z.length, ["zapis", "zapisa", "zapisi", "zapisov"]));
    if (!z.length) { p("ni zapisov", { col: "m" }); continue; }
    const t = gxTabela(S, c, z); tab(t.glava, t.vrste, t.glava.map(g => /Opis|Kje nastopate|Naziv|Naslov|Tema|Opravilo/.test(g) ? 3 : 2));
    if (c === "nacrti") for (const n of z) {
      h(3, "Zgodovina: " + n.naziv);
      const v = (n.razlicice || []).map(x => `Različica ${x.oznaka} – ${gxCas(x.datum)} – ${x.potrdil || "–"} – ${x.opis || ""}`), rv = (n.zgodovina || []).map(x => `rev. ${x.razlicica} – ${gxCas(x.cas)} – ${x.kdo} – ${x.razlog || "brez razloga"}`);
      if (v.length) { p("Izdane različice dokumenta:", { bold: true }); ul(v); }
      if (rv.length) { p("Shranjene spremembe:", { bold: true }); ul(rv); } else if (!v.length) p("Načrt še nima shranjenih sprememb.", { col: "m" });
    }
  }
  if (r.izpusceno_zapisov_drugih_oseb) p(`Zapisi o drugih osebah, ki ste jih vnesli (${r.izpusceno_zapisov_drugih_oseb}), niso vključeni, ker vsebujejo osebne podatke teh oseb.`, { col: "m" });
  h(1, "Priloge");
  const pr = (r.priloge || []).map(x => [x.ime, x.datoteka || "–", x.stranka || "", gxCas(x.ustvarjeno)]).concat(datoteke.map(x => [x.opis, x.datoteka, "", ""]));
  if (pr.length) tab(["Ime", "Datoteka v paketu", "Stranka", "Naloženo"], pr, [3, 3, 2, 2]); else p("ni prilog", { col: "m" });
  h(1, "Revizijska sled (prijave in dejanja)");
  const MAX = 500, sl = r.revizijska_sled, del = sl.slice(-MAX), t = gxSled(S, del);
  p(sl.length > MAX ? `Prikazanih je zadnjih ${MAX} od ${sl.length} vnosov. Celotna sled je v datoteki csv/revizijska-sled.csv.` : `Vnosov: ${sl.length}. Časi so v lokalnem času (Ljubljana).`, { col: "m" });
  tab(t.glava, t.vrste, [2.2, 2.6, 4, 1.6, 2, 1.8]);
  h(1, "Pravna podlaga, rok hrambe in vaše pravice");
  tab(["Postavka", "Opis"], [
    ["Upravljavec", [upr.naziv, upr.naslov, upr.email, upr.telefon].filter(Boolean).join(", ") || "HiGiFood (podatki upravljavca niso vpisani v nastavitvah)"],
    ["Namen in podlaga – uporabniški račun", "Zagotavljanje dostopa do aplikacije in izvajanje pogodbe o storitvah (6. člen, 1. odstavek, točka b Splošne uredbe)."],
    ["Namen in podlaga – zapisi HACCP", "Izpolnjevanje obveznosti nosilca živilske dejavnosti po živilski zakonodaji (Uredba (ES) št. 852/2004 in 178/2002; točka c). Za podatke strank je upravljavec stranka, HiGiFood je obdelovalec (28. člen)."],
    ["Namen in podlaga – revizijska sled", "Varnost, celovitost in sledljivost zapisov (zakoniti interes, točka f, in 32. člen Splošne uredbe). Sled se zaradi celovitosti ne spreminja."],
    ["Rok hrambe", `Uporabniški račun do prenehanja pogodbe oziroma izbrisa računa. Zapisi HACCP v skladu z zakonodajo oziroma odločitvijo upravljavca. Podatki nekdanjih zaposlenih: ${r.hramba_osebje_let} let po odhodu, nato anonimizacija.`]
  ], [30, 70]);
  p("Vaše pravice:", { bold: true });
  ul(["dostop do podatkov in kopija (15. člen)", "popravek netočnih podatkov (16. člen)", "izbris (17. člen), razen kadar hrambo zahteva zakon", "omejitev obdelave (18. člen)", "prenosljivost podatkov (20. člen) – priložena datoteka podatki.json", "ugovor obdelavi na podlagi zakonitega interesa (21. člen)",
    "pritožba pri Informacijskem pooblaščencu RS, Dunajska cesta 22, 1000 Ljubljana, gp.ip@ip-rs.si, www.ip-rs.si"]);
  p("Zahtevo za uveljavljanje pravic pošljite upravljavcu" + (upr.email ? " na " + upr.email : "") + ". Odgovoriti mora brez nepotrebnega odlašanja, najpozneje v enem mesecu.");
  return B;
}
function gxPdf(B, oseba) {
  return pdfBuild({ naslov: "Izvoz osebnih podatkov", podnaslov: oseba, plain: true, logo: null, strankaLogo: null, izdelalLogo: null, stranka: "HiGiFood – varstvo osebnih podatkov", verzija: "1" }, d => {
    for (const b of B) {
      if (b.t === "h") d.h(b.l, b.s); else if (b.t === "p") d.p(b.s, b.o); else if (b.t === "ul") d.bullets(b.items);
      else d.table(b.glava, b.vrste.map(r => r.map(v => String(v == null ? "" : v))), b.sirine || b.glava.map(() => 1), { size: b.glava.length > 8 ? 7 : 8 });
    }
  });
}
function gxHtml(B, oseba) {
  const e = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const body = B.map(b => b.t === "h" ? `<h${b.l + (b.l === 1 ? 0 : 0)}>${e(b.s)}</h${b.l}>` : b.t === "p" ? `<p${b.o.col === "m" ? ' class="m"' : ""}>${b.o.bold ? "<b>" + e(b.s) + "</b>" : e(b.s)}</p>` : b.t === "ul" ? `<ul>${b.items.map(i => `<li>${e(i)}</li>`).join("")}</ul>`
    : `<div class="tw"><table><thead><tr>${b.glava.map(g => `<th>${e(g)}</th>`).join("")}</tr></thead><tbody>${b.vrste.map(r => `<tr>${r.map(v => `<td>${e(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`).join("\n");
  return `<!doctype html><html lang="sl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Izvoz osebnih podatkov – ${e(oseba)}</title>
<style>body{font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;color:#1d2a22;background:#fff;max-width:1100px;margin:0 auto;padding:16px}h1{color:#2f6f4f;border-bottom:2px solid #2f6f4f;padding-bottom:4px;margin-top:32px}h2{color:#2f6f4f;font-size:17px;margin-top:22px}h3{font-size:15px}.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;margin:8px 0 14px;font-size:13px}th{background:#2f6f4f;color:#fff;text-align:left}th,td{padding:5px 7px;border:1px solid #b8c4bc;vertical-align:top}tr:nth-child(even) td{background:#f1f6f2}.m{color:#5b665f}@media print{h1{break-before:page}h1:first-of-type{break-before:auto}}</style></head><body>
${body}
</body></html>`;
}
// celoten izvoz: podatki s strežnika → ZIP; napredek (besedilo, delež) se sporoča prek nap()
async function izvozOsebnihPodatkov(o, nap) {
  nap = nap || (() => {});
  nap("Pripravljam podatke na strežniku …", 0.05);
  const r = await api("POST", "/api/gdpr/izvoz", o);
  const S = gxSifranti(await baza().catch(() => ({}))), files = [], oseba = r.oseba.ime || (r.uporabniski_racuni[0] || {}).ime || r.oseba.email, imena = new Set();
  const ime = (osn, konc) => { let n = gxSlug(osn.replace(/\.[a-z0-9]{2,4}$/i, "")) + "." + konc, i = 2; while (imena.has(n)) n = gxSlug(osn) + "-" + i++ + "." + konc; imena.add(n); return "priloge/" + n; };
  // priloge kot datoteke; v JSON in poročilu le sklic na ime datoteke
  const pr = r.priloge || [];
  for (let i = 0; i < pr.length; i++) {
    nap(`Prenašam priloge (${i + 1}/${pr.length}) …`, 0.1 + 0.4 * i / pr.length);
    try { const b = await fetch("/api/priloga/" + encodeURIComponent(pr[i].id), { credentials: "same-origin" }); if (!b.ok) throw 0; const f = ime(pr[i].ime, GX_KONC[pr[i].tip] || "bin"); files.push({ name: f, data: new Uint8Array(await b.arrayBuffer()) }); pr[i].datoteka = f; } catch { pr[i].datoteka = "(datoteke ni bilo mogoče prebrati)"; }
  }
  const dat = (r.datoteke || []).map(x => { const f = ime(x.ime, GX_KONC[x.tip] || "bin"); files.push({ name: f, data: Uint8Array.from(atob(x.podatki), c => c.charCodeAt(0)) }); return { opis: x.ime === "podpis" ? "Podpis (Moji podatki)" : "Logotip (Moji podatki)", datoteka: f, tip: x.tip }; });
  nap("Izdelujem poročilo …", 0.55);
  const B = gxPorocilo(r, S, dat);
  files.push({ name: "porocilo.pdf", data: new Uint8Array(await gxPdf(B, oseba).arrayBuffer()) });
  files.push({ name: "porocilo.html", data: utf8(gxHtml(B, oseba)) });
  nap("Pripravljam preglednice CSV …", 0.75);
  files.push({ name: "csv/racun.csv", data: utf8(gxCsv(["Podatek", "Vrednost"], r.uporabniski_racuni.flatMap(u => gxRacun(u, true)))) });
  for (const [c, z] of Object.entries(r.zapisi)) { const t = gxTabela(S, c, z, true); files.push({ name: "csv/" + (GX_DATOTEKA[c] || c) + ".csv", data: utf8(gxCsv(t.glava, t.vrste)) }); }
  const zg = (r.zapisi.nacrti || []).flatMap(n => (n.zgodovina || []).map(x => [n.naziv, x.razlicica, gxCas(x.cas, true), x.kdo, x.razlog]));
  if (zg.length) files.push({ name: "csv/nacrti-zgodovina.csv", data: utf8(gxCsv(["Načrt", "Revizija", "Datum in čas", "Kdo", "Razlog"], zg)) });
  const ts = gxSled(S, r.revizijska_sled, true); files.push({ name: "csv/revizijska-sled.csv", data: utf8(gxCsv(ts.glava, ts.vrste)) });
  // strojno berljiva kopija: enaki ključi kot prej, priloge kot sklic na datoteko (brez base64)
  const json = Object.assign({}, r, { datoteke: undefined, priloge: pr, datoteke_moji_podatki: dat });
  files.push({ name: "podatki.json", data: utf8(JSON.stringify(json, null, 2)) });
  nap("Stiskam ZIP …", 0.9);
  const zip = await gxZip(files.sort((a, b) => (a.name.includes("/") ? 1 : 0) - (b.name.includes("/") ? 1 : 0) || a.name.localeCompare(b.name)));
  const p = gxParts(new Date()), naziv = `izvoz-osebnih-podatkov-${gxSlug(oseba)}-${p.year}-${p.month}-${p.day}.zip`;
  nap("Končano.", 1);
  return { zip, naziv, r, datotek: files.length };
}
// izvoz podatkov stranke (poslovni podatki): podatki.json + priloge
async function izvozPodatkovStranke(sid, nap) {
  nap = nap || (() => {}); nap("Pripravljam podatke stranke …", 0.1);
  const r = await api("POST", "/api/gdpr/izvoz-stranke", { stranka_id: sid }), files = [], imena = new Set();
  for (let i = 0; i < r.priloge.length; i++) {
    const x = r.priloge[i]; nap(`Prenašam priloge (${i + 1}/${r.priloge.length}) …`, 0.2 + 0.6 * i / r.priloge.length);
    try { const b = await fetch("/api/priloga/" + encodeURIComponent(x.id), { credentials: "same-origin" }); if (!b.ok) throw 0; let n = x.id + "-" + gxSlug(x.ime) + "." + (GX_KONC[x.tip] || "bin"); while (imena.has(n)) n = "_" + n; imena.add(n); files.push({ name: "priloge/" + n, data: new Uint8Array(await b.arrayBuffer()) }); x.datoteka = "priloge/" + n; } catch {}
  }
  files.push({ name: "podatki.json", data: utf8(JSON.stringify(r, null, 2)) });
  nap("Stiskam ZIP …", 0.9);
  const st = ((r.zapisi.stranke || [])[0] || {}).naziv || "stranka", p = gxParts(new Date());
  return { zip: await gxZip(files), naziv: `izvoz-podatkov-stranke-${gxSlug(st)}-${p.year}-${p.month}-${p.day}.zip` };
}
