// Baza za odločitveno drevo (baza/drevo_profili.json, baza/drevo_faze.json):
//  - profil živila: temperaturni režim shranjevanja, temperatura ob prevzemu, toplotna obdelava (po imenu, skupini ali sestavini)
//  - predlog razvrstitve nevarnosti: odgovori V1–V4 (Codex), PRP / OPRP / CCP, mejna vrednost iz režima živila, spremljanje, korektivni ukrepi
// Vse je predlog: mejne vrednosti in razvrstitev mora strokovno potrditi odgovorna oseba / svetovalec.
const DREVO_OPOMBA = "Predlog iz baze znanja (odločitveno drevo) – potrebna strokovna potrditev.";
const drevoRe = s => { if (!s) return null; try { return new RegExp(s, "i"); } catch { return null; } };
// vzorec profila živila velja le na začetku besede (»Omleta« ni mleto meso, »Ribez« ni riba); izjeme profila (»mleti mandlji«, »arašidovo maslo«)
const profilRe = s => { if (!s) return null; try { return new RegExp("(?<!\\p{L})(?:" + s + ")", "iu"); } catch { return null; } };
const profilUstreza = (p, t) => { const r = profilRe(p.vzorec); if (!r || !t || !r.test(t)) return false; const iz = profilRe(p.izjeme); return !(iz && iz.test(t)); };
// čas za režim, če ga obstoječa namestitev v svoji bazi režimov še nima (baza/rezimi.json, polje »cas«)
const DREVO_CAS = { zam: "ves čas skladiščenja", hl0: "ves čas skladiščenja", hl4: "ves čas skladiščenja", hl6: "ves čas skladiščenja", hl8: "ves čas skladiščenja", sob: "ves čas skladiščenja", jaj: "ves čas skladiščenja", skz: "ves čas skladiščenja",
  kuh: "vsaj 15 s", kuh63: "vsaj 15 s", kuh68: "vsaj 15 s", hlaj: "do 20 °C v ≤ 2 h, nato do 5 °C v ≤ 4 h", vro: "do serviranja (občasno preverjanje središčne temperature)", pon: "vsaj 15 s" };
// temperatura iz režima (brez naziva): predloga {od}/{do} ali opis
const drevoTempRez = r => !r ? "" : r.enota ? "" : r.predloga && /\{(od|do)\}/.test(r.predloga) ? r.predloga.replace(/\{od\}/g, fnum(r.od)).replace(/\{do\}/g, fnum(r.do)) : rezimOpis(r) || r.predloga || "";
const drevoCasRez = r => !r ? "" : r.cas || DREVO_CAS[r.id] || "";
const drevoRezim = (db, id) => (db.rezimi || []).find(r => r.id === id) || null;
const drevoMala = s => String(s || "").trim().toLowerCase();

// profil živila iz baze: 1) ime ustreza vzorcu (vrstni red v bazi: specifično pred splošnim), 2) skupina, 3) skupina sestavine z enakim imenom
function profilZivila(z, db) {
  const P = db.drevo_profili || [], ime = String(z.naziv || ""), sk = drevoMala(z.skupina);
  if (!P.length || !ime.trim() && !sk) return null;
  for (const p of P) if (ime && profilUstreza(p, ime)) return p;
  for (const p of P) if ((p.skupine || []).some(s => drevoMala(s) === sk)) return p;
  const ses = (db.sestavine || []).find(s => drevoMala(s.naziv) === drevoMala(ime));
  if (ses) for (const p of P) if ((p.skupine || []).includes(ses.skupina)) return p;
  for (const p of P) if (sk && profilUstreza(p, sk)) return p;
  return P.find(p => p.id === "splosno") || null;
}
// mejna vrednost iz režima: predloga režima ({od}, {do}) ali opis; naziv le, če ne vsebuje že vrednosti
const drevoMejaRez = (db, id) => { const r = drevoRezim(db, id); if (!r) return ""; const t = drevoTempRez(r); return /\d/.test(r.naziv) ? r.naziv : r.naziv + ": " + t; };
const prevzemOpis = p => { const m = p.prevzem_max; if (m === null || m === undefined || m === "") return p.prevzem_opis || "po specifikaciji dobavitelja"; const t = "≤ " + fnum(m) + " °C"; return t + (p.prevzem_opis && !String(p.prevzem_opis).startsWith(t) ? " (" + p.prevzem_opis + ")" : ""); };
// kratek opis profila za tabelo živil
function profilOpis(p, db) {
  if (!p) return "";
  const r = drevoRezim(db, p.rezim), t = p.toplotna && drevoRezim(db, p.toplotna);
  return [r ? r.naziv.replace(/^Hlajeno /, "hlajeno ") : "", "prevzem " + prevzemOpis(p), t ? "toplotna obdelava " + rezimOpis(t) : ""].filter(Boolean).join(" · ");
}
// izpolni živilo iz profila (ne prepiše vrednosti, ki jih je vpisal uporabnik); vrne profil ali null
// režim, prevzem in toplotno obdelavo zamenja le, če so prazni ali še enaki predlogu prejšnjega profila (npr. po popravku naziva)
function izpolniZivilo(z, db) {
  const p = profilZivila(z, db); if (!p) return null;
  const prej = z.profil_predlog && (db.drevo_profili || []).find(x => x.id === z.profil);
  const nastavi = (k, v, pv) => { const t = String(z[k] === undefined || z[k] === null ? "" : z[k]).trim(); if (!t || prej && t === pv) z[k] = v; };
  nastavi("rezim", p.rezim, prej && prej.rezim); nastavi("prevzem", prevzemOpis(p), prej && prevzemOpis(prej)); nastavi("toplotna_rezim", p.toplotna || "", prej && (prej.toplotna || ""));
  z.profil = p.id;
  if (!String(z.shranjevanje || "").trim()) z.shranjevanje = p.shranjevanje || drevoMejaRez(db, p.rezim);
  if (!String(z.skupina || "").trim()) { const ses = (db.sestavine || []).find(s => drevoMala(s.naziv) === drevoMala(z.naziv)); z.skupina = ses ? ses.skupina : p.naziv; }
  if (z.rte === undefined || z.rte === "") z.rte = !!p.rte;
  z.profil_predlog = true;
  return p;
}

// profil za nevarnost: živilo načrta ali profil, omenjen v koraku / nevarnosti; sicer najstrožji med živili načrta
function profilZaNevarnost(h, W, db) {
  const P = db.drevo_profili || [], korak = (W.koraki.find(k => k.id === h.korak_id) || {}).naziv || "", txt = korak + " " + (h.nevarnost || "");
  const zz = W.zivila.filter(z => String(z.naziv || "").trim());
  const om = zz.find(z => drevoMala(txt).includes(drevoMala(z.naziv))); if (om) return profilZivila(om, db);
  const pv = P.find(p => p.id !== "splosno" && profilUstreza(p, korak)); if (pv) return pv;
  const pp = zz.map(z => profilZivila(z, db)).filter(Boolean); if (!pp.length) return P.find(p => p.id === "splosno") || null;
  // hlajeni režim: najnižja zgornja meja med hlajenimi živili (zamrznjena in suha se ne štejejo); toplotna obdelava: najvišja zahteva
  const doR = p => { const r = drevoRezim(db, p.rezim); return r && r.do !== undefined && r.do !== null && r.do !== "" && +r.do >= 0 && +r.do <= 10 ? +r.do : 99; }, odT = p => { const r = drevoRezim(db, p.toplotna); return r ? +r.od || 0 : 0; };
  const hl = pp.filter(p => doR(p) < 99).sort((a, b) => doR(a) - doR(b))[0], top = pp.slice().sort((a, b) => odT(b) - odT(a))[0];
  const seznam = zz.map(z => [String(z.naziv).trim(), profilZivila(z, db)]).filter(([, p]) => p && p.id !== "splosno");
  // brez hlajenih živil (vse sobna temperatura / zamrznjeno): skupni režim živil, ne izmišljeno hlajenje; toplotna obdelava le, če jo zahteva kakšno živilo
  const rez0 = [...new Set(pp.map(p => p.rezim).filter(Boolean))];
  return { id: "nacrt", naziv: "", rezim: hl ? hl.rezim : rez0.length === 1 ? rez0[0] : rez0.includes("sob") ? "sob" : "hl4", toplotna: top.toplotna || "", prevzem_seznam: seznam.map(([n, p]) => n + " " + prevzemOpis(p)), vir: (hl || pp[0]).vir };
}

// predlog razvrstitve za nevarnost: { pravilo, profil, kontrola } ali null
function predlogDrevo(h, W, db) {
  const F = db.drevo_faze || []; if (!F.length) return null;
  const korak = (W.koraki.find(k => k.id === h.korak_id) || {}).naziv || "";
  const ust = p => (p.tip === "*" || p.tip === h.tip) && (drevoRe(p.vzorec) || /./).test(korak) && (!p.nevarnost_vzorec || (drevoRe(p.nevarnost_vzorec) || /./).test(h.nevarnost || ""));
  const pr = F.find(p => p.tip !== "*" && ust(p)) || F.find(p => p.tip === "*" && ust(p)); if (!pr) return null;
  const p = profilZaNevarnost(h, W, db) || {};
  let vrsta = pr.vrsta, mejna = "", rid = "";
  if (pr.mejna === "@prevzem") mejna = p.prevzem_seznam ? (p.prevzem_seznam.length ? "Ob prevzemu: " + p.prevzem_seznam.join("; ") : "Ob prevzemu po specifikaciji dobavitelja") : "Ob prevzemu " + prevzemOpis(p);
  else if (pr.mejna === "@rezim") { rid = p.rezim; mejna = drevoMejaRez(db, rid); }
  else if (pr.mejna === "@toplotna") { rid = p.toplotna || "kuh"; mejna = drevoMejaRez(db, rid); }
  else if (pr.mejna && drevoRezim(db, pr.mejna)) { rid = pr.mejna; mejna = drevoMejaRez(db, rid); }
  else mejna = pr.mejna || "";
  // živilo, ki se hrani pri sobni temperaturi: hlajenje ni potrebno → predpogojni program
  if (vrsta === "OPRP" && rid === "sob") { vrsta = "PRP"; mejna = ""; }
  const r = rid && drevoRezim(db, rid), temperatura = r ? drevoTempRez(r) : pr.mejna === "@prevzem" ? mejna.replace(/^Ob prevzemu:?\s*/, "") : "", cas = (r && drevoCasRez(r)) || pr.cas || "", vir = [r && r.vir, pr.vir, p.vir].filter(Boolean)[0] || "baza znanja";
  const c = { hid: h.id, drevo: (pr.drevo || []).slice(0, 4), drevo_ver: "2022", vrsta, utemeljitev: pr.utemeljitev + (p.naziv && p.id !== "splosno" ? " Živilo: " + p.naziv + "." : "") + " " + DREVO_OPOMBA,
    ukrep: h.obstojec || "", predlog_drevo: true, drevo_pravilo: pr.id, drevo_profil: p.id || "" };
  if (["CCP", "OPRP"].includes(vrsta)) Object.assign(c, { kaj: pr.kaj || "", naziv: pr.faza + (p.naziv && p.id !== "splosno" ? " – " + p.naziv : ""), mejna, mejna_predlog: !!mejna, temperatura, cas, temp_olja: pr.temp_olja || "",
    mejna_vir_vrsta: "smernica", mejna_vir: vir + " – predlog iz baze znanja, potrebna strokovna potrditev", spremljanje: pr.spremljanje || "", pogostost: pr.pogostost || "",
    korektivni: pr.korektivni || "", verifikacija: pr.verifikacija || "", evidenca: pr.evidenca || "" });
  return { pravilo: pr, profil: p, kontrola: c };
}
