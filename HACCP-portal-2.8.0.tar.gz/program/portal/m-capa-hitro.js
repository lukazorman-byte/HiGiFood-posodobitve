// Ena neskladnost na enem zaslonu (povezava iz e-poštnega obvestila): pregled odstopanja in predlaganega ukrepa,
// vnos vzroka, dolgoročnega ukrepa in preverjanja učinkovitosti, fotografija dokaza in zaprtje – prilagojeno za telefon.
async function pageNeskladnost(v, m) {
  const c = (await D.list("capa")).find(x => x.id === m[1]);
  if (!c) { v.innerHTML = '<p class="note">Neskladnosti ni mogoče najti – morda je bila izbrisana ali do nje nimate dostopa.</p>'; return; }
  const st = (await D.list("stranke")).find(s => s.id === c.stranka_id) || {}, lahko = canManage(), zaprta = c.status === "zaprto";
  const pon = Array.isArray(c.ponovitve) ? c.ponovitve : [];
  v.innerHTML = `<div class="nk">
    <p class="mut" style="margin:0 0 6px"><a href="#/stranka/${esc(c.stranka_id)}/capa">${esc(sIme(st) || "Stranka")} · vse neskladnosti</a></p>
    <div class="card"><div class="row" style="margin:0 0 6px"><span class="badge ${zaprta ? "ok" : c.rok && daysTo(c.rok) < 0 ? "bad" : "warn"}">${esc(c.status || "odprto")}</span>${c.rok && !zaprta ? dueBadge(c.rok) : ""}${c.samodejno ? '<span class="mut">odprta samodejno ob odstopanju v evidenci</span>' : ""}</div>
      <p style="font-size:16px;margin:4px 0 8px"><b>${esc(c.opis || "")}</b></p>
      <p class="mut" style="margin:0">${esc(fdt(c.cas || c.ustvarjeno))}${c.proces ? " · " + esc(c.proces) : ""}${c.tveganje ? " · tveganje " + esc(c.tveganje) : ""}</p>
      ${pon.length ? `<details style="margin-top:8px"><summary>Ponovitve (${pon.length})</summary><ul>${pon.map(p => `<li>${esc(fdt(p.cas))}: ${esc(p.opis)}</li>`).join("")}</ul></details>` : ""}
      ${c.takojsnji_ukrep ? `<div class="note info" style="margin-top:10px"><b>Takojšnji ukrep${c.ukrep_vir ? " (HACCP načrt: " + esc(c.ukrep_vir) + ")" : ""}:</b> ${esc(c.takojsnji_ukrep)}</div>` : ""}
      ${c.slike && c.slike.length ? slikeHtml(c.slike, 6) : ""}</div>
    ${zaprta ? `<div class="card"><h2>Zaprto</h2><p>${esc(fdate(c.datum_zapiranja))}${c.zaprl ? " · " + esc(c.zaprl) : ""}</p>${c.dolgorocni_ukrep ? `<p><b>Ukrep:</b> ${esc(c.dolgorocni_ukrep)}</p>` : ""}${c.ucinkovitost ? `<p><b>Učinkovitost:</b> ${esc(c.ucinkovitost)}</p>` : ""}</div>` : !lahko ? '<p class="note info">Neskladnost lahko zapre odgovorna oseba ali svetovalec.</p>' : `
    <div class="card"><h2>Ukrep in zaprtje</h2><p class="err" id="nk_e"></p>
      <label class="f"><span>Ugotovljen vzrok</span><textarea id="nk_v" rows="2">${esc(c.vzrok || "")}</textarea></label>
      <label class="f req"><span>Korektivni / preventivni ukrep (dolgoročni)</span><textarea id="nk_u" rows="3">${esc(c.dolgorocni_ukrep || "")}</textarea></label>
      <label class="f req"><span>Preverjanje učinkovitosti</span><textarea id="nk_p" rows="2" placeholder="npr. naslednje 3 meritve v mejah">${esc(c.ucinkovitost || "")}</textarea></label>
      <label class="f"><span>Fotografija dokaza (neobvezno)</span><input type="file" id="nk_f" accept="image/*" capture="environment"></label>
      <div class="nk-g"><button class="btn ghost sec" id="nk_s">Shrani (v izvajanju)</button><button class="btn" id="nk_z">Zapri neskladnost</button></div></div>`}</div>`;
  if (zaprta || !lahko) return;
  const shrani = async zapri => {
    const e = $("#nk_e"), o = { vzrok: $("#nk_v").value.trim(), dolgorocni_ukrep: $("#nk_u").value.trim(), ucinkovitost: $("#nk_p").value.trim() };
    if (zapri && (!o.dolgorocni_ukrep || !o.ucinkovitost)) { e.textContent = "Za zaprtje vpišite dolgoročni ukrep in preverjanje učinkovitosti."; return; }
    $$(".nk-g .btn").forEach(b => b.disabled = true); e.textContent = "";
    try {
      const fi = $("#nk_f").files[0]; if (fi) { const up = await uploadFile(await zmanjsajSliko(fi), c.stranka_id, "capa", c.obrat_id || null); o.slike = [...(c.slike || []), up.id]; }
      Object.assign(o, zapri ? { status: "zaprto", zaprl: ME.u.ime, datum_zapiranja: today(), _razlog: "zaprtje neskladnosti" } : { status: c.status === "odprto" ? "v izvajanju" : c.status, _razlog: "dopolnitev ukrepa" });
      await D.set("capa", c.id, Object.assign({ _ver: c.spremenjeno || c.ustvarjeno }, o)); toast(zapri ? "Neskladnost zaprta" : "Shranjeno"); pageNeskladnost(v, m);
    } catch (er) { e.textContent = er.message; $$(".nk-g .btn").forEach(b => b.disabled = false); }
  };
  $("#nk_s").onclick = () => shrani(false); $("#nk_z").onclick = () => shrani(true);
}
route(/^\/neskladnost\/([\w-]+)$/, pageNeskladnost, "Neskladnost", "stranke");
