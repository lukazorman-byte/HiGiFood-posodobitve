(async () => {
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
    // nova različica programa: stran se enkrat osveži sama (če ni odprto okno z obrazcem), da se ne prikazuje stara
    const imel = !!navigator.serviceWorker.controller; let osvezeno = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => { if (!imel || osvezeno) return; osvezeno = true; const d = document.getElementById("dlg"); if (d && d.open) { if (typeof toast === "function") toast("Na voljo je nova različica programa. Osvežite stran (F5)."); } else location.reload(); });
  }
  { const mz = location.hash.match(/^#\/geslo\/([\w-]+)$/); if (mz) { showNastaviGeslo(mz[1]); return; } } // povezava iz e-pošte
  try {
    ME.u = await api("GET", "/api/auth/jaz");
    try { Object.assign(STATE, await fetch("/api/auth/stanje").then(r => r.json())); } catch {}
    applyPreview(); await loadTisk(); await loadVidnost(); naloziIzdelovalca(); start(); syncOffQueue();
    if (/[?&]nedostop=1/.test(location.search)) { history.replaceState(null, "", "/"); toast("Generator dokumentacije za vašo vlogo ni na voljo ali vam ga je skril administrator.", true); }
  } catch (e) {
    if (e.offline) { // brez povezave: uporabi shranjenega uporabnika (podatki iz predpomnilnika)
      let u = null; try { u = JSON.parse(localStorage.getItem("haccp_me") || "null"); } catch {}
      if (u) { ME.u = u; await loadTisk(); await loadVidnost(); start(); return; }
    }
    try { const s = await fetch("/api/auth/stanje").then(r => r.json()); Object.assign(STATE, s);
      // javna stran: neprijavljen obiskovalec vstopne strani (brez povezave #/… iz e-pošte in brez ?portal) gre na spletno stran; »Prijava« tam vodi na /?portal
      if (s.stran_javna && s.nastavljeno && location.pathname === "/" && !location.hash && !/[?&]portal\b/.test(location.search)) { location.replace("/stran/"); return; }
      showLogin(!s.nastavljeno); } catch (e2) { document.body.innerHTML = "<p style='padding:20px'>Strežnik ni dosegljiv.</p>"; }
  }
})();
