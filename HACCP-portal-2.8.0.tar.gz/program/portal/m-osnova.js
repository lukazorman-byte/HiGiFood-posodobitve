// Nadzorna plošča in seznam strank.
const COLLS = ["stranke", "obrati", "nacrti", "navodila", "evidence", "capa", "usposabljanja", "oprema", "osebje", "dogodki", "dobavitelji", "storitve", "ciscenje_nacrt", "kemikalije"];
async function loadAll(q) {
  const out = {};
  await Promise.all(COLLS.map(async c => { try { out[c] = await D.list(c, q && c !== "stranke" ? q : undefined); } catch { out[c] = []; } }));
  out.vseStranke = out.stranke; // za izbirni seznam filtra (da lahko preklopiš na drugo stranko)
  if (q && q.stranka_id) out.stranke = out.stranke.filter(s => s.id === q.stranka_id);
  return out;
}
// seznam prostorov ali naprav obrata kot besedilo: »Kuhinja (topla priprava); Hladilnica« + dodatno besedilo
const seznamObrata = (l, dodatno) => [(Array.isArray(l) ? l : []).filter(x => x && x.ime).map(x => x.ime + (x.opis ? " (" + x.opis + ")" : "")).join("; "), String(dodatno || "").trim()].filter(Boolean).join(". ");
// prikazno ime stranke: kratko ime, če je vpisano (uradni naziv ostane v dokumentih)
const sIme = s => String((s && (s.kratko_ime || s.naziv)) || "");
const mapOf = (arr, k) => Object.fromEntries((arr || []).map(x => [x.id, k ? x[k] : x.kratko_ime || x.naziv]));

// enotna ocena področij za Certifikacijo in Inšpekcijo (ista pravila na obeh straneh): s = "ustrezno" | "delno" | "manjka"
// d: zbirke stranke (osebje, usposabljanja, oprema, dobavitelji, nacrti)
function ocenaPodrocij(d) {
  const pot = s => !!s && daysTo(String(s).slice(0, 10)) < 0, o = (s, txt) => ({ s, txt });
  const os = d.osebje || [], up = d.usposabljanja || [], op = d.oprema || [], db = d.dobavitelji || [], na = (d.nacrti || []).filter(n => n.status !== "zastarelo");
  const osZ = os.filter(x => pot(x.higienski_do) || pot(x.zdravniski_do)), upZ = up.filter(x => pot(x.veljavno_do));
  const usp = !os.length ? o("manjka", "Zaposleni niso vneseni") : osZ.length || upZ.length ? o("manjka", [osZ.length ? mnx(osZ.length, ["zaposleni", "zaposlena", "zaposleni", "zaposlenih"]) + " s pretečenim izobraževanjem ali zdravniškim pregledom" : "", upZ.length ? mnx(upZ.length, ["poteklo usposabljanje", "potekli usposabljanji", "potekla usposabljanja", "poteklih usposabljanj"]) : ""].filter(Boolean).join(", ")) : !up.length ? o("delno", "Usposabljanja niso vnesena") : o("ustrezno", "Vse veljavnosti so v redu");
  const opZ = op.filter(x => pot(x.naslednji_servis)).length;
  const opr = !op.length ? o("manjka", "Oprema ni vnesena") : opZ ? o("delno", opZ + " naprav s pretečenim servisom/umerjanjem") : o("ustrezno", "Servisi/umerjanja niso pretečeni");
  const dbZ = db.filter(x => pot(x.naslednja_ocena)).length, dbP = db.filter(x => x.ocena === "pogojno odobren").length, dbN = db.filter(x => !x.ocena || x.ocena === "ni ocenjen").length, dbX = db.filter(x => x.ocena === "zavrnjen").length;
  const dob = !db.length ? o("manjka", "Dobavitelji niso vneseni") : dbZ || dbP || dbN || dbX ? o("delno", [dbZ && dbZ + " s pretečeno oceno", dbP && dbP + " pogojno odobren(ih)", dbN && dbN + " neocenjen(ih)", dbX && dbX + " zavrnjen(ih)"].filter(Boolean).join(", ")) : o("ustrezno", "Vsi dobavitelji so odobreni, ocene niso pretečene");
  const npot = na.filter(n => n.status === "potrjeno").length;
  const hac = npot ? o("ustrezno", mnx(npot, ["potrjen načrt", "potrjena načrta", "potrjeni načrti", "potrjenih načrtov"])) : na.length ? o("manjka", "Potrjenega načrta ni – " + mnx(na.length, ["osnutek", "osnutka", "osnutki", "osnutkov"]) + " (ni potrjen)") : o("manjka", "HACCP načrt ni izdelan");
  return { usposobljenost: usp, oprema: opr, dobavitelji: dob, haccp: hac };
}
const OCENA_INSP = { ustrezno: "ok", delno: "warn", manjka: "bad" };

// zbere vse roke iz podatkov (nadzorna plošča, koledar)
function collectDeadlines(d) {
  const L = [], sm = mapOf(d.stranke);
  // roki samo za obstoječe stranke (izbrisane so v košu)
  const add = (datum, tip, naslov, sid, tab, bad, ura) => { if (datum && (!sid || sid in sm)) L.push({ datum: String(datum).slice(0, 10), ura: ura || "", tip, naslov, stranka_id: sid, stranka: sm[sid] || "", href: sid ? `#/stranka/${sid}/${tab}` : "#/koledar" }); };
  for (const s of d.stranke) add(s.naslednji_pregled, "Pregled stranke", "Pregled: " + s.naziv, s.id, "podatki");
  const obm = Object.fromEntries((d.obrati || []).map(o => [o.id, o]));
  for (const n of d.nacrti) if (n.status !== "zastarelo") {
    add(n.naslednji_pregled || letnaRevizija(n), "Pregled načrta", (n.naslednji_pregled ? "Pregled" : "Letna revizija") + " HACCP načrta: " + n.naziv, n.stranka_id, "nacrti");
    const ob = obm[n.obrat_id]; if (pregledPoSpremembi(n, ob)) add(String(ob.sprememba_opreme).slice(0, 10), "Pregled načrta", "Pregled HACCP načrta po spremembi naprav ali prostorov obrata " + ob.naziv + ": " + n.naziv, n.stranka_id, "nacrti");
  }
  for (const n of d.navodila) if (n.status !== "zastarelo") add(n.naslednji_pregled, "Pregled dokumenta", "Pregled navodila: " + n.naslov, n.stranka_id, "navodila");
  for (const o of d.osebje) { add(o.higienski_do, "Izobraževanje", "Poteče izobraževanje: " + o.ime, o.stranka_id, "osebje"); add(o.zdravniski_do, "Zdravniški pregled", "Poteče zdravniški pregled: " + o.ime, o.stranka_id, "osebje"); }
  for (const u of d.usposabljanja) add(u.veljavno_do, "Usposabljanje", "Poteče usposabljanje: " + u.tema, u.stranka_id, "osebje");
  for (const o of d.oprema) add(o.naslednji_servis, "Oprema", "Servis/umerjanje: " + o.naziv, o.stranka_id, "oprema");
  for (const o of d.dobavitelji) add(o.naslednja_ocena, "Dobavitelj", "Ocena dobavitelja: " + o.naziv, o.stranka_id, "dobavitelji");
  for (const c of d.capa) if (c.status !== "zaprto") add(c.rok, "CAPA", "Rok ukrepa: " + (c.opis || "").slice(0, 60), c.stranka_id, "capa");
  for (const e of d.dogodki) if (e.status !== "opravljeno") add(e.datum, e.vrsta || "Dogodek", (e.ura ? e.ura + " " : "") + e.naslov, e.stranka_id, "koledar", false, e.ura);
  for (const c of ciscenjeStanje(d.ciscenje_nacrt || [], d.evidence || [])) add(c.next, "Čiščenje", "Čiščenje: " + (c.n.podrocje ? c.n.podrocje + " – " : "") + c.n.opravilo, c.n.stranka_id, "higiena");
  for (const k of d.kemikalije || []) add(k.rok_uporabe, "Čistilo", "Poteče rok uporabe: " + k.naziv, k.stranka_id, "higiena");
  for (const s of d.storitve) add(s.naslednji_pregled, "Priporočen pregled", "Priporočen naslednji pregled (storitev)", s.stranka_id, "storitve");
  return L.sort((a, b) => a.datum.localeCompare(b.datum) || (a.ura || "99").localeCompare(b.ura || "99")); // isti dan: po uri, dogodki brez ure na koncu
}

// manjkajoči podatki po stranki
function missingData(d, s) {
  const m = [];
  if (!s.odgovorna_oseba) m.push("odgovorna oseba");
  if (!s.naslov) m.push("naslov");
  if (!s.dejavnost) m.push("vrsta dejavnosti");
  if (!d.obrati.some(o => o.stranka_id === s.id)) m.push("noben obrat");
  else if (d.obrati.some(o => o.stranka_id === s.id && !o.opis_prostorov && !(o.prostori || []).length)) m.push("opis prostorov");
  if (!d.osebje.some(o => o.stranka_id === s.id)) m.push("seznam zaposlenih");
  if (!d.nacrti.some(o => o.stranka_id === s.id)) m.push("HACCP načrt");
  if (!d.dobavitelji.some(o => o.stranka_id === s.id)) m.push("dobavitelji");
  return m;
}

async function pageDashboard(v) {
  const flt = JSON.parse(sessionStorage.getItem("dflt") || "{}");
  const d = await loadAll(flt.sid ? { stranka_id: flt.sid } : null);
  const sm = mapOf(d.stranke), t = today();
  const stOk = s => !flt.st || s.status === flt.st;
  const strs = d.stranke.filter(stOk), ids = new Set(strs.map(s => s.id));
  const inScope = x => ids.has(x.stranka_id);
  const dl = collectDeadlines(Object.fromEntries(Object.entries(d).map(([k, a]) => [k, k === "stranke" ? strs : a.filter(inScope)]))).filter(x => (!flt.od || x.datum >= flt.od) && (!flt.do || x.datum <= flt.do));
  const due = dl.filter(x => daysTo(x.datum) >= 0 && daysTo(x.datum) <= 30), over = dl.filter(x => daysTo(x.datum) < 0); // vsak rok samo enkrat: v zamudi ali v 30 dneh
  const count = (arr, f) => arr.filter(x => inScope(x) && f(x)).length;
  const kpi = (n, l, cls, href) => href ? `<a class="kpi ${cls || ""}" href="${href}"><b>${n}</b><span>${l}</span></a>` : `<div class="kpi ${cls || ""}"><b>${n}</b><span>${l}</span></div>`;
  const rec = d.evidence.filter(inScope), capaOpen = d.capa.filter(c => inScope(c) && c.status !== "zaprto");
  const devs = rec.filter(r => (r.skladno === false || r.skladno === "ne") && r.status !== "potrjeno"); // odprta odstopanja (potrjen zapis je že pregledan)
  const pzHref = hasRole(ME.u, "admin", "svetovalec", "odgovorna") ? "#/pregled-zapisov" : ""; // zaposleni nima Pregleda zapisov
  const dbz = await baza(); const pravno = d.navodila.filter(n => inScope(n) && navodiloOpozorila(n, dbz).length).length;
  const stale = pravno + d.navodila.filter(n => inScope(n) && (n.status === "zastarelo" || (n.naslednji_pregled && daysTo(n.naslednji_pregled) < 0))).length + d.nacrti.filter(n => inScope(n) && (n.status === "zastarelo" || (n.naslednji_pregled && daysTo(n.naslednji_pregled) < 0))).length;
  const exp = dl.filter(x => ["Izobraževanje", "Zdravniški pregled", "Usposabljanje", "Oprema"].includes(x.tip) && daysTo(x.datum) >= 0 && daysTo(x.datum) <= 30).length; // potekli so že med »roki v zamudi«
  const recent = [];
  for (const c of COLLS) for (const x of d[c]) if (c === "stranke" ? ids.has(x.id) : inScope(x)) recent.push({ c, x, t: x.spremenjeno || x.ustvarjeno || "", ur: !!(x.spremenjeno && x.spremenjeno !== x.ustvarjeno) });
  recent.sort((a, b) => b.t.localeCompare(a.t));
  const NAMES = { stranke: "Stranka", obrati: "Obrat", nacrti: "HACCP načrt", navodila: "Navodilo", evidence: "Zapis", capa: "Neskladnost / CAPA", usposabljanja: "Usposabljanje", oprema: "Oprema", osebje: "Zaposleni", dogodki: "Dogodek", dobavitelji: "Dobavitelj", storitve: "Storitev", ciscenje_nacrt: "Opravilo čiščenja", kemikalije: "Čistilo" };
  const miss = strs.map(s => ({ s, m: missingData(d, s) })).filter(x => x.m.length);
  const urn = await D.list("urnik").catch(() => []), RED = rednostStrank(strs, urn, d.ciscenje_nacrt, d.evidence), redV = strs.map(s => ({ s, r: RED[s.id] })).sort((a, b) => (a.r && a.r.pct !== null ? a.r.pct : 101) - (b.r && b.r.pct !== null ? b.r.pct : 101)), redNizka = redV.filter(x => x.r && x.r.pct !== null && x.r.pct < 70).length;
  v.innerHTML = `
  <details class="filtri"${flt.sid || flt.st || flt.od || flt.do ? " open" : ""}><summary>Filter${flt.sid || flt.st || flt.od || flt.do ? ' <span class="badge info">vklopljen</span>' : ""}</summary><div class="row">${isStaff() ? `<select id="fs" style="max-width:240px"><option value="">Vse stranke</option>${(d.vseStranke || d.stranke).map(s => `<option value="${s.id}" ${flt.sid === s.id ? "selected" : ""}>${esc(sIme(s))}</option>`).join("")}</select>` : ""}
    <select id="fst" style="max-width:200px"><option value="">Vsa stanja sistema</option>${STATUS_SISTEMA.map(s => `<option ${flt.st === s ? "selected" : ""}>${s}</option>`).join("")}</select>
    <label class="mut">Roki od <input type="date" id="fod" value="${flt.od || ""}" style="width:auto"></label><label class="mut">do <input type="date" id="fdo" value="${flt.do || ""}" style="width:auto"></label>
    <button class="btn ghost sec sm" id="fx">Počisti filter</button></div></details>
  ${(() => {
    // ploščice v treh blokih; prikazane so samo tiste, ki niso 0 (število strank vedno)
    const cisZ = ciscenjeStanje(d.ciscenje_nacrt.filter(inScope), d.evidence.filter(inScope)).filter(x => x.zamuda).length;
    const BL = [["Stranke in načrti", [isStaff() ? [strs.length, ["stranka", "stranki", "stranke", "strank"], "", "#/stranke", 1] : null, [strs.filter(s => s.status === "aktivna").length, ["aktiven HACCP sistem", "aktivna HACCP sistema", "aktivni HACCP sistemi", "aktivnih HACCP sistemov"], "", "#/stranke"], [count(d.nacrti, n => n.status === "osnutek"), ["načrt v pripravi", "načrta v pripravi", "načrti v pripravi", "načrtov v pripravi"]], [count(d.nacrti, n => n.status === "v pregledu"), ["načrt v potrjevanju", "načrta v potrjevanju", "načrti v potrjevanju", "načrtov v potrjevanju"]], [count(d.nacrti, n => n.status === "potrjeno"), ["potrjen načrt", "potrjena načrta", "potrjeni načrti", "potrjenih načrtov"]]], "Ni načrtov."],
      ["Roki", [[over.length, ["rok v zamudi", "roka v zamudi", "roki v zamudi", "rokov v zamudi"], "bad", "#/koledar"], [due.length, ["rok v 30 dneh", "roka v 30 dneh", "roki v 30 dneh", "rokov v 30 dneh"], "warn", "#/koledar"], [stale, ["dokument za posodobitev", "dokumenta za posodobitev", "dokumenti za posodobitev", "dokumentov za posodobitev"], "warn"], [exp, ["izobraževanje ali oprema poteka", "izobraževanji ali opremi potečeta", "izobraževanja ali oprema potečejo", "izobraževanj ali opreme poteče"], "warn"], [cisZ, ["opravilo čiščenja v zamudi", "opravili čiščenja v zamudi", "opravila čiščenja v zamudi", "opravil čiščenja v zamudi"], "warn", "#/danes"]], "Ni rokov v zamudi ali v naslednjih 30 dneh."],
      ["Odstopanja", [[devs.length, ["odstopanje v zapisih", "odstopanji v zapisih", "odstopanja v zapisih", "odstopanj v zapisih"], "warn", pzHref], [capaOpen.length, ["odprt ukrep CAPA", "odprta ukrepa CAPA", "odprti ukrepi CAPA", "odprtih ukrepov CAPA"], capaOpen.some(c => c.rok && daysTo(c.rok) < 0) ? "bad" : "warn"], [rec.filter(r => r.status === "vneseno").length, ["zapis za pregled", "zapisa za pregled", "zapisi za pregled", "zapisov za pregled"], "", pzHref]], "Ni odprtih odstopanj."]];
    return `<div class="kpi-bloki">${BL.map(([naslov, pl, prazno]) => { const vid = pl.filter(x => x && (x[0] || x[4])); return `<section class="kpi-blok"><h3>${naslov}</h3><div class="kpis">${vid.map(x => kpi(x[0], mn(x[0], x[1]), x[0] ? x[2] : "", x[3])).join("") || `<p class="kpi-ok">✓ ${prazno}</p>`}</div></section>`; }).join("")}</div>`;
  })()}
  <div class="grid g2">
    <div class="card"><h2>Prihajajoči roki in zamude <a class="h-link" href="#/koledar">vsi roki ›</a></h2>${dl.length ? `<div class="tw"><table class="t"><tr><th>Rok</th><th>Kaj</th>${isStaff() && strs.length > 1 ? "<th>Stranka</th>" : ""}</tr>${dl.filter(x => daysTo(x.datum) <= 60).slice(0, 8).map(x => `<tr class="click" onclick="location.hash='${x.href.slice(1)}'"><td>${dueBadge(x.datum)}</td><td>${esc(x.naslov)}</td>${isStaff() && strs.length > 1 ? `<td>${esc(x.stranka)}</td>` : ""}</tr>`).join("") || `<tr><td colspan="3" class="empty">Ni rokov v naslednjih 60 dneh.</td></tr>`}</table></div>` : '<div class="empty">Ni vnesenih rokov.</div>'}</div>
    <div class="card"><h2>Odprta odstopanja in CAPA</h2>${capaOpen.length ? `<div class="tw"><table class="t"><tr><th>Opis</th><th>Rok</th>${strs.length > 1 ? "<th>Stranka</th>" : ""}</tr>${capaOpen.slice(0, 8).map(c => `<tr class="click" onclick="location.hash='#/stranka/${c.stranka_id}/capa'"><td>${esc((c.opis || "").slice(0, 80))}</td><td>${dueBadge(c.rok)}</td>${strs.length > 1 ? `<td>${esc(sm[c.stranka_id] || "")}</td>` : ""}</tr>`).join("")}</table></div>` : '<div class="empty">Ni odprtih ukrepov.</div>'}</div>
  </div>
  <div class="card" id="rednost"><h2>Rednost vnosov (zadnjih 30 dni) ${redNizka ? `<span class="badge bad">${mnx(redNizka, ["stranka", "stranki", "stranke", "strank"])} pod 70 %</span>` : ""}</h2><p class="mut" style="margin-top:0">Delež obdobij, v katerih so bile evidence vnesene po urniku pogostosti in načrtu čiščenja.</p>${redV.length ? `<div class="tw"><table class="t"><tr><th>Stranka</th><th>Rednost</th><th></th></tr>${redV.slice(0, 15).map(x => `<tr class="click" onclick="location.hash='#/stranka/${x.s.id}/evidence'"><td>${esc(sIme(x.s))}</td><td>${rednostBadge(x.r)}</td><td style="width:45%">${x.r && x.r.pct !== null ? `<div class="rd-bar"><span class="${x.r.pct >= 90 ? "ok" : x.r.pct >= 70 ? "warn" : "bad"}" style="width:${x.r.pct}%"></span></div><small class="mut">${x.r.ok} od ${x.r.vse}</small>` : x.r ? "" : '<a href="#/stranka/' + x.s.id + '/evidence">določite pogostost vnosov</a>'}</td></tr>`).join("")}</table></div>` : '<div class="empty">Ni strank.</div>'}</div>
  <div class="grid g2 dash-spodaj">
    <details class="card dash-zlozi"><summary><h2>Manjkajoči podatki strank <span class="badge ${miss.length ? "warn" : "ok"}">${miss.length}</span></h2></summary>${miss.length ? `<div class="tw"><table class="t"><tr><th>Stranka</th><th>Manjka</th></tr>${miss.slice(0, 20).map(x => `<tr class="click" onclick="location.hash='#/stranka/${x.s.id}/podatki'"><td>${esc(sIme(x.s))}</td><td>${x.m.map(esc).join(", ")}</td></tr>`).join("")}</table></div>` : '<div class="empty">Vsi osnovni podatki so izpolnjeni.</div>'}</details>
    <details class="card dash-zlozi" open><summary><h2>Zadnje aktivnosti <span class="badge">${recent.length > 99 ? "99+" : recent.length}</span></h2></summary>${recent.length ? `<div class="tw"><table class="t"><tr><th>Kdaj</th><th>Kdo</th><th>Kaj</th><th>Stranka</th></tr>${recent.slice(0, 10).map(r => { const h = ((ISK.find(i => i[0] === r.c) || [])[4] || (() => ""))(r.x); return `<tr${h ? ` class="click" onclick="location.hash='${h.slice(1)}'"` : ""}><td>${fdt(r.t)}</td><td>${esc((r.ur ? r.x.spremenil_ime : r.x.ustvaril_ime) || r.x.ustvaril_ime || "")}</td><td>${NAMES[r.c] || r.c}: ${h ? `<a href="${h}">` : ""}${esc(r.x.naziv || r.x.naslov || r.x.ime || r.x.opravilo || (r.c === "evidence" && EV[r.x.vrsta] ? EV[r.x.vrsta].ime : r.x.vrsta) || r.x.tema || r.x.opis || fdate(r.x.datum) || "")}${h ? "</a>" : ""} ${r.ur ? '<span class="badge">urejeno</span>' : '<span class="badge ok">novo</span>'}</td><td>${esc(sm[r.c === "stranke" ? r.x.id : r.x.stranka_id] || "")}</td></tr>`; }).join("")}</table></div>` : '<div class="empty">Še ni aktivnosti.</div>'}</details>
  </div>`;
  const save = () => { sessionStorage.setItem("dflt", JSON.stringify({ sid: $("#fs") ? $("#fs").value : "", st: $("#fst").value, od: $("#fod").value, do: $("#fdo").value })); pageDashboard(v); };
  for (const id of ["fs", "fst", "fod", "fdo"]) if ($("#" + id)) $("#" + id).onchange = save;
  $("#fx").onclick = () => { sessionStorage.removeItem("dflt"); pageDashboard(v); };
  if (typeof dashDodatki === "function") dashDodatki(v, d); // prvi koraki, opozorila sistema
}

async function pageStranke(v) {
  const el = document.createElement("div"); v.innerHTML = ""; v.appendChild(el);
  const [st, ur, nc, ev] = await Promise.all(["stranke", "urnik", "ciscenje_nacrt", "evidence"].map(c => D.list(c).catch(() => [])));
  REDNOST = rednostStrank(st, ur, nc, ev);
  await listView(el, "stranke", null, { open: r => location.hash = "#/stranka/" + r.id + "/podatki", create: reload => openForm("stranke", null, null, reload),
    extra: isStaff() && st.length ? '<button class="btn ghost sec" id="iz_pred" title="Nova stranka prevzame opremo, načrt čiščenja in urnik evidenc od obstoječe">+ Iz predloge</button> ' : "",
    bind: () => { const b = $("#iz_pred", el); if (b) b.onclick = () => izPredloge(st); } });
}

// nova stranka iz predloge: prevzame opremo, načrt čiščenja in urnik evidenc izbrane stranke (brez zapisov, oseb in datumov)
const PREDLOGA_ZBIRKE = [["oprema", "Oprema in instrumenti (z mejnimi vrednostmi)"], ["ciscenje_nacrt", "Načrt čiščenja"], ["urnik", "Urnik evidenc (pogostost vnosov)"]];
const PREDLOGA_BREZ = ["id", "stranka_id", "obrat_id", "ustvarjeno", "ustvaril", "ustvaril_ime", "spremenjeno", "spremenil", "spremenil_ime", "revizije", "verzija", "slike", "naslednji_servis", "zacetek"];
async function izPredloge(st) {
  const opt = st.slice().sort((a, b) => sIme(a).localeCompare(sIme(b), "sl")).map(s => `<option value="${s.id}">${esc(sIme(s))}</option>`).join("");
  modal("Nova stranka iz predloge", `<p class="mut">Nova stranka prevzame izbrane nastavitve obstoječe stranke. Zapisi, zaposleni, dokumenti in datumi (servisi) se ne kopirajo; obrati se ne prenesejo (vse velja za celotno stranko).</p>
    <label class="f"><span>Predloga (obstoječa stranka)</span><select id="pr_s">${opt}</select></label>
    <div id="pr_z">${PREDLOGA_ZBIRKE.map(([c, l]) => `<label style="display:flex;gap:8px;align-items:center;margin:6px 0"><input type="checkbox" data-pz="${c}" checked> ${l} <span class="mut" data-pn="${c}"></span></label>`).join("")}</div>`,
    [{ t: "Prekliči", cls: "ghost sec" }, { t: "Naprej: podatki nove stranke", fn: () => {
      const vir = st.find(s => s.id === $("#pr_s").value), zb = $$("[data-pz]:checked").map(x => x.dataset.pz);
      setTimeout(() => openFormPre("stranke", { dejavnost: vir.dejavnost }, null, async nov => { if (nov) { await kopirajPredlogo(vir, nov, zb); location.hash = "#/stranka/" + nov.id + "/oprema"; } }), 0);
    } }]);
  let zap = 0; // ob hitri menjavi predloge odgovor za prejšnjo izbiro ne sme prepisati novega
  const stej = async () => { const moj = ++zap, sid = $("#pr_s").value; for (const [c] of PREDLOGA_ZBIRKE) { const e = $(`[data-pn="${c}"]`); if (e) e.textContent = ""; } for (const [c] of PREDLOGA_ZBIRKE) { const n = (await D.list(c, { stranka_id: sid }).catch(() => [])).length; if (moj !== zap) return; const e = $(`[data-pn="${c}"]`); if (e) e.textContent = "(" + n + ")"; } };
  $("#pr_s").onchange = stej; stej();
}
async function kopirajPredlogo(vir, nov, zbirke) {
  const st = [], napake = [];
  for (const c of zbirke) {
    const rows = await D.list(c, { stranka_id: vir.id }).catch(() => []); let n = 0;
    for (const r of rows) { const o = Object.fromEntries(Object.entries(r).filter(([k]) => !PREDLOGA_BREZ.includes(k))); o.stranka_id = nov.id; try { await D.add(c, o); n++; } catch (e) { napake.push(e.message); } }
    st.push(`${(PREDLOGA_ZBIRKE.find(x => x[0] === c) || [c, c])[1]}: ${n}`);
  }
  toast(`Iz predloge »${sIme(vir)}« prevzeto – ${st.join(", ")}` + (napake.length ? ` (napak: ${napake.length})` : ""), !!napake.length);
}

// Moji podatki: naziv, ime in priimek, izobrazba, funkcija in kontakt za naslovnico dokumentov (Izdelal = svetovalec, Odobril = odgovorna oseba)
async function pageMojiPodatki(v) {
  await naloziIzdelovalca(); const m = IZDELOVALEC.moje || {}, vl = ME.u.vloga;
  const kaj = vl === "admin" || vl === "svetovalec" ? "Izdelal (svetovalec)" : vl === "odgovorna" ? "Odobril (odgovorna oseba)" : "";
  v.innerHTML = `<div class="card"><h2>Moji podatki</h2><p class="mut">${kaj ? `Podatki se izpišejo na naslovnici in v nogi dokumentov (HACCP načrt, navodila, evidence) v polju <b>${kaj}</b>.` : "Podatki se izpišejo v dokumentih, ki jih izvozite."} Polja, ki jih pustite prazna, se izpolnijo iz podatkov podjetja.</p>
    <div class="grid g2">${IZD_POLJA.map(([k, l, ph]) => `<label class="f"><span>${esc(l)}${k === "ime" ? ' <b class="req" aria-hidden="true">*</b>' : ""}</span><input id="mp_${k}" value="${esc(m[k] || "")}" placeholder="${esc(ph)}" maxlength="200"${k === "email" ? ' type="email"' : k === "telefon" ? ' type="tel"' : ""}${k === "ime" ? " required" : ""}></label>`).join("")}</div>
    <div class="row"><button class="btn" id="mp_s">Shrani</button></div></div>
    <div class="card"><h2>Tako bo na naslovnici</h2><div id="mp_p"></div></div>
    ${kaj.startsWith("Izdelal") ? `<div class="card"><h2>Logotip izdelovalca</h2><p class="mut">Prikaže se na naslovnici dokumentov, ki jih izdelate (poleg logotipa HiGiFood in logotipa stranke). PNG, JPEG ali WebP do 1,5 MB.</p><div class="row"><img id="ml_prev" alt="Vaš logotip" style="max-height:60px;max-width:180px;border:1px solid var(--line);border-radius:6px;padding:4px;background:#fff" ${m.logo ? "" : "hidden"}><input type="file" id="ml_f" accept="image/png,image/jpeg,image/webp" style="width:auto"><button class="btn ghost sec" id="ml_up">Naloži</button>${m.logo ? '<button class="btn ghost sec danger" id="ml_del">Odstrani</button>' : ""}</div></div>` : ""}`;
  const zberi = () => Object.fromEntries(IZD_POLJA.map(([k]) => [k, $("#mp_" + k).value.trim()]));
  const pred = () => { const z = zberi(), vr = kaj.startsWith("Izdelal") ? izdelovalecVrstice(z) : [[imeZNazivom(z), z.izobrazba].filter(Boolean).join(", "), z.funkcija].filter(Boolean);
    $("#mp_p").innerHTML = kaj ? `<table class="t"><tr><th style="width:30%">${esc(kaj)}</th><td>${vr.map(esc).join("<br>") || '<span class="mut">ni podatkov</span>'}</td></tr></table>` : '<p class="mut">Vaša vloga ni navedena na naslovnici dokumentov.</p>'; };
  $$("input[id^=mp_]", v).forEach(i => i.oninput = pred); pred();
  // podpis svetovalca (slika): na naslovnici v polju »Izdelal (svetovalec)«
  if (hasRole(ME.u, "svetovalec")) {
    v.insertAdjacentHTML("beforeend", `<div class="card" id="mpod_c"><h2>Podpis</h2><p class="mut">Slika podpisa se izpiše na naslovnici dokumentov v polju »Izdelal (svetovalec)«. PNG ali JPEG (najbolje z belim ozadjem), do 1,5 MB.</p>
      <div class="row"><img id="mpod_prev" alt="Vaš podpis" style="max-height:60px;max-width:240px;${m.podpis ? "" : "display:none"}"><input type="file" id="mpod_f" accept="image/png,image/jpeg" aria-label="Datoteka s podpisom"><button class="btn sec" id="mpod_up">Naloži podpis</button>${m.podpis ? '<button class="btn ghost sec" id="mpod_del">Odstrani</button>' : ""}</div></div>`);
    if (m.podpis) fetch("/api/izdelovalec-podpis/" + ME.u.id + "?t=" + Date.now()).then(r => r.status === 200 ? r.blob() : null).then(b => { if (b) $("#mpod_prev").src = URL.createObjectURL(b); }).catch(() => {});
    const poPodpisu = async () => { IZDELOVALEC.podpis = {}; await naloziIzdelovalca(); pageMojiPodatki(v); };
    $("#mpod_up").onclick = () => { const f = $("#mpod_f").files[0]; if (!f) return toast("Izberite datoteko.", true); const rd = new FileReader(); rd.onload = async () => { try { await api("POST", "/api/izdelovalec-podpis/" + ME.u.id, { tip: f.type, podatki: String(rd.result).split(",")[1] }); toast("Podpis shranjen"); await poPodpisu(); } catch (e) { fail(e); } }; rd.readAsDataURL(f); };
    if ($("#mpod_del")) $("#mpod_del").onclick = () => confirmBox("Odstranim podpis?", async () => { try { await api("DELETE", "/api/izdelovalec-podpis/" + ME.u.id); toast("Podpis odstranjen"); await poPodpisu(); } catch (e) { fail(e); } }, true);
  }
  if (m.logo && $("#ml_prev")) fetch("/api/izdelovalec-logo/" + ME.u.id + "?t=" + Date.now()).then(r => r.status === 200 ? r.blob() : null).then(b => { if (b) $("#ml_prev").src = URL.createObjectURL(b); }).catch(() => {});
  const poLogu = async () => { IZDELOVALEC.logo = {}; await naloziIzdelovalca(); pageMojiPodatki(v); };
  if ($("#ml_up")) $("#ml_up").onclick = () => { const f = $("#ml_f").files[0]; if (!f) return toast("Izberite datoteko.", true); const rd = new FileReader(); rd.onload = async () => { try { await api("POST", "/api/izdelovalec-logo/" + ME.u.id, { tip: f.type, podatki: String(rd.result).split(",")[1] }); toast("Logotip shranjen"); await poLogu(); } catch (e) { fail(e); } }; rd.readAsDataURL(f); };
  if ($("#ml_del")) $("#ml_del").onclick = () => confirmBox("Odstranim logotip izdelovalca?", async () => { try { await api("DELETE", "/api/izdelovalec-logo/" + ME.u.id); toast("Logotip odstranjen"); await poLogu(); } catch (e) { fail(e); } }, true);
  $("#mp_s").onclick = async () => { if (!$("#mp_ime").value.trim()) return toast("Ime in priimek je obvezen podatek.", true);
    try { const r = await api("POST", "/api/auth/izdelovalec", zberi()); IZDELOVALEC.moje = r.moje; IZDELOVALEC.za = {}; ME.u.ime = r.moje.ime; try { localStorage.setItem("haccp_me", JSON.stringify(ME.u)); } catch {} toast("Shranjeno – podatki veljajo za vse vaše dokumente."); } catch (e) { fail(e); } };
}
navItem("nadzorna", "Nadzorna plošča", "#/nadzorna");
route(/^\/moji-podatki$/, pageMojiPodatki, "Moji podatki", "moji-podatki");
navItem("stranke", "Stranke", "#/stranke", ["admin", "svetovalec"]);
navItem("moja", "Moje podjetje", "#/moja", ["odgovorna", "zaposleni"]);
route(/^\/nadzorna$/, pageDashboard, "Nadzorna plošča", "nadzorna");
route(/^\/stranke$/, pageStranke, "Stranke", "stranke");
route(/^\/moja$/, async v => { const s = await D.list("stranke"); if (s[0]) location.hash = "#/stranka/" + (s.find(x => x.id === ME.u.stranka_id) || s[0]).id + "/podatki"; else v.innerHTML = '<p class="empty">Za vaš uporabniški račun ni določene stranke.</p>'; }, "Moje podjetje", "moja");
