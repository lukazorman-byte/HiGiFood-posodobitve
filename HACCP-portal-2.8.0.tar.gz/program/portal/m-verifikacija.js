// Letni pregled (verifikacija) HACCP sistema – Uredba (ES) št. 852/2004, čl. 5(2)(f): postopki za preverjanje učinkovitosti.
// Poročilo za izbrano obdobje (privzeto zadnjih 12 mesecev): rednost vnosov po urniku, odstopanja po vrstah in napravah, neskladnosti
// (odprte, zaprte, čas do zaprtja), potekli roki (usposobljenost, oprema, dobavitelji, pregled načrta) in samodejni predlogi za spremembe.
// Sklepe in predloge mora pregledati in potrditi svetovalec oziroma HACCP skupina.
const dniMed = (a, b) => Math.max(0, Math.round((Date.parse(String(b).slice(0, 10) + "T00:00:00Z") - Date.parse(String(a).slice(0, 10) + "T00:00:00Z")) / 864e5));
async function verifikacijaPodatki(ctx, od, doo) {
  const R = await inspData(ctx, od, doo), d = R.d, ev = R.ev, ectx = await evCtx(ctx), danes = today();
  const urnik = await D.list("urnik", { stranka_id: ctx.stranka_id }).catch(() => []); // ni med zbirkami loadAll
  const ref = doo < danes ? doo : danes, vPer = s => { const t = lokDan(s); return t >= od && t <= doo; }, potekel = s => !!s && String(s).slice(0, 10) < ref;
  // evidence po vrstah
  const poVrstah = {}; for (const e of ev) { const v = poVrstah[e.vrsta] = poVrstah[e.vrsta] || { n: 0, odst: 0 }; v.n++; if (e.skladno === false) v.odst++; }
  // rednost po urniku: pričakovani vnosi (obdobje / »najdlje med vnosi«) in opravljeni (največ en vnos na interval)
  const rednost = urnik.filter(u => !u.ustvarjeno || lokDan(u.ustvarjeno) <= doo).map(u => {
    const zac = [od, lokDan(u.ustvarjeno) || od].sort().pop(), ur = Math.max(1, Number(u.frekvenca_ur) || 24), dni = dniMed(zac, doo) + 1;
    const pricakovano = Math.max(1, Math.floor(dni * 24 / ur)), im = imenaNaprave(ectx, u.naprava);
    const zapisi = ev.filter(e => e.vrsta === u.vrsta && (!u.naprava || im.has(e.oprema) || im.has(e.izdelek)) && (!u.obrat_id || e.obrat_id === u.obrat_id)).map(e => Date.parse(e.cas)).sort((a, b) => a - b);
    const t0 = new Date(zac + "T00:00:00").getTime(), t1 = new Date(doo + "T23:59:59").getTime(), intervali = new Set();
    for (const t of zapisi) if (t >= t0 && t <= t1) intervali.add(Math.floor((t - t0) / (ur * 3600e3))); // dva vnosa v istem intervalu (npr. isti dan) štejeta kot eden
    const opravljeno = intervali.size;
    return { vrsta: (EV[u.vrsta] || {}).ime || u.vrsta, naprava: u.naprava || "", ur, pricakovano, opravljeno: Math.min(opravljeno, pricakovano), delez: Math.min(100, Math.round(Math.min(opravljeno, pricakovano) / pricakovano * 100)) };
  });
  // naprave in izdelki s ponavljajočimi se odstopanji
  const kje = {}; for (const e of ev.filter(x => x.skladno === false)) { const k = e.oprema || e.izdelek || e.obmocje || (EV[e.vrsta] || {}).ime || e.vrsta; (kje[k] = kje[k] || []).push(e); }
  const ponavljajoca = Object.entries(kje).map(([k, a]) => ({ kje: k, n: a.length, vrsta: (EV[a[0].vrsta] || {}).ime || a[0].vrsta, zadnje: a.map(e => e.cas).sort().pop() })).sort((a, b) => b.n - a.n);
  // neskladnosti
  const capa = d.capa.filter(c => vPer(c.cas || c.ustvarjeno)), zaprte = capa.filter(c => c.status === "zaprto"), odprte = d.capa.filter(c => lokDan(c.cas || c.ustvarjeno) <= doo && (c.status !== "zaprto" || (c.datum_zapiranja && String(c.datum_zapiranja).slice(0, 10) > doo)));
  const casi = zaprte.filter(c => c.datum_zapiranja).map(c => dniMed(c.cas || c.ustvarjeno, c.datum_zapiranja));
  const capaS = { vse: capa.length, samodejne: capa.filter(c => c.samodejno).length, zaprte: zaprte.length, odprte: odprte.length, vZamudi: odprte.filter(c => potekel(c.rok)).length,
    povprecje: casi.length ? Math.round(casi.reduce((a, b) => a + b, 0) / casi.length * 10) / 10 : null, ponovitve: capa.reduce((a, c) => a + (Array.isArray(c.ponovitve) ? c.ponovitve.length : 0), 0) };
  // potekli roki
  const roki = [];
  for (const o of d.osebje || []) { if (o.datum_odhoda && o.datum_odhoda < danes) continue; if (potekel(o.higienski_do)) roki.push(["Zaposleni", o.ime, "higienski minimum / izobraževanje", o.higienski_do]); if (potekel(o.zdravniski_do)) roki.push(["Zaposleni", o.ime, "zdravniški pregled", o.zdravniski_do]); }
  for (const u of d.usposabljanja || []) if (potekel(u.veljavno_do)) roki.push(["Usposabljanje", u.tema, "veljavnost", u.veljavno_do]);
  for (const o of d.oprema || []) if (o.aktivno !== false && potekel(o.naslednji_servis)) roki.push(["Oprema", o.naziv, "servis / umerjanje", o.naslednji_servis]);
  for (const x of d.dobavitelji || []) if (potekel(x.naslednja_ocena)) roki.push(["Dobavitelj", x.naziv, "ocena dobavitelja", x.naslednja_ocena]);
  const nacrti = d.nacrti.filter(n => n.status !== "zastarelo").map(n => { const po = potrditevNacrta(n), potrjen = po.opravljena ? String(po.datum).slice(0, 10) : "";
    return { naziv: n.naziv, status: n.status || "", razlicica: n.verzija_oznaka || "", potrjen, stara: !!potrjen && dniMed(potrjen, danes) > 365, pregled: n.naslednji_pregled || "" }; });
  for (const n of nacrti) if (potekel(n.pregled)) roki.push(["HACCP načrt", n.naziv, "pregled načrta", n.pregled]);
  // predlogi (samodejni; potrdi svetovalec)
  const predlogi = [];
  for (const p of ponavljajoca.filter(x => x.n >= 3).slice(0, 5)) predlogi.push(`»${p.kje}«: ${p.n} odstopanj (${p.vrsta}). Preverite delovanje naprave ali postopek; po potrebi spremenite mejno vrednost, pogostost spremljanja ali korektivni ukrep v HACCP načrtu.`);
  for (const r of rednost.filter(x => x.delez < 80)) predlogi.push(`Rednost vnosov »${r.vrsta}${r.naprava ? " – " + r.naprava : ""}« je ${r.delez} % (${r.opravljeno} od ${r.pricakovano}). Preverite, ali je pogostost izvedljiva, in določite odgovorno osebo za vnos.`);
  if (capaS.vZamudi) predlogi.push(`${mnx(capaS.vZamudi, ["neskladnost je", "neskladnosti sta", "neskladnosti so", "neskladnosti je"])} v zamudi. Zaprite jih ali določite nove roke z utemeljitvijo.`);
  if (capaS.povprecje !== null && capaS.povprecje > 14) predlogi.push(`Povprečni čas do zaprtja neskladnosti je ${fnum(capaS.povprecje)} dni. Priporočljivo je, da se ukrepi zaključijo hitreje (npr. v 14 dneh).`);
  for (const n of nacrti.filter(x => x.stara || !x.potrjen)) predlogi.push(n.potrjen ? `HACCP načrt »${n.naziv}« je bil potrjen pred več kot 12 meseci (${fdate(n.potrjen)}). Opravite letno revizijo načrta.` : `HACCP načrt »${n.naziv}« še ni potrjen.`);
  if (roki.length) predlogi.push(`Potekli roki: ${roki.length} (usposobljenost, oprema, dobavitelji ali pregled načrta). Podrobnosti so v razdelku 5.`);
  if (!ev.length) predlogi.push("V obdobju ni vnesenih evidenc. Brez zapisov učinkovitosti HACCP sistema ni mogoče dokazati.");
  return { R, od, doo, poVrstah, rednost, ponavljajoca, capaS, roki, nacrti, predlogi };
}
function verifikacijaDoc(d, ctx, V) {
  const pct = (a, b) => b ? Math.round(a / b * 100) + " %" : "–";
  d.h(1, "1. Namen in obseg");
  d.p(`Letni pregled (verifikacija) HACCP sistema podjetja ${ctx.stranka.naziv} za obdobje ${fdate(V.od)} – ${fdate(V.doo)}. Pregled preverja, ali se sistem izvaja, kot je načrtovano, in ali je učinkovit (Uredba (ES) št. 852/2004, 5. člen, točka f; Codex CXC 1-1969, načelo 6). Podatki so izpisani iz sistema HiGiFood; sklepe in predloge potrdi svetovalec oziroma HACCP skupina.`);
  d.h(1, "2. Evidence in odstopanja");
  const vr = Object.entries(V.poVrstah).sort((a, b) => b[1].n - a[1].n);
  d.table(["Vrsta evidence", "Zapisov", "Odstopanj", "Delež odstopanj"], vr.map(([k, v]) => [(EV[k] || {}).ime || k, String(v.n), String(v.odst), pct(v.odst, v.n)]), [50, 15, 15, 20]);
  d.h(2, "Rednost vnosov po urniku");
  if (V.rednost.length) d.table(["Evidenca", "Naprava / izdelek", "Najdlje med vnosi", "Opravljeno / pričakovano", "Rednost"], V.rednost.map(r => [r.vrsta, r.naprava || "–", r.ur + " h", r.opravljeno + " / " + r.pricakovano, r.delez + " %"]), [30, 24, 14, 18, 14]);
  else d.p("Pogostosti vnosov niso določene, zato rednosti ni mogoče oceniti.", { col: "m" });
  d.h(2, "Ponavljajoča se odstopanja");
  if (V.ponavljajoca.length) d.table(["Naprava / izdelek / območje", "Evidenca", "Odstopanj", "Zadnje"], V.ponavljajoca.slice(0, 15).map(p => [p.kje, p.vrsta, String(p.n), fdt(p.zadnje)]), [36, 32, 12, 20]);
  else d.p("V obdobju ni bilo odstopanj.", { col: "m" });
  d.h(1, "3. Neskladnosti in korektivni ukrepi");
  const c = V.capaS;
  d.table(["Kazalnik", "Vrednost"], [["Neskladnosti v obdobju", String(c.vse)], ["od tega samodejno odprtih ob odstopanju v evidenci", String(c.samodejne)], ["ponovitve, pridružene odprtim neskladnostim", String(c.ponovitve)], ["Zaprtih v obdobju", String(c.zaprte)], ["Povprečni čas do zaprtja", c.povprecje === null ? "–" : fnum(c.povprecje) + " dni"], ["Trenutno odprtih", String(c.odprte)], ["od tega v zamudi", String(c.vZamudi)]], [60, 40]);
  d.h(1, "4. HACCP načrti");
  if (V.nacrti.length) d.table(["Načrt", "Stanje", "Različica", "Potrjen", "Naslednji pregled"], V.nacrti.map(n => [n.naziv, n.status, n.razlicica || "–", n.potrjen ? fdate(n.potrjen) : "–", n.pregled ? fdate(n.pregled) : "–"]), [34, 16, 12, 18, 20]);
  else d.p("Stranka nima HACCP načrta.", { col: "r" });
  d.h(1, "5. Potekli roki");
  if (V.roki.length) d.table(["Področje", "Kdo / kaj", "Rok", "Potekel"], V.roki.map(r => [r[0], r[1], r[2], fdate(r[3])]), [18, 36, 28, 18]);
  else d.p("Ni poteklih rokov.", { col: "m" });
  d.h(1, "6. Ocena po področjih");
  d.table(["Področje", "Ocena", "Podrobnosti"], V.R.check.map(x => [x.p, x.st === "ok" ? "v redu" : x.st === "warn" ? "preveri" : "manjka / zamuda", x.txt]), [32, 14, 54]);
  d.h(1, "7. Sklepi in predlogi za spremembe");
  if (V.predlogi.length) d.bullets(V.predlogi); else d.p("Na podlagi podatkov ni predlogov za spremembe. HACCP sistem se izvaja v skladu z načrtom.");
  d.p("Predlogi so pripravljeni samodejno iz podatkov. HACCP skupina oceni njihovo upravičenost, sprejete spremembe pa vnese v HACCP načrt (nova različica z razlogom spremembe).", { col: "m" });
  d.h(1, "8. Potrditev pregleda");
  d.table(["Vloga", "Ime in priimek", "Datum", "Podpis"], [["Svetovalec / vodja HACCP skupine", "", "", ""], ["Odgovorna oseba", ctx.stranka.odgovorna_oseba || "", "", ""]], [30, 30, 18, 22]);
}
// gumb v zavihku Inšpekcija: izbira obdobja (privzeto zadnjih 12 mesecev), PDF ali Word
function letniPregledDialog(ctx) {
  const doo = today(), od = addDays(doo, -365);
  modal("Letni pregled HACCP sistema (verifikacija)", `<p class="mut">Poročilo o izvajanju in učinkovitosti HACCP sistema za izbrano obdobje: rednost vnosov, odstopanja, neskladnosti, potekli roki in predlogi za spremembe načrta.</p>
    <div class="fgrid"><label class="f"><span>Od</span><input type="date" id="vf_od" value="${od}"></label><label class="f"><span>Do</span><input type="date" id="vf_do" value="${doo}"></label></div>`,
  [{ t: "Prekliči", cls: "ghost sec" }, { t: "Word", cls: "ghost", fn: () => izdelaj("docx") }, { t: "PDF", fn: () => izdelaj("pdf") }]);
  async function izdelaj(vrsta) {
    const a = $("#vf_od").value, b = $("#vf_do").value; if (!a || !b || a > b) { toast("Izberite veljavno obdobje.", true); return false; }
    try {
      const V = await verifikacijaPodatki(ctx, a, b), meta = { naslov: "Letni pregled HACCP sistema", podnaslov: "Verifikacija za obdobje " + fdate(a) + " – " + fdate(b), stranka: ctx.stranka.naziv, stanje: "izpis iz sistema na dan " + fdate(today()) + " – potrebna potrditev HACCP skupine" };
      dlBlob(vrsta === "docx" ? docxBuild(meta, d => verifikacijaDoc(d, ctx, V)) : pdfBuild(meta, d => verifikacijaDoc(d, ctx, V)), "letni-pregled-" + ctx.stranka.naziv + "-" + b + "." + vrsta);
      toast("Letni pregled pripravljen" + (V.predlogi.length ? " – " + mnx(V.predlogi.length, ["predlog", "predloga", "predlogi", "predlogov"]) + " za spremembe" : ""));
    } catch (e) { fail(e); return false; }
  }
}
