// Izvoz: XLSX in PDF (brez knjižnic). PDF uporablja standardni pisavi Helvetica z dodanimi glifi č, ć, đ.
const CRCT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRCT[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
const utf8 = s => new TextEncoder().encode(s);
function zipStoreU8(files) {
  const parts = [], cen = []; let off = 0;
  const u16 = (v, a, o) => { a[o] = v & 255; a[o + 1] = v >> 8 & 255; }, u32 = (v, a, o) => { u16(v & 0xFFFF, a, o); u16(v >>> 16, a, o + 2); };
  for (const f of files) {
    const nm = utf8(f.name), c = crc32(f.data), h = new Uint8Array(30), e = new Uint8Array(46);
    u32(0x04034b50, h, 0); u16(20, h, 4); u16(0x0800, h, 6); u32(c, h, 14); u32(f.data.length, h, 18); u32(f.data.length, h, 22); u16(nm.length, h, 26);
    u32(0x02014b50, e, 0); u16(20, e, 4); u16(20, e, 6); u16(0x0800, e, 8); u32(c, e, 16); u32(f.data.length, e, 20); u32(f.data.length, e, 24); u16(nm.length, e, 28); u32(off, e, 42);
    parts.push(h, nm, f.data); cen.push(e, nm); off += 30 + nm.length + f.data.length;
  }
  const cl = cen.reduce((a, x) => a + x.length, 0), end = new Uint8Array(22);
  u32(0x06054b50, end, 0); u16(files.length, end, 8); u16(files.length, end, 10); u32(cl, end, 12); u32(off, end, 16);
  return new Blob([...parts, ...cen, end]);
}
const xe = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "");
function colName(i) { let s = ""; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
function downloadXlsx(name, sheets) {
  if (!canPrint(name)) return;
  const used = new Set();
  const sx = sheets.map(sh => {
    const rows = [sh.glava, ...sh.vrste];
    const widths = sh.glava.map((_, c) => Math.min(60, Math.max(10, ...rows.map(r => String(r[c] == null ? "" : r[c]).length + 2))));
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join("")}</cols><sheetData>${rows.map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => { const ref = colName(ci) + (ri + 1); if (typeof v === "number" && isFinite(v) && ri > 0) return `<c r="${ref}"><v>${v}</v></c>`; return `<c r="${ref}" t="inlineStr" s="${ri === 0 ? 1 : 2}"><is><t xml:space="preserve">${xe(v)}</t></is></c>`; }).join("")}</row>`).join("")}</sheetData></worksheet>`;
  });
  const sn = sheets.map(s => { let n = String(s.ime).replace(/[\\\/?*\[\]:]/g, " ").slice(0, 31) || "List"; while (used.has(n)) n += "_"; used.add(n); return n; });
  const files = [
    ["[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`],
    ["_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
    ["xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sn.map((n, i) => `<sheet name="${xe(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets></workbook>`],
    ["xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
    ["xl/styles.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF2F6F4F"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment wrapText="1" vertical="top"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs></styleSheet>`],
    ...sx.map((x, i) => [`xl/worksheets/sheet${i + 1}.xml`, x])
  ].map(([name, t]) => ({ name, data: utf8(t) }));
  dlBlob(zipStoreU8(files), name.endsWith(".xlsx") ? name : name + ".xlsx");
}

// ---------- PDF ----------
const HW = { r: [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584],
  b: [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584] };
const DIA = { "Č": [128, "C"], "č": [129, "c"], "Ć": [130, "C"], "ć": [131, "c"], "Đ": [132, "D"], "đ": [133, "d"] };
// znaki izven WinAnsi, ki jih ima pisava Helvetica: kode 134–139 so v /Differences preslikane na ≤ ≥ − … ≠ (mejne vrednosti CCP);
// kode 128–133 zasedajo č ć đ, zato sta € in „ preslikana na prosti kodi 141 in 143; puščica → (Helvetica je nima) se izpiše kot »->«
const WANSI = { "š": 0x9A, "Š": 0x8A, "ž": 0x9E, "Ž": 0x8E, "–": 0x96, "—": 0x97, "“": 0x93, "”": 0x94, "„": 143, "‘": 0x91, "’": 0x92, "•": 0x95, "€": 141, "≈": 126, "‹": 60, "›": 0x9B, "≤": 134, "≥": 135, "−": 136, "…": 137, "≠": 139, "\u00a0": 32, "\u202f": 32, "\u2009": 32 };
const WANSI_W = { "≤": 549, "≥": 549, "−": 584, "…": 1000, "≠": 549, "→": 917, "€": 556, "„": 333 };
function pdfCode(ch) {
  if (DIA[ch]) return DIA[ch][0];
  if (WANSI[ch]) return WANSI[ch];
  const c = ch.charCodeAt(0);
  if (c >= 32 && c < 127) return c;
  if (c >= 0xA0 && c <= 0xFF) return c;
  if (c === 9 || c === 10) return 32;
  return 63;
}
function pdfW(ch, bold, size) {
  if (DIA[ch]) { const b = DIA[ch][1]; return pdfW(b, bold, size); }
  if (ch === "š" || ch === "ž") return (bold ? 500 : 500) * size / 1000;
  if (ch === "Š") return 667 * size / 1000; if (ch === "Ž") return 611 * size / 1000;
  const c = ch.charCodeAt(0), t = bold ? HW.b : HW.r;
  if (c >= 32 && c <= 126) return t[c - 32] * size / 1000;
  if (ch === "–" || ch === "—") return (ch === "–" ? 556 : 1000) * size / 1000;
  if (ch === "•") return 350 * size / 1000;
  if (WANSI_W[ch]) return WANSI_W[ch] * size / 1000;
  return 556 * size / 1000;
}
const hexOf = s => Array.from(String(s).replace(/→/g, "->")).map(ch => pdfCode(ch).toString(16).padStart(2, "0")).join("");
const f2 = n => (Math.round(n * 100) / 100).toString();

class Pdf {
  constructor(o) {
    this.o = Object.assign({ naslov: "Dokument", podnaslov: "", verzija: "1.0", datum: today(), stranka: "", noga: true }, o);
    this.W = o && o.landscape ? 841.89 : 595.28; this.H = o && o.landscape ? 595.28 : 841.89; this.M = 48; this.pages = []; this.imgs = []; this.toc = []; this.offset = o && o.offset || 0;
    this.newPage();
  }
  newPage() { this.pages.push({ s: [], links: [], im: new Set() }); this.y = this.H - this.M - 18; return this.pages[this.pages.length - 1]; }
  get cur() { return this.pages[this.pages.length - 1]; }
  need(h) { if (this.y - h < this.M + 22) this.newPage(); }
  color(c) { return c === "g" ? "0.184 0.435 0.31" : c === "r" ? "0.7 0.15 0.12" : c === "m" ? "0.4 0.45 0.42" : c === "w" ? "1 1 1" : c === "l" ? "0.9 0.95 0.92" : "0.1 0.13 0.11"; }
  text(x, y, s, size, bold, col) { this.cur.s.push(`BT ${this.color(col)} rg /${bold ? "F2" : "F1"} ${size} Tf ${f2(x)} ${f2(y)} Td <${hexOf(s)}> Tj ET`); }
  wrap(s, w, size, bold) {
    const out = [];
    for (const para of String(s == null ? "" : s).split("\n")) {
      let line = "", lw = 0;
      for (const word of para.split(/(\s+)/)) {
        if (!word) continue;
        const ww = Array.from(word).reduce((a, ch) => a + pdfW(ch, bold, size), 0);
        if (lw + ww > w && line.trim()) { out.push(line.trimEnd()); line = ""; lw = 0; if (/^\s+$/.test(word)) continue; }
        // beseda, daljša od stolpca: razdeli jo z vezajem (»kontami-/nacija«), ne brez oznake
        if (ww > w) { const hw = pdfW("-", bold, size); for (const ch of word) { const cw = pdfW(ch, bold, size); if (lw + cw + hw > w && line.trim()) { out.push(/[\s-]$/.test(line) ? line : line + "-"); line = ""; lw = 0; } line += ch; lw += cw; } continue; }
        line += word; lw += ww;
      }
      out.push(line.trimEnd());
    }
    return out;
  }
  h(level, s) {
    const size = level === 1 ? 16 : level === 2 ? 13 : 11;
    const ls = this.wrap(s, this.W - 2 * this.M, size, true); // dolg naslov se prelomi (ne steče čez desni rob)
    this.need(ls.length * (size + 4) + 26); this.y -= level === 1 ? 10 : 6;
    if (!(this.o && this.o.tocNivo && level > this.o.tocNivo)) this.toc.push({ level, s, page: this.pages.length + this.offset });
    ls.forEach((l, i) => { this.text(this.M, this.y, l, size, true, "g"); this.y -= size + (i < ls.length - 1 ? 4 : 6); });
    if (level === 1) { this.cur.s.push(`${this.color("g")} RG 0.8 w ${f2(this.M)} ${f2(this.y + 3)} m ${f2(this.W - this.M)} ${f2(this.y + 3)} l S`); this.y -= 12; }
  }
  p(s, o) {
    o = o || {}; const size = o.size || 10, lead = size * 1.4, w = this.W - 2 * this.M - (o.indent || 0);
    for (const l of this.wrap(s, w, size, o.bold)) { this.need(lead); this.text(this.M + (o.indent || 0), this.y, l, size, o.bold, o.col); this.y -= lead; }
    this.y -= o.gap === undefined ? 4 : o.gap;
  }
  bullets(list, o) { for (const t of list) { const size = 10, w = this.W - 2 * this.M - 14; const ls = this.wrap(t, w, size); ls.forEach((l, i) => { this.need(14); if (!i) this.text(this.M + 2, this.y, "•", size, false); this.text(this.M + 14, this.y, l, size, false); this.y -= 14; }); } this.y -= 4; }
  imgIdx(im) { let i = this.imgs.indexOf(im); if (i < 0) { i = this.imgs.length; this.imgs.push(im); } return i; }
  img(im, maxW, maxH, cap) {
    if (!im) return;
    const sc = Math.min((maxW || 300) / im.w, (maxH || 220) / im.h, 1), w = im.w * sc, h = im.h * sc, capL = cap ? this.wrap(cap, this.W - 2 * this.M, 8.5) : [];
    this.need(h + capL.length * 11 + 10);
    const i = this.imgIdx(im); this.cur.im.add(i);
    this.cur.s.push(`q ${f2(w)} 0 0 ${f2(h)} ${f2(this.M)} ${f2(this.y - h)} cm /Im${i} Do Q`); this.y -= h + 4;
    for (const l of capL) { this.text(this.M, this.y - 7, l, 8.5, false, "m"); this.y -= 11; }
    this.y -= 8;
  }
  gap(n) { this.y -= n; }
  box(s, col) { const w = this.W - 2 * this.M - 16, ls = this.wrap(s, w, 9.5); const h = ls.length * 13 + 10; this.need(h + 6); this.cur.s.push(`${col === "r" ? "1 0.93 0.91" : "0.99 0.96 0.85"} rg ${f2(this.M)} ${f2(this.y - h + 4)} ${f2(this.W - 2 * this.M)} ${f2(h)} re f`); let yy = this.y - 8; for (const l of ls) { this.text(this.M + 8, yy, l, 9.5, false, col === "r" ? "r" : "d"); yy -= 13; } this.y -= h + 6; }
  table(glava, vrste, sirine, o) {
    o = o || {}; if (!vrste.length && !o.prazno) vrste = [["ni podatkov"].concat(Array(Math.max(0, glava.length - 1)).fill(""))]; // prazna tabela: jasno, da ni zapisov
    const size = o.size || 8.5, lead = size * 1.35, pad = o.tesno ? 1 : 6, tw = this.W - 2 * this.M;
    const sum = sirine.reduce((a, b) => a + b, 0), cw = sirine.map(x => x / sum * tw);
    const hl = glava.map((g, i) => this.wrap(g, cw[i] - 8, size, true)), hh = Math.max(...hl.map(l => l.length)) * lead + 8;
    const drawHead = () => { this.need(hh + 20); this.cur.s.push(`${this.color("g")} rg ${f2(this.M)} ${f2(this.y - hh + 4)} ${f2(tw)} ${f2(hh)} re f`); let x = this.M; glava.forEach((g, i) => { let yy = this.y - 8; for (const l of hl[i]) { this.text(x + 4, yy, l, size, true, "w"); yy -= lead; } x += cw[i]; }); this.y -= hh; };
    drawHead();
    vrste.forEach((r, ri) => {
      const cells = glava.map((_, i) => this.wrap(r[i] == null ? "" : r[i], cw[i] - 8, size));
      const vseh = Math.max(1, ...cells.map(c => c.length)), dno = this.M + 22;
      const celaH = Math.max(o.minH || 0, vseh * lead + pad), stran = this.H - this.M - 18 - hh - dno;
      if (this.y - celaH < dno && (celaH <= stran || this.y - (3 * lead + 6) < dno)) { this.newPage(); drawHead(); } // na novo stran, razen če je vrstica višja od cele strani
      // vrstica, višja od preostanka strani, se nadaljuje na naslednji strani (z glavo tabele) – besedilo se ne izgubi
      let od = 0;
      while (od < vseh) {
        const prostor = Math.max(1, Math.floor((this.y - dno - 6) / lead)), n = Math.min(vseh - od, prostor), zadnji = od + n >= vseh;
        const h = Math.max(zadnji && od === 0 ? o.minH || 0 : 0, n * lead + pad);
        if (ri % 2) this.cur.s.push(`0.95 0.97 0.95 rg ${f2(this.M)} ${f2(this.y - h + 4)} ${f2(tw)} ${f2(h)} re f`);
        let x = this.M; cells.forEach((c, i) => { let yy = this.y - 7; for (const l of c.slice(od, od + n)) { this.text(x + 4, yy, l, size, false); yy -= lead; } x += cw[i]; });
        this.cur.s.push(`0.82 0.86 0.83 RG 0.4 w ${f2(this.M)} ${f2(this.y - h + 4)} m ${f2(this.W - this.M)} ${f2(this.y - h + 4)} l S`);
        if (o.grid) { let gx = this.M; this.cur.s.push(`0.7 0.74 0.71 RG 0.4 w`); for (let i = 0; i <= cw.length; i++) { this.cur.s.push(`${f2(gx)} ${f2(this.y + 4)} m ${f2(gx)} ${f2(this.y - h + 4)} l S`); gx += cw[i] || 0; } }
        this.y -= h; od += n;
        if (od < vseh) { this.newPage(); drawHead(); }
      }
    });
    this.y -= 8;
  }
  // diagram poteka: navpična veriga polj; koraki: [{t, ccp, tag}] – enako kot v Wordu: CCP v rdečem okvirju z napisom
  // »KRITIČNA KONTROLNA TOČKA (CCP)«; oznaka »nadaljevanje diagrama« samo, kadar se diagram res prelomi na novo stran (mesta prelomov si zapomni za Word)
  flow(steps) {
    const w = 330, x = (this.W - w) / 2, sir = (s, size, b) => Array.from(s).reduce((a, ch) => a + pdfW(ch, b, size), 0), prel = [];
    (this.flowPrelomi = this.flowPrelomi || []).push(prel);
    steps.forEach((st, i) => {
      const ls = this.wrap((st.n ? st.n + ". " : "") + st.t, w - 16, 9, st.ccp), h = ls.length * 12 + 10 + (st.ccp ? 11 : 0);
      if (this.y - (h + 18) < this.M + 22) {
        if (i > 0) { const t = "nadaljevanje diagrama", tw = sir(t, 8, false), cx = this.W / 2 - (tw + 10) / 2; this.cur.s.push(`${this.color("g")} rg ${f2(cx)} ${f2(this.y - 4)} m ${f2(cx + 7)} ${f2(this.y - 4)} l ${f2(cx + 3.5)} ${f2(this.y - 10)} l f`); this.text(cx + 10, this.y - 10, t, 8, false, "g"); prel.push(i); }
        this.newPage();
      }
      const stroke = st.ccp ? "0.7 0.15 0.12" : "0.184 0.435 0.31";
      this.cur.s.push(`1 1 1 rg ${stroke} RG ${st.ccp ? 1.5 : 1.2} w ${f2(x)} ${f2(this.y - h)} ${f2(w)} ${f2(h)} re B`);
      let yy = this.y - 12; for (const l of ls) { this.text(this.W / 2 - sir(l, 9, !!st.ccp) / 2, yy, l, 9, !!st.ccp, "d"); yy -= 12; }
      if (st.ccp) { const t = "KRITIČNA KONTROLNA TOČKA (CCP)"; this.text(this.W / 2 - sir(t, 7, true) / 2, yy + 1, t, 7, true, "r"); }
      if (st.tag) this.text(x + w + 8, this.y - h / 2 - 3, st.tag, 8, true, st.ccp ? "r" : "m");
      this.y -= h;
      if (i < steps.length - 1) { this.cur.s.push(`${this.color("g")} RG ${this.color("g")} rg 1 w ${f2(this.W / 2)} ${f2(this.y)} m ${f2(this.W / 2)} ${f2(this.y - 12)} l S ${f2(this.W / 2 - 3)} ${f2(this.y - 8)} m ${f2(this.W / 2 + 3)} ${f2(this.y - 8)} l ${f2(this.W / 2)} ${f2(this.y - 13)} l f`); this.y -= 14; }
    });
    this.y -= 10;
  }
  // napis slike (npr. »Tloris 1: …«): krepko, na isti strani kot slika (prostor zagotovi klic need pred napisom)
  napis(s) { this.p(s, { bold: true }); }
  // oštevilčeni koraki [{n, t}]: izpis kot doslej (»1. …«); v Wordu pravi oštevilčen seznam
  stevilke(list) { for (const x of list) this.p(x.n + ". " + x.t); }
  // sestavi končni PDF; cover + TOC pred vsebino (prvi dve vsebinski strani sta rezervirani)
  // razporeditev kazala po straneh glede na dejansko višino vnosov (dolg naslov = 2 vrstici), da nič ne pade pod nogo
  tocStrani() {
    const out = [[]], vrh = this.H - this.M - 36, dno = this.M + 34; let y = vrh;
    for (const e of this.toc) {
      const vel = e.level === 1 ? 10.5 : 9.5, x0 = this.M + (e.level - 1) * 14; let ls = this.wrap(e.s, this.W - this.M - 40 - x0, vel, e.level === 1);
      if (ls.length > 2) ls = [ls[0], ls[1].replace(/\s*\S*$/, "") + " …"];
      const h = (ls.length - 1) * 12 + 15;
      if (y - h < dno && out[out.length - 1].length) { out.push([]); y = vrh; }
      out[out.length - 1].push({ e, vel, x0, ls }); y -= h;
    }
    return out;
  }
  build(tocPages) {
    if (this.o.plain) tocPages = 0;
    const o = this.o, objs = [], add = s => { objs.push(s); return objs.length; };
    const logo = o.logo === undefined ? LOGO.pdf || LOGO.im : o.logo, okvir = !(o.logo === undefined && LOGO.privzeti); if (logo) this.imgIdx(logo);
    const slogo = o.strankaLogo === undefined ? strankaLogoZa(o.stranka) : o.strankaLogo; if (slogo) this.imgIdx(slogo);
    const ilogo = o.plain ? null : o.izdelalLogo !== undefined ? o.izdelalLogo : izdelovalecLogoZa(null); if (ilogo) this.imgIdx(ilogo);
    for (const p of o.podpisi || []) if (p.podpis_slika) this.imgIdx(p.podpis_slika);
    const body = this.pages, total = body.length + (o.plain ? 0 : 1) + tocPages;
    add("<< /Type /Catalog /Pages 2 0 R >>"); add(""); // pages se zapolni kasneje
    const enc = "<< /Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences [128 /Ccaron /ccaron /Cacute /cacute /Dcroat /dcroat /lessequal /greaterequal /minus /ellipsis 139 /notequal 141 /Euro 143 /quotedblbase] >>";
    const f1 = add(`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding ${enc} >>`), f2o = add(`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding ${enc} >>`);
    const imObj = this.imgs.map(im => add({ dict: `<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.u8.length} >>`, data: im.u8 }));
    const kids = [];
    const mkPage = (stream, used) => { const c = add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`); const p = add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f2(this.W)} ${f2(this.H)}] /Resources << /Font << /F1 ${f1} 0 R /F2 ${f2o} 0 R >>${used && used.size ? ` /XObject << ${[...used].map(i => `/Im${i} ${imObj[i]} 0 R`).join(" ")} >>` : ""} >> /Contents ${c} 0 R >>`); kids.push(p); };
    const T = this, tx = (x, y, s, size, bold, col) => `BT ${T.color(col)} rg /${bold ? "F2" : "F1"} ${size} Tf ${f2(x)} ${f2(y)} Td <${hexOf(s)}> Tj ET\n`;
    // naslovnica
    let cv = `${T.color("g")} rg 0 ${f2(T.H - 250)} ${f2(T.W)} 250 re f\n` + tx(T.M, T.H - 90, "HiGiFood", 30, true, "w") + "\n" + tx(T.M, T.H - 115, "HACCP dokumentacija", 13, false, "w") + "\n";
    // naslov največ 3 vrstice, podnaslov 2 (sicer prekrijeta blok »Podjetje«)
    const skrajsaj = (ls, n) => ls.length > n ? ls.slice(0, n - 1).concat([ls[n - 1].replace(/\s*\S*$/, "") + " …"]) : ls;
    const tl = skrajsaj(T.wrap(o.naslov, T.W - 2 * T.M, 24, true), 3); let yy = T.H - 330; for (const l of tl) { cv += tx(T.M, yy, l, 24, true, "d") + "\n"; yy -= 30; }
    if (o.podnaslov) for (const l of skrajsaj(T.wrap(o.podnaslov, T.W - 2 * T.M, 12, false), 2)) { cv += tx(T.M, yy - 6, l, 12, false, "m") + "\n"; yy -= 17; }
    let cvUsed = new Set();
    const izd = o.izdelal || izdelovalecVrstice(izdelovalecZa(null));
    yy = 212; for (const [k, v] of [["Podjetje", o.stranka], ["Različica", o.verzija], ["Datum", fdate(o.datum)], ["Izdelal", izd.length ? izd : o.avtor || ""], ["Stanje", o.stanje || "osnutek – potrebna strokovna potrditev"]]) if (v && v.length) { cv += tx(T.M, yy, k, 10, true, "m"); for (const l of [].concat(v).flatMap(s => this.wrap(String(s), T.W - 2 * T.M - 90, 10)).slice(0, k === "Izdelal" ? 5 : 3)) { cv += tx(T.M + 90, yy, l, 10, false) + "\n"; yy -= 13; } yy -= 5; }
    if (o.podpisi && o.podpisi.length) { const n = o.podpisi.length, g = 14, bw = (T.W - 2 * T.M - g * (n - 1)) / n, by = 306, bh = 74;
      o.podpisi.forEach((p, i) => { const x = T.M + i * (bw + g); cv += `0.72 0.77 0.74 RG 0.6 w ${f2(x)} ${f2(by)} ${f2(bw)} ${f2(bh)} re S\n` + tx(x + 8, by + bh - 15, p.vloga, 9, true, "m") + tx(x + 8, by + bh - 29, (T.wrap(String(p.ime || "—"), bw - 16, 10)[0] || ""), 10, false) + (p.opis ? tx(x + 8, by + bh - 41, (T.wrap(String(p.opis), bw - 16, 8)[0] || ""), 8, false, "m") : "") + tx(x + 8, by + 21, "Datum: " + (p.datum ? fdate(p.datum) : "____________________"), 9, false, "m") + tx(x + 8, by + 7, p.podpis_tekst || (p.podpis_slika ? "Podpis:" : "Podpis: ____________________________"), 9, !!p.podpis_tekst, p.podpis_tekst ? "g" : "m");
        if (p.podpis_slika) { const im = p.podpis_slika, ii = this.imgIdx(im), sc = Math.min((bw * 0.55) / im.w, 30 / im.h, 1), w = im.w * sc, h = im.h * sc; cv += `q ${f2(w)} 0 0 ${f2(h)} ${f2(x + bw - 8 - w)} ${f2(by + 4)} cm /Im${ii} Do Q\n`; cvUsed.add(ii); } }); }
    cv += tx(T.M, 60, "Dokument je pripravljen s pomočjo orodja in ne pomeni uradne odobritve ali samodejne skladnosti z zakonodajo.", 8, false, "m") + "\n";
    if (logo) { const i = this.imgIdx(logo), sc = Math.min(150 / logo.w, 70 / logo.h, 1), w = logo.w * sc, h = logo.h * sc, x = T.W - T.M - w - 10, yb = T.H - 60 - h; cv += `${okvir ? `1 1 1 rg ${f2(x - 10)} ${f2(yb - 8)} ${f2(w + 20)} ${f2(h + 16)} re f\n` : ""}q ${f2(w)} 0 0 ${f2(h)} ${f2(x)} ${f2(yb)} cm /Im${i} Do Q\n`; cvUsed.add(i); }
    if (ilogo) { const i = this.imgIdx(ilogo), sc = Math.min(140 / ilogo.w, 56 / ilogo.h, 1), w = ilogo.w * sc, h = ilogo.h * sc, yb = T.H - 232; cv += `1 1 1 rg ${f2(T.M - 6)} ${f2(yb - 6)} ${f2(w + 12)} ${f2(h + 12)} re f\nq ${f2(w)} 0 0 ${f2(h)} ${f2(T.M)} ${f2(yb)} cm /Im${i} Do Q\n`; cvUsed.add(i); }
    if (slogo) { const i = this.imgIdx(slogo), sc = Math.min(160 / slogo.w, 70 / slogo.h, 1), w = slogo.w * sc, h = slogo.h * sc; cv += `q ${f2(w)} 0 0 ${f2(h)} ${f2(T.M)} 226 cm /Im${i} Do Q\n`; cvUsed.add(i); }
    if (!o.plain) mkPage(cv, cvUsed);
    // kazalo
    const tocs = [], strani = this.tocStrani();
    for (let p = 0; p < tocPages; p++) {
      let s = tx(T.M, T.H - T.M - 6, p ? "Kazalo (nadaljevanje)" : "Kazalo", 16, true, "g") + "\n", y = T.H - T.M - 36;
      for (const { e, vel, x0, ls } of strani[p] || []) {
        ls.forEach((l, i) => { s += tx(x0, y, l, vel, e.level === 1, "d") + (i === 0 ? tx(T.W - T.M - 24, y, String(e.page), 10, false, "m") : "") + "\n"; if (i < ls.length - 1) y -= 12; }); y -= 15;
      }
      tocs.push(s);
    }
    tocs.forEach(s => { const idx = kids.length + 1; mkPage(s + this.foot(idx + 0, total)); });
    body.forEach((pg, i) => mkPage(pg.s.join("\n") + "\n" + (o.noga === false ? "" : this.foot((o.plain ? 1 : 2) + tocPages + i, total)), pg.im)); // noga: false – brez noge (npr. nalepke)
    objs[1] = `<< /Type /Pages /Kids [${kids.map(k => k + " 0 R").join(" ")}] /Count ${kids.length} >>`;
    const chunks = []; let pos = 0, offs = [];
    const put = x => { const u = typeof x === "string" ? Uint8Array.from(x, c => c.charCodeAt(0) & 255) : x; chunks.push(u); pos += u.length; };
    put("%PDF-1.4\n");
    objs.forEach((s, i) => { offs.push(pos); if (typeof s === "string") put(`${i + 1} 0 obj\n${s}\nendobj\n`); else { put(`${i + 1} 0 obj\n${s.dict}\nstream\n`); put(s.data); put("\nendstream\nendobj\n"); } });
    const xr = pos;
    put(`xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map(x => String(x).padStart(10, "0") + " 00000 n \n").join("") + `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R /Info << /Title <FEFF${Array.from(this.o.naslov).map(c => c.charCodeAt(0).toString(16).padStart(4, "0")).join("")}> >> >>\nstartxref\n${xr}\n%%EOF`);
    const out = chunks;
    return new Blob(out, { type: "application/pdf" });
  }
  foot(pageNo, total) {
    const o = this.o, T = this, sir = T.W - 2 * T.M - 64;
    if (this._noga === undefined) { const nz = o.plain ? "" : o.izdelalNoga !== undefined ? o.izdelalNoga : izdelovalecNoga(izdelovalecZa(null)); this._noga = [T.wrap(znamka(`${o.stranka || "HiGiFood HACCP"} | ${o.naslov} | v${o.verzija} | ${fdate(o.datum)}`), sir, 8)[0] || "", nz ? T.wrap("Izdelal: " + znamka(nz), sir, 8)[0] : ""]; }
    const [t, t2] = this._noga;
    return `0.8 0.85 0.82 RG 0.5 w ${f2(T.M)} 40 m ${f2(T.W - T.M)} 40 l S\nBT 0.4 0.45 0.42 rg /F1 8 Tf ${f2(T.M)} 28 Td <${hexOf(t)}> Tj ET\n${t2 ? `BT 0.4 0.45 0.42 rg /F1 8 Tf ${f2(T.M)} 18 Td <${hexOf(t2)}> Tj ET\n` : ""}BT 0.4 0.45 0.42 rg /F1 8 Tf ${f2(T.W - T.M - 50)} 28 Td <${hexOf("Stran " + pageNo + " / " + total)}> Tj ET`;
  }
}
// zgradi dokument z dvema prehodoma (število strani kazala vpliva na številke strani)
// Moji podatki (naslovnica): Izdelal = prijavljeni svetovalec ali administrator, pri stranki pa njen dodeljeni svetovalec; Odobril = odgovorna oseba stranke
const IZDELOVALEC = { privzeto: null, moje: null, za: {}, logo: {}, podpis: {} };
async function naloziIzdelovalca(sid) {
  try { const r = await api("GET", "/api/auth/izdelovalec" + (sid ? "?stranka_id=" + encodeURIComponent(sid) : "")); IZDELOVALEC.privzeto = r.privzeto; IZDELOVALEC.moje = r.moje; if (sid) IZDELOVALEC.za[sid] = r.za || {}; } catch {}
  // elektronske odobritve načrtov stranke (veljavne, dokler se načrt ne spremeni)
  if (sid && IZDELOVALEC.za[sid]) { try { IZDELOVALEC.za[sid].odobritve = (await api("GET", "/api/potrditve?stranka_id=" + encodeURIComponent(sid))).filter(x => x.vrsta === "odobritev" && x.zbirka === "nacrti"); } catch { IZDELOVALEC.za[sid].odobritve = []; } }
  // logotip izdelovalca (naloži se enkrat; po spremembi se predpomnilnik izprazni)
  const z = izdelovalecZa(sid); if (z && z.id && z.logo && !(z.id in IZDELOVALEC.logo)) IZDELOVALEC.logo[z.id] = await loadImg("/api/izdelovalec-logo/" + z.id + "?t=" + Date.now(), 600);
  await naloziPodpis(z);
  return IZDELOVALEC;
}
// podpis svetovalca (slika) za naslovnico; naloži se enkrat
async function naloziPodpis(z) { if (z && z.id && z.podpis && !(z.id in IZDELOVALEC.podpis)) IZDELOVALEC.podpis[z.id] = await loadImg("/api/izdelovalec-podpis/" + z.id + "?t=" + Date.now(), 500).catch(() => null); }
const podpisZa = z => z && z.id && z.podpis ? IZDELOVALEC.podpis[z.id] || null : null;
// izdelovalec načrta: pri potrjenem načrtu podatki ob potrditvi (že izdan dokument se ne spremeni), sicer trenutni svetovalec
const izdelovalecNacrta = rec => rec && rec.status === "potrjeno" && rec.izdelal_posnetek && rec.izdelal_posnetek.ime ? rec.izdelal_posnetek : izdelovalecZa(rec && rec.stranka_id);
const izdelovalecLogoZa = sid => { const z = izdelovalecZa(sid); return z && z.id && z.logo ? IZDELOVALEC.logo[z.id] || null : null; };
// zadnja elektronska odobritev načrta; veljavna samo, če se načrt po odobritvi ni spremenil
function odobritevNacrta(rec) { const a = ((IZDELOVALEC.za[rec.stranka_id] || {}).odobritve || []).filter(x => x.ref_id === rec.id).sort((a, b) => String(b.cas).localeCompare(String(a.cas))); return a[0] || null; }
const IZD_POLJA = [["naziv", "Strokovni ali akademski naziv", "npr. mag., dr."], ["ime", "Ime in priimek", ""], ["izobrazba", "Izobrazba", "npr. univ. dipl. inž. živilske tehnologije"], ["funkcija", "Funkcija / delovno mesto", "npr. svetovalec za varnost živil, vodja kuhinje"], ["podjetje", "Podjetje", ""], ["naslov", "Naslov podjetja", ""], ["email", "E-pošta", ""], ["telefon", "Telefon", ""]];
const jeSvetovalec = () => typeof ME !== "undefined" && !!ME.u && (hasRole(ME.u, "admin") || hasRole(ME.u, "svetovalec"));
function izdelovalecZa(sid) {
  if (!sid && typeof ME !== "undefined" && ME.u && !jeSvetovalec()) sid = ME.u.stranka_id;
  const sv = sid && IZDELOVALEC.za[sid] && IZDELOVALEC.za[sid].svetovalec;
  return sv || IZDELOVALEC.moje || (typeof ME !== "undefined" && ME.u ? { ime: ME.u.ime, email: ME.u.email } : {});
}
const svetovalecManjka = sid => !jeSvetovalec() && !!sid && !!IZDELOVALEC.za[sid] && !IZDELOVALEC.za[sid].svetovalec;
function odobrilZa(sid, stranka) { const z = sid && IZDELOVALEC.za[sid] && IZDELOVALEC.za[sid].odgovorna; return z && z.ime ? z : { ime: (stranka && stranka.odgovorna_oseba) || "" }; }
const imeZNazivom = z => [z.naziv, z.ime].filter(Boolean).join(" ");
// ime blagovne znamke povsod enako (»HiGiFood«, tudi če je v podatkih vpisano »Higifood« ali »HIGIFOOD«)
const znamka = s => String(s == null ? "" : s).replace(/(?<![@.\/\w-])higi\s?food(?![\w@-]|\.\w)/gi, "HiGiFood"); // ne v e-naslovih in domenah (info@higifood.si)
const izdelovalecVrstice = z => z ? [[imeZNazivom(z), z.izobrazba].filter(Boolean).join(", "), z.funkcija, z.podjetje, z.naslov, [z.email, z.telefon].filter(Boolean).join(" · ")].filter(Boolean).slice(0, 5).map(znamka) : [];
const izdelovalecNoga = z => z ? znamka([imeZNazivom(z), z.izobrazba, z.podjetje].filter(Boolean).join(", ")) : "";
function pdfBuild(meta, fill) {
  let tp = 1, doc;
  for (let k = 0; k < 3; k++) {
    doc = new Pdf(Object.assign({}, meta, { offset: 1 + tp })); fill(doc);
    const need = Math.max(1, doc.tocStrani().length);
    if (need === tp) break; tp = need;
  }
  // statistika zadnjega dokumenta (število strani in začetne strani poglavij) – npr. za opozorilo o predolgem HACCP načrtu
  pdfBuild.zadnji = { strani: doc.pages.length + tp + 1, poglavja: doc.toc.filter(e => e.level === 1).map(e => ({ s: e.s, stran: e.page })) };
  return doc.build(tp);
}
function downloadPdf(name, spec) {
  const blob = pdfBuild({ naslov: spec.naslov, podnaslov: spec.podnaslov, stranka: spec.stranka || "" }, d => {
    d.h(1, spec.naslov);
    if (spec.tabela) d.table(spec.tabela.glava, spec.tabela.vrste, spec.tabela.sirine);
  });
  dlBlob(blob, name.endsWith(".pdf") ? name : name + ".pdf");
}

// ---------- Word (.docx): isti vmesnik kot Pdf (h, p, bullets, stevilke, napis, table, flow, box, gap, img), vse urejljivo v Wordu ----------
// Oblika sledi PDF-ju (referenca): Arial, barve HiGiFood, naslovi z zeleno črto, tabele brez navpičnih črt z zeleno glavo in izmeničnimi
// vrsticami, naslovnica z zelenim pasom, pravo polje kazala s številkami strani iz PDF-ja, pravi seznami (numbering.xml), enotna noga.
const DX = { W: 9638, PG_W: 11906, PG_H: 16838, M: 1134, ZEL: "2F6F4F", SVETLA: "F1F6F2", CRTA: "B8C4BC", SIVA: "666666", TEMNA: "1D2420", RDECA: "B3261E" };
const DX_KV = /^(Podatek|Postavka)$/i; // tabele »ključ–vrednost«: prvi stolpec 30 %, sivo besedilo
class Docx {
  constructor(o) { this.o = Object.assign({ naslov: "Dokument", podnaslov: "", verzija: "1.0", datum: today(), stranka: "" }, o); this.b = []; this.imgs = []; this.toc = []; this.sezn = []; this.nFlow = 0; }
  r(t, o) {
    o = o || {}; const parts = String(t == null ? "" : t).split("\n");
    const rpr = `${o.b ? "<w:b/><w:bCs/>" : ""}${o.col ? `<w:color w:val="${o.col}"/>` : ""}${o.sz ? `<w:sz w:val="${o.sz}"/><w:szCs w:val="${o.sz}"/>` : ""}`;
    return parts.map((s, i) => `<w:r>${rpr ? `<w:rPr>${rpr}</w:rPr>` : ""}${i ? "<w:br/>" : ""}<w:t xml:space="preserve">${xe(s)}</w:t></w:r>`).join("");
  }
  ppr(o) {
    o = o || {}; const sp = [o.before !== undefined ? `w:before="${o.before}"` : "", o.after !== undefined ? `w:after="${o.after}"` : ""].filter(Boolean).join(" ");
    return `<w:pPr>${o.style ? `<w:pStyle w:val="${o.style}"/>` : ""}${o.keep ? "<w:keepNext/>" : ""}${o.brk ? "<w:pageBreakBefore/>" : ""}${o.num ? `<w:numPr><w:ilvl w:val="0"/><w:numId w:val="${o.num}"/></w:numPr>` : ""}${sp ? `<w:spacing ${sp}/>` : ""}${o.ind ? `<w:ind w:left="${o.ind}" w:hanging="${o.hang || 0}"/>` : ""}${o.jc ? `<w:jc w:val="${o.jc}"/>` : ""}</w:pPr>`;
  }
  para(t, o) { return `<w:p>${this.ppr(o)}${this.r(t, o)}</w:p>`; }
  h(level, s) { if (!(this.o && this.o.tocNivo && level > this.o.tocNivo)) this.toc.push({ level, s }); this.b.push(this.para(s, { style: "Heading" + Math.min(level, 3) })); }
  p(s, o) { o = o || {}; this.b.push(this.para(s, { b: o.bold, col: o.col === "m" ? DX.SIVA : o.col === "r" ? DX.RDECA : o.col === "g" ? DX.ZEL : "", sz: o.size ? Math.round(o.size * 2) : 0, after: o.gap === 1 ? 20 : undefined })); }
  // napis slike ali tabele: krepko, vedno na isti strani kot slika (keepNext)
  napis(s) { this.b.push(this.para(s, { style: "Napis" })); }
  gap() { this.b.push(this.para("", { after: 40 })); }
  imgXml(im, maxW, maxH) {
    let i = this.imgs.indexOf(im); if (i < 0) { i = this.imgs.length; this.imgs.push(im); }
    const mw = Math.min(maxW, DX.W / 20), sc = Math.min(mw / im.w, maxH / im.h, 1), cx = Math.round(im.w * sc * 12700), cy = Math.round(im.h * sc * 12700), id = i + 1;
    return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${id}" name="Slika ${id}"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${id}" name="slika${id}.jpg"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rIdImg${id}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;
  }
  // slika v polni ločljivosti, sredinsko, največ širina besedila; napis (če je) pod sliko kot doslej – tlorisi imajo napis nad sliko (napis())
  img(im, maxW, maxH, cap) { if (!im) return; this.b.push(`<w:p>${this.ppr({ jc: "center", after: 80, keep: !!cap })}${this.imgXml(im, maxW || 300, maxH || 220)}</w:p>`); if (cap) this.b.push(this.para(cap, { col: DX.SIVA, sz: 17, after: 160, jc: "center" })); }
  // alineje: pravi seznam (numbering.xml, numId 1)
  bullets(list) { for (const t of list) this.b.push(this.para(t, { style: "Seznam", num: 1 })); }
  // oštevilčeni koraki: oštevilčen seznam (decimal), vsak seznam začne pri svoji prvi številki
  stevilke(list) { if (!list.length) return; const z = +list[0].n || 1, id = 2 + this.sezn.length; this.sezn.push(z); for (const x of list) this.b.push(this.para(x.t, { style: "Seznam", num: id })); }
  cell(t, w, o) {
    o = o || {};
    return `<w:tc><w:tcPr><w:tcW w:w="${w}" w:type="dxa"/>${o.span ? `<w:gridSpan w:val="${o.span}"/>` : ""}${o.fill ? `<w:shd w:val="clear" w:color="auto" w:fill="${o.fill}"/>` : ""}${o.brez ? `<w:tcBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tcBorders>` : ""}${o.obroba ? `<w:tcBorders>${["top", "left", "bottom", "right"].map(s => `<w:${s} w:val="single" w:sz="4" w:space="0" w:color="${DX.CRTA}"/>`).join("")}</w:tcBorders>` : ""}${o.mar ? `<w:tcMar><w:top w:w="${o.mar}" w:type="dxa"/><w:left w:w="${o.mar}" w:type="dxa"/><w:bottom w:w="${o.mar}" w:type="dxa"/><w:right w:w="${o.mar}" w:type="dxa"/></w:tcMar>` : ""}${o.va ? `<w:vAlign w:val="${o.va}"/>` : ""}</w:tcPr>${o.xml !== undefined ? o.xml : this.para(t, { style: "Tabela", b: o.b, col: o.col, sz: o.sz, jc: o.jc })}</w:tc>`;
  }
  // tabela: samo vodoravne črte (insideH, bottom), brez navpičnih; fiksna postavitev čez širino besedila; odmiki celic 100/50
  tbl(rows, widths, o) {
    o = typeof o === "string" ? { borders: o } : o || {};
    const bd = o.borders || `<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="${DX.CRTA}"/><w:right w:val="nil"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="${DX.CRTA}"/><w:insideV w:val="nil"/></w:tblBorders>`;
    return `<w:tbl><w:tblPr>${o.plavajoca ? `<w:tblpPr w:leftFromText="0" w:rightFromText="0" w:topFromText="0" w:bottomFromText="0" w:vertAnchor="page" w:horzAnchor="page" w:tblpX="${o.plavajoca[0]}" w:tblpY="${o.plavajoca[1]}"/><w:tblOverlap w:val="overlap"/>` : ""}<w:tblW w:w="${widths.reduce((a, b) => a + b, 0)}" w:type="dxa"/>${o.ind !== undefined ? `<w:tblInd w:w="${o.ind}" w:type="dxa"/>` : ""}${bd}<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="50" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="50" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr><w:tblGrid>${widths.map(w => `<w:gridCol w:w="${w}"/>`).join("")}</w:tblGrid>${rows}</w:tbl>`;
  }
  table(glava, vrste, sirine, o) {
    o = o || {}; if (!vrste.length && !o.prazno) vrste = [["ni podatkov"].concat(Array(Math.max(0, glava.length - 1)).fill(""))];
    const kv = glava.length === 2 && DX_KV.test(String(glava[0]).trim());
    const raz = kv ? [30, 70] : sirine && sirine.length === glava.length ? sirine : glava.map(() => 1), sum = raz.reduce((a, b) => a + b, 0);
    const W = raz.map(x => Math.floor(x / sum * DX.W)); W[W.length - 1] += DX.W - W.reduce((a, b) => a + b, 0);
    // vrstica, višja od pol strani (ocena: širina besedila / širina stolpca), se sme deliti čez stran
    const pol = (DX.PG_H - 2 * DX.M) / 2, visina = r => Math.max(...glava.map((_, i) => String(r[i] == null ? "" : r[i]).split("\n").reduce((a, l) => a + Math.max(1, Math.ceil(l.length * 85 / Math.max(200, W[i] - 200))), 0))) * 200 + 100;
    const head = `<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>${glava.map((g, i) => this.cell(g, W[i], { fill: DX.ZEL, b: 1, col: "FFFFFF" })).join("")}</w:tr>`;
    const rows = vrste.map((r, ri) => `<w:tr>${visina(r) > pol ? "" : "<w:trPr><w:cantSplit/></w:trPr>"}${glava.map((_, i) => this.cell(r[i] == null ? "" : r[i], W[i], { fill: ri % 2 ? DX.SVETLA : "", col: kv && i === 0 ? DX.SIVA : "" })).join("")}</w:tr>`).join("");
    this.b.push(this.tbl(head + rows, W)); this.b.push(this.para("", { after: 80, sz: 8 }));
  }
  box(s, col) { this.b.push(this.tbl(`<w:tr><w:trPr><w:cantSplit/></w:trPr>${this.cell(s, DX.W, { fill: col === "r" ? "FDE8E6" : "FFF4D6", col: col === "r" ? DX.RDECA : "", mar: 120 })}</w:tr>`, [DX.W], { borders: '<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>' })); this.b.push(this.para("", { after: 80, sz: 8 })); }
  // urejljiv diagram: Wordove oblike (polja + puščice) v skupini
  shapes(items, W, H, label) {
    this.sid = this.sid || 100; const E = 9525, e = v => Math.round(v * E), WW = e(W), HH = e(H), hx = c => String(c || "000000").replace("#", "").toUpperCase(), sz = 18;
    const tx = (t, s, col, b) => `<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/></w:pPr><w:r><w:rPr>${b ? "<w:b/>" : ""}<w:color w:val="${col}"/><w:sz w:val="${s}"/><w:szCs w:val="${s}"/></w:rPr><w:t xml:space="preserve">${xe(t)}</w:t></w:r></w:p>`;
    const sp = items.map(i => { const id = ++this.sid;
      if (i.t === "rect") return `<wps:wsp><wps:cNvPr id="${id}" name="Polje ${id}"/><wps:cNvSpPr/><wps:spPr><a:xfrm><a:off x="${e(i.x)}" y="${e(i.y)}"/><a:ext cx="${e(i.w)}" cy="${e(i.h)}"/></a:xfrm><a:prstGeom prst="${i.oblika || "rect"}"><a:avLst/></a:prstGeom>${i.fill ? `<a:solidFill><a:srgbClr val="${hx(i.fill)}"/></a:solidFill>` : "<a:noFill/>"}${i.stroke ? `<a:ln w="${i.sw || 15240}"><a:solidFill><a:srgbClr val="${hx(i.stroke)}"/></a:solidFill></a:ln>` : "<a:ln><a:noFill/></a:ln>"}</wps:spPr><wps:txbx><w:txbxContent>${tx(i.text, i.sz || sz, i.col || DX.TEMNA, i.bold)}${i.sub ? tx(i.sub, 14, DX.RDECA, true) : ""}</w:txbxContent></wps:txbx><wps:bodyPr rot="0" vert="horz" wrap="square" lIns="36000" tIns="18000" rIns="36000" bIns="18000" anchor="ctr" anchorCtr="0"><a:noAutofit/></wps:bodyPr></wps:wsp>`;
      const x1 = e(i.x1), y1 = e(i.y1), x2 = e(i.x2), y2 = e(i.y2);
      return `<wps:wsp><wps:cNvPr id="${id}" name="Povezava ${id}"/><wps:cNvCnPr/><wps:spPr><a:xfrm><a:off x="${Math.min(x1, x2)}" y="${Math.min(y1, y2)}"/><a:ext cx="${Math.abs(x2 - x1)}" cy="${Math.abs(y2 - y1)}"/></a:xfrm><a:prstGeom prst="straightConnector1"><a:avLst/></a:prstGeom><a:ln w="12700"><a:solidFill><a:srgbClr val="${hx(i.c)}"/></a:solidFill><a:tailEnd type="triangle" w="med" len="med"/></a:ln></wps:spPr><wps:bodyPr/></wps:wsp>`; }).join("");
    const did = ++this.sid;
    return `<w:r><mc:AlternateContent><mc:Choice Requires="wpg"><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${WW}" cy="${HH}"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:docPr id="${did}" name="Diagram ${did}" descr="${xe(label || "Diagram poteka")}"/><wp:cNvGraphicFramePr/><a:graphic><a:graphicData uri="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"><wpg:wgp><wpg:cNvGrpSpPr/><wpg:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${WW}" cy="${HH}"/><a:chOff x="0" y="0"/><a:chExt cx="${WW}" cy="${HH}"/></a:xfrm></wpg:grpSpPr>${sp}</wpg:wgp></a:graphicData></a:graphic></wp:inline></w:drawing></mc:Choice><mc:Fallback><w:pict/></mc:Fallback></mc:AlternateContent></w:r>`;
  }
  // diagram poteka kot v PDF-ju (polja 330 pt, CCP rdeče z napisom); deli se samo tam, kjer se diagram v PDF-ju prelomi na novo stran
  flow(steps) {
    const k = this.nFlow++, prelomi = ((this.o._pdf && this.o._pdf.flow) || [])[k] || [], PX = 4 / 3; // pt → px (9525 EMU = 1 px)
    const bw = 330 * PX, W = Math.round(bw + 2 * 80), x0 = (W - bw) / 2, deli = []; let od = 0; // ob strani prostor za oznako (CCP1, OPRP2)
    for (const p of prelomi.filter(i => i > 0 && i < steps.length)) { deli.push(steps.slice(od, p).map((s, j) => [s, od + j])); od = p; }
    deli.push(steps.slice(od).map((s, j) => [s, od + j]));
    deli.forEach((part, di) => {
      const items = []; let y = 4;
      part.forEach(([st, gi], i) => {
        const txt = (st.n ? st.n + ". " : "") + st.t, vr = Math.max(1, Math.ceil(Array.from(txt).reduce((a, ch) => a + pdfW(ch, !!st.ccp, 9), 0) / (330 - 16))), h = (vr * 12 + 10 + (st.ccp ? 11 : 0)) * PX;
        items.push({ t: "rect", x: x0, y, w: bw, h, fill: "FFFFFF", stroke: st.ccp ? DX.RDECA : DX.ZEL, sw: st.ccp ? 19050 : 15240, text: txt, bold: !!st.ccp, sub: st.ccp ? "KRITIČNA KONTROLNA TOČKA (CCP)" : "" });
        if (st.tag) items.push({ t: "rect", x: x0 + bw + 4, y: y + h / 2 - 9, w: W - x0 - bw - 4, h: 18, text: st.tag, bold: true, sz: 16, col: st.ccp ? DX.RDECA : DX.SIVA });
        y += h; if (i < part.length - 1) { items.push({ t: "line", x1: W / 2, y1: y, x2: W / 2, y2: y + 14 * PX, c: DX.ZEL }); y += 14 * PX; }
      });
      this.b.push(`<w:p>${this.ppr({ jc: "center", before: 60, after: 60, brk: di > 0 })}${this.shapes(items, W, y + 4, "Diagram poteka")}</w:p>`);
      if (di < deli.length - 1) this.b.push(this.para("▼ nadaljevanje diagrama", { jc: "center", col: DX.ZEL, sz: 16, after: 0 }));
    });
    this.b.push(this.para("", { after: 120 }));
  }
  // naslovnica kot v PDF-ju: zeleni pas na vrhu strani, naslov, okvirja za podpis, podatki brez črt, opomba na dnu
  naslovnica() {
    const o = this.o, logo = o.logo === undefined ? LOGO.pdf || LOGO.im : o.logo, slogo = o.strankaLogo === undefined ? strankaLogoZa(o.stranka) : o.strankaLogo, ilogo = o.plain ? null : o.izdelalLogo !== undefined ? o.izdelalLogo : izdelovalecLogoZa(null);
    const brez = '<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders>', tw = v => Math.round(v * 20);
    const levo = this.para("HiGiFood", { b: 1, col: "FFFFFF", sz: 48, after: 0, before: 0 }) + this.para("HACCP dokumentacija", { col: "FFFFFF", sz: 22, after: 200 }) + (ilogo ? `<w:p>${this.ppr({ after: 0 })}${this.imgXml(ilogo, 140, 56)}</w:p>` : "");
    const desno = logo ? `<w:p>${this.ppr({ jc: "right", after: 0 })}${this.imgXml(logo, 150, 70)}</w:p>` : this.para("", {});
    const pas = this.tbl(`<w:tr><w:trPr><w:trHeight w:val="${tw(250)}" w:hRule="exact"/></w:trPr>${this.cell("", 7400, { fill: DX.ZEL, xml: levo, va: "top" })}${this.cell("", DX.PG_W - 7400, { fill: DX.ZEL, xml: desno, va: "top" })}</w:tr>`, [7400, DX.PG_W - 7400], { borders: brez, plavajoca: [0, 0] })
      .replace('<w:tblCellMar><w:top w:w="50" w:type="dxa"/><w:left w:w="100" w:type="dxa"/>', `<w:tblCellMar><w:top w:w="${tw(64)}" w:type="dxa"/><w:left w:w="${DX.M}" w:type="dxa"/>`).replace('<w:right w:w="100" w:type="dxa"/></w:tblCellMar>', `<w:right w:w="${DX.M + 200}" w:type="dxa"/></w:tblCellMar>`);
    // naslov (24 pt) in ime obrata (12 pt) pod pasom
    const naslov = this.para(o.naslov, { b: 1, sz: 48, col: DX.TEMNA, before: tw(12), after: 120 }) + (o.podnaslov ? this.para(o.podnaslov, { col: DX.SIVA, sz: 24, after: 0 }) : "");
    // okvirja za podpis (dva ločena, vmes prazen stolpec)
    let podpisi = "";
    if (o.podpisi && o.podpisi.length) {
      const n = o.podpisi.length, g = tw(14), bw = Math.floor((DX.W - g * (n - 1)) / n), sir = [], cel = [];
      o.podpisi.forEach((p, i) => {
        if (i) { sir.push(g); cel.push(this.cell("", g, { brez: 1 })); }
        sir.push(bw); cel.push(this.cell("", bw, { obroba: 1, mar: 160, xml: this.para(p.vloga, { b: 1, col: DX.SIVA, sz: 18, after: 60 }) + this.para(p.ime || "—", { b: 1, sz: 20, after: p.opis ? 20 : 120 }) + (p.opis ? this.para(p.opis, { col: DX.SIVA, sz: 16, after: 100 }) : "") + this.para("Datum: " + (p.datum ? fdate(p.datum) : "____________________"), { col: DX.SIVA, sz: 18, after: 60 }) + this.para(p.podpis_tekst || "Podpis: ____________________________", { col: p.podpis_tekst ? DX.ZEL : DX.SIVA, b: p.podpis_tekst ? 1 : 0, sz: 18, after: 0 }) }));
      });
      podpisi = this.tbl(`<w:tr><w:trPr><w:trHeight w:val="${tw(74)}"/></w:trPr>${cel.join("")}</w:tr>`, sir, { borders: brez, plavajoca: [DX.M, tw(841.89 - 306 - 74)] });
    }
    // podatki brez črt; »Izdelal« je ena celica z več vrsticami
    const izd = o.izdelal || izdelovalecVrstice(izdelovalecZa(null)), vrst = [["Podjetje", o.stranka], ["Različica", o.verzija], ["Datum", fdate(o.datum)], ["Izdelal", (izd && izd.length ? izd : [o.avtor || ""]).filter(Boolean).join("\n")], ["Stanje", o.stanje || "osnutek – potrebna strokovna potrditev"]].filter(r => r[1]);
    const kv = (slogo ? `<w:tr>${this.cell("", DX.W, { span: 2, xml: `<w:p>${this.ppr({ after: 120 })}${this.imgXml(slogo, 160, 70)}</w:p>` })}</w:tr>` : "") + vrst.map(r => `<w:tr>${this.cell(r[0], 1800, { b: 1, col: DX.SIVA, sz: 20 })}${this.cell(r[1], DX.W - 1800, { sz: 20 })}</w:tr>`).join("");
    const podatki = this.tbl(kv, [1800, DX.W - 1800], { borders: brez, plavajoca: [DX.M, tw(841.89 - 212 - 12 - (slogo ? 84 : 0))] });
    const opomba = this.tbl(`<w:tr>${this.cell("Dokument je pripravljen s pomočjo orodja in ne pomeni uradne odobritve ali samodejne skladnosti z zakonodajo. Urejate ga lahko v Wordu.", DX.W, { col: DX.SIVA, sz: 16 })}</w:tr>`, [DX.W], { borders: brez, plavajoca: [DX.M, tw(841.89 - 72)] });
    // neviden prvi odstavek: dokument, ki se začne s tabelo, v LibreOffice izgubi besedilo v poljih diagrama
    const zacetek = '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/><w:rPr><w:sz w:val="2"/></w:rPr></w:pPr></w:p>';
    return zacetek + pas + podpisi + podatki + opomba + naslov + `<w:p><w:r><w:br w:type="page"/></w:r></w:p>`;
  }
  // kazalo: pravo polje TOC; vnaprej vpisane številke strani iz PDF-ja (enaka postavitev), Word ga ob odprtju osveži
  kazalo() {
    const nivo = Math.max(1, Math.min(3, this.o.tocNivo || 2)), strani = (this.o._pdf && this.o._pdf.toc) || [], E = this.toc.filter(t => t.level <= nivo);
    const zac = `<w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \\o "1-${nivo}" \\h \\z \\u </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r>`, kon = '<w:r><w:fldChar w:fldCharType="end"/></w:r>';
    const vr = E.map((t, i) => `<w:p>${this.ppr({ style: "TOC" + Math.min(3, t.level) })}${i === 0 ? zac : ""}${this.r(t.s)}<w:r><w:tab/></w:r>${this.r(strani[this.toc.indexOf(t)] !== undefined ? String(strani[this.toc.indexOf(t)]) : "")}${i === E.length - 1 ? kon : ""}</w:p>`);
    return this.para("Kazalo", { style: "KazaloNaslov" }) + (vr.length ? vr.join("") : `<w:p>${zac}${kon}</w:p>`) + `<w:p><w:r><w:br w:type="page"/></w:r></w:p>`;
  }
  build() {
    const o = this.o, NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup" xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"';
    const zacetek = o.plain ? "" : this.naslovnica() + this.kazalo();
    const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${NS}><w:body>${zacetek}${this.b.join("")}<w:sectPr><w:footerReference w:type="default" r:id="rId3"/>${o.plain ? "" : '<w:footerReference w:type="first" r:id="rId6"/>'}<w:pgSz w:w="${DX.PG_W}" w:h="${DX.PG_H}"/><w:pgMar w:top="${DX.M}" w:right="${DX.M}" w:bottom="${DX.M}" w:left="${DX.M}" w:header="567" w:footer="567" w:gutter="0"/>${o.plain ? "" : "<w:titlePg/>"}</w:sectPr></w:body></w:document>`;
    const A = '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"/>';
    const H = (id, ime, sz, pred, za, crta, nivo) => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${ime}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="9"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/>${crta ? `<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="4" w:color="${DX.ZEL}"/></w:pBdr>` : ""}<w:spacing w:before="${pred}" w:after="${za}"/>${nivo !== undefined ? `<w:outlineLvl w:val="${nivo}"/>` : ""}</w:pPr><w:rPr>${A}<w:b/><w:bCs/><w:color w:val="${DX.ZEL}"/><w:sz w:val="${sz}"/><w:szCs w:val="${sz}"/></w:rPr></w:style>`;
    const TOC = (n, b, ind) => `<w:style w:type="paragraph" w:styleId="TOC${n}"><w:name w:val="toc ${n}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="39"/><w:pPr><w:tabs><w:tab w:val="right" w:leader="dot" w:pos="${DX.W}"/></w:tabs><w:spacing w:before="0" w:after="60"/>${ind ? `<w:ind w:left="${ind}"/>` : ""}</w:pPr><w:rPr>${A}${b ? "<w:b/><w:bCs/>" : ""}<w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>`;
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr>${A}<w:color w:val="${DX.TEMNA}"/><w:sz w:val="19"/><w:szCs w:val="19"/><w:lang w:val="sl-SI" w:eastAsia="sl-SI" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:widowControl/><w:spacing w:after="80" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>` +
      `<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/><w:pPr><w:widowControl/><w:spacing w:after="80" w:line="276" w:lineRule="auto"/></w:pPr><w:rPr>${A}<w:sz w:val="19"/><w:szCs w:val="19"/><w:lang w:val="sl-SI"/></w:rPr></w:style>` +
      H("Heading1", "heading 1", 32, 360, 120, true, 0) + H("Heading2", "heading 2", 24, 240, 80, false, 1) + H("Heading3", "heading 3", 21, 200, 60, false, 2) + H("KazaloNaslov", "Kazalo – naslov", 32, 0, 240, false) +
      `<w:style w:type="paragraph" w:styleId="Napis"><w:name w:val="caption"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="120" w:after="80"/></w:pPr><w:rPr>${A}<w:b/><w:bCs/><w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="Tabela"><w:name w:val="Tabela – besedilo"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr>${A}<w:sz w:val="17"/><w:szCs w:val="17"/></w:rPr></w:style>` +
      `<w:style w:type="paragraph" w:styleId="Seznam"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:uiPriority w:val="34"/><w:qFormat/><w:pPr><w:spacing w:after="40"/><w:contextualSpacing/></w:pPr></w:style>` +
      TOC(1, true, 0) + TOC(2, false, 280) + TOC(3, false, 560) +
      `<w:style w:type="paragraph" w:styleId="Noga"><w:name w:val="footer"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr><w:rPr>${A}<w:color w:val="${DX.SIVA}"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr></w:style></w:styles>`;
    // seznami: 1 = alineje (•), 2… = oštevilčeni koraki (vsak seznam svoj začetek)
    const lvl = (fmt, txt, font) => `<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="${fmt}"/><w:lvlText w:val="${txt}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="360" w:hanging="240"/></w:pPr><w:rPr>${font}</w:rPr></w:lvl>`;
    const numbering = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="singleLevel"/>${lvl("bullet", "•", A)}</w:abstractNum><w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="singleLevel"/>${lvl("decimal", "%1.", A)}</w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>${this.sezn.map((z, i) => `<w:num w:numId="${2 + i}"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="${z}"/></w:lvlOverride></w:num>`).join("")}</w:numbering>`;
    // noga: vsi teksti, tudi polji PAGE in NUMPAGES ter » / «, Arial 8 pt #666666
    const t = znamka(`${o.stranka || "HiGiFood HACCP"} | ${o.naslov.slice(0, 60)} | v${o.verzija} | ${fdate(o.datum)}`), izN = o.plain ? "" : o.izdelalNoga !== undefined ? o.izdelalNoga : izdelovalecNoga(izdelovalecZa(null)), t2 = izN ? "Izdelal: " + znamka(izN) : "";
    const RP = `<w:rPr>${A}<w:color w:val="${DX.SIVA}"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr>`, run = s => `<w:r>${RP}<w:t xml:space="preserve">${xe(s)}</w:t></w:r>`;
    const fld = i => `<w:r>${RP}<w:fldChar w:fldCharType="begin"/></w:r><w:r>${RP}<w:instrText xml:space="preserve"> ${i} </w:instrText></w:r><w:r>${RP}<w:fldChar w:fldCharType="separate"/></w:r><w:r>${RP}<w:t>1</w:t></w:r><w:r>${RP}<w:fldChar w:fldCharType="end"/></w:r>`;
    const footer = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr ${NS}><w:p><w:pPr><w:pStyle w:val="Noga"/><w:pBdr><w:top w:val="single" w:sz="4" w:space="4" w:color="${DX.CRTA}"/></w:pBdr><w:tabs><w:tab w:val="right" w:pos="${DX.W}"/></w:tabs></w:pPr>${run(t)}<w:r>${RP}<w:tab/></w:r>${run("Stran ")}${fld("PAGE")}${run(" / ")}${fld("NUMPAGES")}</w:p>${t2 ? `<w:p><w:pPr><w:pStyle w:val="Noga"/></w:pPr>${run(t2)}</w:p>` : ""}</w:ftr>`;
    const footerPrva = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr ${NS}><w:p><w:pPr><w:pStyle w:val="Noga"/></w:pPr></w:p></w:ftr>`;
    const avtor = (o.izdelal && o.izdelal[0]) || o.avtor || "HiGiFood", zdaj = new Date().toISOString().replace(/\.\d+Z$/, "Z");
    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xe(o.naslov)}</dc:title><dc:subject>${xe(o.podnaslov || "")}</dc:subject><dc:creator>${xe(avtor)}</dc:creator><cp:lastModifiedBy>${xe(avtor)}</cp:lastModifiedBy><cp:version>${xe(o.verzija)}</cp:version><dc:language>sl-SI</dc:language><dcterms:created xsi:type="dcterms:W3CDTF">${zdaj}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${zdaj}</dcterms:modified></cp:coreProperties>`;
    const app = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>HiGiFood</Application><Company>HiGiFood</Company><DocSecurity>0</DocSecurity></Properties>`;
    const fonts = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:fonts xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:font w:name="Arial"><w:panose1 w:val="020B0604020202020204"/><w:charset w:val="EE"/><w:family w:val="swiss"/><w:pitch w:val="variable"/></w:font></w:fonts>`;
    const R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships", X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', CT = "application/vnd.openxmlformats-officedocument";
    const files = [
      ["[Content_Types].xml", `${X}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/><Override PartName="/word/document.xml" ContentType="${CT}.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="${CT}.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="${CT}.wordprocessingml.settings+xml"/><Override PartName="/word/numbering.xml" ContentType="${CT}.wordprocessingml.numbering+xml"/><Override PartName="/word/fontTable.xml" ContentType="${CT}.wordprocessingml.fontTable+xml"/><Override PartName="/word/footer1.xml" ContentType="${CT}.wordprocessingml.footer+xml"/><Override PartName="/word/footer2.xml" ContentType="${CT}.wordprocessingml.footer+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="${CT}.extended-properties+xml"/></Types>`],
      ["_rels/.rels", `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${R}/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="${R}/extended-properties" Target="docProps/app.xml"/></Relationships>`],
      ["word/_rels/document.xml.rels", `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${R}/styles" Target="styles.xml"/><Relationship Id="rId2" Type="${R}/settings" Target="settings.xml"/><Relationship Id="rId3" Type="${R}/footer" Target="footer1.xml"/><Relationship Id="rId4" Type="${R}/numbering" Target="numbering.xml"/><Relationship Id="rId5" Type="${R}/fontTable" Target="fontTable.xml"/><Relationship Id="rId6" Type="${R}/footer" Target="footer2.xml"/>${this.imgs.map((_, i) => `<Relationship Id="rIdImg${i + 1}" Type="${R}/image" Target="media/slika${i + 1}.jpg"/>`).join("")}</Relationships>`],
      ["word/settings.xml", `${X}<w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:updateFields w:val="true"/><w:defaultTabStop w:val="709"/><w:characterSpacingControl w:val="doNotCompress"/><w:themeFontLang w:val="sl-SI"/><w:decimalSymbol w:val=","/><w:listSeparator w:val=";"/></w:settings>`],
      ["word/styles.xml", styles], ["word/numbering.xml", numbering], ["word/fontTable.xml", fonts], ["word/footer1.xml", footer], ["word/footer2.xml", footerPrva], ["word/document.xml", doc],
      ["docProps/core.xml", core], ["docProps/app.xml", app],
    ].map(([name, s]) => ({ name, data: utf8(s) })).concat(this.imgs.map((im, i) => ({ name: `word/media/slika${i + 1}.jpg`, data: im.u8 })));
    const z = zipStoreU8(files); return new Blob([z], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
  }
}
// Word: najprej se isti dokument postavi kot PDF (številke strani kazala, prelomi diagrama), nato se zgradi .docx
function docxBuild(meta, fill) {
  let pdf = null;
  try { let tp = 1, doc; for (let k = 0; k < 3; k++) { doc = new Pdf(Object.assign({}, meta, { offset: 1 + tp })); fill(doc); const need = Math.max(1, doc.tocStrani().length); if (need === tp) break; tp = need; } pdf = { toc: doc.toc.map(e => e.page), flow: doc.flowPrelomi || [] }; } catch {}
  const d = new Docx(Object.assign({}, meta, { _pdf: pdf })); fill(d); return d.build();
}


// ---------- slike: nalaganje, pretvorba v JPEG (za PDF in Word), logotip ----------
const LOGO = { im: null };
async function loadImg(url, maxPx, bg) {
  try {
    const r = await fetch(url); if (!r.ok || r.status === 204) return null;
    const bmp = await createImageBitmap(await r.blob());
    const sc = Math.min(1, (maxPx || 1400) / Math.max(bmp.width, bmp.height)), w = Math.max(1, Math.round(bmp.width * sc)), h = Math.max(1, Math.round(bmp.height * sc));
    const c = document.createElement("canvas"); c.width = w; c.height = h; const g = c.getContext("2d"); g.fillStyle = bg || "#fff"; g.fillRect(0, 0, w, h); g.drawImage(bmp, 0, 0, w, h);
    const blob = await new Promise(ok => c.toBlob(ok, "image/jpeg", 0.85));
    return { u8: new Uint8Array(await blob.arrayBuffer()), w, h };
  } catch { return null; }
}
// logotip stranke (predpomnjen po id); dokumenti ga uporabijo, če se naziv stranke ujema
const SLOGO = {};
async function loadStrankaLogo(s, force) { if (!s || !s.id) return null; if (force || !SLOGO[s.id]) SLOGO[s.id] = { naziv: s.naziv, im: await loadImg("/api/stranka-logo/" + s.id + "?t=" + Date.now(), 600) }; else SLOGO[s.id].naziv = s.naziv; return SLOGO[s.id].im; }
const strankaLogoZa = naziv => { if (!naziv) return null; const e = Object.values(SLOGO).find(x => x.naziv === naziv && x.im); return e ? e.im : null; };
async function navStrankaLogo() {
  const b = $("#stlogo"); if (!b) return; b.hidden = true; b.innerHTML = "";
  const sid = ME.u && ME.u.stranka_id; if (!sid) return;
  try { const r = await fetch("/api/stranka-logo/" + sid + "?t=" + Date.now()); if (r.status !== 200) return; const u = URL.createObjectURL(await r.blob()); b.innerHTML = `<img src="${u}" alt="Logotip podjetja">`; b.hidden = false; } catch {}
}
// lasten logotip (z belim okvirjem) ali privzeti logotip HiGiFood brez ozadja: za PDF na zeleni pasici, za Word na beli strani
async function loadLogo() {
  const own = await loadImg("/api/logo?t=" + Date.now(), 600);
  if (own) Object.assign(LOGO, { im: own, pdf: null, privzeti: false });
  else Object.assign(LOGO, { im: await loadImg("/logo-svetlo.png", 600), pdf: await loadImg("/logo-temno.png", 600, "rgb(47,111,79)"), privzeti: true });
}
