// HACCP dokument: izbira navodil po ključu teme, čiščenje besedila navodil in preverjanje pred izpisom.
// Pravila: vsak protokol (ključ teme) se izpiše samo enkrat, prilagojen protokol ima prednost pred splošno predlogo;
// besedilo za izpolnjevalca ni končno besedilo; dokler je kaj odprto, ostane dokument v stanju OSNUTEK.

// ključ teme navodila: ključ predloge iz knjižnice (npr. ciscenje, voda, hlajenje) ali ročno izbran ključ;
// pri lastnem navodilu brez ključa se tema prepozna iz naslova
const TEME_NASLOV = [[/osebn\w* higien|zdravstven\w* stanj/i, "osebna_higiena"], [/čiščen|razkuž/i, "ciscenje"], [/prevzem/i, "prevzem"], [/skladišč/i, "skladiscenje"], [/temperatur|hladiln|zamrzoval|vroč\w* verig/i, "temperature"], [/navzkrižn/i, "navzkrizno"], [/alergen/i, "alergeni"], [/odpad/i, "odpadki"], [/škodljiv|\bddd\b|deratiz/i, "ddd"], [/\bvod[aei]\b|pitn/i, "voda"], [/vzdrževan/i, "vzdrzevanje"], [/merilni|umerjan|kalibr/i, "merilni_instrumenti"], [/sledljiv/i, "sledljivost"], [/odpoklic|umik/i, "odpoklic"], [/reklamac/i, "reklamacije"], [/usposablj/i, "usposabljanje"], [/notranj\w* kontrol|interni pregled/i, "notranja_kontrola"], [/pregled\w* dokumentac/i, "pregled_dokumentacije"], [/hlajenj/i, "hlajenje"], [/toplotn\w* obdelav|kuhanj|pečenj/i, "toplotna_obdelava"], [/ohranjan\w* toplot|vroč\w* drža|regeneracij/i, "ohranjanje_toplote"], [/bris|hitri test|vzorčen/i, "vzorcenje"], [/čistil|kemikal/i, "kemikalije"], [/cvrt|friter|olj\w* za cvrt/i, "cvrtje"]];
// ključi tem za izbiro v obrazcu navodila (lastno navodilo z istim ključem nadomesti predlogo)
const TEME_KLJUCI = [["osebna_higiena", "Osebna higiena"], ["ciscenje", "Čiščenje in razkuževanje"], ["prevzem", "Prevzem blaga"], ["skladiscenje", "Skladiščenje"], ["temperature", "Temperature"], ["navzkrizno", "Navzkrižna kontaminacija"], ["alergeni", "Alergeni"], ["odpadki", "Odpadki"], ["ddd", "Škodljivci (DDD)"], ["voda", "Pitna voda"], ["vzdrzevanje", "Vzdrževanje"], ["merilni_instrumenti", "Merilni instrumenti"], ["sledljivost", "Sledljivost"], ["odpoklic", "Umik in odpoklic"], ["reklamacije", "Reklamacije"], ["usposabljanje", "Usposabljanje"], ["notranja_kontrola", "Notranja kontrola"], ["pregled_dokumentacije", "Pregled dokumentacije"], ["hlajenje", "Hlajenje"], ["toplotna_obdelava", "Toplotna obdelava"], ["ohranjanje_toplote", "Ohranjanje toplote in regeneracija"], ["vzorcenje", "Brisi in hitri testi"], ["kemikalije", "Čistila in razkužila"], ["cvrtje", "Cvrtje in olje"]];
// teme navodila (seznam): izbrane teme (n.teme), starejša ena tema (n.tema) ali ključ predloge; pri lastnem navodilu brez izbrane teme
// se teme predlagajo iz naslova (vse ujemajoče se, ne le prva) – to je predlog, ki ga uporabnik potrdi v obrazcu navodila
function temeNavodila(n) {
  if (Array.isArray(n.teme) && n.teme.length) return n.teme.slice();
  if (n.tema) return [n.tema];
  if (n.predloga) return [n.predloga];
  const t = TEME_NASLOV.filter(([re]) => re.test(n.naslov || "")).map(x => x[1]);
  return t.length ? [...new Set(t)] : ["lastno:" + String(n.naslov || n.id || "").trim().toLowerCase()];
}
const temePredlog = n => !(Array.isArray(n.teme) && n.teme.length) && !n.tema && !n.predloga; // teme le predlagane iz naslova
function temaNavodila(n) { return temeNavodila(n)[0]; } // združljivost: prva tema
// prilagojen protokol: lastno navodilo, potrjeno navodilo ali navodilo z urejeno vsebino (ni le nespremenjena kopija predloge)
const navPrilagojeno = n => !n.predloga || n.status === "potrjeno" || (n.revizije || []).some(r => r.prej && "vsebina" in r.prej);
function izberiNavodila(navodila) {
  const skupine = new Map(), porocilo = [];
  for (const n of navodila || []) { if (n.status === "zastarelo") continue; for (const k of temeNavodila(n)) { if (!skupine.has(k)) skupine.set(k, []); skupine.get(k).push(n); } }
  const ocena = n => (n.status === "potrjeno" ? 4 : 0) + (navPrilagojeno(n) ? 2 : 0) + (temeNavodila(n).length > 1 ? 1 : 0);
  const izbrana = [], poId = new Map();
  for (const [k, l] of skupine) {
    const ur = l.slice().sort((a, b) => ocena(b) - ocena(a) || String(b.spremenjeno || b.ustvarjeno || "").localeCompare(String(a.spremenjeno || a.ustvarjeno || "")));
    // navodilo z več temami se izpiše enkrat (pri vseh temah, kjer je izbrano)
    if (poId.has(ur[0].id)) poId.get(ur[0].id)._teme.push(k); else { const x = Object.assign({}, ur[0], { _tema: k, _teme: [k] }); poId.set(ur[0].id, x); izbrana.push(x); }
    const prilagojena = ur.filter(navPrilagojeno);
    if (prilagojena.length > 1) porocilo.push({ tip: "odprto", txt: `Tema »${k}«: več prilagojenih navodil (${prilagojena.map(n => "»" + n.naslov + "«").join(", ")}) – izpisano je »${ur[0].naslov}«; razlike razrešite in odvečna navodila označite kot zastarela.` });
    else if (ur.length > 1) porocilo.push({ tip: "info", txt: `Tema »${k}«: splošna predloga ni izpisana, ker obstaja »${ur[0].naslov}«.` });
  }
  return { izbrana, porocilo };
}
// besedilo za izpolnjevalca (navodilo za uporabnika predloge), ki se ne sme izpisati kot končno besedilo
// - meje besed z lookaround in zastavico u (\b ne deluje s šumniki), »DOLOČITI« samo z velikimi črkami (»določiti« je navadna beseda);
// - »[MANJKA]« le kot samostojna oznaka »[MANJKA: …]« / »[MANJKA – …]« ali sama v vrstici, ne kadar je omenjena v stavku
const IZP_CI = /(?<!\p{L})(?:ugotovite vir|nastavite v sistemu|določite|vpišite|dopolnite)(?!\p{L})|_{3,}/iu;
const IZP_CS = /(?<!\p{L})(?:DOLOČITI|TODO)(?!\p{L})|\[MANJKA\s*(?::|–|-)[^\]]*\]|^\s*(?:\d+\.\s*)?\[MANJKA\]\s*$/u;
const IZPOLNJEVALEC = { test: t => IZP_CI.test(String(t)) || IZP_CS.test(String(t)) };
// čisto besedilo navodila za dokument: brez naslova, podjetja, različice predloge, pravne podlage in OPOMBE (to so podatki, ne vsebina)
function cistiNavodilo(n) {
  const out = [], odprto = []; let pravna = false;
  const L = String(n.vsebina || "").split("\n");
  L.forEach((l, i) => {
    const t = l.trim();
    if (i === 0 && t === String(n.naslov || "").trim()) return;
    if (/^(Podjetje|Različica predloge)\s*:/i.test(t)) return;
    if (/^\d+\.\s*PRAVNA/i.test(t) || /^pravna (in strokovna )?podlaga/i.test(t)) { pravna = true; return; }
    if (pravna) { if (!t) { pravna = false; return; } if (/^\d+\.\s+[A-ZČŠŽ ]{4,}$/.test(t)) pravna = false; else return; }
    if (/^OPOMBA\s*:/i.test(t)) return;
    l = l.replace(/\s*\(KT\s?\d+\)|\bKT\s?\d+\s*[:–-]\s*/g, ""); // interne oznake kontrolnih točk (KT) se ne izpišejo
    if (t && IZPOLNJEVALEC.test(t)) { odprto.push(t.slice(0, 120)); out.push((/^\d+\.\s/.test(t) ? t.match(/^\d+\.\s/)[0] : "") + "[MANJKA – dopolnite po dejanskem stanju v obratu]"); return; }
    out.push(l);
  });
  while (out.length && !out[out.length - 1].trim()) out.pop();
  return { vrstice: out, odprto };
}
// del navodila, ki se nanaša na temo: razdelki z naslovom teme (brez naslovov, ki združujejo tudi druge teme), sicer stavki s ključno besedo
const TEMA_KLJUC = { hlajenje: { re: /hlaj/i, ne: /toplotn|kuhan|pečen|ohranj|pogrev|regener|cvr/i }, cvrtje: { re: /cvr|friter|olj\w* za cvr/i, ne: /hlaj|toplotn|kuhan/i } };
// naslov razdelka v navodilu: »## …«, oštevilčen naslov brez končnega ločila ali vrstica z velikimi črkami
const jeNaslovRazdelka = l => { const s = String(l).trim(); return s.length > 0 && s.length <= 90 && (/^#{1,3}\s/.test(s) || (/^\d+(\.\d+)*\.?\s+\S/.test(s) && !/[.!?]$/.test(s)) || (s === s.toLocaleUpperCase("sl") && /\p{Lu}{3}/u.test(s))); };
// razdelki navodila (za »Razdeli navodilo«): [{ h, i0 (vrstica naslova), i1 (konec, izključno) }]
function razdelkiNavodila(n) {
  const L = String(n.vsebina || "").split("\n"), out = [];
  L.forEach((l, i) => { if (i === 0 && l.trim() === String(n.naslov || "").trim()) return; if (jeNaslovRazdelka(l)) { if (out.length) out[out.length - 1].i1 = i; out.push({ h: l.trim(), i0: i, i1: L.length }); } });
  return out.filter(r => L.slice(r.i0 + 1, r.i1).some(x => x.trim()));
}
function besediloTeme(n, tema) {
  const p = TEMA_KLJUC[tema]; if (!p) return "";
  const L = String(n.vsebina || "").split("\n"); if (L.length && L[0].trim() === String(n.naslov || "").trim()) L.shift();
  const jeNaslov = jeNaslovRazdelka;
  const deli = []; let cur = null;
  for (const l of L) { if (jeNaslov(l)) { cur = { h: l, t: [] }; deli.push(cur); } else if (cur) cur.t.push(l); }
  const raz = deli.filter(d => p.re.test(d.h) && !p.ne.test(d.h));
  if (raz.length) return raz.map(d => d.t.join("\n")).join("\n");
  return L.join("\n").split(/(?<=[.!?])\s+|\n+|;\s*/).filter(s => p.re.test(s)).join("\n");
}
// prvi stavek namena navodila (za poglavje Predpogojni programi)
function namenNavodila(n, db) {
  const p = (db.navodila_predloge || []).find(x => x.id === n.predloga), L = String(n.vsebina || "").split("\n"), i = L.findIndex(l => /^\s*1\.\s*NAMEN/i.test(l));
  const t = (i >= 0 ? L.slice(i + 1).find(l => l.trim()) : "") || (p && p.namen) || "";
  const s = String(t).trim().replace(/\s+/g, " "), m = /^(.{20,220}?[.!?])(\s|$)/.exec(s);
  return m ? m[1] : s.slice(0, 200);
}

// preverjanje pred izpisom: seznam odprtih vprašanj (dokument ostane OSNUTEK) in strokovnih opozoril (brez samodejnih zaključkov)
// x: { rec, W, stranka, ob, navodila (izbrana), db, oz (oznake CCP/OPRP), besedila (izpisana besedila poglavij), poglavja (id → številka) }
function preveriNacrt(x) {
  const { rec, W, navodila, db, oz } = x, out = [], odp = t => out.push({ tip: "odprto", txt: t }), opo = t => out.push({ tip: "opozorilo", txt: t });
  const korak = id => (W.koraki.find(k => k.id === id) || {}).naziv || "–", ozn = h => oz[h.id] || (W.kontrole[h.id] || {}).vrsta || "";
  // potrditev
  const po = potrditevNacrta(rec, W);
  if (po.prihodnost) odp(`Datum potrditve (${fdate(po.datum)}) je v prihodnosti – potrditev ni opravljena.`);
  if (rec.status === "potrjeno" && !po.potrdil) odp("Načrt je označen kot potrjen, potrjevalec ni vpisan.");
  // alergeni
  const nepAlg = W.zivila.filter(z => !z.alergeni || /preverit|\?|neznan/i.test(z.alergeni) || z.alergeni_potrjeni !== true); // potrditev v čarovniku (Podrobnosti živila)
  if (nepAlg.length) odp("Nepotrjeni alergeni pri živilih: " + nepAlg.map(z => z.naziv).filter(Boolean).join(", ") + ".");
  // nevarnosti in ukrepi
  const brezVrste = W.nevarnosti.filter(h => hazStatus(h) === "potrjeno" && !(W.kontrole[h.id] || {}).vrsta);
  if (brezVrste.length) odp(`${brezVrste.length} potrjenih nevarnosti nima vrste ukrepa (npr. ${korak(brezVrste[0].korak_id)}: ${brezVrste[0].nevarnost}).`);
  const kont = W.nevarnosti.filter(h => ["CCP", "OPRP"].includes((W.kontrole[h.id] || {}).vrsta)).map(h => [h, W.kontrole[h.id]]);
  for (const [h, c] of kont) {
    const n = ozn(h);
    if (!c.mejna) odp(`${n} (${korak(h.korak_id)}): mejna vrednost ni določena.`);
    else if (!c.mejna_vir && !c.mejna_vir_predpis) odp(`${n} (${korak(h.korak_id)}): meja »${c.mejna}« nima utemeljitve (vir meje).`);
    if (!c.evidenca) odp(`${n} (${korak(h.korak_id)}): ni povezane evidence.`);
    if (!c.verifikacija) odp(`${n} (${korak(h.korak_id)}): ni plana verifikacije.`);
    if (c.mejna) {
      if (/[>≥]\s*-?\d+([.,]\d+)?\s*(°C)?\s*do\s/i.test(c.mejna)) odp(`${n}: neveljaven zapis meje »${c.mejna}« (npr. »>4 do 6 °C«) – navedite en razpon ali eno mejo.`);
      if (/>\s*-\s*\d/.test(c.mejna)) odp(`${n}: zapis »${c.mejna}« pomeni topleje od meje (npr. »>-18 °C«); za zamrzovanje uporabite »≤ -18 °C«.`);
      if (/\d+\s*do\s*\d+\s*(ur|h\b|min|dni)/i.test(c.mejna)) odp(`${n}: razpon »${c.mejna}« ni enolična meja – določite eno vrednost.`);
      if (/olj|cvr|friter/i.test(korak(h.korak_id) + " " + c.kaj + " " + h.nevarnost)) { const t = (/(\d{3})\s*°C/.exec(c.mejna) || [])[1]; if (t && +t > 175) odp(`${n}: temperatura olja ${t} °C presega priporočenih 175 °C (Uredba (EU) 2017/2158, akrilamid).`); }
    }
  }
  // en vir podatkov: številke v opisu ukrepa in korektivnih ukrepih morajo ustrezati mejni vrednosti, pogostost v opisu polju Pogostost
  for (const [h, c] of kont) {
    const n = ozn(h), mj = vrednostiEnot(c.mejna);
    for (const [polje, t] of [["opis ukrepa", c.ukrep], ["korektivni ukrepi", c.korektivni]]) { const vs = vrednostiEnot(t).filter(x => mj.some(m => m.e === x.e) && !mj.some(m => m.e === x.e && m.v === x.v)); if (vs.length) odp(`${n} (${korak(h.korak_id)}): ${polje} navaja ${[...new Set(vs.map(x => x.v + " " + x.e))].join(", ")}, mejna vrednost je »${c.mejna}« – uskladite.`); }
    const fp = pogostostNaDan(c.pogostost), fu = pogostostNaDan(c.ukrep); if (fp && fu && fp !== fu) odp(`${n} (${korak(h.korak_id)}): pogostost »${c.pogostost}« (${fp}× dnevno), opis ukrepa pa ${fu}× dnevno – uskladite.`);
  }
  // alergeni, ki jih sestava pogosto vsebuje, niso označeni (sulfiti: vino, kis, suho sadje; zelena: jušne osnove, začimbne mešanice)
  for (const z of W.zivila) { const t = [z.naziv, z.sestava, z.priprava].join(" ").toLowerCase(), a = String(z.alergeni || "").toLowerCase();
    if (/(?<!\p{L})(vin(o|a|u|om|ski\p{L}*)|kis(a|om)?|suh\p{L}* sadj\p{L}*|rozin\p{L}*|suh\p{L}* (marelic|sliv|smokv)\p{L}*)(?!\p{L})/u.test(t) && !/sulfit|žvepl/.test(a)) odp(`Živilo »${z.naziv}« omenja vino, kis ali suho sadje – alergen »Žveplov dioksid/sulfiti« ni označen (preverite).`);
    if (/jušn\p{L}* osnov|bujon|(?<!\p{L})fond(?!\p{L})|začimbn\p{L}* mešanic|vegeta/u.test(t) && !/zelen/.test(a)) odp(`Živilo »${z.naziv}« omenja jušno osnovo ali začimbno mešanico – alergen »Zelena« ni označen (preverite).`); }
  const oprp = kont.filter(([, c]) => c.vrsta === "OPRP").length; if (oprp > 8) opo(`Določenih je ${oprp} OPRP (več kot 8) – preverite, ali so vsi res potrebni.`);
  const ocenjene = W.nevarnosti.filter(h => rizik(h)); if (ocenjene.length && !ocenjene.some(h => rizik(h) <= W.metoda.nizko_do) && !W.metoda.nizke_izpuscene) opo("Nobena nevarnost ni ocenjena kot nizka – preverite oceno tveganja (ali v koraku 4 označite, da so nizka tveganja namerno izpuščena).");
  // protislovja: hlajenje
  const hl = kont.filter(([h, c]) => /hlaj/i.test(korak(h.korak_id) + " " + (c.kaj || ""))).map(([, c]) => c.mejna).filter(Boolean);
  if (new Set(hl.map(m => (/(\d+(?:[.,]\d+)?)\s*(ur|h\b|min)/i.exec(m) || [])[0]).filter(Boolean)).size > 1) odp("Protislovje: različni časi hlajenja (" + hl.join("; ") + ").");
  // navodila: besedilo za izpolnjevalca, predpisi
  for (const n of navodila) {
    const c = cistiNavodilo(n); if (c.odprto.length) odp(`Navodilo »${n.naslov}«: nedokončano besedilo (${c.odprto.slice(0, 2).map(t => "»" + t.slice(0, 50) + "«").join(", ")}${c.odprto.length > 2 ? " …" : ""}).`);
    const w = typeof navodiloOpozorila === "function" ? navodiloOpozorila(n, db) : []; if (w.length) odp(`Navodilo »${n.naslov}«: ${w.join("; ")}.`);
  }
  // besedila poglavij: oznake [MANJKA] in besedilo za izpolnjevalca
  for (const [id, t] of Object.entries(x.besedila || {})) { const m = String(t || "").split("\n").filter(l => IZPOLNJEVALEC.test(l)); if (m.length) odp(`Poglavje ${(x.poglavja || {})[id] || id}: manjkajoči podatki (${m.slice(0, 2).map(l => "»" + l.trim().slice(0, 50) + "«").join(", ")}).`); }
  // sklici na poglavja: samo obstoječa
  const vsa = Object.values(x.poglavja || {}).map(Number), maks = Math.max(0, ...vsa);
  for (const [id, t] of Object.entries(x.besedila || {})) for (const m of String(t || "").matchAll(/poglavj\w*\s+(\d+)/gi)) if (+m[1] > maks || !vsa.includes(+m[1])) odp(`Neveljaven sklic »${m[0]}« v poglavju ${(x.poglavja || {})[id] || id}.`);
  // predpisi za preverjanje (datum zadnjega preverjanja starejši od 12 mesecev)
  const star = (x.predpisi || []).filter(z => !z.preverjeno || daysTo(String(z.preverjeno).slice(0, 10)) < -365); if (star.length) opo(`${star.length} predpisov v prilogi ni bilo preverjenih zadnjih 12 mesecev (npr. ${star[0].predpis}).`);
  const Z = W.zbiranje || {};
  if (!(Z.kultura_zaveza || Z.kultura_sporocanje || Z.kultura_usposabljanje || Z.kultura_pregled)) odp("Kultura varnosti hrane ni opisana (zaveza vodstva, sporočanje težav, usposabljanje, pregled).");
  // vloge iz navodil (odgovornosti) morajo biti določene v HACCP skupini
  const vloge = new Set((Z.clani || []).map(c => String(c.vloga || "").toLowerCase()).filter(Boolean)), ZNANE = ["vodja kuhinje", "vodja izmene", "vodja haccp", "odgovorna oseba", "vodja lokala", "vodja obrata"];
  if ((Z.clani || []).length) { const v = new Set(); for (const n of navodila) for (const z of ZNANE) if (String(n.vsebina || "").toLowerCase().includes(z) && ![...vloge].some(x => x.includes(z.split(" ")[0]) && x.includes(z.split(" ").pop()))) v.add(z); if (v.size) odp("Vloge iz navodil niso določene v HACCP skupini: " + [...v].join(", ") + "."); }
  else if (!Z.hacc_ekipa) odp("HACCP skupina ni določena (člani in vloge).");
  // način prodaje in koraki
  const kor = W.koraki.map(k => k.naziv).join(" ").toLowerCase(), np = Z.nacin_prodaje || [];
  if (np.includes("dostava") && !/dostav|transport|prevoz/.test(kor)) odp("Izbrana je dostava, v procesu pa ni koraka dostave ali transporta.");
  if (np.includes("s_seboj") && !/pakir|embal|s seboj/.test(kor)) odp("Izbrana je prodaja za s seboj, v procesu pa ni koraka pakiranja.");
  // živila iz procesa (sladoled, pijače, led) morajo biti v opisu živil
  const ziv = W.zivila.map(z => (z.naziv || "") + " " + (z.skupina || "")).join(" ").toLowerCase();
  [[/sladoled/, "sladoled"], [/pijač|točiln/, "pijače"], [/led|ledomat|kocke ledu/, "led"]].forEach(([re, ime]) => { if (re.test(kor) && !re.test(ziv) && !(ime === "pijače" && /pijač|kav|sok|vod/.test(ziv))) odp(`V procesu je ${ime}, v opisu živil (poglavje 5) pa ga ni.`); });
  // odločitveno drevo in razvrstitev
  for (const h of W.nevarnosti) { const c = W.kontrole[h.id]; if (!c || !c.drevo) continue; const p = drevoPredlogVer(c.drevo, drevoVer(c)); if (p === "spremeni") odp(`${korak(h.korak_id)}: po odločitvenem drevesu je treba spremeniti korak, proces ali izdelek (V4 = Ne) – uvedite kontrolni ukrep in ponovite analizo.`); if (p === "CCP" && c.vrsta !== "CCP") odp(`${korak(h.korak_id)}: drevo odločanja predlaga CCP, razvrstitev je ${c.vrsta || "ni določena"} – utemeljite ali uskladite.`); if (p === "ni CCP" && c.vrsta === "CCP") odp(`${ozn(h)} (${korak(h.korak_id)}): drevo odločanja ne predlaga CCP – utemeljite razvrstitev.`); }
  // vrednosti v navodilih in mejne vrednosti v poglavju CCP/OPRP (en vir vrednosti)
  for (const [h, c] of kont) { const kl = (korak(h.korak_id) + " " + (c.kaj || "")).toLowerCase(), tema = /hlaj/.test(kl) ? "hlajenje" : /cvr|olj/.test(kl) ? "cvrtje" : ""; if (!tema || !c.mejna) continue;
    const st = t => [...String(t).matchAll(/(\d+(?:[.,]\d+)?)\s*(°C|ur\p{L}*|h(?!\p{L})|min\p{L}*)/giu)].map(m => m[1].replace(",", ".") + m[2].toLowerCase().replace(/^ur\p{L}*$/u, "h").replace(/^min\p{L}*$/u, "min")), mj = st(c.mejna);
    for (const n of navodila.filter(x => temeNavodila(x).includes(tema))) {
      const nv = st(besediloTeme(n, tema)); // samo vrednosti iz razdelka ali stavkov o tej temi
      const razl = nv.filter(v => mj.length && !mj.includes(v) && mj.some(m => m.replace(/[\d.]/g, "") === v.replace(/[\d.]/g, "")));
      if (razl.length) odp(`Navodilo »${n.naslov}« (${tema}) navaja ${[...new Set(razl)].join(", ")}, ${ozn(h)} pa »${c.mejna}« – vrednosti uskladite (generator ne izbira med njimi).`);
    } }
  // številke CCP/OPRP v prostem besedilu: oznaka mora obstajati in faza v istem stavku se mora ujemati (sicer uporabite {{CCP:faza}})
  { const poOzn = {}; for (const [hid, o] of Object.entries(oz)) poOzn[o] = korak((W.nevarnosti.find(h => h.id === hid) || {}).korak_id);
    const prosta = [["Opis dejavnosti", x.stranka && x.stranka.opis_dejavnosti], ["Opis prostorov", x.ob && x.ob.opis_prostorov], ["Opis opreme", x.ob && x.ob.oprema_opis], ...navodila.map(n => ["Navodilo »" + n.naslov + "«", n.vsebina]), ...(W.poglavja || []).filter(c => c.custom).map(c => ["Poglavje »" + c.naslov + "«", c.besedilo]), ...Object.entries(W.besedila_pogl || {}).map(([id, t]) => ["Poglavje " + ((x.poglavja || {})[id] || id), t]), ...Object.values(W.kontrole).filter(c => c && c.utemeljitev).map(c => ["Utemeljitev ukrepa (" + (oz[c.hid] || c.vrsta || "") + ")", c.utemeljitev])];
    const javljeno = new Set();
    for (const [kje, t] of prosta) for (const s of String(t || "").split(/(?<=[.!?])\s+|\n+/).filter(s => !/^\s*Število (kritičnih|CCP)/.test(s))) for (const m of s.matchAll(/(?<![\p{L}{:])(CCP|OPRP)\s?(\d+)(?!\d)/gu)) {
      const o = m[1] + m[2], f = poOzn[o]; let msg = "";
      if (!f) msg = `${kje}: omenja ${o}, ki ne obstaja – namesto številke uporabite oznako {{${m[1]}:faza}}.`;
      else { const druge = W.koraki.map(k => k.naziv).filter(n => n && n.length >= 4 && n.toLowerCase() !== f.toLowerCase() && s.toLowerCase().includes(n.toLowerCase())); if (druge.length && !s.toLowerCase().includes(f.toLowerCase())) msg = `${kje}: »${s.trim().slice(0, 90)}« – ${o} je faza »${f}«, ne »${druge[0]}«. Uporabite oznako {{${m[1]}:${f}}}.`; }
      if (msg && !javljeno.has(msg)) { javljeno.add(msg); odp(msg); }
    }
    for (const [kje, t] of prosta) for (const m of String(t || "").matchAll(/\{\{\s*(CCP|OPRP)\s*:\s*([^}]+?)\s*\}\}/g)) { if (!/^\[MANJKA/.test(zamenjajOznake(m[0], W, oz))) continue; const msg = `${kje}: oznaka ${m[0]} – ${m[1]} za »${m[2]}« ne obstaja.`; if (!javljeno.has(msg)) { javljeno.add(msg); odp(msg); } } }
  // teme navodil le predlagane iz naslova: potrdite v obrazcu navodila
  const nepTeme = navodila.filter(temePredlog); if (nepTeme.length) opo(`Teme protokola niso potrjene pri navodilih: ${nepTeme.map(n => "»" + n.naslov + "«").join(", ")} (predlog iz naslova) – potrdite jih v obrazcu navodila.`);
  // strokovna opozorila (brez samodejnih zaključkov)
  const vse = [W.zivila.map(z => [z.naziv, z.sestava, z.priprava].join(" ")).join(" "), W.koraki.map(k => k.naziv).join(" "), W.nevarnosti.map(h => h.nevarnost + " " + (h.obstojec || "")).join(" "), navodila.map(n => n.vsebina).join(" ")].join(" ").toLowerCase();
  // obravnavano opozorilo (gumb »Obravnavano« z utemeljitvijo v koraku 6) se ne javi več, utemeljitev se izpiše v dokumentu
  const obr = W.obravnavano || {};
  STROKOVNA_OPOZORILA.forEach(([k, re, t]) => { if (re.test(vse) && !(obr[k] && obr[k].utemeljitev)) out.push({ tip: "opozorilo", txt: t, kljuc: k }); });
  return out;
}
// vrednosti z enotami (°C, min, h) za primerjavo opisa ukrepa z mejo; pogostost na dan (»1× dnevno«, »dvakrat dnevno«)
function vrednostiEnot(t) { return [...String(t || "").matchAll(/(-?\d+(?:[.,]\d+)?)\s*(°C|min\p{L}*|ur\p{L}*|h(?!\p{L}))/giu)].map(m => ({ v: +m[1].replace(",", "."), e: /^min/i.test(m[2]) ? "min" : /^(ur|h)/i.test(m[2]) ? "h" : "°C" })); }
function pogostostNaDan(t) {
  t = String(t || "").toLowerCase(); let m = /(\d+)\s*[×x]\s*(?:na\s*)?(?:dan|dnevno)/.exec(t); if (m) return +m[1];
  const B = { enkrat: 1, dvakrat: 2, trikrat: 3, štirikrat: 4, petkrat: 5 }; m = /(enkrat|dvakrat|trikrat|štirikrat|petkrat)\s*(?:na\s*)?(?:dan|dnevno)/.exec(t); if (m) return B[m[1]];
  return /(?<!\p{L})(vsak dan|dnevno)(?!\p{L})/u.test(t) && !/\d|krat/.test(t) ? 1 : null;
}
// vir meje za dokument: predpis (iz baze zakonodaje, s členom) ali jasno ločena smernica / strokovno priporočilo
function virMeje(c) {
  const v = c.mejna_vir_vrsta || "", pr = [c.mejna_vir_predpis, c.mejna_vir_clen].filter(Boolean).join(", ");
  if (v === "predpis" || (!v && pr)) return "Predpis: " + [pr, c.mejna_vir].filter(Boolean).join(" – ");
  if (v === "smernica") return "Smernica / strokovno priporočilo (ni predpis): " + (c.mejna_vir || "");
  return v ? v + (c.mejna_vir ? ": " + c.mejna_vir : "") : c.mejna_vir || "";
}
// alergeni EU pri živilu (brez opombe »preveriti«); unija za obrat (poglavje 5)
const alergeniZivila = z => String(z.alergeni || "").replace(/\s*\((?:preveriti|preveri|odprto)[^)]*\)/ig, "").split(/[,;]/).map(x => x.trim()).filter(x => x && !/^ni alergenov$/i.test(x));
const alergeniObrata = W => [...new Set(W.zivila.flatMap(alergeniZivila))].sort((a, b) => a.localeCompare(b, "sl"));
// strokovna opozorila po ključnih besedah: [ključ, vzorec, besedilo] – ključ veže utemeljitev »Obravnavano« (W.obravnavano[ključ])
const STROKOVNA_OPOZORILA = [["surova_jajca", /surov\w* jajc|tiramis|majonez\w* doma/, "Surova jajca: preverite uporabo pasteriziranih jajc ali ustrezno toplotno obdelavo."], ["nizka_temperatura", /rosbif|(?<!\p{L})rare(?!\p{L})|nizk\w* temperatur\w* (pečen|kuhan)|sous.?vide/u, "Meso pri nižji temperaturi (rosbif, sous-vide): potrebna je validacija časa in temperature."], ["histamin", /tun[ae]?(?!\p{L})|skuš|sardel|inčun|histamin/u, "Ribe z možnim histaminom (tuna, skuša, sardele): nadzor hladne verige in dobavitelja."], ["cvrtje_alergeni", /skupn\w* olj|isto olje|cvrtj/, "Cvrtje: preverite navzkrižni prenos alergenov v skupnem olju."], ["spiranje_mesa", /sp\w*ranj\w* surov\w* mes|umivanj\w* mes|pran\w* (piščan|perutnin|mes)/, "Spiranje surovega mesa ni priporočeno (razpršitev mikroorganizmov)."], ["mikroval", /mikroval\w*.{0,20}odtaj|odtaj\w*.{0,20}mikroval/, "Odtajanje v mikrovalovni pečici: živilo takoj toplotno obdelajte."]];
const opozoriloIme = k => ((STROKOVNA_OPOZORILA.find(x => x[0] === k) || [])[2] || k).replace(/:.*$/, "");
// najdaljša poglavja dokumenta (iz statistike pdfBuild): opozorilo, če ima dokument več kot meja strani
function dolzinaDokumenta(st, meja) {
  if (!st || st.strani <= (meja || 50)) return "";
  const p = st.poglavja.map((e, i) => ({ s: e.s, n: (i + 1 < st.poglavja.length ? st.poglavja[i + 1].stran : st.strani + 1) - e.stran })).sort((a, b) => b.n - a.n).slice(0, 3);
  return `Dokument ima ${st.strani} strani (cilj približno 45–50). Največ dolžine: ${p.map(x => `${x.s} (${x.n} str.)`).join(", ")}.`;
}
// predlog odločitvenega drevesa (V1–V4): »CCP«, »ni CCP« ali "" (ni dovolj odgovorov)
// odločitveno drevo za CCP: Codex CXC 1-1969, rev. 2022, Priloga IV (tabela 1); načrti z odgovori brez oznake različice uporabljajo prejšnje drevo (rev. 2003)
const DREVO_VPR = {
  "2022": ["Ali je pomembno nevarnost na tem koraku mogoče obvladati na sprejemljivo raven s predpogojnimi programi (npr. dobra higienska praksa)?",
    "Ali na tem koraku obstajajo specifični kontrolni ukrepi za ugotovljeno pomembno nevarnost?",
    "Ali bo naslednji korak preprečil ali odstranil ugotovljeno pomembno nevarnost ali jo zmanjšal na sprejemljivo raven?",
    "Ali lahko ta korak posebej prepreči ali odstrani ugotovljeno pomembno nevarnost ali jo zmanjša na sprejemljivo raven?"],
  "2003": ["Ali na tem koraku že obstaja ukrep za obvladovanje te nevarnosti?", "Ali je ta korak posebej namenjen odstranitvi ali zmanjšanju nevarnosti na sprejemljivo raven?",
    "Ali bi lahko onesnaženje preseglo sprejemljive ravni ali se povečalo do nesprejemljivih ravni?", "Ali bo naslednji korak odstranil ali zmanjšal nevarnost na sprejemljivo raven?"]
};
const DREVO_VIR = { "2022": "Codex CXC 1-1969 (rev. 2022), Priloga IV", "2003": "Codex CXC 1-1969 (rev. 2003)" };
// različica drevesa za kontrolni ukrep: nova vprašanja, razen če ima ukrep odgovore po prejšnjem drevesu
const drevoVer = c => c && c.drevo_ver === "2022" ? "2022" : c && (c.drevo || []).some(Boolean) ? "2003" : "2022";
// predlog po drevesu: »CCP«, »ni CCP«, »spremeni« (proces/izdelek) ali "" (premalo odgovorov)
function drevoPredlogVer(a, ver) {
  a = a || [];
  if (ver !== "2022") return drevoPredlog(a);
  if (a[0] === "d") return "ni CCP"; if (a[0] !== "n") return "";
  if (a[1] === "n") return "ni CCP"; if (a[1] !== "d") return "";
  if (a[2] === "d") return "ni CCP"; if (a[2] !== "n") return "";
  return a[3] === "d" ? "CCP" : a[3] === "n" ? "spremeni" : "";
}
function drevoBesedilo(a, ver) {
  a = a || [];
  if (ver !== "2022") { if (a[0] === "n") return "V1 = Ne: uvedite ali spremenite ukrep na tem koraku/procesu; šele nato presodite razvrstitev."; if (a[1] === "d") return "Predlog: možna CCP (korak je namenjen obvladovanju nevarnosti). Presodite sami."; if (a[1] === "n" && a[2] === "n") return "Predlog: ni CCP – PRP ali OPRP."; if (a[2] === "d" && a[3] === "d") return "Predlog: ni CCP na tem koraku (nadzor na naslednjem koraku) – PRP ali OPRP."; if (a[2] === "d" && a[3] === "n") return "Predlog: možna CCP. Presodite sami."; return "Odgovorite na vprašanja."; }
  if (a[0] === "d") return "Predlog (V1 = Da): korak ni CCP – nevarnost obvladujejo predpogojni programi (rutinski PRP ali PRP z večjo pozornostjo, npr. spremljanje in zapisi – OPRP).";
  if (a[0] !== "n") return "Odgovorite na vprašanja.";
  if (a[1] === "n") return "Predlog (V2 = Ne): korak ni CCP – ocenite naslednje korake. Če CCP ni določena na nobenem koraku, spremenite proces ali izdelek in ponovite analizo.";
  if (a[1] !== "d") return "Odgovorite na V2.";
  if (a[2] === "d") return "Predlog (V3 = Da): korak ni CCP – CCP je naslednji korak, ki nevarnost prepreči, odstrani ali zmanjša.";
  if (a[2] !== "n") return "Odgovorite na V3.";
  if (a[3] === "d") return "Predlog (V4 = Da): korak je CCP. Presodite tudi, ali ukrep deluje skupaj z ukrepom na drugem koraku (potem sta CCP oba koraka).";
  if (a[3] === "n") return "Predlog (V4 = Ne): spremenite korak, proces ali izdelek, da uvedete kontrolni ukrep, in ponovite analizo nevarnosti.";
  return "Odgovorite na V4.";
}
function drevoPredlog(a) { a = a || []; if (a[0] === "n") return ""; if (a[1] === "d") return "CCP"; if (a[1] === "n" && a[2] === "n") return "ni CCP"; if (a[2] === "d" && a[3] === "d") return "ni CCP"; if (a[2] === "d" && a[3] === "n") return "CCP"; return ""; }
// ali vsi alergeni živil potrjeni (stavek o popolni matriki alergenov se izpiše samo takrat)
const alergeniPotrjeni = W => W.zivila.length > 0 && W.zivila.every(z => z.alergeni && !/preverit|\?|neznan/i.test(z.alergeni) && z.alergeni_potrjeni === true);
