// Predloge pogodb za stranko (Word): strokovni nadzor sistema HACCP in pomoč pri odpravi pomanjkljivosti po inšpekcijskem nadzoru.
// Podatki izvajalca (svetovalčevo podjetje) se zapomnijo v brskalniku (isti ključ kot pri pogodbi o obdelavi osebnih podatkov).
// Pri inšpekciji se lahko iz ugotovitev odprejo neskladnosti (CAPA) z rokom za odpravo – sledenje odprave v aplikaciji.
// Vse je PREDLOGA: pred podpisom jo pregleda pravnik.
const POG_ORGANI = ["Uprava RS za varno hrano, veterinarstvo in varstvo rastlin (UVHVVR)", "Zdravstveni inšpektorat RS (ZIRS)", "Tržni inšpektorat RS (TIRS)", "Drugo"];
const pogIzvajalec = () => { try { return JSON.parse(localStorage.getItem("gdpr_izvajalec") || "{}") || {}; } catch { return {}; } };
const pogShraniIzvajalca = o => { try { localStorage.setItem("gdpr_izvajalec", JSON.stringify(Object.assign(pogIzvajalec(), o))); } catch {} };
const pogPrazno = (t, n) => t && String(t).trim() ? String(t).trim() : "_".repeat(n || 16);
const pogEur = v => v === "" || v === null || v === undefined || isNaN(+v) ? "________ EUR" : fnum(+v, 2, 2) + " EUR";
const pogStranka = s => [s.naziv, s.naslov, s.davcna ? "ID za DDV: " + s.davcna : "", s.maticna ? "matična št.: " + s.maticna : ""].filter(Boolean).join(", ");
const pogIzv = o => [o.naziv, o.naslov, o.davcna ? "davčna št.: " + o.davcna : ""].filter(Boolean).join(", ");
// ugotovitve inšpektorja: ena na vrstico (oštevilčenje in alineje se odstranijo)
const pogUgotovitve = t => String(t || "").split("\n").map(x => x.replace(/^\s*(?:[-•*]|\d+[.)])\s*/, "").trim()).filter(Boolean);

function pogStranki(d, s, o) {
  d.h(1, "Pogodbeni stranki");
  d.table(["Vloga", "Podatki"], [["Naročnik", pogStranka(s) || pogPrazno("", 40)], ["ki ga zastopa", pogPrazno(s.odgovorna_oseba, 30)], ["Izvajalec", pogIzv(o) || pogPrazno("", 40)], ["ki ga zastopa", pogPrazno(o.zastopnik, 30)]], [25, 75]);
}
function pogPodpisi(d, s, o) {
  d.p("Pogodba je sestavljena v dveh enakih izvodih, od katerih prejme vsaka stranka po enega. Veljati začne z dnem podpisa obeh strank.");
  d.table(["Naročnik", "Izvajalec"], [["Kraj in datum: ____________", "Kraj in datum: ____________"], ["Podpis in žig: ____________ (" + pogPrazno(s.odgovorna_oseba, 12) + ")", "Podpis in žig: ____________ (" + pogPrazno(o.zastopnik, 12) + ")"]], [50, 50]);
}

function pogodbaNadzorDoc(d, s, o, p, obrati) {
  d.p("PREDLOGA. Pred podpisom naj jo pregleda pravnik in prilagodi dejanskemu razmerju.", { col: "r" });
  pogStranki(d, s, o);
  d.h(1, "1. Predmet pogodbe");
  d.p("Izvajalec za naročnika opravlja strokovni nadzor in svetovanje pri izvajanju sistema HACCP in dobre higienske prakse v skladu z Uredbo (ES) št. 852/2004 o higieni živil, Uredbo (ES) št. 178/2002 in nacionalnimi predpisi o živilih.");
  d.p("Pogodba velja za obrate: " + (obrati.length ? obrati.map(x => x.naziv + (x.naslov ? " (" + x.naslov + ")" : "")).join("; ") : pogPrazno("", 40)) + ".");
  d.h(1, "2. Obseg storitev");
  d.bullets([
    `redni obiski na lokaciji: ${pogPrazno(p.obiski, 4)} letno, s poročilom po obisku (ugotovitve, priporočila, roki);`,
    "pregled evidenc (temperature, prevzem, čiščenje, usposabljanja, neskladnosti) v aplikaciji HiGiFood in opozarjanje na manjkajoče ali neskladne zapise;",
    "vzdrževanje HACCP načrta: posodobitev ob spremembah izdelkov, procesov, opreme ali prostorov ter letni pregled (verifikacija) sistema;",
    "svetovanje pri neskladnostih in korektivnih ukrepih ter preverjanje njihove učinkovitosti;",
    "priprava na uradni (inšpekcijski) nadzor in pregled dokumentacije pred njim;",
    "svetovanje po telefonu in e-pošti v delovnem času izvajalca" + (p.ure ? ` (vključeno do ${p.ure} ur mesečno)` : "") + ";",
    p.usposabljanje ? "usposabljanje zaposlenih s področja higiene živil in HACCP (" + p.usposabljanje + ");" : "usposabljanje zaposlenih po dogovoru in ceniku izvajalca;",
  ]);
  d.p("Storitve, ki niso navedene v tem členu (npr. pomoč pri odpravi pomanjkljivosti po inšpekcijskem nadzoru, izredni obiski, vzorčenje in laboratorijske analize), se opravijo po posebnem dogovoru ali ceniku izvajalca.");
  d.h(1, "3. Obveznosti naročnika");
  d.bullets([
    "izvaja ukrepe iz HACCP načrta in redno vodi evidence;",
    "izvajalcu omogoči dostop do prostorov, dokumentacije in zaposlenih ter mu posreduje potrebne podatke;",
    "izvajalca brez odlašanja obvesti o spremembah (novi izdelki, procesi, oprema, prostori, dobavitelji), o resnih neskladnostih in o vsakem uradnem nadzoru ter mu posreduje zapisnik ali odločbo;",
    "pravočasno plačuje dogovorjeno ceno.",
  ]);
  d.p("Za varnost živil in skladnost z živilsko zakonodajo je odgovoren nosilec živilske dejavnosti (17. člen Uredbe (ES) št. 178/2002). Izvajalec s svojimi storitvami naročniku pri tem strokovno pomaga, odgovornosti pa ne prevzema.");
  d.h(1, "4. Cena in plačilo");
  d.p(`Cena storitev iz 2. člena znaša ${pogEur(p.cena)} ${p.obdobje || "mesečno"}${p.ddv === false ? " (izvajalec ni zavezanec za DDV)" : " brez DDV; DDV se obračuna po veljavni stopnji"}. Izvajalec izstavi račun ${p.obdobje === "letno" ? "enkrat letno" : "za pretekli mesec"}, naročnik ga plača v ${pogPrazno(p.rok_placila, 3)} dneh od prejema.`);
  d.p(`Dodatne storitve se obračunajo po urni postavki ${pogEur(p.urna)} brez DDV; potni stroški ${p.potni ? p.potni : "po dogovoru"}.`);
  d.h(1, "5. Trajanje in odpoved");
  d.p(`Pogodba se sklene ${p.do ? "za določen čas od " + fdate(p.od || today()) + " do " + fdate(p.do) : "za nedoločen čas z začetkom " + fdate(p.od || today())}. Vsaka stranka jo lahko pisno odpove z odpovednim rokom ${pogPrazno(p.odpoved, 3)} dni. Ob hujši kršitvi obveznosti jo lahko stranka odpove brez odpovednega roka, če druga stranka kršitve ne odpravi v 15 dneh po pisnem opozorilu.`);
  d.p("Ob prenehanju pogodbe izvajalec naročniku izroči ali omogoči izvoz vse dokumentacije in evidenc, ki jih je vodil zanj.");
  d.h(1, "6. Odgovornost");
  d.p("Izvajalec storitve opravlja s skrbnostjo dobrega strokovnjaka. Ne odgovarja za škodo, ki nastane, ker naročnik ni upošteval njegovih navodil in priporočil, ker ga ni pravočasno obvestil o spremembah ali ker mu je posredoval nepopolne ali napačne podatke. Izid uradnega nadzora ni predmet jamstva izvajalca.");
  d.h(1, "7. Zaupnost in varstvo osebnih podatkov");
  d.p("Stranki varujeta kot poslovno skrivnost vse podatke, ki jih izvesta pri izvajanju pogodbe. Obdelavo osebnih podatkov (zaposleni, uporabniki aplikacije) urejata ločena pogodba o obdelavi osebnih podatkov po 28. členu Splošne uredbe (EU) 2016/679.");
  d.h(1, "8. Končne določbe");
  d.p(`Spremembe in dopolnitve pogodbe so veljavne le v pisni obliki. Morebitne spore stranki rešujeta sporazumno, sicer je pristojno sodišče v ${pogPrazno(p.sodisce, 14)}.`);
  pogPodpisi(d, s, o);
}

function pogodbaInspekcijaDoc(d, s, o, p) {
  const ug = pogUgotovitve(p.ugotovitve);
  d.p("PREDLOGA. Pred podpisom naj jo pregleda pravnik in prilagodi dejanskemu razmerju.", { col: "r" });
  pogStranki(d, s, o);
  d.h(1, "1. Podatki o uradnem nadzoru");
  d.table(["Postavka", "Podatki"], [
    ["Nadzorni organ", pogPrazno(p.organ, 30)],
    ["Datum nadzora", p.datum ? fdate(p.datum) : pogPrazno("", 12)],
    ["Zapisnik / odločba (št.)", pogPrazno(p.stevilka, 20)],
    ["Rok za odpravo po zapisniku / odločbi", p.rok ? fdate(p.rok) : pogPrazno("", 12)],
    ["Obrat", pogPrazno(p.obrat, 30)],
  ], [35, 65]);
  d.h(1, "2. Predmet pogodbe");
  d.p("Izvajalec naročniku strokovno pomaga pri odpravi nepravilnosti in pomanjkljivosti, ugotovljenih pri uradnem nadzoru iz 1. člena, ter pri pripravi dokazil o njihovi odpravi.");
  d.h(1, "3. Ugotovljene pomanjkljivosti in načrt odprave");
  d.table(["Št.", "Ugotovitev nadzornega organa", "Ukrep", "Odgovoren", "Rok"],
    (ug.length ? ug : ["", "", ""]).map((u, i) => [String(i + 1), u || pogPrazno("", 24), "", "", p.rok ? fdate(p.rok) : ""]), [6, 40, 28, 14, 12]);
  d.p("Ukrepe, odgovorne osebe in roke stranki dopolnita v načrtu odprave, ki ga izvajalec pripravi v roku iz 4. člena. Načrt je priloga te pogodbe.", { col: "m" });
  d.h(1, "4. Storitve izvajalca");
  d.bullets([
    `pregled zapisnika oziroma odločbe in priprava načrta odprave z ukrepi, odgovornimi osebami in roki v ${pogPrazno(p.dni_nacrt, 3)} dneh od prejema zapisnika;`,
    "dopolnitev oziroma posodobitev HACCP načrta, delovnih navodil in evidenc, na katere se nanašajo ugotovitve;",
    "usposabljanje zaposlenih, kadar se ugotovitev nanaša na znanje ali ravnanje zaposlenih;",
    `kontrolni obisk na lokaciji pred iztekom roka (${pogPrazno(p.obiski, 2)}) in preverjanje, ali so ukrepi izvedeni in učinkoviti;`,
    "priprava poročila o odpravi pomanjkljivosti z dokazili (fotografije, evidence, računi) za nadzorni organ; poročilo podpiše in pošlje naročnik;",
    "po potrebi pomoč pri pripravi utemeljene prošnje za podaljšanje roka.",
  ]);
  d.p("Izvajalec naročnika v upravnem ali prekrškovnem postopku ne zastopa, razen na podlagi posebnega pisnega pooblastila.");
  d.h(1, "5. Obveznosti naročnika");
  d.bullets([
    "izvajalcu takoj posreduje zapisnik, odločbo in vso dokumentacijo, ki se nanaša na nadzor;",
    "na svoje stroške izvede ukrepe iz načrta odprave (npr. popravila, nabava opreme, storitve tretjih oseb) v dogovorjenih rokih;",
    "izvajalca obvesti o vsakem nadaljnjem dopisu ali obisku nadzornega organa.",
  ]);
  d.p("Za odpravo pomanjkljivosti in spoštovanje rokov, ki jih je določil nadzorni organ, je odgovoren naročnik kot nosilec živilske dejavnosti.");
  d.h(1, "6. Cena in plačilo");
  d.p(p.cena !== "" && p.cena !== undefined && p.cena !== null
    ? `Cena storitev iz 4. člena znaša ${pogEur(p.cena)} brez DDV (pavšal). Dodatno delo, ki presega obseg iz 4. člena, se obračuna po urni postavki ${pogEur(p.urna)} brez DDV.`
    : `Storitve se obračunajo po dejansko porabljenem času po urni postavki ${pogEur(p.urna)} brez DDV; izvajalec vodi evidenco opravljenega dela.`);
  d.p(`Potni stroški: ${p.potni || "po dogovoru"}. Naročnik račun plača v ${pogPrazno(p.rok_placila, 3)} dneh od prejema.`);
  d.h(1, "7. Trajanje");
  d.p(`Pogodba velja do oddaje poročila o odpravi pomanjkljivosti nadzornemu organu${p.rok ? ", predvidoma do " + fdate(p.rok) : ""}, oziroma do zaključka postopka, če nadzorni organ zahteva dopolnitve.`);
  d.h(1, "8. Odgovornost");
  d.p("Izvajalec storitve opravlja s skrbnostjo dobrega strokovnjaka. Ne jamči za izid postopka pred nadzornim organom in ne odgovarja za posledice, ki nastanejo, ker naročnik ukrepov ni izvedel pravočasno ali v dogovorjenem obsegu.");
  d.h(1, "9. Končne določbe");
  d.p(`Stranki varujeta zaupnost podatkov, ki jih izvesta pri izvajanju pogodbe. Spremembe so veljavne le v pisni obliki. Morebitne spore rešujeta sporazumno, sicer je pristojno sodišče v ${pogPrazno(p.sodisce, 14)}.`);
  pogPodpisi(d, s, o);
}

// kartica v razdelku »Storitve« stranke (samo administrator in svetovalec)
function pogodbeKartica(el, ctx) {
  if (!hasRole(ME.u, "admin", "svetovalec")) return;
  el.insertAdjacentHTML("afterbegin", `<div class="card" id="pog"><h2>Pogodbe</h2><p class="mut">Predloge pogodb (Word) s podatki stranke. Pred podpisom naj jih pregleda pravnik.</p>
    <div class="row"><button class="btn ghost" id="pog_n">Pogodba o strokovnem nadzoru (Word)</button><button class="btn ghost" id="pog_i">Pomoč pri odpravi pomanjkljivosti po inšpekciji (Word)</button></div></div>`);
  $("#pog_n", el).onclick = () => pogodbaObrazec(ctx, "nadzor");
  $("#pog_i", el).onclick = () => pogodbaObrazec(ctx, "inspekcija");
}

async function pogodbaObrazec(ctx, vrsta) {
  const s = ctx.stranka, iz = pogIzvajalec(), obrati = await D.list("obrati", { stranka_id: s.id }).catch(() => []);
  const izv = `<h3>Izvajalec (vaše podjetje)</h3><div class="fgrid"><label class="f"><span>Naziv</span><input id="pg_in" value="${esc(iz.naziv || "")}"></label><label class="f"><span>Naslov</span><input id="pg_ia" value="${esc(iz.naslov || "")}"></label>
    <label class="f"><span>Davčna številka</span><input id="pg_id" value="${esc(iz.davcna || "")}"></label><label class="f"><span>Zastopnik</span><input id="pg_iz" value="${esc(iz.zastopnik || "")}"></label></div>`;
  const placilo = `<label class="f"><span>Urna postavka (EUR brez DDV)</span><input id="pg_ur" type="number" min="0" step="0.01" value="${esc(iz.urna || "")}"></label><label class="f"><span>Rok plačila (dni)</span><input id="pg_rp" type="number" min="0" value="${esc(iz.rok_placila || "15")}"></label>
    <label class="f"><span>Potni stroški</span><input id="pg_pt" value="${esc(iz.potni || "")}" placeholder="npr. 0,43 EUR/km ali vključeni"></label><label class="f"><span>Pristojno sodišče (kraj)</span><input id="pg_so" value="${esc(iz.sodisce || "")}"></label>`;
  const nadzor = `<h3>Pogoji</h3><div class="fgrid"><label class="f"><span>Cena (EUR brez DDV)</span><input id="pg_c" type="number" min="0" step="0.01"></label><label class="f"><span>Obdobje</span><select id="pg_ob"><option value="mesečno">mesečno</option><option value="letno">letno</option></select></label>
    <label class="f"><span>Redni obiski na leto</span><input id="pg_ob2" type="number" min="0" value="4"></label><label class="f"><span>Svetovanje (ur mesečno, neobvezno)</span><input id="pg_ure" type="number" min="0"></label>
    <label class="f"><span>Usposabljanje zaposlenih (neobvezno)</span><input id="pg_us" placeholder="npr. enkrat letno na lokaciji"></label><label class="f"><span>Začetek</span><input id="pg_od" type="date" value="${today()}"></label>
    <label class="f"><span>Konec (prazno = nedoločen čas)</span><input id="pg_do" type="date"></label><label class="f"><span>Odpovedni rok (dni)</span><input id="pg_odp" type="number" min="0" value="30"></label>${placilo}
    <label class="f" style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="pg_ddv" style="width:auto;min-height:0" ${iz.ddv === false ? "checked" : ""}> Izvajalec ni zavezanec za DDV</label></div>`;
  const insp = `<h3>Uradni nadzor</h3><div class="fgrid"><label class="f"><span>Nadzorni organ</span><select id="pg_or">${POG_ORGANI.map(x => `<option>${esc(x)}</option>`).join("")}</select></label><label class="f"><span>Datum nadzora</span><input id="pg_dn" type="date"></label>
    <label class="f"><span>Št. zapisnika / odločbe</span><input id="pg_st"></label><label class="f"><span>Rok za odpravo</span><input id="pg_rk" type="date"></label>
    <label class="f"><span>Obrat</span><select id="pg_obr"><option value=""></option>${obrati.map(x => `<option value="${x.id}">${esc(x.naziv)}</option>`).join("")}</select></label>
    <label class="f wide"><span>Ugotovitve inšpektorja (ena v vrstici, iz zapisnika)</span><textarea id="pg_ug" rows="5" placeholder="npr. Ni evidence temperature hladilnika za maj&#10;Poškodovane stenske ploščice v kuhinji"></textarea></label></div>
    <h3>Pogoji</h3><div class="fgrid"><label class="f"><span>Pavšal (EUR brez DDV, prazno = po urah)</span><input id="pg_c" type="number" min="0" step="0.01"></label><label class="f"><span>Načrt odprave v (dni)</span><input id="pg_dnn" type="number" min="1" value="5"></label>
    <label class="f"><span>Kontrolni obiski</span><input id="pg_ob2" type="number" min="0" value="1"></label>${placilo}
    <label class="f wide" style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="pg_capa" style="width:auto;min-height:0" checked> Za vsako ugotovitev odpri neskladnost (CAPA) z rokom za odpravo – sledenje odprave v aplikaciji</label></div>`;
  const naslov = vrsta === "nadzor" ? "Pogodba o strokovnem nadzoru sistema HACCP" : "Pogodba o pomoči pri odpravi pomanjkljivosti po inšpekcijskem nadzoru";
  modal(naslov, `<p class="err" id="ferr"></p><p class="mut">Naročnik: <b>${esc(s.naziv)}</b>${s.odgovorna_oseba ? ", " + esc(s.odgovorna_oseba) : ""}. Prazna polja ostanejo v pogodbi za ročni vpis.</p>${izv}${vrsta === "nadzor" ? nadzor : insp}`,
    [{ t: "Prekliči", cls: "ghost sec" }, { t: "Prenesi pogodbo (Word)", fn: async () => {
      const v = id => { const x = $("#" + id); return x ? x.value.trim() : ""; };
      const o = { naziv: v("pg_in"), naslov: v("pg_ia"), davcna: v("pg_id"), zastopnik: v("pg_iz") };
      const p = { urna: v("pg_ur"), rok_placila: v("pg_rp"), potni: v("pg_pt"), sodisce: v("pg_so"), cena: v("pg_c"), obiski: v("pg_ob2") };
      pogShraniIzvajalca(Object.assign({}, o, { urna: p.urna, rok_placila: p.rok_placila, potni: p.potni, sodisce: p.sodisce }, vrsta === "nadzor" ? { ddv: !$("#pg_ddv").checked } : {}));
      await loadStrankaLogo(s);
      if (vrsta === "nadzor") {
        Object.assign(p, { obdobje: v("pg_ob"), ure: v("pg_ure"), usposabljanje: v("pg_us"), od: v("pg_od"), do: v("pg_do"), odpoved: v("pg_odp"), ddv: !$("#pg_ddv").checked });
        if (p.do && p.od && p.do < p.od) { $("#ferr").textContent = "Konec pogodbe je pred začetkom."; return false; }
        dlBlob(docxBuild({ naslov, podnaslov: "strokovni nadzor in svetovanje (HACCP, dobra higienska praksa)", stranka: s.naziv, stanje: "PREDLOGA – pred podpisom pregleda pravnik" }, d => pogodbaNadzorDoc(d, s, o, p, obrati)), "pogodba-nadzor-" + s.naziv + ".docx");
        return;
      }
      const ob = obrati.find(x => x.id === v("pg_obr"));
      Object.assign(p, { organ: v("pg_or"), datum: v("pg_dn"), stevilka: v("pg_st"), rok: v("pg_rk"), obrat: ob ? ob.naziv : "", ugotovitve: $("#pg_ug").value, dni_nacrt: v("pg_dnn") });
      const ug = pogUgotovitve(p.ugotovitve);
      if ($("#pg_capa").checked && ug.length && !p.rok) { $("#ferr").textContent = "Za odprtje neskladnosti vpišite rok za odpravo (ali izklopite možnost)."; return false; }
      dlBlob(docxBuild({ naslov, podnaslov: (p.organ || "uradni nadzor") + (p.datum ? ", " + fdate(p.datum) : ""), stranka: s.naziv, stanje: "PREDLOGA – pred podpisom pregleda pravnik" }, d => pogodbaInspekcijaDoc(d, s, o, p)), "pogodba-inspekcija-" + s.naziv + ".docx");
      if ($("#pg_capa").checked && ug.length) {
        let n = 0; const vir = [p.organ, p.datum ? fdate(p.datum) : "", p.stevilka ? "št. " + p.stevilka : ""].filter(Boolean).join(", ");
        for (const u of ug) { try { await D.add("capa", { stranka_id: s.id, obrat_id: ob ? ob.id : null, cas: new Date().toISOString(), proces: "Uradni nadzor", opis: u + (vir ? " (ugotovitev nadzora: " + vir + ")" : ""), tveganje: "srednje", nujnost: "nujna", rok: p.rok, status: "odprto", takojsnji_ukrep: "", dolgorocni_ukrep: "" }); n++; } catch (e) { fail(e); break; } }
        toast("Pogodba prenesena, odprtih neskladnosti: " + n + " (Neskladnosti / CAPA).");
      }
    } }]);
}
