// Profil stranke z zavihki.
const TABS = [
  ["podatki", "Podatki"], ["obrati", "Obrati"], ["tloris", "Tloris"], ["osebje", "Zaposleni in usposabljanja"], ["dobavitelji", "Dobavitelji"], ["oprema", "Oprema in instrumenti"],
  ["nacrti", "HACCP načrti"], ["navodila", "Navodila in obrazci"], ["evidence", "Evidence"], ["higiena", "Higiena"], ["capa", "Neskladnosti / CAPA"], ["inspekcija", "Inšpekcija"], ["koledar", "Koledar"], ["priloge", "Priloge"], ["potrditve", "Potrditve in različice"], ["sledljivost", "Sledljivost"], ["alergeni", "Alergeni in jedilnik"], ["certifikacija", "Certifikacija"], ["storitve", "Storitve"], ["uporabniki", "Uporabniki"]
];
const TABEXT = {}; // zavihki, ki jih dodajajo drugi moduli: ime → (el, ctx)
// razdelki profila stranke v skupinah (levi meni; na ozkem zaslonu spustni seznam)
const SKUPINE = [
  ["Podjetje", ["podatki", "obrati", "tloris", "osebje", "dobavitelji", "oprema", "uporabniki"]],
  ["Vsakodnevno delo", ["evidence", "higiena", "capa", "koledar", "sledljivost", "alergeni"]],
  ["HACCP sistem", ["nacrti", "navodila", "potrditve", "certifikacija"]],
  ["Pregledi in dokumenti", ["inspekcija", "priloge", "storitve"]]
];
async function pageStranka(v, m) {
  const sid = m[1], tab = m[2] || "podatki";
  let s;
  try { s = await D.list("stranke").then(a => a.find(x => x.id === sid)); } catch (e) { throw e; }
  if (!s) throw new Error("Stranka ni najdena ali nimate dostopa.");
  $("#title").textContent = sIme(s);
  await loadStrankaLogo(s);
  const obrati = await D.list("obrati", { stranka_id: sid });
  const ctx = { stranka_id: sid, stranka: s, obrati: mapOf(obrati) };
  const tabs = TABS.filter(t => !(t[0] === "storitve" && hasRole(ME.u, "zaposleni")) && !(t[0] === "uporabniki" && hasRole(ME.u, "zaposleni")) && !(t[0] === "osebje" && hasRole(ME.u, "zaposleni")) && (t[0] === "podatki" || vis("tab:" + t[0]) || VIS.zak["tab:" + t[0]]));
  const zak = t => !vis("tab:" + t) && VIS.zak["tab:" + t]; // ni v paketu stranke: zavihek je viden z ključavnico
  // razdelek ni viden (tudi skrit za vlogo, odprt z neposrednim naslovom) → nazaj na Podatke
  if (tab !== "podatki" && ((!vis("tab:" + tab) && !zak(tab)) || (TABS.some(t => t[0] === tab) && !tabs.some(t => t[0] === tab)))) { const ime = (TABS.find(t => t[0] === tab) || [])[1]; toast(`Zavihek »${ime || tab}« ${hasRole(ME.u, "zaposleni") || hasRole(ME.u, "odgovorna") ? "za vašo vlogo ni na voljo ali vam ga je skril administrator" : "ni na voljo"}. Odprti so podatki stranke.`, true); location.hash = "#/stranka/" + sid + "/podatki"; return; }
  const vSkup = new Set(SKUPINE.flatMap(g => g[1])), skup = SKUPINE.concat([["Drugo", tabs.map(t => t[0]).filter(k => !vSkup.has(k))]])
    .map(([ime, ks]) => [ime, ks.map(k => tabs.find(t => t[0] === k)).filter(Boolean)]).filter(g => g[1].length);
  const ime = t => t[1] + (zak(t[0]) ? " 🔒" : "");
  v.innerHTML = `<div class="stranka-lay"><nav class="tabs snav" aria-label="Razdelki stranke">${skup.map(([g, ts]) => `<div class="snav-g">${g}</div>${ts.map(t => `<a href="#/stranka/${sid}/${t[0]}" class="${t[0] === tab ? "on" : ""}${zak(t[0]) ? " zaklep" : ""}"${t[0] === tab ? ' aria-current="page"' : ""}>${t[1]}${zak(t[0]) ? ' <span aria-label="ni v paketu">🔒</span>' : ""}</a>`).join("")}`).join("")}</nav>
    <div class="snav-vsebina"><label class="snav-mob"><span class="mut">Razdelek</span><select id="snav-sel">${skup.map(([g, ts]) => `<optgroup label="${g}">${ts.map(t => `<option value="${t[0]}" ${t[0] === tab ? "selected" : ""}>${esc(ime(t))}</option>`).join("")}</optgroup>`).join("")}</select></label><div id="tabbody"></div></div></div>`;
  $("#snav-sel").onchange = e => { location.hash = "#/stranka/" + sid + "/" + e.target.value; };
  const el = $("#tabbody");
  const T = {
    podatki: () => tabPodatki(el, ctx, obrati),
    obrati: () => listView(el, "obrati", ctx, { extra: canManage() ? '<button class="btn ghost sec" id="ob_nv">Naprave in prostori → oprema in čiščenje</button>' : "", bind: e2 => { const b = $("#ob_nv", e2); if (b) b.onclick = () => napraveVOpremo(ctx, () => {}); } }),
    tloris: () => tabTloris(el, ctx),
    osebje: async () => { el.innerHTML = '<h2>Zaposleni</h2><div id="t1"></div><h2 style="margin-top:20px">Usposabljanja</h2><div id="t2"></div>'; await listView($("#t1"), "osebje", ctx, { extra: '<button class="btn ghost sec" id="kart">Kartoteke zaposlenih (PDF)</button>' }); await listView($("#t2"), "usposabljanja", ctx); const kb = $("#kart"); if (kb) kb.onclick = () => kartotekePdf(ctx); },
    dobavitelji: () => listView(el, "dobavitelji", ctx),
    oprema: () => listView(el, "oprema", ctx, { extra: `<a class="btn ghost sec" href="#/qr/${sid}">QR kode naprav</a>` }),
    nacrti: () => tabNacrti(el, ctx),
    navodila: () => tabNavodila(el, ctx),
    evidence: () => tabEvidence(el, ctx),
    higiena: () => tabHigiena(el, ctx),
    capa: () => tabCapa(el, ctx),
    inspekcija: () => tabInspekcija(el, ctx),
    koledar: () => tabKoledar(el, ctx),
    priloge: () => tabPriloge(el, ctx),
    storitve: () => tabStoritve(el, ctx),
    uporabniki: () => tabUporabniki(el, ctx)
  };
  for (const [k, fn] of Object.entries(TABEXT)) T[k] = () => fn(el, ctx);
  if (tab !== "podatki" && zak(tab)) { el.innerHTML = await zaklenjenoHtml("tab:" + tab); return; }
  await (T[tab] || T.podatki)();
}

// logotip stranke: prikaže se na naslovnici dokumentov te stranke in v meniju uporabnikov stranke
function logoStrankeCard(el, s) {
  const im = SLOGO[s.id] && SLOGO[s.id].im;
  el.insertAdjacentHTML("beforeend", `<div class="card"><h2>Logotip podjetja</h2><p class="mut">Prikaže se na naslovnici PDF in Word dokumentov te stranke ter v meniju njenih uporabnikov. PNG, JPEG ali WebP do 1,5 MB.</p><div class="row"><img id="sl_prev" alt="Logotip ${esc(s.naziv)}" style="max-height:60px;max-width:180px;border:1px solid var(--line);border-radius:6px;padding:4px;background:#fff" ${im ? "" : "hidden"}><input type="file" id="sl_f" accept="image/png,image/jpeg,image/webp" style="max-width:260px" aria-label="Datoteka z logotipom"><button class="btn" id="sl_up">Naloži</button>${im ? '<button class="btn ghost sec" id="sl_del">Odstrani</button>' : ""}</div></div>`);
  if (im) { const r = new FileReader(); r.onload = () => { const p = $("#sl_prev"); if (p) p.src = r.result; }; r.readAsDataURL(new Blob([im.u8], { type: "image/jpeg" })); }
  const po = async () => { await loadStrankaLogo(s, true); if (ME.u.stranka_id === s.id) navStrankaLogo(); render(); };
  $("#sl_up").onclick = () => { const f = $("#sl_f").files[0]; if (!f) return toast("Izberite datoteko.", true); const rd = new FileReader(); rd.onload = async () => { try { await api("POST", "/api/stranka-logo/" + s.id, { tip: f.type, podatki: String(rd.result).split(",")[1] }); toast("Logotip shranjen"); await po(); } catch (e) { fail(e); } }; rd.readAsDataURL(f); };
  if (im) $("#sl_del").onclick = () => confirmBox("Odstranim logotip podjetja?", async () => { try { await api("DELETE", "/api/stranka-logo/" + s.id); toast("Logotip odstranjen"); await po(); } catch (e) { fail(e); } }, true);
}
// svetovalci stranke (samo administrator): kljukica dodeli ali odvzame stranko; svetovalec vidi samo dodeljene stranke
async function svetovalciCard(el, s) {
  const us = (await api("GET", "/api/uporabniki").catch(() => [])).filter(u => hasRole(u, "svetovalec")); if (!el.isConnected) return;
  el.insertAdjacentHTML("beforeend", `<div class="card" id="sv-card"><h2>Svetovalci</h2><p class="mut">Svetovalec vidi in ureja samo stranke, ki so mu dodeljene.</p>
    ${us.length ? `<div class="u-st-seznam">${us.map(u => `<label class="u-st"><input type="checkbox" data-sv="${u.id}" ${(u.stranke || []).includes(s.id) ? "checked" : ""} ${u.aktiven ? "" : "disabled"}> ${esc(u.ime)} <span class="mut">${esc(u.email)}${hasRole(u, "admin") ? " · administrator" : ""}${u.aktiven ? "" : " (neaktiven)"}</span></label>`).join("")}</div>` : '<p class="mut">Ni svetovalcev. Dodate jih v meniju <a href="#/uporabniki">Uporabniki</a> (vloga HACCP-svetovalec).</p>'}</div>`);
  $$("[data-sv]", el).forEach(c => c.onchange = async () => {
    const u = us.find(x => x.id === c.dataset.sv), nove = c.checked ? [...new Set((u.stranke || []).concat(s.id))] : (u.stranke || []).filter(x => x !== s.id);
    try { const r = await api("PUT", "/api/uporabniki/" + u.id, { stranke: nove }); u.stranke = r.stranke; toast(c.checked ? "Svetovalec dodeljen: " + u.ime : "Stranka odvzeta: " + u.ime); }
    catch (e) { c.checked = !c.checked; fail(e); }
  });
}
async function tabPodatki(el, ctx, obrati) {
  const s = ctx.stranka, d = await loadAll({ stranka_id: s.id }); if (isStaff()) await paketi().catch(() => {});
  const miss = missingData(d, s);
  const row = (l, v) => v ? `<tr><th style="width:38%">${l}</th><td>${esc(v)}</td></tr>` : "";
  const zaPregled = d.evidence.filter(e => e.status === "vneseno").length, odprteCapa = d.capa.filter(c => c.status !== "zaprto").length;
  el.innerHTML = `<div class="row"><button class="btn" id="ed">Uredi podatke</button><span class="sp"></span>${badge(s.status)}</div>
  ${miss.length ? `<p class="note">Manjkajoči podatki: ${miss.map(esc).join(", ")}.</p>` : ""}
  <div class="grid g2"><div class="card"><h2>Podjetje</h2><table class="t">${row("Naziv", s.naziv)}${row("Matična št.", s.maticna)}${row("Davčna št.", s.davcna)}${row("Naslov", s.naslov)}${row("Odgovorna oseba", s.odgovorna_oseba)}${row("E-naslov", s.email)}${row("Telefon", s.telefon)}${row("Dejavnost", [s.dejavnost].concat(s.dodatne_dejavnosti || []).filter((x, i, a) => x && a.indexOf(x) === i).join(", "))}${s.kratko_ime ? row("Kratko ime", s.kratko_ime) : ""}${row("Opis dejavnosti", s.opis_dejavnosti)}${isStaff() ? row("Paket", imePaketaStranke(s.paket)) + row("Interne opombe", s.notranje) : ""}<tr><th>Naslednji pregled</th><td>${dueBadge(s.naslednji_pregled)}</td></tr></table></div>
  <div class="card"><h2>Povezano gradivo</h2><div class="st-ploscice">${[["obrati", "Obrati", d.obrati.length], ["osebje", "Zaposleni", d.osebje.length], ["dobavitelji", "Dobavitelji", d.dobavitelji.length], ["oprema", "Oprema in instrumenti", d.oprema.length],
    ["nacrti", "HACCP načrti", d.nacrti.length, d.nacrti.length ? (d.nacrti.some(n => n.status === "potrjeno") ? "potrjen" : "ni potrjenega") : "", d.nacrti.length && !d.nacrti.some(n => n.status === "potrjeno") ? "warn" : ""], ["navodila", "Navodila in obrazci", d.navodila.length],
    ["evidence", "Evidence", d.evidence.length, zaPregled ? zaPregled + " za pregled" : "", zaPregled ? "warn" : ""], ["capa", "Odprte CAPA", odprteCapa, "", odprteCapa ? "bad" : ""]].map(([t, l, n, pod, cls]) => `<a class="st-pl ${cls || ""}" href="#/stranka/${s.id}/${t}"><b>${n}</b><span>${l}</span>${pod ? `<small>${esc(pod)}</small>` : ""}</a>`).join("")}</div></div></div>
  ${d.storitve.length ? `<div class="card"><h2>Zgodovina storitev in pregledov</h2><div class="tw"><table class="t"><tr><th>Datum</th><th>Vrsta</th><th>Minut</th><th>Opis</th></tr>${d.storitve.sort((a, b) => b.datum.localeCompare(a.datum)).slice(0, 8).map(x => `<tr><td>${fdate(x.datum)}</td><td>${esc(x.vrsta)}</td><td>${esc(x.minute || "")}</td><td>${esc((x.opis || "").slice(0, 120))}</td></tr>`).join("")}</table></div></div>` : ""}`;
  $("#ed").onclick = () => openForm("stranke", s, null, () => render());
  // nastavitve stranke (logotip, paket, svetovalci) skupaj v enem razdelku
  if (hasRole(ME.u, "admin", "svetovalec", "odgovorna")) {
    el.insertAdjacentHTML("beforeend", '<h2 class="st-razdelek">Nastavitve stranke</h2><div class="grid g3 st-nast" id="st_nast"></div>');
    const n = $("#st_nast", el); logoStrankeCard(n, s); await paketStrankeCard(n, s);
    if (hasRole(ME.u, "admin")) await svetovalciCard(n, s);
    else { await naloziIzdelovalca(s.id); const sv = (IZDELOVALEC.za[s.id] || {}).svetovalec; n.insertAdjacentHTML("beforeend", `<div class="card" id="st_sv"><h2>Svetovalec</h2>${sv ? `<p><b>${esc(imeZNazivom(sv))}</b>${sv.izobrazba ? ", " + esc(sv.izobrazba) : ""}<br>${esc([sv.podjetje, sv.email, sv.telefon].filter(Boolean).join(" · "))}</p>` : '<p class="note">Stranka nima dodeljenega svetovalca, zato HACCP načrta ni mogoče izdelati. Obrnite se na administratorja.</p>'}</div>`); }
  }
}

async function tabPriloge(el, ctx) {
  const rows = await D.list("priloge", { stranka_id: ctx.stranka_id });
  el.innerHTML = `<div class="row"><input type="file" id="pf" accept="image/*,application/pdf,text/plain" style="max-width:340px"><button class="btn" id="pu">Naloži prilogo</button><span class="mut">Slike, PDF, besedilo do 8 MB.</span></div><div class="tw"><table class="t"><tr><th>Datoteka</th><th>Velikost</th><th>Naloženo</th><th>Kdo</th></tr>${rows.map(r => `<tr><td><a href="/api/priloga/${r.id}" target="_blank" rel="noopener">${esc(r.ime)}</a></td><td>${Math.round(r.velikost / 1024)} kB</td><td>${fdt(r.ustvarjeno)}</td><td>${esc(r.ustvaril || "")}</td></tr>`).join("") || '<tr><td colspan="4" class="empty">Ni prilog.</td></tr>'}</table></div>`;
  $("#pu").onclick = async () => {
    const f = $("#pf").files[0]; if (!f) return toast("Izberite datoteko.", true);
    try { await uploadFile(f, ctx.stranka_id, null); toast("Naloženo"); tabPriloge(el, ctx); } catch (e) { fail(e); }
  };
}
// fotografije s telefona (pogosto 3–8 MB) se pred pošiljanjem zmanjšajo na največ 1600 px (JPEG); manjše slike, slike,
// ki jih brskalnik ne zna prebrati (npr. HEIC), in druge datoteke ostanejo nespremenjene
async function zmanjsajSliko(f, max) {
  max = max || 1600;
  if (!f || !/^image\/(jpeg|png|webp)$/.test(f.type) || f.size < 400e3 || typeof createImageBitmap !== "function") return f;
  try {
    const bm = await createImageBitmap(f, { imageOrientation: "from-image" }), k = Math.min(1, max / Math.max(bm.width, bm.height)), c = document.createElement("canvas");
    c.width = Math.round(bm.width * k); c.height = Math.round(bm.height * k);
    const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(bm, 0, 0, c.width, c.height); if (bm.close) bm.close();
    const b = await new Promise(r => c.toBlob(r, "image/jpeg", 0.82));
    return b && b.size < f.size ? new File([b], f.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" }) : f;
  } catch { return f; }
}
function uploadFile(f, sid, povezava, obrat) {
  return new Promise((ok, no) => {
    const rd = new FileReader();
    rd.onload = async () => { try { ok(await api("POST", "/api/priloga", { stranka_id: sid, obrat_id: obrat || null, ime: f.name, tip: f.type || "text/plain", povezava, podatki: String(rd.result).split(",")[1] })); } catch (e) { no(e); } };
    rd.onerror = () => no(new Error("Datoteke ni mogoče prebrati."));
    rd.readAsDataURL(f);
  });
}

// koledar stranke: dogodki (urejanje) in samodejni roki iz drugih razdelkov (enako kot v skupnem koledarju)
async function tabKoledar(el, ctx) {
  el.innerHTML = '<div id="kd_dog"></div><h2 style="margin-top:22px">Samodejni roki</h2><p class="mut">Roki iz drugih razdelkov: poteki usposabljanj in zdravniških pregledov, servisi opreme, ocene dobaviteljev, roki neskladnosti (CAPA), pregledi dokumentov. Uredite jih v razdelku, iz katerega izhajajo.</p><div id="kd_avto"></div>';
  await listView($("#kd_dog", el), "dogodki", ctx);
  const d = await loadAll({ stranka_id: ctx.stranka_id }), dl = collectDeadlines(d).filter(x => x.stranka_id === ctx.stranka_id && !/\/koledar$/.test(x.href) && x.tip !== "Čiščenje");
  const av = $("#kd_avto", el); if (!av) return;
  av.innerHTML = dl.length ? `<div class="tw"><table class="t"><thead><tr><th>Rok</th><th>Vrsta</th><th>Opis</th><th></th></tr></thead><tbody>${dl.map(x => `<tr><td>${dueBadge(x.datum)}</td><td>${esc(x.tip)}</td><td>${esc(x.naslov)}</td><td><a class="btn sm ghost sec" href="${esc(x.href)}">Odpri</a></td></tr>`).join("")}</tbody></table></div>` : '<p class="empty">Ni samodejnih rokov – vnesite datume (npr. »Veljavno do« pri usposabljanju, »Naslednji servis« pri opremi).</p>';
}
async function tabStoritve(el, ctx) {
  el.innerHTML = '<div id="st_kpi"></div><div id="st_list"></div>'; pogodbeKartica(el, ctx); // predloge pogodb (nadzor, pomoč po inšpekciji)
  // števci se izračunajo ob vsakem nalaganju seznama (tudi po shranjevanju ali brisanju storitve)
  const kpi = rows => { const min = rows.reduce((a, r) => a + (Number(r.minute) || 0), 0), ob = rows.filter(r => r.vrsta === "Obisk na lokaciji").length;
    $("#st_kpi", el).innerHTML = `<div class="kpis"><div class="kpi"><b>${rows.length}</b><span>${mn(rows.length, ["opravljena storitev", "opravljeni storitvi", "opravljene storitve", "opravljenih storitev"])}</span></div><div class="kpi"><b>${fnum(min / 60, 1, 1)} h</b><span>skupaj porabljenega časa</span></div><div class="kpi"><b>${ob}</b><span>${mn(ob, ["obisk", "obiska", "obiski", "obiskov"])} na lokaciji</span></div></div>`; };
  await listView($("#st_list", el), "storitve", ctx, { onRows: kpi, extra: `<button class="btn ghost sec" id="povz">Povzetek dela za stranko</button>`, bind: (e3, rows) => { $("#povz", e3).onclick = () => {
    const min = rows.reduce((a, r) => a + (Number(r.minute) || 0), 0);
    const txt = ["Povzetek dela za stranko: " + ctx.stranka.naziv, "Datum izpisa: " + fdate(today()), "", ...rows.slice().sort((a, b) => a.datum.localeCompare(b.datum)).map(r => `${fdate(r.datum)} | ${r.vrsta || ""} | ${fnum(r.minute || 0)} min | ${r.opis || ""}`), "", "Skupaj: " + mnx(rows.length, ["storitev", "storitvi", "storitve", "storitev"]) + ", " + fnum(min / 60, 1, 1) + " ure."].join("\n");
    modal("Povzetek dela", `<textarea style="min-height:300px" readonly>${esc(txt)}</textarea>`, [{ t: "Zapri", cls: "ghost sec" }, { t: "Prenesi .txt", fn: () => { dlBlob(new Blob([txt], { type: "text/plain" }), "povzetek-" + ctx.stranka.naziv + ".txt"); return false; } }]);
  }; } });
}
function dlBlob(b, name) { if (!canPrint(name)) return; const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = name.replace(/[^\w.\-šđčćžŠĐČĆŽ ]/g, "_"); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }

async function tabUporabniki(el, ctx) {
  const all = await api("GET", "/api/uporabniki");
  const us = all.filter(u => u.stranka_id === ctx.stranka_id);
  el.innerHTML = `<div class="row"><span class="sp"></span><button class="btn" id="un">+ Nov uporabnik</button></div><div class="tw"><table class="t"><tr><th>Ime</th><th>E-naslov</th><th>Vloga</th><th>Stanje</th><th>Zadnja prijava</th></tr>${us.map(u => `<tr class="click" data-id="${u.id}"><td>${esc(u.ime)}</td><td>${esc(u.email)}</td><td>${esc(ROLE[u.vloga])}</td><td>${u.aktiven ? '<span class="badge ok">aktiven</span>' : '<span class="badge bad">onemogočen</span>'}</td><td>${fdt(u.zadnja_prijava)}</td></tr>`).join("") || '<tr><td colspan="5" class="empty">Ni uporabnikov.</td></tr>'}</table></div><p class="mut">Zaposleni lahko vnašajo evidence; odgovorna oseba potrjuje zapise in ureja podatke podjetja.</p>`;
  $("#un").onclick = () => userForm(null, ctx.stranka_id, () => tabUporabniki(el, ctx));
  $$("tr[data-id]", el).forEach(tr => tr.onclick = () => userForm(us.find(u => u.id === tr.dataset.id), ctx.stranka_id, () => tabUporabniki(el, ctx)));
}
function userForm(u, sid, done) {
  const roles = hasRole(ME.u, "odgovorna") ? ["zaposleni"] : ["odgovorna", "zaposleni"];
  modal(u ? "Uredi uporabnika" : "Nov uporabnik", `<p class="err" id="ferr"></p><div class="fgrid"><label class="f req"><span>Ime in priimek</span><input id="u_i" value="${esc(u ? u.ime : "")}"></label><label class="f req"><span>E-naslov</span><input id="u_e" type="email" value="${esc(u ? u.email : "")}" ${u ? "disabled" : ""}></label>${u ? "" : `<label class="f"><span>Vloga</span><select id="u_v">${roles.map(r => `<option value="${r}">${ROLE[r]}</option>`).join("")}</select></label>`}<label class="f ${u ? "" : "req"}"><span>${u ? "Novo začasno geslo (pustite prazno, če ne spreminjate)" : "Začasno geslo (vsaj 10 znakov)"}</span><input id="u_p" type="text" autocomplete="off"></label>${u ? `<label class="f"><span>Aktiven</span><input type="checkbox" id="u_a" ${u.aktiven ? "checked" : ""}></label>` : ""}</div>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: async () => {
    // napake ob poljih, preden gre zahteva na strežnik (enako kot v Uporabnikih)
    $$(".f-err", $("#dlg-b")).forEach(x => x.remove()); $$(".f.bad", $("#dlg-b")).forEach(x => x.classList.remove("bad")); $("#ferr").textContent = "";
    const nap = [];
    if (!$("#u_i").value.trim()) nap.push(["u_i", "Vpišite ime in priimek."]);
    if (!u && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test($("#u_e").value.trim())) nap.push(["u_e", "Vpišite veljaven e-naslov."]);
    if ((!u || $("#u_p").value) && $("#u_p").value.trim().length < 10) nap.push(["u_p", "Geslo mora imeti vsaj 10 znakov."]);
    for (const [id, m] of nap) oznaciPolje($("#" + id), m);
    if (nap.length) { $("#" + nap[0][0]).focus(); return false; }
    try {
      if (u) { const b = { ime: $("#u_i").value, aktiven: $("#u_a").checked }; if ($("#u_p").value) b.geslo = $("#u_p").value; await api("PUT", "/api/uporabniki/" + u.id, b); }
      else await api("POST", "/api/uporabniki", { ime: $("#u_i").value, email: $("#u_e").value, geslo: $("#u_p").value, vloga: $("#u_v").value, stranka_id: sid });
      toast("Shranjeno"); done();
    } catch (e) { $("#ferr").textContent = e.message; return false; }
  } }]);
}

route(/^\/stranka\/([\w-]+)(?:\/([a-z]+))?$/, pageStranka, "Stranka", "stranke");

// Kartoteka zaposlenega: osnovni podatki, veljavnosti in usposabljanja, kjer je oseba navedena med udeleženci. En list na osebo, za podpis.
async function kartotekePdf(ctx) {
  try {
    const [os, us] = await Promise.all([D.list("osebje", { stranka_id: ctx.stranka_id }), D.list("usposabljanja", { stranka_id: ctx.stranka_id })]);
    if (!os.length) return toast("Ni zaposlenih.", true);
    const blob = pdfBuild({ naslov: "Kartoteke zaposlenih", stranka: ctx.stranka.naziv, verzija: "1.0" }, d => {
      os.forEach((o, i) => {
        if (i) d.newPage();
        d.h(1, o.ime);
        d.table(["Podatek", "Vrednost"], [["Delovno mesto", o.funkcija || ""], ["E-naslov", o.email || ""], ["Higienski minimum / izobraževanje do", o.higienski_do ? fdate(o.higienski_do) : ""], ["Zdravniški pregled do", o.zdravniski_do ? fdate(o.zdravniski_do) : ""], ["Opomba", o.opomba || ""]], [40, 60]);
        // udeleženci so seznam imen (vejica, podpičje ali nova vrstica): ujemanje po celem imenu (»Ana« ni »Jana Novak«), prazno ime nima usposabljanj
        const ime = String(o.ime || "").trim().toLowerCase().replace(/\s+/g, " "), mine = ime ? us.filter(u => String(u.udelezenci || "").split(/[,;\n]+/).map(x => x.trim().toLowerCase().replace(/\s+/g, " ")).includes(ime)) : [];
        d.h(2, "Usposabljanja");
        if (mine.length) d.table(["Tema", "Datum", "Veljavno do", "Izvajalec"], mine.map(u => [u.tema, u.datum ? fdate(u.datum) : "", u.veljavno_do ? fdate(u.veljavno_do) : "", u.izvajalec || ""]), [40, 16, 18, 26]);
        else d.p("Ni zabeleženih usposabljanj.", { col: "m" });
        d.p("Seznanjen(a) z navodili: ______________________   Podpis zaposlenega: ______________________   Datum: ______________", { size: 9, col: "m" });
      });
    });
    dlBlob(blob, "kartoteke-" + ctx.stranka.naziv + ".pdf");
  } catch (e) { fail(e); }
}

// obrazec stranke: podatki podjetja po davčni številki ali nazivu – seznam zavezancev FURS (matična št., dejavnost, naziv, naslov),
// sicer register EU VIES (naziv, naslov za zavezance za DDV); povezava na bizi.si za ostale podatke
function podjetjePoDavcni() {
  const inp = $("#f_davcna"); if (!inp || $("#f_vies")) return;
  inp.closest("label").insertAdjacentHTML("afterend", `<div class="f wide" id="vies-ovoj" style="margin-top:-4px"><div style="display:flex;flex-wrap:wrap;gap:6px 12px;align-items:center"><button type="button" class="btn ghost sec sm" id="f_vies">Izpolni po davčni številki</button><a id="f_bizi" target="_blank" rel="noopener" href="https://www.bizi.si/">Poišči na bizi.si</a><small class="mut" id="vies_r" style="flex:1 1 240px">Vpišite davčno številko ali začnite tipkati naziv podjetja: podatki se izpolnijo iz uradnih registrov (FURS, VIES).</small></div></div>`);
  const r = $("#vies_r"), bizi = () => { $("#f_bizi").href = "https://www.bizi.si/iskanje/?q=" + encodeURIComponent(inp.value.trim() || ($("#f_naziv") || {}).value || ""); };
  inp.addEventListener("input", bizi); bizi();
  // vpis podatkov: prazna polja se izpolnijo, za drugačne vpisane vrednosti se ponudi zamenjava
  const vpisi = p => {
    const razl = [];
    for (const [k, v] of [["naziv", p.naziv], ["naslov", p.naslov], ["davcna", p.davcna], ["maticna", p.maticna], ["dejavnost", p.dejavnost], ["skd", p.skd], ["pravna_oblika", p.pravna_oblika], ["nosilec", p.nosilec], ["odgovorna_oseba", p.nosilec]]) {
      const el = $("#f_" + k); if (!el || !v) continue;
      if (!el.value.trim()) el.value = v; else if (el.value.trim() !== v) razl.push([k, v]);
    }
    const opis = [p.naziv, p.naslov, p.maticna ? "mat. št. " + p.maticna : "", p.skd ? "SKD " + p.skd : "", p.nosilec ? "nosilec " + p.nosilec : "", p.zavezanec === true ? "zavezanec za DDV" : p.zavezanec === false && p.vir === "FURS" ? "ni zavezanec za DDV" : ""].filter(Boolean).map(esc).join(", ");
    r.innerHTML = (razl.length ? `Register ${esc(p.vir || "")}: ${opis}. Vpisani podatki se razlikujejo. <a href="#" id="vies_u">Uporabi podatke iz registra</a>` : `Izpolnjeno iz registra ${esc(p.vir || "")}: ${opis}.`);
    const u = $("#vies_u"); if (u) u.onclick = e => { e.preventDefault(); for (const [k, v] of razl) $("#f_" + k).value = v; r.textContent = "Podatki iz registra so vpisani."; };
    bizi();
  };
  $("#f_vies").onclick = async () => {
    const d = inp.value.trim(); if (!d) { r.textContent = "Najprej vpišite davčno številko (ali začnite tipkati naziv)."; return; }
    r.textContent = "Iščem v registru …"; $("#f_vies").disabled = true;
    try {
      const p = await api("GET", "/api/podjetje/" + encodeURIComponent(d)); inp.value = p.davcna;
      if (!p.naziv) { r.textContent = "Številke ni v registrih. Podatke vpišite ročno (poglejte na bizi.si)."; return; }
      vpisi(p);
    } catch (e) { r.textContent = e.message; } finally { $("#f_vies").disabled = false; }
  };
  // predlogi pri vpisu naziva (seznam FURS)
  const naz = $("#f_naziv"); if (!naz) return;
  naz.setAttribute("autocomplete", "off");
  naz.closest("label").insertAdjacentHTML("beforeend", `<div id="naz_p" class="naz-predlogi" role="listbox" hidden></div>`);
  const pr = $("#naz_p"); let t = null, zadnji = "";
  naz.addEventListener("input", () => {
    clearTimeout(t); const q = naz.value.trim(); if (q.length < 3) { pr.hidden = true; return; }
    t = setTimeout(async () => {
      if (q === zadnji) return; zadnji = q;
      let o; try { o = await api("GET", "/api/podjetje?q=" + encodeURIComponent(q)); } catch { return; }
      if (naz.value.trim() !== q) return;
      pr.innerHTML = o.zadetki.map((z, i) => `<button type="button" role="option" data-i="${i}"><b>${esc(z.naziv)}</b><small>${esc([z.naslov, "davčna " + z.davcna].filter(Boolean).join(" · "))}</small></button>`).join("");
      pr.hidden = !o.zadetki.length;
      $$("button", pr).forEach(b => b.onclick = () => { const z = o.zadetki[+b.dataset.i]; pr.hidden = true; naz.value = ""; vpisi(z); });
    }, 300);
  });
  naz.addEventListener("keydown", e => { if (e.key === "Escape" && !pr.hidden) { e.stopPropagation(); e.preventDefault(); pr.hidden = true; } });
}
