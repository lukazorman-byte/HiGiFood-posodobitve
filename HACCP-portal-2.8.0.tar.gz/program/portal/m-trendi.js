// Trendi temperatur naprav (hladilniki, zamrzovalniki, vitrine): graf z dovoljenim območjem in opozorilo,
// ko se naprava v zadnjih dneh segreva proti zgornji meji – še preden pride do odstopanja.
const TR_HLAD = /hlad|zamrz|vitrin|šoker|soker|ledomat/i;
// meritve naprave (tudi pred preimenovanjem) v zadnjih »dni« dneh, urejene po času
function trendTocke(rows, ctx, naziv, dni) {
  const im = imenaNaprave(ctx, naziv), od = Date.now() - dni * 864e5;
  return rows.filter(r => r.vrsta === "temperatura" && im.has(r.oprema) && r.vrednost !== "" && r.vrednost !== null && isFinite(Number(r.vrednost)) && Date.parse(r.cas) >= od)
    .map(r => ({ t: Date.parse(r.cas), v: Number(r.vrednost), min: r.min === "" || r.min == null ? null : Number(r.min), max: r.max === "" || r.max == null ? null : Number(r.max), ok: r.skladno !== false }))
    .sort((a, b) => a.t - b.t);
}
// meje naprave: iz opreme, sicer iz zadnjega zapisa
function trendMeje(ctx, naziv, pts) {
  const o = ((ctx && ctx.opremaRows) || []).find(x => x.naziv === naziv) || {}, z = pts[pts.length - 1] || {}, n = v => v === "" || v == null || !isFinite(Number(v)) ? null : Number(v);
  return { min: n(o.meja_min) !== null ? n(o.meja_min) : z.min, max: n(o.meja_max) !== null ? n(o.meja_max) : z.max };
}
// ocena trenda: naklon (°C na dan, linearna regresija zadnjih 14 dni) in povprečje zadnjih treh meritev glede na zgornjo mejo
function trendOcena(pts, meje) {
  const od = Date.now() - 14 * 864e5, p = pts.filter(x => x.t >= od);
  if (p.length < 4 || meje.max === null || meje.max === undefined) return { segreva: false, naklon: null };
  const xs = p.map(x => (x.t - p[0].t) / 864e5), ys = p.map(x => x.v), n = p.length, mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n;
  const sxx = xs.reduce((a, x) => a + (x - mx) ** 2, 0), naklon = sxx ? xs.reduce((a, x, i) => a + (x - mx) * (ys[i] - my), 0) / sxx : 0;
  const zadnje = ys.slice(-3).reduce((a, b) => a + b, 0) / Math.min(3, ys.length), razpon = meje.min !== null && meje.min !== undefined ? Math.max(1, meje.max - meje.min) : 4;
  // segreva se: narašča vsaj 0,1 °C na dan in je v zgornji četrtini dovoljenega območja (še ne čez mejo)
  const segreva = naklon >= 0.1 && zadnje >= meje.max - razpon / 4;
  const dni = naklon > 0 && zadnje < meje.max ? Math.max(0, Math.round((meje.max - zadnje) / naklon)) : null;
  return { segreva, naklon: Math.round(naklon * 100) / 100, zadnje: Math.round(zadnje * 10) / 10, dni };
}
// graf SVG: dovoljeno območje (zeleno), meritve (črta), odstopanja (rdeče pike)
function trendSvg(pts, meje) {
  const W = 680, H = 230, L = 44, Rr = 12, T = 12, B = 30;
  if (!pts.length) return '<p class="mut">V izbranem obdobju ni meritev.</p>';
  const vs = pts.map(p => p.v).concat([meje.min, meje.max].filter(v => v !== null && v !== undefined));
  let lo = Math.min(...vs), hi = Math.max(...vs); if (hi - lo < 4) { const s = (hi + lo) / 2; lo = s - 2; hi = s + 2; } lo = Math.floor(lo - 1); hi = Math.ceil(hi + 1);
  const t0 = pts[0].t, t1 = Math.max(pts[pts.length - 1].t, t0 + 864e5), X = t => L + (t - t0) / (t1 - t0) * (W - L - Rr), Y = v => T + (hi - v) / (hi - lo) * (H - T - B);
  const korak = Math.max(1, Math.ceil((hi - lo) / 6)), osi = [];
  for (let v = Math.ceil(lo); v <= hi; v += korak) osi.push(`<line x1="${L}" x2="${W - Rr}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}" stroke="var(--line)" stroke-width="1"/><text x="${L - 6}" y="${(Y(v) + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--mut)">${fnum(v)}</text>`);
  const dnevi = Math.max(1, Math.round((t1 - t0) / 864e5)), kd = Math.max(1, Math.ceil(dnevi / 6)), dat = [];
  for (let i = 0; i <= dnevi; i += kd) { const t = t0 + i * 864e5, d = new Date(t); dat.push(`<text x="${X(t).toFixed(1)}" y="${H - 10}" text-anchor="middle" font-size="11" fill="var(--mut)">${d.getDate()}. ${d.getMonth() + 1}.</text>`); }
  const pas = meje.max !== null && meje.max !== undefined ? `<rect x="${L}" width="${W - L - Rr}" y="${Y(Math.min(hi, meje.max)).toFixed(1)}" height="${(Y(meje.min !== null && meje.min !== undefined ? Math.max(lo, meje.min) : lo) - Y(Math.min(hi, meje.max))).toFixed(1)}" fill="var(--okbg)"/>` +
    `<line x1="${L}" x2="${W - Rr}" y1="${Y(meje.max).toFixed(1)}" y2="${Y(meje.max).toFixed(1)}" stroke="var(--bad)" stroke-dasharray="5 4" stroke-width="1.2"/><text x="${W - Rr}" y="${(Y(meje.max) - 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--bad)">meja ${fnum(meje.max)} °C</text>` : "";
  const crta = pts.map(p => X(p.t).toFixed(1) + "," + Y(p.v).toFixed(1)).join(" ");
  const pike = pts.map(p => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="${p.ok ? 2.5 : 4}" fill="${p.ok ? "var(--acc)" : "var(--bad)"}"><title>${esc(fdt(new Date(p.t).toISOString()))}: ${esc(fnum(p.v))} °C</title></circle>`).join("");
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px;display:block" role="img" aria-label="Graf temperature">${pas}${osi.join("")}${dat.join("")}<polyline points="${crta}" fill="none" stroke="var(--acc)" stroke-width="1.6"/>${pike}</svg>`;
}
const trendBesedilo = (o, meje) => o.naklon === null ? "Za oceno trenda je potrebnih vsaj 4 meritev v zadnjih 14 dneh in določena zgornja meja." :
  o.segreva ? `Naprava se segreva: ${o.naklon > 0 ? "+" : ""}${fnum(o.naklon)} °C na dan, zadnje meritve povprečno ${fnum(o.zadnje)} °C (meja ${fnum(meje.max)} °C)${o.dni !== null ? ", meja bo dosežena v približno " + mnx(o.dni, ["dnevu", "dneh", "dneh", "dneh"]) : ""}. Preverite tesnila, nastavitev termostata in polnjenje.` :
  `Trend v zadnjih 14 dneh: ${o.naklon > 0 ? "+" : ""}${fnum(o.naklon)} °C na dan – brez opozorila.`;
// naprave za trend: hladilna oprema in naprave iz zapisov temperature
function trendNaprave(rows, ctx) {
  const s = new Set(((ctx && ctx.opremaRows) || []).filter(o => TR_HLAD.test(o.tip || "") || TR_HLAD.test(o.naziv || "")).filter(o => o.aktivno !== false).map(o => o.naziv));
  for (const r of rows) if (r.vrsta === "temperatura" && r.oprema) s.add(r.oprema);
  return [...s].filter(Boolean).sort((a, b) => a.localeCompare(b, "sl"));
}
// opozorila za stran Danes: naprave, ki se segrevajo
function trendOpozorila(rows, ctx) {
  return trendNaprave(rows, ctx).map(n => { const p = trendTocke(rows, ctx, n, 14), m = trendMeje(ctx, n, p), o = trendOcena(p, m); return o.segreva ? { naprava: n, o, m } : null; }).filter(Boolean);
}
// kartica v zavihku Evidence: izbira naprave in obdobja, graf, ocena trenda
function trendKartica(el, ctx, rows) {
  const nap = trendNaprave(rows, ctx); if (!el) return;
  if (!nap.length) { el.innerHTML = ""; return; }
  const sh = (() => { try { return JSON.parse(sessionStorage.getItem("trend") || "{}"); } catch { return {}; } })();
  el.innerHTML = `<div class="card" id="trend_k"><div class="row" style="margin:0 0 8px"><h2 style="margin:0">Trend temperature</h2><span class="sp"></span>
    <select id="tr_n" aria-label="Naprava" style="max-width:240px">${nap.map(n => `<option ${sh.n === n ? "selected" : ""}>${esc(n)}</option>`).join("")}</select>
    <select id="tr_d" aria-label="Obdobje" style="max-width:150px">${[[14, "14 dni"], [30, "30 dni"], [90, "90 dni"]].map(([d, l]) => `<option value="${d}" ${+sh.d === d ? "selected" : ""}>${l}</option>`).join("")}</select></div><div id="tr_g"></div><p id="tr_o" style="margin:6px 0 0"></p></div>`;
  const risi = () => {
    const n = $("#tr_n", el).value, d = +$("#tr_d", el).value || 30; try { sessionStorage.setItem("trend", JSON.stringify({ n, d })); } catch {}
    const p = trendTocke(rows, ctx, n, d), m = trendMeje(ctx, n, p), o = trendOcena(trendTocke(rows, ctx, n, 14), m);
    $("#tr_g", el).innerHTML = trendSvg(p, m); const t = $("#tr_o", el); t.textContent = trendBesedilo(o, m); t.className = o.segreva ? "note" : "mut";
  };
  $("#tr_n", el).onchange = $("#tr_d", el).onchange = risi; risi();
}
