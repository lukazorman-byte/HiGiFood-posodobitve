// Jezik vmesnika za zaposlene (Moj račun → Jezik): angleščina ali hrvaščina/bosanščina.
// Prevede se samo besedilo vmesnika, ki se v celoti ujema z vnosom v slovarju (gumbi, naslovi, polja obrazcev evidenc, stran Danes);
// podatki, ki jih vnesejo uporabniki (imena, opombe, navodila), ostanejo nespremenjeni. Navodila se prevedejo z gumbom »Prevod« (DeepL).
const I18N = {
  "Nadzorna plošča": ["Dashboard", "Nadzorna ploča"], "Danes (opravila)": ["Today (tasks)", "Danas (zadaci)"], "Danes": ["Today", "Danas"], "Stranke": ["Clients", "Klijenti"],
  "Moje podjetje": ["My company", "Moja tvrtka"], "Pregled zapisov": ["Records review", "Pregled zapisa"], "Koledar in roki": ["Calendar and deadlines", "Kalendar i rokovi"],
  "Odjava": ["Log out", "Odjava"], "Prijavi napako": ["Report a problem", "Prijavi grešku"], "Iskanje (/)": ["Search (/)", "Pretraga (/)"], "Vsakodnevno delo": ["Daily work", "Svakodnevni rad"],
  "Shrani": ["Save", "Spremi"], "Prekliči": ["Cancel", "Odustani"], "Zapri": ["Close", "Zatvori"], "Vnesi": ["Enter", "Unesi"], "Potrdi": ["Confirm", "Potvrdi"], "Uredi": ["Edit", "Uredi"],
  "+ Nov zapis": ["+ New record", "+ Novi zapis"], "+ Dodaj": ["+ Add", "+ Dodaj"], "Nov zapis": ["New record", "Novi zapis"], "Vrsta zapisa": ["Record type", "Vrsta zapisa"],
  "Shranjeno": ["Saved", "Spremljeno"], "shranjeno": ["saved", "spremljeno"], "Zapisano": ["Recorded", "Zapisano"], "Shranjeno – odstopanje.": ["Saved – deviation.", "Spremljeno – odstupanje."],
  "Shranjeno – odstopanje. Odprta je neskladnost z rokom jutri; ukrep je v zavihku Neskladnosti.": ["Saved – deviation. A non-conformity has been opened (due tomorrow); see the Non-conformities tab.", "Spremljeno – odstupanje. Otvorena je nesukladnost s rokom sutra; mjera je u kartici Nesukladnosti."],
  "Hiter vnos temperature": ["Quick temperature entry", "Brzi unos temperature"], "Vnosi, ki jih je treba opraviti": ["Entries to be made", "Unosi koje treba obaviti"],
  "Vsi redni vnosi so opravljeni.": ["All regular entries are done.", "Svi redovni unosi su obavljeni."], "Čiščenje": ["Cleaning", "Čišćenje"], "Ukrepi z rokom v tem tednu": ["Actions due this week", "Mjere s rokom ovaj tjedan"],
  "Ni nujnih ukrepov.": ["No urgent actions.", "Nema hitnih mjera."], "ODSTOPANJE": ["DEVIATION", "ODSTUPANJE"], "Stranka": ["Client", "Klijent"], "Danes za opraviti": ["To do today", "Za danas"],
  "Opravljeno: ": ["Done: ", "Obavljeno: "], "Čas": ["Time", "Vrijeme"], "Vrsta": ["Type", "Vrsta"], "Podatek": ["Data", "Podatak"], "Ocena": ["Assessment", "Ocjena"], "Vnesel": ["Entered by", "Unio"], "Stanje": ["Status", "Stanje"],
  "skladno": ["compliant", "sukladno"], "odstopanje": ["deviation", "odstupanje"], "vneseno": ["entered", "uneseno"], "potrjeno": ["confirmed", "potvrđeno"], "odprto": ["open", "otvoreno"], "zaprto": ["closed", "zatvoreno"], "v izvajanju": ["in progress", "u tijeku"],
  "Opomba": ["Note", "Napomena"], "Fotografija (neobvezno)": ["Photo (optional)", "Fotografija (neobavezno)"], "Obrat": ["Site", "Objekt"], "Razlog popravka (obvezno)": ["Reason for correction (required)", "Razlog ispravka (obavezno)"],
  // vrste evidenc
  "Prevzem blaga": ["Goods receipt", "Prijem robe"], "Temperatura hladilnika / zamrzovalnika": ["Fridge / freezer temperature", "Temperatura hladnjaka / zamrzivača"], "Toplotna obdelava": ["Heat treatment", "Toplinska obrada"],
  "Hlajenje": ["Cooling", "Hlađenje"], "Čiščenje in razkuževanje": ["Cleaning and disinfection", "Čišćenje i dezinfekcija"], "Notranji higienski pregled": ["Internal hygiene check", "Interni higijenski pregled"],
  "Kontrola opreme / instrumenta": ["Equipment / instrument check", "Kontrola opreme / instrumenta"], "Sledljivost / vaja odpoklica": ["Traceability / recall drill", "Sljedivost / vježba povlačenja"],
  "Mikrobiološki bris / analiza": ["Microbiological swab / analysis", "Mikrobiološki bris / analiza"], "Hitri test čiščenja (ATP, beljakovine, alergen, razkužilo)": ["Rapid cleaning test (ATP, protein, allergen, disinfectant)", "Brzi test čišćenja (ATP, proteini, alergen, dezinficijens)"],
  "DDD: obisk izvajalca": ["Pest control: contractor visit", "DDD: posjet izvođača"], "DDD: opažanje škodljivcev": ["Pest control: pest sighting", "DDD: uočeni štetnici"], "Zdravstvena izjava zaposlenega": ["Employee health declaration", "Zdravstvena izjava zaposlenika"],
  "Analiza / laboratorijski izvid": ["Analysis / laboratory report", "Analiza / laboratorijski nalaz"], "Pregled embalaže": ["Packaging check", "Pregled ambalaže"], "Drugo (dejavnosti, prilagojeno)": ["Other (custom)", "Drugo (prilagođeno)"],
  // polja obrazcev evidenc
  "Dobavitelj": ["Supplier", "Dobavljač"], "Izdelek": ["Product", "Proizvod"], "Izdelek / surovina": ["Product / raw material", "Proizvod / sirovina"], "Šarža (LOT)": ["Batch (LOT)", "Serija (LOT)"], "Rok uporabe": ["Use-by date", "Rok uporabe"],
  "Temperatura ob prevzemu (°C)": ["Temperature at receipt (°C)", "Temperatura pri prijemu (°C)"], "Največja dovoljena (°C)": ["Maximum allowed (°C)", "Najviša dopuštena (°C)"],
  "Embalaža nepoškodovana, čista": ["Packaging intact and clean", "Ambalaža neoštećena, čista"], "Dokumentacija (dobavnica, sledljivost) v redu": ["Documents (delivery note, traceability) OK", "Dokumentacija (otpremnica, sljedivost) u redu"],
  "Naprava": ["Appliance", "Uređaj"], "Izmerjena temperatura (°C)": ["Measured temperature (°C)", "Izmjerena temperatura (°C)"], "Dovoljeno od (°C)": ["Allowed from (°C)", "Dopušteno od (°C)"], "Dovoljeno do (°C)": ["Allowed up to (°C)", "Dopušteno do (°C)"],
  "Prenese se iz naprave; določi odgovorna oseba.": ["Taken from the appliance; set by the responsible person.", "Preuzima se iz uređaja; određuje odgovorna osoba."],
  "Temperatura v jedru (°C)": ["Core temperature (°C)", "Temperatura u jezgri (°C)"], "Najmanj (°C)": ["Minimum (°C)", "Najmanje (°C)"], "Čas vzdrževanja (min)": ["Holding time (min)", "Vrijeme održavanja (min)"], "Mejna vrednost po HACCP načrtu.": ["Critical limit from the HACCP plan.", "Granična vrijednost prema HACCP planu."],
  "Začetna temperatura (°C)": ["Initial temperature (°C)", "Početna temperatura (°C)"], "Končna temperatura (°C)": ["Final temperature (°C)", "Završna temperatura (°C)"], "Trajanje hlajenja (min)": ["Cooling time (min)", "Trajanje hlađenja (min)"],
  "Največ končna (°C)": ["Maximum final (°C)", "Najviše završna (°C)"], "Največ trajanje (min)": ["Maximum duration (min)", "Najviše trajanje (min)"],
  "Območje / površina / naprava": ["Area / surface / appliance", "Područje / površina / uređaj"], "Sredstvo": ["Agent", "Sredstvo"], "Izvedeno po navodilu": ["Done according to instructions", "Obavljeno prema uputi"], "Vizualna kontrola – čisto": ["Visual check – clean", "Vizualna kontrola – čisto"],
  "Osebna higiena in oblačila v redu": ["Personal hygiene and clothing OK", "Osobna higijena i odjeća u redu"], "Površine in oprema čiste": ["Surfaces and equipment clean", "Površine i oprema čisti"],
  "Skladišče urejeno, ločeni alergeni in surovo/gotovo": ["Storage tidy, allergens and raw/cooked separated", "Skladište uređeno, odvojeni alergeni i sirovo/gotovo"], "Znakov škodljivcev ni": ["No signs of pests", "Nema znakova štetnika"],
  "Odpadki pravilno shranjeni": ["Waste stored correctly", "Otpad pravilno pohranjen"], "Umivalniki opremljeni (milo, papir)": ["Hand basins equipped (soap, paper)", "Umivaonici opremljeni (sapun, papir)"],
  "Zaposleni": ["Employee", "Zaposlenik"], "Ima simptome (driska, bruhanje, vročina, gnojne rane, kožne okužbe)": ["Has symptoms (diarrhoea, vomiting, fever, infected wounds, skin infections)", "Ima simptome (proljev, povraćanje, vrućica, gnojne rane, kožne infekcije)"],
  "Ukrep": ["Action", "Mjera"], "Ukrep / odločitev odgovorne osebe": ["Action / decision of the responsible person", "Mjera / odluka odgovorne osobe"], "Oprema / instrument": ["Equipment / instrument", "Oprema / instrument"],
  "Deluje pravilno": ["Works correctly", "Radi ispravno"], "Umerjanje / servis veljaven": ["Calibration / service valid", "Umjeravanje / servis valjan"], "Vrednost": ["Value", "Vrijednost"], "Rezultat": ["Result", "Rezultat"], "Uspešno": ["Successful", "Uspješno"],
  "Škodljivec": ["Pest", "Štetnik"], "Kje": ["Where", "Gdje"], "Ugotovitve": ["Findings", "Nalazi"], "Najmanj": ["Minimum", "Najmanje"], "Največ": ["Maximum", "Najviše"],
  // ocena v obrazcu
  "skladno z mejami": ["within limits", "unutar granica"], "zunaj mej – odstopanje": ["outside limits – deviation", "izvan granica – odstupanje"],
  "ODSTOPANJE od mej – ob shranjevanju se odpre neskladnost": ["DEVIATION from limits – a non-conformity will be opened on save", "ODSTUPANJE od granica – pri spremanju se otvara nesukladnost"],
  // Moj račun
  "Moj račun": ["My account", "Moj račun"], "Jezik vmesnika": ["Interface language", "Jezik sučelja"], "Spremeni geslo": ["Change password", "Promijeni lozinku"],
  // neskladnost (telefon)
  "Ukrep in zaprtje": ["Action and closure", "Mjera i zatvaranje"], "Ugotovljen vzrok": ["Identified cause", "Utvrđeni uzrok"], "Korektivni / preventivni ukrep (dolgoročni)": ["Corrective / preventive action (long-term)", "Korektivna / preventivna mjera (dugoročna)"],
  "Preverjanje učinkovitosti": ["Effectiveness check", "Provjera učinkovitosti"], "Fotografija dokaza (neobvezno)": ["Photo evidence (optional)", "Fotografija dokaza (neobavezno)"], "Shrani (v izvajanju)": ["Save (in progress)", "Spremi (u tijeku)"], "Zapri neskladnost": ["Close non-conformity", "Zatvori nesukladnost"],
  "Neskladnost zaprta": ["Non-conformity closed", "Nesukladnost zatvorena"], "Prevod": ["Translation", "Prijevod"],
  // kartica Čiščenje na strani Danes
  "Seznam opravil čiščenja iz načrta, ki so danes na vrsti ali v zamudi. Z »Opravljeno« se ustvari zapis v evidencah (čas in uporabnik samodejno).": ["Cleaning tasks from the plan that are due today or overdue. »Done« creates a record (time and user are filled in automatically).", "Zadaci čišćenja iz plana koji su danas na redu ili kasne. »Obavljeno« stvara zapis (vrijeme i korisnik automatski)."],
  "Načrt čiščenja je prazen.": ["The cleaning plan is empty.", "Plan čišćenja je prazan."], "Odpri Higiena → Načrt čiščenja": ["Open Hygiene → Cleaning plan", "Otvori Higijena → Plan čišćenja"],
  "Ni opravil s pogostostjo.": ["No tasks with a set frequency.", "Nema zadataka s učestalošću."], "Opravljeno": ["Done", "Obavljeno"], "Področje": ["Area", "Područje"], "Opravilo": ["Task", "Zadatak"]
};
const I18N_ATR = ["placeholder", "aria-label", "title"];
const jezikUI = () => (typeof ME !== "undefined" && ME.u && ME.u.jezik) || "sl";
const i18nIdx = j => j === "en" ? 0 : j === "hr" ? 1 : -1;
function prevediBesedilo(s) { const i = i18nIdx(jezikUI()); if (i < 0) return s; const t = String(s).trim(), p = I18N[t]; return p ? String(s).replace(t, p[i]) : s; }
// možnost brez atributa value pošlje svoje besedilo: pred prevodom se izvirnik zapiše v value (sicer bi se shranil prevod, npr. stanje »confirmed«)
function zakleniVrednost(n) { const o = n.parentElement; if (o && o.tagName === "OPTION" && !o.hasAttribute("value")) o.setAttribute("value", o.textContent); }
// prevede besedilna vozlišča in atribute pod »root« (samo celotna ujemanja s slovarjem)
function prevediDOM(root) {
  if (i18nIdx(jezikUI()) < 0 || !root) return;
  if (root.nodeType === 3) { const n = prevediBesedilo(root.nodeValue); if (n !== root.nodeValue) { zakleniVrednost(root); root.nodeValue = n; } return; }
  if (root.nodeType !== 1 || /^(SCRIPT|STYLE|TEXTAREA)$/.test(root.tagName)) return;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => n.parentElement && /^(SCRIPT|STYLE|TEXTAREA)$/.test(n.parentElement.tagName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
  const vv = []; while (w.nextNode()) vv.push(w.currentNode);
  for (const n of vv) { const t = prevediBesedilo(n.nodeValue); if (t !== n.nodeValue) { zakleniVrednost(n); n.nodeValue = t; } }
  for (const el of [root, ...root.querySelectorAll("[placeholder],[aria-label],[title]")]) for (const a of I18N_ATR) if (el.hasAttribute && el.hasAttribute(a)) { const v = el.getAttribute(a), t = prevediBesedilo(v); if (t !== v) el.setAttribute(a, t); }
}
// sproti: vse, kar se doda na stran (pogled, okna, sporočila)
let i18nOpazovalec = null;
function i18nZacni() {
  if (i18nOpazovalec) { i18nOpazovalec.disconnect(); i18nOpazovalec = null; }
  if (i18nIdx(jezikUI()) < 0) return;
  document.documentElement.lang = jezikUI();
  prevediDOM(document.body);
  i18nOpazovalec = new MutationObserver(ms => { for (const m of ms) { if (m.type === "characterData") prevediDOM(m.target); for (const n of m.addedNodes || []) prevediDOM(n); } });
  i18nOpazovalec.observe(document.body, { childList: true, subtree: true, characterData: true });
}
// navodilo v jeziku uporabnika (DeepL na strežniku): gumb nad obrazcem navodila
async function prevodNavodila(rec) {
  const box = document.getElementById("nav_prevod"); if (!box) return;
  box.innerHTML = '<p class="mut">Prevajam …</p>';
  try { const r = await api("POST", "/api/prevedi", { jezik: jezikUI(), besedila: [rec.naslov || "", String(rec.vsebina || "")] });
    box.innerHTML = `<div class="note info" lang="${esc(jezikUI())}"><b>${esc(r.prevodi[0])}</b><div style="white-space:pre-wrap;margin-top:6px">${esc(r.prevodi[1])}</div><p class="mut" style="margin:6px 0 0">${jezikUI() === "en" ? "Machine translation – the Slovenian original is authoritative." : "Strojni prijevod – mjerodavan je slovenski izvornik."}</p></div>`; }
  catch (e) { box.innerHTML = `<p class="note">${esc(e.message)}</p>`; }
}
