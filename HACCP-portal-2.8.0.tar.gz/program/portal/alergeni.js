// Predlog alergenov iz besedila sestavin (Uredba 1169/2011, Priloga II). Ujema se začetek besede (koren) ali cela beseda,
// zato skloni in pridevniške oblike delujejo (pšenični, ovseni, mandljev …), besede z enakim začetkom pa ne (rakija, jajčevci).
// Izjeme: rastlinski »maslo«/»mleko« (kakavovo, arašidovo, sojino …), muškatni orešček, koruzni zdrob, brezglutenski izdelki.
// Rezultat je samo predlog – uporabnik ga mora preveriti. Uporaba: ALERGENI.najdi("ovseni kosmiči, tofu") → [{ alergen, beseda }].
var ALERGENI = (function () {
  // [alergen, korenine (začetek besede), cele besede, besedne zveze]
  var P = [
    ["Žita z glutenom", ["pšeni", "ječmen", "ržen", "ovs", "oves", "pirin", "kamut", "tritikal", "zdrob", "kuskus", "bulgur", "seitan", "kruh", "krušn", "testenin", "drobtin", "gluten", "pivo", "piva"], ["rž", "rži", "pira", "piro"], ["kus kus"]],
    ["Raki", ["rakc", "rakovic", "kozic", "škamp", "jastog", "langust", "krab"], ["rak", "raka", "raki", "rakov", "rake", "rakom", "rakih"], []],
    ["Jajca", ["jajc", "jajč", "majonez", "beljak", "rumenjak"], [], []],
    ["Ribe", ["ribj", "losos", "postrv", "orad", "brancin", "sardel", "sardin", "inčun", "ančov", "skuš", "slanik", "trsk", "oslič", "polenovk"], ["riba", "ribe", "ribi", "ribo", "rib", "tuna", "tune", "tuno", "tunina", "tunine"], []],
    ["Arašidi", ["arašid", "kikirik"], [], []],
    ["Soja", ["soj", "tofu", "edamam", "tempeh"], ["miso"], []],
    ["Mleko", ["mlek", "mleč", "smetan", "jogurt", "skut", "kefir", "sirotk", "mascarpon", "mozzarel", "parmezan", "rikot", "ricott", "pinjen", "laktoz", "masl"], ["sir", "sira", "siri", "sirom", "sirih", "sirni", "sirna", "sirno", "sirne", "sirov", "sirova", "sirovo"], []],
    ["Oreščki", ["oreh", "orešč", "lešnik", "mandelj", "mandlj", "mandel", "indijsk", "pistacij", "makadam", "pekan"], [], []],
    ["Zelena", [], ["zelena", "zelene"], ["gomolj zelene", "listi zelene"]],
    ["Gorčica", ["gorčic"], [], []],
    ["Sezam", ["sezam", "tahin"], [], []],
    ["Žveplov dioksid/sulfiti", ["sulfit", "žveplov", "disulfit"], ["vino", "vina", "e220", "e221", "e222", "e223", "e224", "e228"], ["suho sadje", "suhe slive", "suhe marelice"]],
    ["Volčji bob", ["volčj"], [], []],
    ["Mehkužci", ["školjk", "lignj", "hobotnic", "polž", "mehkuž", "klapavic", "ostrig", "dagnj", "pokrovač", "sip"], [], []]
  ];
  // besede, ki se začnejo kot alergen, a to niso (preverijo se pred korenom)
  var NE = ["maslin", "rakij", "jajčev", "sirup", "sipk", "sirk", "zelenjav", "zelenj", "sledi", "sledov", "sledil", "sledljiv", "testirat", "piraj", "kruhovec", "oslov", "pivnic", "sojenj", "ovsenik"];
  // rastlinski pridevnik pred »maslo«, »mleko«, »smetana«, »sir«: ni mleka (ostane pa morebitni drug alergen, npr. arašidi, soja)
  var RASTL = ["kakav", "arašid", "kokos", "sojin", "soj", "mandlj", "mandelj", "lešnik", "oreh", "indijsk", "sezam", "riž", "ovs", "oves", "shea", "karit", "rastlin", "vegansk", "kikirik", "konopljin", "pistacij"];
  // pridevnik pred besedo, ki izključi alergen te besede: muškatni orešček, kokosov oreh, koruzni zdrob, brezglutenski …
  var PRED = { "Oreščki": ["muškat", "kokos"], "Žita z glutenom": ["koruz", "riž", "ajdov", "brezglut", "proseno", "proso", "kvinoj", "amarant", "tapiok"] };
  var ZA = { "Zelena": ["solat", "papri", "fižol", "čaj", "oliv", "jabol", "grah", "barv", "listnat"] };
  var norm = function (s) { return String(s || "").toLowerCase().replace(/ć/g, "č").replace(/đ/g, "dž"); };
  var zacne = function (b, l) { for (var i = 0; i < l.length; i++) if (b.indexOf(l[i]) === 0) return l[i]; return ""; };
  function najdi(besedilo) {
    var out = [], ze = {};
    var dodaj = function (al, beseda) { if (!ze[al]) { ze[al] = 1; out.push({ alergen: al, beseda: beseda }); } };
    var deli = norm(besedilo).split(/[,;\n()\/]+/);
    for (var d = 0; d < deli.length; d++) {
      var del = " " + deli[d].replace(/[^\p{L}\p{N}]+/gu, " ").trim() + " ", b = del.trim().split(" ").filter(Boolean);
      if (!b.length) continue;
      for (var k = 0; k < P.length; k++) {
        var al = P[k][0];
        for (var z = 0; z < P[k][3].length; z++) if (del.indexOf(" " + P[k][3][z] + " ") >= 0) dodaj(al, P[k][3][z]);
        for (var i = 0; i < b.length; i++) {
          var w = b[i], prej = i ? b[i - 1] : "", nasl = b[i + 1] || "";
          if (zacne(w, NE)) continue;
          if (!(P[k][2].indexOf(w) >= 0 || zacne(w, P[k][1]))) continue;
          if (zacne(prej, PRED[al] || [])) continue;
          if (ZA[al] && zacne(nasl, ZA[al])) continue;
          if (zacne(prej, ["brezglut"]) && al === "Žita z glutenom") continue;
          if (al === "Mleko" && /^(masl|mlek|mleč|smetan|sir)/.test(w) && zacne(prej, RASTL)) continue;
          if (al === "Žita z glutenom" && w.indexOf("gluten") === 0 && /brez/.test(prej)) continue;
          dodaj(al, w);
        }
      }
    }
    return out;
  }
  return { najdi: najdi };
})();
if (typeof module !== "undefined") module.exports = ALERGENI;
