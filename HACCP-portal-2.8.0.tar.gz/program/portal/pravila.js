// Pravila za vnose (razponi, meje, celoštevilski intervali, ura, e-naslov). Isto datoteko uporabljata
// strežnik (platform.js – API vrne 400 z »napaka«) in obrazci (core.js, m-evidence.js – napaka ob polju).
// preveri(zbirka, zapis) vrne seznam [polje, sporočilo]; zapis je celoten zapis (pri popravku: stari zapis + spremembe).
var PRAVILA = (function () {
  var st = function (v) { return v === "" || v === undefined || v === null ? null : typeof v === "number" ? v : /^\s*[-−]?\d+([.,]\d+)?\s*$/.test(String(v)) ? Number(String(v).replace(",", ".").replace("−", "-")) : NaN; };
  var fmt = function (n) { return String(n).replace(".", ","); };
  var dan = function (v) { return v ? String(v).slice(0, 10) : ""; };
  function razpon(r, a, b, la, lb) { var x = st(r[a]), y = st(r[b]); return x !== null && y !== null && isFinite(x) && isFinite(y) && x > y ? [b, "»" + lb + "« mora biti večje ali enako kot »" + la + "« (" + fmt(x) + ")."] : null; }
  function celo(r, k, l, nic) { var n = st(r[k]); return n === null || (nic && n === 0) ? null : !(isFinite(n) && Math.floor(n) === n && n > 0) ? [k, "»" + l + "« mora biti pozitivno celo število (npr. 30)."] : null; }
  function nenegativno(r, k, l) { var n = st(r[k]); return n !== null && isFinite(n) && n < 0 ? [k, "»" + l + "« ne sme biti negativno."] : null; }
  function datumi(r, a, b, la, lb) { return dan(r[a]) && dan(r[b]) && dan(r[b]) < dan(r[a]) ? [b, "»" + lb + "« ne sme biti pred »" + la + "«."] : null; }
  function ura(r, k) { return r[k] === undefined || r[k] === null || r[k] === "" || /^([01]\d|2[0-3]):[0-5]\d$/.test(String(r[k])) ? null : [k, "Ura mora biti v obliki HH:MM (od 00:00 do 23:59)."]; }
  function email(r, k) { var v = r[k] === undefined || r[k] === null ? "" : String(r[k]).trim(); return !v || /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]{2,}$/.test(v) ? null : [k, "E-naslov ni veljaven (npr. ana.novak@podjetje.si)."]; }
  // EAN-8 ali EAN-13 s pravilno kontrolno števko (prazno je dovoljeno)
  function ean(r, k) {
    var v = r[k] === undefined || r[k] === null ? "" : String(r[k]).replace(/\s/g, ""); if (!v) return null;
    if (!/^(\d{8}|\d{13})$/.test(v)) return [k, "EAN mora imeti 8 ali 13 števk (npr. 4006381333931)."];
    var vs = 0, d = v.split("").map(Number), n = d.length;
    for (var i = 0; i < n - 1; i++) vs += d[i] * ((n - 1 - i) % 2 ? 3 : 1);
    return (10 - vs % 10) % 10 === d[n - 1] ? null : [k, "EAN ni veljaven (napačna kontrolna števka) – preverite številko."];
  }
  // seznam izbranih postavk: [{ ime, opis }] (največ 200, ime do 120 znakov, opis do 1000)
  function seznam(r, k, l) {
    var v = r[k]; if (v === undefined || v === null || v === "") return null;
    if (!Array.isArray(v) || v.length > 200 || v.some(function (x) { return !x || typeof x !== "object" || typeof x.ime !== "string" || !x.ime.trim() || x.ime.length > 120 || (x.opis !== undefined && (typeof x.opis !== "string" || x.opis.length > 1000)); })) return [k, "»" + l + "« mora biti seznam postavk z imenom in neobveznim opisom."];
    return null;
  }
  var P = {
    oprema: function (r) { return [razpon(r, "meja_min", "meja_max", "Dovoljeno od", "Dovoljeno do"), celo(r, "interval_dni", "Interval (dni)")]; },
    evidence: function (r) { return [razpon(r, "min", "max", "Dovoljeno od", "Dovoljeno do"), razpon(r, "ph_min", "ph_max", "pH od", "pH do"), razpon(r, "brix_min", "brix_max", "Brix od", "Brix do"), razpon(r, "alkohol_min", "alkohol_max", "Alkohol od", "Alkohol do")]; },
    usposabljanja: function (r) { return [datumi(r, "datum", "veljavno_do", "Datum", "Veljavno do")]; },
    storitve: function (r) { return [nenegativno(r, "minute", "Trajanje (minute)")]; },
    dogodki: function (r) { return [ura(r, "ura"), nenegativno(r, "opomnik_dni", "Opomnik (dni prej)")]; },
    osebje: function (r) { return [email(r, "email")]; },
    sarze: function (r) { return [ean(r, "ean")]; },
    capa: function (r) { return [datumi(r, "cas", "rok", "Datum ugotovitve", "Rok izvedbe"), datumi(r, "cas", "datum_zapiranja", "Datum ugotovitve", "Datum zaprtja")]; },
    ciscenje_nacrt: function (r) { return [celo(r, "pogostost_dni", "Pogostost (na koliko dni)", true)]; },
    obrati: function (r) { return [nenegativno(r, "povrsina", "Površina (m²)"), seznam(r, "prostori", "Prostori"), seznam(r, "naprave", "Naprave in pribor")]; },
    uporabniki: function (r) { return [email(r, "email")]; },
    urnik: function (r) { var n = st(r.frekvenca_ur); return [n !== null && !(n > 0) ? ["frekvenca_ur", "Pogostost vnosa mora biti več kot 0 ur."] : null]; }
  };
  // opozorila (shranjevanje je dovoljeno): šarža s pretečenim rokom ali rokom pred prevzemom; danes = »YYYY-MM-DD« (lokalni dan)
  function opozorila(c, r, danes) {
    var o = [];
    if (c === "sarze" && r && r.rok_uporabe) {
      if (r.datum_prevzema && dan(r.rok_uporabe) < dan(r.datum_prevzema)) o.push("Rok uporabe (" + dan(r.rok_uporabe) + ") je pred datumom prevzema (" + dan(r.datum_prevzema) + ").");
      else if (danes && dan(r.rok_uporabe) < danes) o.push("Rok uporabe (" + dan(r.rok_uporabe) + ") je že potekel.");
    }
    return o;
  }
  // stanje šarže s pretečenim rokom: »pretečeno« (razen porabljenih in umaknjenih)
  var pretecena = function (r, danes) { return !!(r && r.rok_uporabe && danes && dan(r.rok_uporabe) < danes && ["", "na zalogi", "v uporabi", "pretečeno", undefined, null].indexOf(r.status) >= 0); };
  return {
    opozorila: opozorila, pretecena: pretecena,
    preveri: function (c, r) { return P[c] ? P[c](r || {}).filter(Boolean) : []; },
    stevilo: st
  };
})();
if (typeof module !== "undefined") module.exports = PRAVILA;
