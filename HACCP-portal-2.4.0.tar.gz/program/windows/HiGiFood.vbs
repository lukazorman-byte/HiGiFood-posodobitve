' Zagon programa HiGiFood HACCP (Windows program) brez črnega okna.
' Dvoklik: zažene program skrito in odpre brskalnik. Ustavitev: Administracija -> "Ustavi program".
' Z argumentom "tiho" (samodejni zagon ob prijavi) brskalnika ne odpre.
' Po posodobitvi iz aplikacije se program konča s kodo 75; zaganjalnik takrat zažene novo različico.
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
extra = " --zaganjalnik"
If WScript.Arguments.Count > 0 Then
  If WScript.Arguments(0) = "tiho" Then extra = extra & " --tiho"
End If
Do
  rc = sh.Run("""" & dir & "\HACCP-sistem.exe""" & extra, 0, True)
  If rc <> 75 Then Exit Do
  extra = " --zaganjalnik --tiho --po-posodobitvi"
Loop
