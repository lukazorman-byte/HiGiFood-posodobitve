// Posodobitev strežniške namestitve iz podpisane izdaje (zaganja jo POSODOBI-SAMODEJNO.sh v mapi namestitve).
// Prebere opis izdaje (posodobitev.json), preveri podpis z javnim ključem, vgrajenim v nameščeni program, in SHA-256 arhiva,
// naredi kopijo mape program, namesti novo in ohrani nastavitve (program/streznik/.env, Caddyfile). Podatki so v nosilcu Docker.
// Izhodne kode: 0 = nameščena je zadnja različica, 10 = nameščena nova različica (zaženite ZAGON-LINUX-DOCKER.sh), 1 = napaka.
// Možnosti: --naslov <https://…/posodobitev.json ali pot do datoteke>, --preveri (samo preveri, ne namesti)
const fs = require("fs"), path = require("path"), crypto = require("crypto"), os = require("os"), cp = require("child_process");
const PROG = path.resolve(__dirname, ".."), INST = path.dirname(PROG);
const arg = (n, d) => { const i = process.argv.indexOf("--" + n); return i > 0 ? process.argv[i + 1] : d; };
const izpis = m => console.log(new Date().toISOString().replace("T", " ").slice(0, 19) + " " + m);
const konec = (koda, m) => { izpis(m); process.exit(koda); };
const posod = fs.readFileSync(path.join(PROG, "posodobitev.js"), "utf8");
const JAVNI = crypto.createPublicKey(/-----BEGIN PUBLIC KEY-----[\s\S]+?-----END PUBLIC KEY-----/.exec(posod)[0]);
const PRIVZETI = (/PRIVZETI_URL = "([^"]+)"/.exec(posod) || [])[1];
const { novejsa } = require(path.join(PROG, "posodobitev.js"));
const naslov = arg("naslov") || process.env.HACCP_PROGRAM_URL || PRIVZETI;
const lokalna = u => !/^[a-z]+:\/\//i.test(u) || /^file:/i.test(u);
const lokalnaPot = u => /^file:/i.test(u) ? require("url").fileURLToPath(u) : u;
const razresi = (rel, baza) => /^[a-z]+:\/\//i.test(rel) || path.isAbsolute(rel) ? rel : lokalna(baza) ? path.join(path.dirname(lokalnaPot(baza)), rel) : new URL(rel, baza).href;
async function prenesi(u, max) {
  if (lokalna(u)) { const p = lokalnaPot(u); if (fs.statSync(p).size > max) throw new Error("Datoteka je prevelika."); return fs.readFileSync(p); }
  const x = new URL(u); if (x.protocol !== "https:" && !(x.protocol === "http:" && ["127.0.0.1", "localhost"].includes(x.hostname))) throw new Error("Naslov mora biti https: " + u);
  const r = await fetch(u, { redirect: "follow", headers: { "User-Agent": "HiGiFood-streznik" }, signal: AbortSignal.timeout(300e3) });
  if (!r.ok) throw new Error("HTTP " + r.status + " (" + u + ")");
  const b = Buffer.from(await r.arrayBuffer()); if (b.length > max) throw new Error("Datoteka je prevelika."); return b;
}
(async () => {
  const trenutna = JSON.parse(fs.readFileSync(path.join(PROG, "package.json"), "utf8")).version;
  if (!naslov) konec(1, "Naslov izdaj ni nastavljen (--naslov ali HACCP_PROGRAM_URL).");
  const ovoj = JSON.parse((await prenesi(naslov, 1e6)).toString("utf8"));
  if (typeof ovoj.podatki !== "string" || !crypto.verify(null, Buffer.from(ovoj.podatki, "utf8"), JAVNI, Buffer.from(String(ovoj.podpis || ""), "base64"))) konec(1, "Podpis izdaje ni veljaven – posodobitev zavrnjena.");
  const d = JSON.parse(ovoj.podatki);
  if (d.aplikacija !== "higifood" || !/^\d+\.\d+\.\d+$/.test(d.verzija || "")) konec(1, "Opis izdaje ni za ta program.");
  if (!novejsa(d.verzija, trenutna)) konec(0, "Nameščena je zadnja različica (" + trenutna + ").");
  if (!d.izvorna || !/^[0-9a-f]{64}$/.test(d.izvorna.sha256 || "")) konec(1, "Izdaja " + d.verzija + " nima arhiva za strežnik.");
  if (process.argv.includes("--preveri")) konec(0, "Na voljo je različica " + d.verzija + " (nameščena " + trenutna + ").");
  izpis("Prenašam različico " + d.verzija + " …");
  const arh = await prenesi(razresi(d.izvorna.url, naslov), 200e6);
  if (crypto.createHash("sha256").update(arh).digest("hex") !== d.izvorna.sha256) konec(1, "Arhiv se ne ujema z izdajo (SHA-256) – posodobitev zavrnjena.");
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "higifood-")), tgz = path.join(tmp, "izdaja.tar.gz"); fs.writeFileSync(tgz, arh);
  const t = cp.spawnSync("tar", ["-xzf", tgz, "-C", tmp], { encoding: "utf8" }); if (t.status !== 0) konec(1, "Razpakiranje ni uspelo: " + (t.stderr || t.error));
  const nov = path.join(tmp, "program"); let nv = ""; try { nv = JSON.parse(fs.readFileSync(path.join(nov, "package.json"), "utf8")).version; } catch {}
  if (nv !== d.verzija) konec(1, "Arhiv ne vsebuje pričakovane različice (" + (nv || "?") + ").");
  const cas = new Date().toISOString().replace(/[-:]/g, "").replace("T", "-").slice(0, 15), kopija = path.join(INST, "program-pred-posodobitvijo-" + cas);
  fs.renameSync(PROG, kopija);
  try {
    fs.cpSync(nov, PROG, { recursive: true });
    for (const f of ["streznik/.env", "streznik/Caddyfile"]) if (fs.existsSync(path.join(kopija, f))) fs.copyFileSync(path.join(kopija, f), path.join(PROG, f)); // vaše nastavitve
  } catch (e) { try { fs.rmSync(PROG, { recursive: true, force: true }); fs.renameSync(kopija, PROG); } catch {} konec(1, "Namestitev ni uspela, stara različica je vrnjena: " + e.message); }
  // hranimo zadnje tri kopije prejšnjih različic
  const stare = fs.readdirSync(INST).filter(x => /^program-pred-posodobitvijo-/.test(x)).sort(); for (const x of stare.slice(0, Math.max(0, stare.length - 3))) fs.rmSync(path.join(INST, x), { recursive: true, force: true });
  fs.rmSync(tmp, { recursive: true, force: true });
  konec(10, "Nameščena različica " + d.verzija + " (prej " + trenutna + "). Kopija prejšnje: " + path.basename(kopija));
})().catch(e => konec(1, "Napaka: " + e.message));
