// Pripravi izdajo za posodobitev: Windows program, arhiv programa za strežnik (HACCP-portal-<različica>.tar.gz)
// in podpisan opis posodobitev.json (Windows program se posodobi iz aplikacije, strežnik s scripts/posodobi-streznik.js).
// Uporaba (po gradnji .exe):
//   node scripts/izdaja.js --kljuc <zasebni-kljuc.pem> [--url <javni naslov mape z izdajami>/] [--opis "Kaj je novega"] [--exe exe/HACCP-sistem.exe] [--izhod izdaja]
//   Brez --url je izdaja »prenosna«: mapo izdaja/ lahko kopirate na USB in jo v programu izberete s potjo do posodobitev.json.
// Nato vsebino mape izdaja/ objavite na --url (npr. javni repozitorij HiGiFood-posodobitve). Zasebnega ključa nikoli ne objavite.
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const ROOT = path.join(__dirname, "..");
const arg = (n, d) => { const i = process.argv.indexOf("--" + n); return i > 0 ? process.argv[i + 1] : d; };
const kljucPot = arg("kljuc"), url = arg("url"), exe = path.resolve(arg("exe", path.join(ROOT, "exe", "HACCP-sistem.exe"))), izhod = path.resolve(arg("izhod", path.join(ROOT, "izdaja")));
if (!kljucPot) { console.error("Manjka --kljuc. Glejte navodila na vrhu datoteke."); process.exit(1); }
// brez --url: v opisu je le ime datoteke (izdaja deluje iz mape na disku/USB ali z istega spletnega naslova kot opis)
if (url && !/^https:\/\//.test(url) && !/^http:\/\/(127\.0\.0\.1|localhost)[:/]/.test(url)) { console.error("--url mora biti https://"); process.exit(1); }
const zasebni = crypto.createPrivateKey(fs.readFileSync(kljucPot));
// ključ se mora ujemati z javnim ključem, vgrajenim v program
const vgrajen = /-----BEGIN PUBLIC KEY-----[\s\S]+?-----END PUBLIC KEY-----/.exec(fs.readFileSync(path.join(ROOT, "posodobitev.js"), "utf8"))[0];
if (crypto.createPublicKey(zasebni).export({ type: "spki", format: "pem" }).trim() !== vgrajen.trim()) { console.error("Zasebni ključ se ne ujema z javnim ključem v posodobitev.js."); process.exit(1); }
const verzija = require(path.join(ROOT, "package.json")).version, brezExe = process.argv.includes("--brez-exe"), buf = brezExe ? null : fs.readFileSync(exe);
if (buf && buf.subarray(0, 2).toString("latin1") !== "MZ") { console.error("To ni Windows program: " + exe); process.exit(1); }
const ime = "HACCP-sistem-" + verzija + ".exe";
fs.mkdirSync(izhod, { recursive: true }); if (buf) fs.copyFileSync(exe, path.join(izhod, ime));
// arhiv programa za strežnik (brez podatkov, gradenj, ključev in lokalnih nastavitev)
const arhiv = "HACCP-portal-" + verzija + ".tar.gz", izl = ["program/exe", "program/izdaja", "program/podatki", "program/podatki-test", "program/node_modules", "program/dist", "program/baza/_*", "*.pem", "program/streznik/.env"];
const t = require("child_process").spawnSync("tar", ["-czf", path.join(izhod, arhiv), ...izl.map(x => "--exclude=" + x), "-C", path.dirname(ROOT), path.basename(ROOT)], { encoding: "utf8" });
if (t.status !== 0) { console.error("Arhiva ni mogoče narediti (tar): " + (t.stderr || t.error)); process.exit(1); }
if (path.basename(ROOT) !== "program") { console.error("Mapa programa se mora imenovati »program«."); process.exit(1); }
const abuf = fs.readFileSync(path.join(izhod, arhiv)), uu = x => url ? url.replace(/\/?$/, "/") + x : x;
const podatki = JSON.stringify({ aplikacija: "higifood", verzija, datum: new Date().toISOString().slice(0, 10), opis: arg("opis", ""),
  windows: buf ? { url: uu(ime), sha256: crypto.createHash("sha256").update(buf).digest("hex"), velikost: buf.length } : undefined,
  izvorna: { url: uu(arhiv), sha256: crypto.createHash("sha256").update(abuf).digest("hex"), velikost: abuf.length },
  navodila: "Strežnik (Docker): sudo sh POSODOBI-SAMODEJNO.sh (ali vklopite samodejne posodobitve: sudo sh POSODOBI-SAMODEJNO.sh vklopi). Podatki in nastavitve ostanejo." });
const podpis = crypto.sign(null, Buffer.from(podatki, "utf8"), zasebni).toString("base64");
fs.writeFileSync(path.join(izhod, "posodobitev.json"), JSON.stringify({ podatki, podpis }, null, 1));
console.log("Izdaja " + verzija + " pripravljena v " + izhod + ": " + (buf ? ime + ", " : "") + arhiv + ", posodobitev.json");
