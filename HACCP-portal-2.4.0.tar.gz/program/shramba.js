// Shranjevanje zbirk (stranke, uporabniki, evidence …): podatkovna baza SQLite (vgrajena v Node.js 22) ali datoteke JSON.
// SQLite zapiše samo spremenjene zapise (hitro tudi pri veliko evidencah in uporabnikih); JSON je rezerva, če SQLite ni na voljo
// ali je izbrana s HACCP_SHRAMBA=json. Ob prvem zagonu z bazo se obstoječe datoteke <zbirka>.json samodejno prenesejo v bazo
// (izvirnik ostane kot <zbirka>.json.v-bazi). Varnostne kopije ostanejo v obliki JSON (enake kot prej), zato obnova in
// preizkus obnove delujeta z obema načinoma in s kopijami starejših različic.
const fs = require("fs"), path = require("path");
const DB_DATOTEKE = /^haccp\.db(-wal|-shm|-journal)?$|\.json\.v-bazi$/; // ne gre v kopijo kot datoteka (kopija dobi JSON)

function nalozSqlite() {
  if (process.env.HACCP_SHRAMBA === "json") return null;
  const em = process.emitWarning; // SQLite je v Node 22 označen kot preizkusen: opozorilo ne sodi v dnevnik uporabnika
  process.emitWarning = function (w, ...a) { if (/SQLite/i.test(String(w && w.message || w))) return; return em.call(process, w, ...a); };
  try { return require("node:sqlite"); } catch { return null; } finally { process.emitWarning = em; }
}

module.exports = function shramba(DIR) {
  const jsonPot = n => path.join(DIR, n + ".json");
  const beriJson = n => { try { return JSON.parse(fs.readFileSync(jsonPot(n), "utf8")); } catch { return []; } };
  const pisiJson = (n, arr) => {
    const tmp = jsonPot(n) + ".tmp", fd = fs.openSync(tmp, "w");
    try { fs.writeSync(fd, Array.isArray(arr) && arr.length > 2000 ? JSON.stringify(arr) : JSON.stringify(arr, null, 1)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, jsonPot(n));
  };
  const sq = nalozSqlite();
  if (!sq) return { nacin: "json", preberi: beriJson, zapisi: pisiJson, izvozi: () => [], uvoziDatoteke: () => 0, ponastavi: () => {}, zapri: () => {}, DB_DATOTEKE };

  const db = new sq.DatabaseSync(path.join(DIR, "haccp.db"));
  db.exec("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;");
  db.exec("CREATE TABLE IF NOT EXISTS zbirke (ime TEXT PRIMARY KEY, uvozeno TEXT)");
  db.exec("CREATE TABLE IF NOT EXISTS zapisi (zbirka TEXT NOT NULL, kljuc TEXT NOT NULL, poz INTEGER NOT NULL, podatki TEXT NOT NULL, PRIMARY KEY (zbirka, kljuc)) WITHOUT ROWID");
  db.exec("CREATE INDEX IF NOT EXISTS zapisi_poz ON zapisi (zbirka, poz)");
  const q = {
    meta: db.prepare("SELECT ime FROM zbirke WHERE ime = ?"), vseMeta: db.prepare("SELECT ime FROM zbirke ORDER BY ime"),
    dodajMeta: db.prepare("INSERT OR REPLACE INTO zbirke (ime, uvozeno) VALUES (?, ?)"),
    vrstice: db.prepare("SELECT kljuc, poz, podatki FROM zapisi WHERE zbirka = ? ORDER BY poz"),
    vpisi: db.prepare("INSERT OR REPLACE INTO zapisi (zbirka, kljuc, poz, podatki) VALUES (?, ?, ?, ?)"),
    brisi: db.prepare("DELETE FROM zapisi WHERE zbirka = ? AND kljuc = ?"), brisiZbirko: db.prepare("DELETE FROM zapisi WHERE zbirka = ?")
  };
  const posnetek = {}; // zbirka → Map(ključ → { poz, json }) zadnjega zapisanega stanja
  const transakcija = fn => { db.exec("BEGIN IMMEDIATE"); try { fn(); db.exec("COMMIT"); } catch (e) { try { db.exec("ROLLBACK"); } catch {} throw e; } };
  // ključ zapisa: id (enoličen v zbirki), sicer zaporedna številka
  function kljuci(arr) {
    const vid = new Map(), out = [];
    arr.forEach((r, i) => { let k = r && (typeof r.id === "string" || typeof r.id === "number") ? "i:" + r.id : "#" + i; const n = vid.get(k) || 0; vid.set(k, n + 1); if (n) k += "~" + n; out.push(k); });
    return out;
  }
  function zapisiDb(n, arr, celotno) {
    arr = Array.isArray(arr) ? arr : []; const ks = kljuci(arr), prej = celotno ? new Map() : (posnetek[n] || new Map()), nov = new Map();
    transakcija(() => {
      if (celotno) q.brisiZbirko.run(n);
      arr.forEach((r, i) => { const js = JSON.stringify(r), p = prej.get(ks[i]); nov.set(ks[i], { poz: i, json: js }); if (!p || p.poz !== i || p.json !== js) q.vpisi.run(n, ks[i], i, js); });
      if (!celotno) for (const k of prej.keys()) if (!nov.has(k)) q.brisi.run(n, k);
      q.dodajMeta.run(n, new Date().toISOString());
    });
    posnetek[n] = nov;
  }
  function preberi(n) {
    if (!q.meta.get(n)) { // prvič: prenos iz datoteke JSON (če obstaja)
      const arr = fs.existsSync(jsonPot(n)) ? beriJson(n) : [];
      zapisiDb(n, arr, true);
      if (fs.existsSync(jsonPot(n))) try { fs.renameSync(jsonPot(n), jsonPot(n) + ".v-bazi"); } catch {}
      return arr;
    }
    const m = new Map(), arr = [];
    for (const v of q.vrstice.all(n)) { m.set(v.kljuc, { poz: v.poz, json: v.podatki }); arr.push(JSON.parse(v.podatki)); }
    posnetek[n] = m; return arr;
  }
  return {
    nacin: "sqlite", DB_DATOTEKE, preberi, zapisi: (n, arr) => zapisiDb(n, arr, false),
    // za varnostno kopijo: vsaka zbirka kot podatki/<zbirka>.json (enaka oblika kot pri datotekah)
    izvozi: () => q.vseMeta.all().map(({ ime }) => ({ name: "podatki/" + ime + ".json", data: Buffer.from("[" + q.vrstice.all(ime).map(v => v.podatki).join(",") + "]") })),
    // po obnovi iz kopije: datoteke <zbirka>.json zamenjajo vsebino v bazi
    uvoziDatoteke(imena) {
      let n = 0;
      for (const ime of new Set([...imena, ...q.vseMeta.all().map(x => x.ime)])) {
        if (!fs.existsSync(jsonPot(ime))) continue;
        zapisiDb(ime, beriJson(ime), true); try { fs.renameSync(jsonPot(ime), jsonPot(ime) + ".v-bazi"); } catch {} n++;
      }
      return n;
    },
    ponastavi() { transakcija(() => { db.exec("DELETE FROM zapisi"); db.exec("DELETE FROM zbirke"); }); for (const k of Object.keys(posnetek)) delete posnetek[k]; },
    zapri() { try { db.exec("PRAGMA wal_checkpoint(TRUNCATE)"); db.close(); } catch {} }
  };
};
