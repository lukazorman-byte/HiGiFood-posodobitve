// Posodobitev programa iz aplikacije (Administracija → Vzdrževanje → Posodobitve programa).
// Program prebere opis izdaje (posodobitev.json) z nastavljenega naslova. Opis mora biti podpisan s ključem izdajatelja (Ed25519);
// javni ključ je vgrajen spodaj, zasebnega hrani izdajatelj (scripts/izdaja.js). Nepodpisane ali spremenjene izdaje program zavrne.
// Windows program (.exe) se posodobi sam: prenese novo različico, preveri SHA-256, naredi varnostno kopijo podatkov,
// zamenja .exe (stara ostane kot .stara) in se znova zažene. Strežniška (Docker) in izvorna namestitev dobita navodila.
const fs = require("fs"), path = require("path"), crypto = require("crypto");

const JAVNI_KLJUC = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEASNiduXqDpgkPTy7dM5q755cwhxUHhef8h7YO9OpAIF4=
-----END PUBLIC KEY-----`;
const PRIVZETI_URL = "https://raw.githubusercontent.com/lukazorman-byte/HiGiFood-posodobitve/main/posodobitev.json";

// primerjava različic 2.10.0 > 2.9.3
const novejsa = (a, b) => { const x = String(a).split(".").map(n => parseInt(n, 10) || 0), y = String(b).split(".").map(n => parseInt(n, 10) || 0); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };

module.exports = function posodobitev({ DIR, VERZIJA, PACKED, kljuc }) {
  const F = path.join(DIR, "_posodobitev-programa.json");
  const nast = () => { try { return JSON.parse(fs.readFileSync(F, "utf8")); } catch { return {}; } };
  const shrani = o => fs.writeFileSync(F, JSON.stringify(o, null, 1));
  const javni = crypto.createPublicKey(kljuc || JAVNI_KLJUC);
  const naslov = () => process.env.HACCP_PROGRAM_URL || nast().url || PRIVZETI_URL;
  const nacin = () => PACKED && process.platform === "win32" ? "exe" : fs.existsSync("/.dockerenv") || process.env.HACCP_DATA === "/data" ? "docker" : "izvorna";
  // http je dovoljen samo za lokalni preizkus (HACCP_PROGRAM_URL na 127.0.0.1)
  const dovoljen = u => { try { const x = new URL(u); return x.protocol === "https:" || (x.protocol === "http:" && ["127.0.0.1", "localhost"].includes(x.hostname) && !!process.env.HACCP_PROGRAM_URL); } catch { return false; } };

  // prenos prek vgrajenih modulov http/https (brez fetch): preusmeritve največ 5, omejitev velikosti, časovna omejitev
  // lokalni vir (mapa na disku ali USB ključu): C:\…\posodobitev.json, \\strežnik\mapa\…, file:///…, /pot/…
  const lokalna = u => /^[a-zA-Z]:[\\/]/.test(u) || /^\\\\/.test(u) || /^file:/i.test(u) || u.startsWith("/");
  const lokalnaPot = u => /^file:/i.test(u) ? require("url").fileURLToPath(u) : u;
  // povezava v opisu izdaje je lahko le ime datoteke: velja glede na mesto opisa
  const razresi = (rel, baza) => /^[a-z]+:\/\//i.test(rel) || lokalna(rel) ? rel : lokalna(baza) ? path.join(path.dirname(lokalnaPot(baza)), rel) : new URL(rel, baza).href;
  function prenesi(u, max, preus) {
    if (lokalna(u)) return new Promise((ok, ne) => { try { const p = lokalnaPot(u), st = fs.statSync(p); if (st.size > max) return ne(new Error("Datoteka je prevelika.")); ok(fs.readFileSync(p)); } catch (e) { ne(new Error("Datoteke ni mogoče prebrati: " + u + " (" + (e.code || e.message) + ").")); } });
    return new Promise((ok, ne) => {
      if (!dovoljen(u)) return ne(new Error("Naslov mora biti https: " + u));
      const x = new URL(u), lib = x.protocol === "https:" ? require("https") : require("http");
      const rq = lib.get(x, { headers: { "User-Agent": "HiGiFood/" + VERZIJA }, timeout: 60e3 }, r => {
        if ([301, 302, 303, 307, 308].includes(r.statusCode) && r.headers.location) { r.resume(); if ((preus || 0) >= 5) return ne(new Error("Preveč preusmeritev.")); return prenesi(new URL(r.headers.location, u).href, max, (preus || 0) + 1).then(ok, ne); }
        if (r.statusCode !== 200) { r.resume(); return ne(new Error("HTTP " + r.statusCode + " (" + u + ")")); }
        if (Number(r.headers["content-length"] || 0) > max) { r.destroy(); return ne(new Error("Datoteka je prevelika.")); }
        const deli = []; let n = 0;
        r.on("data", c => { n += c.length; if (n > max) { r.destroy(); ne(new Error("Datoteka je prevelika.")); } else deli.push(c); });
        r.on("end", () => ok(Buffer.concat(deli))); r.on("error", ne);
      });
      rq.on("timeout", () => rq.destroy(new Error("časovna omejitev")));
      rq.on("error", e => ne(new Error("Povezava z " + x.host + " ni uspela (" + (e.code || e.message) + ").")));
    });
  }
  // opis izdaje: { podatki: "<JSON niz>", podpis: "<base64 Ed25519 nad nizom podatki>" }
  async function preberiIzdajo() {
    const ovoj = JSON.parse((await prenesi(naslov(), 1e6)).toString("utf8"));
    if (typeof ovoj.podatki !== "string" || typeof ovoj.podpis !== "string") throw new Error("Opis izdaje ni v pravilni obliki.");
    if (!crypto.verify(null, Buffer.from(ovoj.podatki, "utf8"), javni, Buffer.from(ovoj.podpis, "base64"))) throw new Error("Podpis izdaje ni veljaven – posodobitev zavrnjena.");
    const d = JSON.parse(ovoj.podatki);
    if (d.aplikacija !== "higifood" || !/^\d+\.\d+\.\d+$/.test(d.verzija || "")) throw new Error("Opis izdaje ni za ta program.");
    return d;
  }
  let zadnje = null;
  async function preveri() {
    const d = await preberiIzdajo(), nova = novejsa(d.verzija, VERZIJA);
    zadnje = { cas: new Date().toISOString(), trenutna: VERZIJA, zadnja: d.verzija, nova, datum: d.datum || "", opis: d.opis || "", nacin: nacin(), mozna_namestitev: nova && nacin() === "exe" && !!(d.windows && d.windows.url && d.windows.sha256), vir: lokalna(naslov()) ? "mapa" : "splet", navodila: d.navodila || "" };
    return zadnje;
  }
  // prenese in zamenja .exe; vrne pot do nove datoteke (ponovni zagon opravi strežnik)
  async function namesti() {
    if (nacin() !== "exe") throw new Error("Samodejna namestitev je mogoča samo pri Windows programu (.exe).");
    const d = await preberiIzdajo(); if (!novejsa(d.verzija, VERZIJA)) throw new Error("Nameščena je že zadnja različica.");
    const w = d.windows || {}; if (!w.url || !/^[0-9a-f]{64}$/.test(w.sha256 || "")) throw new Error("Izdaja nima Windows programa.");
    const buf = await prenesi(razresi(w.url, naslov()), 300e6);
    if (crypto.createHash("sha256").update(buf).digest("hex") !== w.sha256) throw new Error("Prenesena datoteka se ne ujema z izdajo (SHA-256) – posodobitev zavrnjena.");
    if (buf.subarray(0, 2).toString("latin1") !== "MZ") throw new Error("Prenesena datoteka ni Windows program.");
    const exe = process.execPath, nova = exe + ".nova", stara = exe + ".stara";
    fs.writeFileSync(nova, buf);
    try { fs.unlinkSync(stara); } catch {}
    fs.renameSync(exe, stara); // tekoči program se lahko preimenuje, ne pa izbriše
    try { fs.renameSync(nova, exe); } catch (e) { try { fs.renameSync(stara, exe); } catch {} throw new Error("Zamenjava programa ni uspela: " + e.message); }
    return { exe, verzija: d.verzija };
  }
  return { preveri, namesti, naslov, nastavi: url => { const o = nast(); if (url) o.url = url; else delete o.url; shrani(o); }, zadnje: () => zadnje, nacin, PRIVZETI_URL };
};
module.exports.novejsa = novejsa;
