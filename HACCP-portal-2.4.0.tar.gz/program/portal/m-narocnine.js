// Plačljivi paketi: pregled naročnin in predračunov (administrator), paket na profilu stranke, zaklenjene funkcije (»na voljo v paketu …«).
const PAK = { podatki: null };
async function paketi() { if (!PAK.podatki) PAK.podatki = await api("GET", "/api/paketi"); return PAK.podatki; }
const eur = n => (Math.round((Number(n) || 0) * 100) / 100).toLocaleString("sl-SI", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
const eurPdf = n => eur(n).replace(" €", " EUR");
const STANJE_NAR = { aktivna: "ok", poteka: "warn", zapadla: "bad", neplacano: "warn" };
const stanjeBadge = st => st ? `<span class="badge ${STANJE_NAR[st.koda] || ""}">${esc(st.besedilo)}</span>` : '<span class="badge">brez omejitev</span>';
const STANJE_PR = { izdan: ["izdan", "warn"], placan: ["plačan", "ok"], storniran: ["storniran", ""] };
const prBadge = s => `<span class="badge ${(STANJE_PR[s] || [])[1] || ""}">${esc((STANJE_PR[s] || [s])[0])}</span>`;
function imeModula(id) {
  const n = NAVITEMS.find(x => x.id === id); if (n) return n.label;
  const t = typeof TABS !== "undefined" && TABS.find(x => "tab:" + x[0] === id); return t ? t[1] : id;
}
const imePaketa = (pk, id) => id ? ((pk.paketi.find(p => p.id === id) || {}).ime || id) : "ni določen (vse funkcije)";

// --- zaklenjena funkcija ---
async function zaklenjenoHtml(modul) {
  const pk = await paketi(), potreben = VIS.zak[modul], moj = VIS.paket;
  let kontakt = '<p class="mut">Za nadgradnjo se obrnite na odgovorno osebo v vašem podjetju.</p>';
  if (ME.u.vloga === "odgovorna" && ME.u.stranka_id) {
    const n = await api("GET", "/api/narocnina?stranka_id=" + ME.u.stranka_id).catch(() => null), iz = n && n.izdajatelj;
    kontakt = `<p>Za nadgradnjo se obrnite na svojega svetovalca${iz && (iz.email || iz.telefon) ? ": " + [iz.naziv, iz.email, iz.telefon].filter(Boolean).map(esc).join(", ") : ""}.</p>`;
  }
  const p = pk.paketi.find(x => x.id === potreben) || {};
  return `<div class="card"><h2>🔒 ${esc(imeModula(modul))} ni vključeno v vaš paket</h2>
    <p>Vaš paket: <b>${esc(imePaketa(pk, moj))}</b>. Ta funkcija je na voljo v paketu <b>${esc(p.ime || potreben)}</b> in višjih.</p>
    <p class="mut">${esc(p.ime || "")}: ${esc(p.opis || "")}</p>${kontakt}</div>`;
}
async function pageZaklenjeno(v, m) { v.innerHTML = await zaklenjenoHtml(m[1]); }
route(/^\/paket\/([\w:-]+)$/, pageZaklenjeno, "Funkcija ni v paketu", null);

// --- paket na profilu stranke (zavihek Podatki) ---
async function paketStrankeCard(el, s) {
  if (!["admin", "svetovalec", "odgovorna"].includes(ME.u.vloga)) return;
  const [pk, n] = await Promise.all([paketi(), api("GET", "/api/narocnina?stranka_id=" + s.id).catch(() => null)]); if (!n || !el.isConnected) return;
  const nar = n.narocnina, p = pk.paketi.find(x => x.id === n.paket);
  const vkl = p ? p.moduli.map(imeModula) : [];
  el.insertAdjacentHTML("beforeend", `<div class="card" id="paket-card"><h2>Paket in naročnina</h2>
    <table class="t"><tr><th style="width:38%">Paket</th><td><b>${esc(imePaketa(pk, n.paket))}</b>${p ? `<div class="mut">${esc(p.opis)}</div>` : ""}</td></tr>
    ${nar ? `<tr><th>Obračun</th><td>${nar.obdobje === "letno" ? "letno" : "mesečno"}, ${eur(nar.cena_mesec)} na mesec + DDV</td></tr><tr><th>Plačano do</th><td>${nar.placano_do ? fdate(nar.placano_do) : "–"} ${stanjeBadge(nar.stanje)}</td></tr>` : ""}
    ${p ? `<tr><th>Vključeno</th><td>${vkl.map(esc).join(", ")}</td></tr>` : ""}</table>
    ${n.predracuni.length ? `<h3 style="margin-top:14px">Predračuni</h3><div class="tw"><table class="t"><tr><th>Številka</th><th>Obdobje</th><th>Znesek z DDV</th><th>Rok</th><th>Stanje</th><th></th></tr>${n.predracuni.map(r => `<tr><td>${esc(r.stevilka)}</td><td>${fdate(r.od)} – ${fdate(r.do)}</td><td>${eur(r.skupaj)}</td><td>${fdate(r.rok)}</td><td>${prBadge(r.status)}</td><td><button class="btn sm ghost sec" data-prpdf="${r.id}">PDF</button></td></tr>`).join("")}</table></div>` : ""}
    ${ME.u.vloga === "admin" ? '<p><a href="#/narocnine">Uredi naročnino in predračune</a></p>' : ""}</div>`);
  $$("[data-prpdf]", el).forEach(b => b.onclick = () => predracunPdf(n.predracuni.find(r => r.id === b.dataset.prpdf), n.izdajatelj));
}

// --- predračun (PDF) ---
function predracunPdf(r, iz) {
  iz = iz || {}; const st = r.stranka || {};
  const blob = pdfBuild({ naslov: "Predračun " + r.stevilka, stranka: st.naziv, plain: true, verzija: "1.0", datum: r.datum }, d => {
    if (r.status === "storniran") { // vodni žig čez stran (pod vsebino), da se storniran predračun ne plača po pomoti
      d.cur.s.push(`q 1 0.82 0.82 rg BT /F2 88 Tf 0.766 0.643 -0.643 0.766 ${(d.W / 2 - 205).toFixed(1)} ${(d.H / 2 - 170).toFixed(1)} Tm <${hexOf("STORNIRAN")}> Tj ET Q`); }
    d.text(d.M, d.y, "PREDRAČUN " + r.stevilka + (r.status === "storniran" ? " – STORNIRAN" + (r.storno ? " " + fdate(r.storno) : "") : ""), 16, true, r.status === "storniran" ? "r" : "g"); d.y -= 26;
    d.table(["Izdajatelj", "Kupec"], [[[iz.naziv, iz.naslov, iz.davcna ? "ID za DDV: " + iz.davcna : "", iz.email, iz.telefon].filter(Boolean).join("\n") || "[podatki izdajatelja]", [st.naziv, st.naslov, st.davcna ? "Davčna številka: " + st.davcna : ""].filter(Boolean).join("\n")]], [50, 50]);
    d.gap(6);
    d.table(["Datum izdaje", "Rok plačila", "Obdobje naročnine"], [[fdate(r.datum), fdate(r.rok), fdate(r.od) + " – " + fdate(r.do)]], [30, 30, 40]);
    d.gap(6);
    d.table(["Postavka", "Količina", "Cena", "Znesek"], r.postavke.map(x => [x.opis + "\n" + fdate(x.obdobje.split(" – ")[0]) + " – " + fdate(x.obdobje.split(" – ")[1]), String(x.kolicina) + " mes.", eurPdf(x.cena), eurPdf(x.znesek)]), [52, 14, 17, 17]);
    d.gap(6);
    d.table(["", "Znesek"], [["Skupaj brez DDV", eurPdf(r.neto)], ["DDV " + r.ddv_stopnja + " %", eurPdf(r.ddv)], ["SKUPAJ ZA PLAČILO", eurPdf(r.skupaj)]], [66, 34]);
    d.gap(10);
    d.p("Plačilo: " + (iz.trr ? "TRR " + iz.trr + (iz.banka ? " (" + iz.banka + ")" : "") : "[TRR izdajatelja]") + ", sklic SI00 " + r.stevilka.replace(/^PR-/, "") + ", namen: naročnina HiGiFood HACCP " + r.stevilka + ".", { bold: true });
    d.p("Predračun ni račun. Račun izdamo po prejemu plačila.", { col: "m" });
  });
  dlBlob(blob, "predracun-" + r.stevilka + ".pdf");
}

// --- administrator: naročnine, predračuni, cenik ---
async function pageNarocnine(v) {
  const [d, st] = await Promise.all([api("GET", "/api/narocnine"), D.list("stranke")]);
  const sm = Object.fromEntries(st.map(s => [s.id, s])), pk = d;
  const vrste = st.map(s => ({ s, n: d.stranke[s.id] || null })).sort((a, b) => (a.n ? 0 : 1) - (b.n ? 0 : 1) || String(a.s.naziv).localeCompare(b.s.naziv, "sl"));
  const kod = k => vrste.filter(x => x.n && x.n.stanje.koda === k).length;
  const mrr = vrste.filter(x => x.n && x.n.stanje.koda !== "zapadla").reduce((a, x) => a + (Number(x.n.cena_mesec) || 0), 0);
  const kpi = (n, l, cls) => `<div class="kpi ${cls || ""}"><b>${n}</b><span>${l}</span></div>`;
  const pr = d.predracuni.slice().sort((a, b) => b.datum.localeCompare(a.datum) || b.stevilka.localeCompare(a.stevilka));
  const c = d.cenik, iz = d.izdajatelj;
  v.innerHTML = `<p class="note info">Paket določa, katere funkcije vidijo uporabniki stranke (odgovorna oseba, zaposleni). Stranka brez paketa ima vse funkcije. Plačila urejate sami: izdate predračun, ga pošljete stranki in ga po plačilu označite kot plačanega (podaljša »plačano do«). Računov program ne izdaja.</p>
  <div class="kpis">${kpi(kod("aktivna"), mn(kod("aktivna"), ["aktivna naročnina", "aktivni naročnini", "aktivne naročnine", "aktivnih naročnin"]))}${kpi(kod("poteka"), mn(kod("poteka"), ["poteče", "potečeta", "potečejo", "poteče"]) + " v " + mnx(c.opozorilo_dni, ["dnevu", "dneh", "dneh", "dneh"]))}${kpi(kod("zapadla") + kod("neplacano"), mn(kod("zapadla") + kod("neplacano"), ["zapadla ali neplačana", "zapadli ali neplačani", "zapadle ali neplačane", "zapadlih ali neplačanih"]))}${kpi(eur(mrr), "mesečno (brez DDV)")}</div>
  <div class="card"><h2>Naročnine strank</h2><div class="tw"><table class="t"><tr><th>Stranka</th><th>Paket</th><th>Obračun</th><th>Na mesec</th><th>Plačano do</th><th>Stanje</th><th></th></tr>
  ${vrste.map(({ s, n }) => `<tr><td>${esc(sIme(s))}</td><td>${esc(imePaketa(pk, n && n.paket))}</td><td>${n ? (n.obdobje === "letno" ? "letno" : "mesečno") : ""}</td><td>${n ? eur(n.cena_mesec) : ""}</td><td>${n && n.placano_do ? fdate(n.placano_do) : ""}</td><td>${n ? stanjeBadge(n.stanje) : '<span class="badge">brez omejitev</span>'}</td>
    <td style="white-space:nowrap"><button class="btn sm" data-ur="${s.id}">Uredi</button> ${n ? `<button class="btn sm ghost sec" data-pr="${s.id}">Izdaj predračun</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Ni strank.</td></tr>'}</table></div></div>
  <div class="card"><h2>Predračuni</h2><div class="tw"><table class="t"><tr><th>Številka</th><th>Stranka</th><th>Obdobje</th><th>Z DDV</th><th>Rok</th><th>Stanje</th><th></th></tr>
  ${pr.map(r => `<tr><td>${esc(r.stevilka)}</td><td>${esc((sm[r.stranka_id] || r.stranka || {}).naziv || "")}</td><td>${fdate(r.od)} – ${fdate(r.do)}</td><td>${eur(r.skupaj)}</td><td>${fdate(r.rok)}${r.status === "izdan" && r.rok < today() ? ' <span class="badge bad">zamuda</span>' : ""}</td><td>${prBadge(r.status)}${r.placano_dne ? " " + fdate(r.placano_dne) : ""}</td>
    <td style="white-space:nowrap"><button class="btn sm ghost sec" data-pdf="${r.id}">PDF</button> ${r.status === "izdan" ? `<button class="btn sm" data-pl="${r.id}">Plačano</button> <button class="btn sm ghost sec" data-st="${r.id}">Storniraj</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Ni predračunov.</td></tr>'}</table></div></div>
  <div class="card"><div class="row" style="margin:0 0 8px"><h2 style="margin:0">Paketi</h2><span class="sp"></span><button class="btn" id="pk_nov">Nov paket</button></div><p class="mut">Paket določa funkcije, ki jih vidijo uporabniki stranke, in mesečno ceno za prvi obrat (brez DDV). Cene lahko kadar koli spremenite; obstoječim strankam ostane dogovorjena cena, razen če izberete, da se posodobi.</p><div class="tw"><table class="t"><tr><th>Paket</th><th>Vsebina</th><th>Cena na mesec</th><th>Strank</th><th></th></tr>${pk.paketi.map((p, i) => { const prej = pk.paketi[i - 1], nove = prej ? p.moduli.filter(m => !prej.moduli.includes(m)) : p.moduli, manj = prej ? prej.moduli.filter(m => !p.moduli.includes(m)) : []; return `<tr><td><b>${esc(p.ime)}</b></td><td>${esc(p.opis || "")}<div class="mut">${esc((prej ? (nove.length ? "+ " + nove.map(imeModula).join(", ") : "enake funkcije kot " + prej.ime) + (manj.length ? "; brez: " + manj.map(imeModula).join(", ") : "") : p.moduli.map(imeModula).join(", ")))}</div></td><td>${eur(p.cena)}</td><td>${(d.uporaba || {})[p.id] || 0}</td><td style="white-space:nowrap"><button class="btn sm" data-pku="${p.id}">Uredi</button> <button class="btn sm ghost sec" data-pkx="${p.id}">Izbriši</button></td></tr>`; }).join("") || '<tr><td colspan="5" class="empty">Ni paketov.</td></tr>'}</table></div></div>
  <div class="card"><h2>Cenik in podatki izdajatelja</h2><p class="mut">Cene so brez DDV. Predlog mesečne cene: prvi obrat po ceniku, vsak dodatni obrat s popustom. Pri letnem plačilu se obračuna 12 mesecev manj brezplačnih.</p>
  <div class="fgrid">${[["popust_obrat", "Popust za dodatni obrat (%)"], ["brezplacni_meseci", "Brezplačni meseci pri letnem plačilu"], ["ddv", "DDV (%)"], ["rok_dni", "Rok plačila (dni)"], ["opozorilo_dni", "Opozorilo pred iztekom (dni)"]].map(([k, l]) => `<label class="f"><span>${l}</span><input type="number" min="0" step="0.01" data-c="${k}" value="${esc(c[k])}"></label>`).join("")}</div>
  <div class="fgrid">${[["naziv", "Izdajatelj (naziv)"], ["naslov", "Naslov"], ["davcna", "ID za DDV / davčna št."], ["trr", "TRR (IBAN)"], ["banka", "Banka"], ["email", "E-pošta"], ["telefon", "Telefon"]].map(([k, l]) => `<label class="f"><span>${l}</span><input data-i="${k}" value="${esc(iz[k] || "")}"></label>`).join("")}</div>
  <button class="btn" id="n_sh">Shrani cenik in podatke</button></div>`;
  $("#n_sh").onclick = async () => {
    const cen = {}, izd = {}; $$("[data-c]", v).forEach(i => cen[i.dataset.c] = i.value); $$("[data-i]", v).forEach(i => izd[i.dataset.i] = i.value.trim());
    try { await api("PUT", "/api/narocnine/nastavitve", { cenik: cen, izdajatelj: izd }); PAK.podatki = null; toast("Shranjeno"); render(); } catch (e) { fail(e); }
  };
  $$("[data-ur]", v).forEach(b => b.onclick = () => urediNarocnino(sm[b.dataset.ur], d.stranke[b.dataset.ur], d));
  $("#pk_nov").onclick = () => urediPaket(null, d);
  $$("[data-pku]", v).forEach(b => b.onclick = () => urediPaket(pk.paketi.find(p => p.id === b.dataset.pku), d));
  $$("[data-pkx]", v).forEach(b => b.onclick = () => { const p = pk.paketi.find(x => x.id === b.dataset.pkx); confirmBox("Izbrišem paket »" + p.ime + "«?", async () => { try { await api("DELETE", "/api/narocnine/paketi/" + p.id); PAK.podatki = null; toast("Paket izbrisan"); render(); } catch (e) { fail(e); } }, true); });
  $$("[data-pr]", v).forEach(b => b.onclick = async () => { try { const r = await api("POST", "/api/narocnine/" + b.dataset.pr + "/predracun", {}); toast("Predračun " + r.stevilka + " izdan"); predracunPdf(r, iz); render(); } catch (e) { fail(e); } });
  $$("[data-pdf]", v).forEach(b => b.onclick = () => predracunPdf(pr.find(r => r.id === b.dataset.pdf), iz));
  $$("[data-pl]", v).forEach(b => b.onclick = () => { const r = pr.find(x => x.id === b.dataset.pl); modal("Plačilo predračuna " + r.stevilka, `<p>Znesek: <b>${eur(r.skupaj)}</b>. Naročnina bo podaljšana do ${fdate(r.do)}.</p><label class="f"><span>Datum plačila</span><input type="date" id="pl_d" value="${today()}"></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Označi kot plačano", fn: async () => { await api("POST", "/api/predracun/" + r.id + "/placan", { datum: $("#pl_d").value }); toast("Plačilo zabeleženo"); render(); } }]); });
  $$("[data-st]", v).forEach(b => b.onclick = () => confirmBox("Storniram predračun?", async () => { try { await api("POST", "/api/predracun/" + b.dataset.st + "/storno", {}); toast("Storniran"); render(); } catch (e) { fail(e); } }, true));
}
// ustvarjanje in urejanje paketa: ime, opis, cena, funkcije (moduli)
function urediPaket(p, d) {
  p = p || { id: "", ime: "", opis: "", cena: "", moduli: [] }; const upor = (d.uporaba || {})[p.id] || 0;
  const skupine = {}; for (const m of d.moduli) { const k = m.startsWith("tab:") ? "Zavihki v profilu stranke" : "Meni"; (skupine[k] = skupine[k] || []).push(m); }
  modal(p.id ? "Paket: " + p.ime : "Nov paket", `<div class="fgrid">
    <label class="f"><span>Ime paketa</span><input id="pk_i" value="${esc(p.ime)}" maxlength="60"></label>
    <label class="f"><span>Cena na mesec za prvi obrat (€, brez DDV)</span><input type="number" min="0" step="0.01" id="pk_c" value="${esc(p.cena)}"></label>
    <label class="f wide"><span>Opis (vidi ga tudi stranka)</span><input id="pk_o" value="${esc(p.opis || "")}" maxlength="300"></label></div>
    <div class="row" style="margin:6px 0"><b>Funkcije v paketu</b><span class="sp"></span><button type="button" class="btn sm ghost sec" id="pk_vse">Izberi vse</button><button type="button" class="btn sm ghost sec" id="pk_nic">Počisti</button></div>
    ${Object.entries(skupine).map(([k, ms]) => `<fieldset style="border:1px solid var(--line);border-radius:8px;margin:0 0 8px;padding:6px 10px"><legend class="mut">${k}</legend><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:2px 12px">${ms.map(m => `<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-pkm="${esc(m)}" ${p.moduli.includes(m) ? "checked" : ""}> ${esc(imeModula(m))}</label>`).join("")}</div></fieldset>`).join("")}
    ${upor ? `<label style="display:flex;gap:6px;align-items:center;margin-top:6px"><input type="checkbox" id="pk_pos"> Novo ceno uporabi tudi pri ${upor} obstoječih strankah s tem paketom (sicer jim ostane dogovorjena cena)</label>` : ""}`,
  [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani paket", fn: async () => {
    const moduli = $$("[data-pkm]").filter(c => c.checked).map(c => c.dataset.pkm);
    const r = await api("PUT", "/api/narocnine/paketi/" + p.id, { ime: $("#pk_i").value, opis: $("#pk_o").value, cena: $("#pk_c").value, moduli, posodobi_stranke: !!($("#pk_pos") && $("#pk_pos").checked) });
    PAK.podatki = null; toast("Paket shranjen" + (r.posodobljenih ? ", posodobljenih strank: " + r.posodobljenih : "")); render();
  } }]);
  $("#pk_vse").onclick = () => $$("[data-pkm]").forEach(c => c.checked = true);
  $("#pk_nic").onclick = () => $$("[data-pkm]").forEach(c => c.checked = false);
}
function urediNarocnino(s, n, d) {
  n = n || {}; const pred = d.predlogi[s.id] || {};
  modal("Naročnina: " + s.naziv, `<div class="fgrid">
    <label class="f"><span>Paket</span><select id="nr_p"><option value="">ni določen (vse funkcije, brez obračuna)</option>${d.paketi.map(p => `<option value="${p.id}" ${n.paket === p.id ? "selected" : ""}>${esc(p.ime)}</option>`).join("")}</select></label>
    <label class="f"><span>Obračun</span><select id="nr_o"><option value="mesecno">mesečno</option><option value="letno" ${n.obdobje === "letno" ? "selected" : ""}>letno (${d.cenik.brezplacni_meseci} meseca brezplačno)</option></select></label>
    <label class="f"><span>Cena na mesec (€, brez DDV)</span><input type="number" min="0" step="0.01" id="nr_c" value="${esc(n.cena_mesec !== undefined ? n.cena_mesec : "")}"><small class="mut" id="nr_pc"></small></label>
    <label class="f"><span>Začetek</span><input type="date" id="nr_z" value="${esc(n.zacetek || today())}"></label>
    <label class="f"><span>Plačano do</span><input type="date" id="nr_d" value="${esc(n.placano_do || "")}"></label>
    <label class="f wide"><span>Opomba (vidi samo administrator)</span><input id="nr_op" value="${esc(n.opomba || "")}"></label></div>`,
  [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: async () => {
    const paket = $("#nr_p").value;
    if (!paket) await api("PUT", "/api/narocnine/" + s.id, { paket: null });
    else await api("PUT", "/api/narocnine/" + s.id, { paket, obdobje: $("#nr_o").value, cena_mesec: $("#nr_c").value === "" ? pred[paket] : $("#nr_c").value, zacetek: $("#nr_z").value, placano_do: $("#nr_d").value, opomba: $("#nr_op").value });
    toast("Naročnina shranjena"); render();
  } }]);
  const pc = () => { const p = $("#nr_p").value; $("#nr_pc").innerHTML = p ? `Predlog po ceniku (glede na število obratov): <a href="#" id="nr_up">${eur(pred[p])}</a>` : ""; const a = $("#nr_up"); if (a) a.onclick = e => { e.preventDefault(); $("#nr_c").value = pred[p]; }; };
  $("#nr_p").onchange = pc; pc();
}
route(/^\/narocnine$/, pageNarocnine, "Naročnine in predračuni", "narocnine");
navItem("narocnine", "Naročnine in predračuni", "#/narocnine", ["admin"]);

// --- nadzorna plošča: opozorila o naročnini ---
async function narocninaOpozorilo() {
  if (ME.real) return "";
  if (ME.u.vloga === "admin") {
    const d = await api("GET", "/api/narocnine").catch(() => null); if (!d) return "";
    const vr = Object.entries(d.stranke).filter(([, n]) => n && ["poteka", "zapadla"].includes(n.stanje.koda)); if (!vr.length) return "";
    const st = await D.list("stranke").catch(() => []), sm = Object.fromEntries(st.map(s => [s.id, s.naziv]));
    return `<div class="note" style="border-left:4px solid var(--warnl)"><b>Naročnine:</b><ul style="margin:6px 0 0">${vr.map(([sid, n]) => `<li>${esc(sm[sid] || sid)}: ${esc(n.stanje.besedilo)} (${fdate(n.placano_do)})</li>`).join("")}</ul><a href="#/narocnine">Odpri naročnine</a></div>`;
  }
  if (ME.u.vloga === "odgovorna" && ME.u.stranka_id) {
    const n = await api("GET", "/api/narocnina?stranka_id=" + ME.u.stranka_id).catch(() => null), nar = n && n.narocnina;
    if (!nar || !["poteka", "zapadla"].includes(nar.stanje.koda)) return "";
    const odprt = n.predracuni.find(r => r.status === "izdan");
    return `<div class="note" style="border-left:4px solid var(--warnl)"><b>Naročnina ${nar.stanje.koda === "zapadla" ? "je zapadla" : "kmalu poteče"}</b> (plačano do ${fdate(nar.placano_do)}).${odprt ? ` Predračun ${esc(odprt.stevilka)} za ${eur(odprt.skupaj)} najdete v <a href="#/stranka/${ME.u.stranka_id}/podatki">podatkih podjetja</a>.` : " Za podaljšanje se obrnite na svojega svetovalca."}</div>`;
  }
  return "";
}
