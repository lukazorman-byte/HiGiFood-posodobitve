// Besedila dokumentacije (baza »besedila«): čarovnik vstavi opisna besedila poglavij s podatki načrta (in po dejavnosti),
// besedilo poglavja je mogoče prilagoditi in ponastaviti, nova poglavja se vstavijo tudi v starejše načrte; generator uporablja ista besedila.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  ok(await pg.evaluate(async () => (await baza()).besedila.length >= 30), "baza znanja ima zbirko besedil");
  const nid = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Moj Likerček d.o.o.", odgovorna_oseba: "Eva Bečan", dejavnost: "Turistična kmetija / dopolnilna dejavnost" }); const o = await D.add("obrati", { stranka_id: s.id, naziv: "Destilarna", naslov: "Vas 5" });
    const W = { branza: "liker", zbiranje: { hacc_ekipa: "Eva Bečan – vodja\nAna Novak – tehnolog", kupci: "odrasli potrošniki" }, zivila: [{ id: "z1", naziv: "Orehov liker", alergeni: "Oreščki" }],
      koraki: [{ id: "k1", naziv: "Prevzem alkoholne osnove" }, { id: "k2", naziv: "Maceracija" }, { id: "k3", naziv: "Polnjenje" }],
      nevarnosti: [{ id: "h1", korak_id: "k1", tip: "K", nevarnost: "Metanol", verjetnost: "3", teza: "5", potrjeno: true }], kontrole: { h1: { hid: "h1", vrsta: "CCP" } },
      // starejši načrt: shranjena poglavja brez novih (uvod, skupina, prp)
      poglavja: [["podjetje", "Podatki o podjetju in obratu"], ["dejavnost", "Dejavnost in obseg"], ["zivila", "Opis živil"], ["navodila", "Delovna navodila in predpogojni programi"], ["priloga", "Priloga"]].map(([id, naslov]) => ({ id, naslov, on: true })) };
    return (await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "Liker", vsebina: W })).id;
  });
  await pg.goto(B + "/#/carovnik/" + nid); await pg.waitForSelector(".stepper"); await pg.click(".stepper button >> nth=6"); await pg.waitForSelector("[data-pb]", { state: "attached" });
  const pgl = await pg.$$eval("#pgl tr[data-i] input[data-k=naslov]", i => i.map(x => x.value));
  ok(pgl[0] === "Namen in obseg sistema HACCP" && pgl.indexOf("HACCP skupina in odgovornosti") === pgl.indexOf("Podatki o podjetju in obratu") + 1 && pgl.indexOf("Predpogojni programi") === pgl.indexOf("Delovna navodila in predpogojni programi") - 1, "starejši načrt: nova poglavja vstavljena na pravo mesto (" + pgl.join(" | ") + ")");
  const uvod = await pg.inputValue('[data-pb="uvod"]');
  ok(/Moj Likerček d\.o\.o\./.test(uvod) && /Destilarna, Vas 5/.test(uvod) && /Prevzem alkoholne osnove → Maceracija → Polnjenje/.test(uvod) && /Eva Bečan/.test(uvod) && !/\{/.test(uvod), "uvod: besedilo z vstavljenimi podatki (podjetje, obrat, koraki, odgovorna oseba)");
  ok(/Eva Bečan – vodja/.test(await pg.inputValue('[data-pb="skupina"]')), "HACCP skupina iz koraka 1");
  ok(/Posebnosti alkoholnih pijač/.test(await pg.inputValue('[data-pb="nevarnosti"]')) && !/Posebnosti mesa/.test(await pg.inputValue('[data-pb="nevarnosti"]')), "besedila po dejavnosti: alkoholne pijače da, meso ne");
  ok(/CCP1 \(Prevzem alkoholne osnove\)/.test(await pg.inputValue('[data-pb="ccp"]')) && /Oreščki/.test(await pg.inputValue('[data-pb="zivila"]')), "CCP in alergeni iz načrta v besedilu");
  // prilagoditev besedila poglavja PRP
  await pg.click('details.pgl-b:has([data-pb="prp"]) summary'); await pg.fill('[data-pb="prp"]', "## Naš program\n\nLastno besedilo o PRP.\n\n- prva alineja\n- druga alineja");
  ok(await pg.locator('[data-pbr="prp"]:visible').count() === 1, "prilagojeno besedilo: gumb za ponastavitev");
  // izvoz Word: besedila v dokumentu
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#xdoc")]); const buf = require("fs").readFileSync(await dl.path()).toString("utf8");
  ok(/Namen dokumenta/.test(buf) && /Moj Likerček/.test(buf) && /Posebnosti alkoholnih pijač/.test(buf) && /Lastno besedilo o PRP/.test(buf) && !/Čiščenje in razkuževanje<\/w:t>/.test(buf), "Word: besedila iz baze in prilagojeno besedilo PRP (namesto privzetega)");
  await pg.click('[data-pbr="prp"]'); ok(/Čiščenje in razkuževanje/.test(await pg.inputValue('[data-pb="prp"]')), "ponastavitev na besedilo iz baze");
  // generator dokumentacije
  await pg.goto(B + "/generator/"); await pg.waitForSelector("#cat option[value=liker]", { state: "attached" });
  await pg.selectOption("#cat", "liker"); await pg.fill("#company", "Moj Likerček d.o.o."); await pg.click("#segbar-haccp .chip.act:has-text('Priporočeni')"); await pg.waitForSelector("#out-haccp h2");
  const g = await pg.textContent("#out-haccp");
  ok(/Namen dokumenta/.test(g) && /Moj Likerček d\.o\.o\./.test(g) && /Posebnosti alkoholnih pijač/.test(g) && /Verifikacija/.test(g) && /HACCP skupina/.test(g), "generator: ista besedila (namen, dejavnost, verifikacija) s podatki obrazca");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
