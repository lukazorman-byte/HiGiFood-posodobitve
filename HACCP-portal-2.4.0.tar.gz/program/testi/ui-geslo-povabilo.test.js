// Pozabljeno geslo in povabila po e-pošti: povezava z enkratnim žetonom, nastavitev gesla v brskalniku, enak odgovor za neznan naslov.
const net = require("net"), fs = require("fs"), path = require("path");
const B = process.env.BASE, OUT = process.env.OUT || require("os").tmpdir(); fs.mkdirSync(OUT, { recursive: true });
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
// SMTP, ki shrani sporočila (besedilo je v base64)
const posta = [];
const smtp = net.createServer(c => { let data = false, buf = "", to = "", body = []; c.on("error", () => {}); c.write("220 mock\r\n");
  c.on("data", d => { buf += d; let i; while ((i = buf.indexOf("\r\n")) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 2);
    if (data) { if (l === ".") { data = false; const t = body.join("\r\n"), k = t.indexOf("\r\n\r\n"); posta.push({ to, besedilo: Buffer.from(t.slice(k + 4).replace(/\s/g, ""), "base64").toString("utf8") }); body = []; c.write("250 ok\r\n"); } else body.push(l); continue; }
    if (/^EHLO/.test(l)) c.write("250 mock\r\n"); else if (/^RCPT TO:<(.+)>/.test(l)) { to = /^RCPT TO:<(.+)>/.exec(l)[1]; c.write("250 ok\r\n"); } else if (/^MAIL/.test(l)) c.write("250 ok\r\n");
    else if (l === "DATA") { data = true; c.write("354 go\r\n"); } else if (l === "QUIT") { c.write("221 bye\r\n"); c.end(); } } }); });
const cakaj = async (pogoj, ms = 8000) => { for (let i = 0; i < ms / 100; i++) { const r = pogoj(); if (r) return r; await new Promise(r => setTimeout(r, 100)); } return null; };
(async () => {
  await new Promise(r => smtp.listen(0, "127.0.0.1", r)); const sport = smtp.address().port;
  const br = await chromium.launch(); const errs = [];
  const mk = async () => { const p = await (await br.newContext()).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => (await D.add("stranke", { naziv: "Povabilo d.o.o." })).id);
  // brez nastavljene e-pošte: razumljivo sporočilo
  const brez = await pg.evaluate(() => api("POST", "/api/auth/pozabljeno", { email: "a@t.si" }).then(() => "", e => e.message));
  ok(/administratorja/.test(brez), "brez nastavljene e-pošte: »obrnite se na administratorja«");
  await pg.evaluate(([port, B]) => api("PUT", "/api/nastavitve", { streznik: "127.0.0.1", vrata: port, varnost: "brez", od: "HiGiFood <n@t.si>", naslov_aplikacije: B }), [sport, B]);
  // povabilo novemu uporabniku
  await pg.goto(B + "/#/uporabniki"); await pg.waitForSelector("#un"); await pg.click("#un");
  await pg.fill("#u_i", "Nina Nova"); await pg.fill("#u_e", "nina@t.si"); await pg.selectOption("#u_v", "odgovorna"); await pg.selectOption("#u_s", sid);
  await pg.check("#u_pov"); ok(await pg.locator("#u_p_w").isHidden(), "ob povabilu polje za začasno geslo izgine");
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('Povabilo poslano')");
  const pov = await cakaj(() => posta.find(m => m.to === "nina@t.si"));
  ok(pov && /Povabilo d\.o\.o\./.test(pov.besedilo) && /\/#\/geslo\/[\w-]{20,}/.test(pov.besedilo), "povabilo prispe po e-pošti (stranka in povezava)");
  ok(await pg.locator('tr:has-text("nina@t.si") .badge:has-text("povabljen")').count() === 1, "seznam: uporabnik označen kot povabljen");
  const link = /(http\S+\/#\/geslo\/[\w-]+)/.exec(pov.besedilo)[1];
  const n = await mk(); await n.goto(link); await n.waitForSelector("text=Dobrodošli! Nastavite geslo");
  ok((await n.textContent("#login")).includes("nina@t.si"), "povezava odpre stran za nastavitev gesla z e-naslovom");
  await n.fill("#gz_1", "ninino-geslo-1"); await n.fill("#gz_2", "ninino-geslo-2"); await n.click("#gz_f button"); ok((await n.textContent("#gz_e")).includes("ne ujemata"), "neujemajoči gesli zavrnjeni");
  await n.fill("#gz_2", "ninino-geslo-1"); await n.click("#gz_f button"); await n.waitForSelector("#gz_ok");
  ok(await n.inputValue("#le") === "nina@t.si", "po nastavitvi: prijava z vpisanim e-naslovom");
  await n.fill("#lp", "ninino-geslo-1"); await n.click("#lf button"); await n.waitForSelector("#shell:not([hidden])"); ok(true, "prijava z novim geslom (brez obvezne zamenjave)");
  await n.goto(link); await n.waitForSelector("text=Povezava ni veljavna"); ok(true, "povezava je enkratna");
  // pozabljeno geslo
  const lp = await mk(); await lp.goto(B + "/"); await lp.waitForSelector("#l_poz"); await lp.click("#l_poz"); await lp.fill("#pz_m", "ni-ga@t.si"); await lp.click("#dlg-f .btn:last-child");
  await lp.waitForSelector("text=Če račun s tem e-naslovom obstaja"); const neznan = posta.length;
  await lp.click("#dlg-f .btn"); await lp.click("#l_poz"); await lp.fill("#pz_m", "nina@t.si"); await lp.click("#dlg-f .btn:last-child"); await lp.waitForSelector("text=Če račun s tem e-naslovom obstaja");
  const ponast = await cakaj(() => posta.slice(neznan).find(m => m.to === "nina@t.si" && /ponastavitev gesla/.test(m.besedilo)));
  ok(posta.slice(0, neznan).every(m => m.to !== "ni-ga@t.si") && ponast, "neznan naslov: enak odgovor, brez sporočila; znan: sporočilo s povezavo");
  const l2 = /(http\S+\/#\/geslo\/[\w-]+)/.exec(ponast.besedilo)[1];
  await lp.goto(l2); await lp.waitForSelector("text=Nastavite novo geslo"); await lp.fill("#gz_1", "novo-geslo-777"); await lp.fill("#gz_2", "novo-geslo-777"); await lp.click("#gz_f button"); await lp.waitForSelector("#gz_ok");
  const prijava = async g => (await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "application/json", Origin: B }, body: JSON.stringify({ email: "nina@t.si", geslo: g }) })).status;
  ok(await prijava("novo-geslo-777") === 200 && await prijava("ninino-geslo-1") === 401, "novo geslo deluje, staro ne");
  ok(await n.evaluate(() => api("GET", "/api/auth/jaz").then(() => 200, e => e.status)) === 401, "po ponastavitvi gesla so prejšnje prijave odjavljene");
  // ponovno pošiljanje povabila iz urejanja uporabnika
  const pred = posta.length; await pg.reload(); await pg.waitForSelector('tr:has-text("nina@t.si")'); await pg.click('tr:has-text("nina@t.si")'); await pg.click("#u_inv"); await pg.waitForSelector(".toast.show:has-text('Poslano')");
  ok(await cakaj(() => posta.length > pred), "»Pošlji povezavo za nastavitev gesla« iz urejanja uporabnika");
  ok(await pg.evaluate(() => api("GET", "/api/revizijska-sled?n=60").then(r => ["povabilo-poslano", "povabilo-sprejeto", "geslo-pozabljeno", "geslo-ponastavljeno"].every(a => r.vnosi.some(e => e.akcija === a)))), "dogodki v revizijski sledi");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); smtp.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.message); process.exit(2); });
