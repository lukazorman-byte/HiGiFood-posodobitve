// Poišče Playwright (lokalno, globalno ali prek NODE_PATH) in Chromium.
const cp = require("child_process"), fs = require("fs");
let pw;
for (const f of [() => require("playwright"), () => require(cp.execSync("npm root -g", { stdio: ["ignore", "pipe", "ignore"] }).toString().trim() + "/playwright")]) { try { pw = f(); break; } catch {} }
if (!pw) { console.log("PRESKOČENO: Playwright ni nameščen (npm i -g playwright)"); process.exit(77); }
const own = (() => { try { return pw.chromium.executablePath(); } catch { return null; } })(); // Playwrightov lasten Chromium ima prednost
const exe = process.env.PW_CHROMIUM || [own, "/opt/pw-browsers/chromium", "/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/google-chrome"].find(p => p && fs.existsSync(p));
// Če test zahteva pot do brskalnika, ki na tem računalniku ne obstaja (npr. v GitHub Actions), jo prezri.
const opts = o => { o = Object.assign({}, o || {}); if (o.executablePath && !fs.existsSync(o.executablePath)) delete o.executablePath; return Object.assign({}, exe ? { executablePath: exe } : {}, o); };
module.exports = { chromium: { launch: o => pw.chromium.launch(opts(o)) } };
