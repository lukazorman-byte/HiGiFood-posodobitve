// Vse besedilo na rdečem ozadju ali v rdeči barvi (napake, odstopanja, brisanje) ima zadosten kontrast (WCAG: 4,5 : 1, velike črke 3 : 1) v svetlem in temnem načinu.
const { chromium } = require("./pw.js"); const B = process.env.BASE;
(async () => { const br = await chromium.launch(); const slabi = new Map();
  for (const sch of ["light", "dark"]) {
    const p = await (await br.newContext({ viewport: { width: 1280, height: 900 }, colorScheme: sch })).newPage(); p.on("dialog", d => d.dismiss());
    await p.goto(B + "/"); await p.waitForSelector("#testhint"); await p.click('[data-t="admin@test.si"]'); await p.click("#lf button"); await p.waitForSelector("#shell:not([hidden])");
    const sid = await p.evaluate(async () => (await D.list("stranke"))[0].id);
    const preveri = async (kje) => { const r = await p.evaluate(() => {
      const rgb = c => (c.match(/[\d.]+/g) || []).map(Number), L = ([r, g, b]) => { const f = x => { x /= 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
      const ozadje = el => { while (el) { const c = rgb(getComputedStyle(el).backgroundColor); if (c.length >= 3 && (c.length < 4 || c[3] > 0.5)) return c; el = el.parentElement; } return [255, 255, 255]; };
      const rdeca = c => c[0] > 150 && c[0] - c[1] > 50 && c[0] - c[2] > 50;
      const out = [];
      for (const el of document.querySelectorAll("body *")) {
        if (!el.offsetParent && getComputedStyle(el).position !== "fixed") continue; const cs = getComputedStyle(el); if (cs.visibility === "hidden" || +cs.opacity < 0.5) continue;
        const txt = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join(" "); if (!txt) continue;
        const bg = ozadje(el), fg = rgb(cs.color); if (!rdeca(bg) && !rdeca(fg)) continue;
        const a = L(fg), b = L(bg), k = (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05), velik = parseFloat(cs.fontSize) >= 18.6 || (parseFloat(cs.fontSize) >= 14 && +cs.fontWeight >= 700);
        if (k < (velik ? 3 : 4.5)) out.push((el.className && typeof el.className === "string" ? "." + el.className.split(" ").join(".") : el.tagName) + " »" + txt.slice(0, 30) + "« " + k.toFixed(1) + ":1");
      } return out; }); for (const x of r) slabi.set(sch + " | " + x, kje); };
    const strani = ["#/nadzorna", "#/danes", "#/koledar", "#/pregled-zapisov", "#/stranke", "#/umiki", "#/narocnine", "#/uporabniki", "#/vzdrzevanje", "#/admin"].concat(["podatki", "evidence", "capa", "higiena", "oprema", "osebje", "nacrti", "inspekcija"].map(t => "#/stranka/" + sid + "/" + t));
    for (const h of strani) { await p.goto(B + "/" + h); await p.waitForTimeout(700); await preveri(h); }
    // obvestilo o napaki, obrazec z napakami, potrditev brisanja
    await p.evaluate(() => toast("Poskusna napaka", true)); await preveri("toast");
    await p.goto(B + "/#/stranke"); await p.waitForTimeout(500); await p.evaluate(() => openForm("stranke", null, {}, () => {})); await p.waitForSelector("#f_naziv"); await p.fill("#f_davcna", "123"); await p.click("#dlg-f .btn:last-child"); await p.waitForTimeout(300); await preveri("obrazec z napakami");
    await p.keyboard.press("Escape"); await p.evaluate(async () => { const s = (await D.list("stranke"))[0]; openForm("stranke", s, {}, () => {}); }); await p.waitForTimeout(400); await preveri("obrazec – gumb Izbriši");
    await p.keyboard.press("Escape"); await p.evaluate(() => confirmBox("Res izbrišem?", () => {}, true)); await p.waitForTimeout(300); await preveri("potrditev brisanja");
  }
  console.log(slabi.size ? [...slabi].map(([k, v]) => k + "  [" + v + "]").join("\n") : "vse rdeče besedilo ima zadosten kontrast"); await br.close(); })();
