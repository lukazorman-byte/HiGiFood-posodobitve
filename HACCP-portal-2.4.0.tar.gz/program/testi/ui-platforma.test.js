// Platforma – popravki po pregledu: izbris uporabnika (koš), kratko ime stranke, več dejavnosti → predloge čarovnika, nadzorna plošča brez ničel,
// povezava na načrt čiščenja, kaj manjka v Storitvah, prazna stanja z gumbom, hiter vnos temperature, generator s stranko, priporočena 2FA.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const mk = async w => { const p = await (await br.newContext({ viewport: { width: w || 1280, height: 900 } })).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // P7: prazna nadzorna plošča – brez ploščic z 0, bloki s sporočilom
  await pg.goto(B + "/#/nadzorna"); await pg.waitForSelector(".kpi-bloki");
  ok(await pg.locator(".kpi-blok").count() === 3 && await pg.locator(".kpi").count() === 1 && await pg.locator(".kpi-ok").count() === 2, "nadzorna plošča: 3 bloki, samo ploščica »strank«, ostala bloka »✓«");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "EVA BEČAN - NOSILKA DOPOLNILNE DEJAVNOSTI NA KMETIJI", kratko_ime: "Eva Bečan", dejavnost: "Turistična kmetija / dopolnilna dejavnost", dodatne_dejavnosti: ["Pekarna / slaščičarna"] });
    const o = await D.add("obrati", { stranka_id: s.id, naziv: "Kmetija" });
    await D.add("oprema", { stranka_id: s.id, obrat_id: o.id, naziv: "Hladilnik 1", tip: "hladilnik", meja_min: 0, meja_max: 4 });
    const n = await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP kmetija" });
    const u = await api("POST", "/api/uporabniki", { ime: "Zan Zaposleni", email: "zan@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id });
    const od = await api("POST", "/api/uporabniki", { ime: "Oda", email: "oda@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s.id });
    return { sid: s.id, nid: n.id, uid: u.id, od: od.id };
  });
  // P3: kratko ime v aplikaciji, uradni naziv ostane
  await pg.goto(B + "/#/stranke"); await pg.waitForSelector("#lb a:has-text('Eva Bečan')");
  ok(/NOSILKA DOPOLNILNE/.test(await pg.textContent("#lb")), "seznam strank: kratko ime + uradni naziv pod njim");
  await pg.goto(B + "/#/nadzorna"); await pg.waitForSelector("#fs", { state: "attached" }); ok(await pg.locator("#fs option:has-text('Eva Bečan')").count() === 1 && !(await pg.locator("#fs option:has-text('NOSILKA')").count()), "izbirnik strank: kratko ime");
  await pg.goto(B + `/#/stranka/${ids.sid}/podatki`); await pg.waitForSelector("#title:has-text('Eva Bečan')"); await pg.waitForSelector("#tabbody th:has-text('Dejavnost')"); ok(/Pekarna \/ slaščičarna/.test(await pg.textContent("#tabbody")), "profil: naslov s kratkim imenom, vse dejavnosti");
  // P6: dejavnosti → predlogi v čarovniku
  await pg.goto(B + "/#/carovnik/" + ids.nid); await pg.waitForSelector(".stepper"); await pg.click(".stepper button >> nth=1"); await pg.waitForSelector("#wpred");
  const pb = await pg.$$eval("[data-pb]", b => b.map(x => x.dataset.pb)); ok(["jedi", "pekarna", "liker"].every(x => pb.includes(x)), "čarovnik: predloge glede na dejavnosti stranke (" + pb.join(", ") + ")");
  await pg.click("[data-pb=liker]"); ok(await pg.inputValue("#wb") === "liker", "klik na predlog izbere predlogo");
  // P12: prazno stanje z gumbom za prvi zapis
  await pg.goto(B + `/#/stranka/${ids.sid}/dobavitelji`); await pg.waitForSelector("[data-prvi]"); await pg.click("[data-prvi]"); await pg.waitForSelector("dialog[open] #f_naziv");
  ok(true, "prazen seznam: gumb »Dodaj prvi zapis« odpre obrazec"); await pg.keyboard.press("Escape");
  // P8: Danes – povezava na načrt čiščenja
  await pg.goto(B + "/#/danes"); await pg.waitForSelector("[data-hnacrt]"); await pg.click("[data-hnacrt]");
  await pg.waitForSelector(".steps button.on:has-text('Načrt čiščenja')"); ok(true, "Danes: prazen načrt čiščenja → neposredno v Higiena → Načrt čiščenja");
  // P13: hiter vnos temperature (mobilni pogled)
  const m = await mk(390); await m.goto(B + "/"); await m.fill("#le", "a@t.si"); await m.fill("#lp", "dolgogeslo123"); await m.click("#lf button"); await m.waitForSelector("#shell:not([hidden])");
  await m.goto(B + "/#/danes"); await m.waitForSelector("#ht_0"); await m.fill("#ht_0", "3.5"); await m.press("#ht_0", "Enter"); await m.waitForSelector("#htr_0 .badge.ok");
  await m.fill("#ht_0", "9"); await m.click("[data-ht='0']"); await m.waitForSelector("#htr_0 .badge.bad");
  const ev = await m.evaluate(async sid => (await D.list("evidence", { stranka_id: sid })).filter(e => e.vrsta === "temperatura").map(e => [e.vrednost, e.skladno, e.oprema]), ids.sid);
  ok(ev.length === 2 && ev.some(e => e[0] === 3.5 && e[1] === true) && ev.some(e => e[0] === 9 && e[1] === false && e[2] === "Hladilnik 1"), "hiter vnos temperature: zapisa s skladnostjo glede na meje naprave");
  ok(await m.evaluate(() => document.querySelector("#ht_0").getBoundingClientRect().height) >= 48, "mobilni pogled: veliko polje za vnos");
  // P9: Storitve – kaj manjka
  await pg.goto(B + "/#/storitve"); await pg.waitForSelector("details.manjka"); await pg.click("details.manjka summary");
  ok(/odgovorna oseba|naslov/i.test(await pg.textContent("details.manjka ul")) && /Storitve/.test(await pg.textContent("#title")), "Storitve: klik na število pokaže, kaj manjka (brez odpiranja stranke)");
  // P11: generator s stranko
  await pg.goto(B + "/generator/"); await pg.waitForSelector("#stranka option:has-text('Eva Bečan')", { state: "attached" });
  await pg.selectOption("#stranka", ids.sid); await pg.waitForFunction(() => /BEČAN/.test(document.querySelector("#company").value));
  ok(await pg.inputValue("#cat") === "jedi", "generator: izbira stranke izpolni podjetje in vrsto proizvodnje");
  // P14: izbris uporabnika
  const o = await mk(); await o.goto(B + "/"); await o.fill("#le", "oda@t.si"); await o.fill("#lp", "dolgogeslo123"); await o.click("#lf button"); await o.waitForSelector("#shell:not([hidden])");
  ok(await o.evaluate(async id => (await fetch("/api/uporabniki/" + id, { method: "DELETE", headers: { Origin: location.origin } })).status, ids.uid) === 403, "odgovorna oseba ne more brisati uporabnikov (tudi svojih zaposlenih)");
  await pg.goto(B + "/#/uporabniki"); await pg.waitForSelector("td:has-text('zan@t.si')"); await pg.click("tr:has-text('zan@t.si')"); await pg.waitForSelector("#u_del");
  await pg.click("#u_del"); await pg.waitForSelector("dialog[open] >> text=Koš"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !/zan@t\.si/.test(document.querySelector("#view").textContent));
  const k = await pg.evaluate(async () => (await api("GET", "/api/kos")).filter(x => x.zbirka === "uporabniki"));
  ok(k.length === 1 && /zan@t\.si/.test(k[0].ime), "izbrisan uporabnik je v Košu");
  const pr = await pg.evaluate(async () => { try { await api("POST", "/api/auth/prijava", { email: "zan@t.si", geslo: "dolgogeslo123" }); return "ok"; } catch (e) { return e.message; } });
  ok(pr !== "ok", "izbrisan uporabnik se ne more prijaviti");
  const self = await pg.evaluate(async () => { try { await api("DELETE", "/api/uporabniki/" + ME.u.id); return "ok"; } catch (e) { return e.message; } }); ok(/Sebe/.test(self), "sebe ni mogoče izbrisati");
  await pg.evaluate(async id => api("POST", "/api/kos/" + id + "/obnovi"), k[0].id);
  ok(await pg.evaluate(async () => (await api("GET", "/api/uporabniki")).some(u => u.email === "zan@t.si")), "obnova uporabnika iz Koša");
  // P1: priporočena obvezna 2FA z enim klikom
  await pg.goto(B + "/#/admin/varnost"); await pg.waitForSelector("#var_p"); await pg.click("#var_p"); await pg.waitForSelector(".toast.show:has-text('Shranjeno')");
  const v = await pg.$$eval("[data-o2]:checked", c => c.map(x => x.dataset.o2)); ok(v.join() === "admin,svetovalec" && /Shranjeno/.test(await pg.textContent("#toast")), "»Vklopi priporočeno«: obvezna 2FA za administratorja in svetovalca");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
