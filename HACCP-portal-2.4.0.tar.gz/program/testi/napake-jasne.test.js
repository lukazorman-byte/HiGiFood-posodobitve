// Napake so izpisane jasno: označene z »Napaka«, opozorilo za bralnike zaslona, gumb za zapiranje, razumljivo besedilo strežnika in aplikacije.
const B = process.env.BASE; const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const r = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Jasne napake" }); await api("POST", "/api/uporabniki", { ime: "Z", email: "zj@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id });
    return { ni: await api("GET", "/api/d/stranke/neobstaja").then(() => "", e => e.message), zb: await api("GET", "/api/d/neobstaja").then(() => "", e => e.message), s: s.id };
  });
  ok(/ni mogoče najti/.test(r.ni) && /ne obstaja/.test(r.zb), "strežnik: razumljiva sporočila (" + r.ni + " | " + r.zb + ")");
  await pg.evaluate(() => toast("Poskusna napaka za preverjanje.", true));
  const t = await pg.evaluate(() => { const e = $("#toast"); return { role: e.getAttribute("role"), live: e.getAttribute("aria-live"), txt: e.textContent, x: !!$(".toast-x", e), show: e.classList.contains("show") }; });
  ok(t.role === "alert" && t.live === "assertive" && /Napaka/.test(t.txt) && /Poskusna napaka/.test(t.txt) && t.x && t.show, "napaka: oznaka »Napaka«, role=alert, gumb za zapiranje");
  // berljivost: besedilo mora imeti drugačno barvo kot ozadje (prej ga je pravilo .err obarvalo enako kot ozadje)
  const kontrast = await pg.evaluate(() => { const L = c => { const [r, g, b] = c.match(/\d+/g).slice(0, 3).map(x => { x /= 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; }; const cs = getComputedStyle($(".toast-b")), bg = getComputedStyle($("#toast")).backgroundColor; const a = L(cs.color), b = L(bg); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); });
  ok(kontrast >= 4.5, "besedilo napake je berljivo (kontrast " + kontrast.toFixed(1) + ":1)");
  await pg.click(".toast-x"); ok(await pg.evaluate(() => !$("#toast").classList.contains("show")), "gumb × zapre obvestilo");
  // napaka med odprtim oknom (npr. obrazec) je vidna nad oknom, ne skrita pod njim; po zaprtju okna se obvestilo vrne na stran
  await pg.evaluate(() => { openForm("stranke", null, {}, () => {}); toast("Napaka med urejanjem.", true); });
  ok(await pg.evaluate(() => { const r = $("#toast").getBoundingClientRect(), el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return !!el && $("#toast").contains(el); }), "napaka je vidna nad odprtim oknom");
  await pg.keyboard.press("Escape"); await pg.waitForFunction(() => !document.querySelector("dialog[open]")); ok(await pg.waitForFunction(() => $("#toast").parentElement === document.body, null, { timeout: 3000 }).then(() => true, () => false), "po zaprtju okna je obvestilo spet na strani");
  await pg.evaluate(() => toast("Shranjeno")); ok(await pg.evaluate(() => $("#toast").getAttribute("role") === "status" && !$(".toast-x")), "navadno obvestilo ostane preprosto (role=status)");
  await pg.evaluate(() => fail(new TypeError("x is undefined"))); ok(/nepričakovane napake.*Osvežite stran/.test(await pg.textContent("#toast")), "napaka v kodi: jasno navodilo uporabniku");
  const z = await (await br.newContext()).newPage(); await z.goto(B + "/"); await z.fill("#le", "zj@t.si"); await z.fill("#lp", "dolgogeslo123"); await z.click("#lf button"); await z.waitForSelector("#shell:not([hidden])");
  const zp = await z.evaluate(() => api("POST", "/api/d/stranke", { naziv: "X" }).then(() => "", e => e.message)); ok(/nimate pravic/.test(zp), "zaposleni: »" + zp + "«");
  await z.goto(B + "/#/vidnost"); await z.waitForFunction(() => location.hash === "#/nadzorna"); ok(/Nastavitve vidnosti.*ni na voljo za vašo vlogo/.test(await z.textContent("#toast")), "strani brez dostopa: ime razdelka in razlog (" + await z.textContent("#toast") + ")");
  await z.goto(B + "/#/stranka/" + r.s + "/osebje"); await z.waitForFunction(() => /\/podatki$/.test(location.hash)); ok(/Zavihek »Zaposleni in usposabljanja«/.test(await z.textContent("#toast")), "skrit zavihek: ime zavihka v obvestilu");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
