// Posodobitev strežnika iz podpisane izdaje (scripts/posodobi-streznik.js): namestitev nove različice, ohranitev .env in Caddyfile,
// kopija prejšnje različice, zavrnitev ponarejenega arhiva ali tujega podpisa.
const fs = require("fs"), os = require("os"), path = require("path"), crypto = require("crypto"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const ROOT = path.join(__dirname, "..");
const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519"), tuj = crypto.generateKeyPairSync("ed25519").privateKey;
const pem = publicKey.export({ type: "spki", format: "pem" }).trim();
// kopija programa z drugim javnim ključem in različico
function program(cilj, verzija) {
  fs.mkdirSync(cilj, { recursive: true });
  for (const f of ["package.json", "posodobitev.js", "server.js", "platform.js"]) fs.copyFileSync(path.join(ROOT, f), path.join(cilj, f));
  fs.mkdirSync(path.join(cilj, "scripts")); fs.copyFileSync(path.join(ROOT, "scripts", "posodobi-streznik.js"), path.join(cilj, "scripts", "posodobi-streznik.js"));
  fs.mkdirSync(path.join(cilj, "streznik")); fs.copyFileSync(path.join(ROOT, "streznik", "Caddyfile"), path.join(cilj, "streznik", "Caddyfile"));
  const p = JSON.parse(fs.readFileSync(path.join(cilj, "package.json"), "utf8")); p.version = verzija; fs.writeFileSync(path.join(cilj, "package.json"), JSON.stringify(p));
  fs.writeFileSync(path.join(cilj, "posodobitev.js"), fs.readFileSync(path.join(cilj, "posodobitev.js"), "utf8").replace(/-----BEGIN PUBLIC KEY-----[\s\S]+?-----END PUBLIC KEY-----/, pem));
}
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "posstr-")), INST = path.join(tmp, "haccp-portal"), IZD = path.join(tmp, "izdaja");
program(path.join(INST, "program"), "2.2.0");
fs.writeFileSync(path.join(INST, "program", "streznik", ".env"), "COMPOSE_PROFILES=cloudflare\nTUNNEL_TOKEN=moj-zeton\n");
fs.writeFileSync(path.join(INST, "program", "streznik", "Caddyfile"), "haccp.moja-domena.si {\n}\n");
// izdaja 2.3.0: arhiv mape program + podpisan opis
const nova = path.join(tmp, "gradnja", "program"); program(nova, "2.3.0"); fs.writeFileSync(path.join(nova, "NOVO.txt"), "nova datoteka");
fs.mkdirSync(IZD); const arh = path.join(IZD, "HACCP-portal-2.3.0.tar.gz");
cp.spawnSync("tar", ["-czf", arh, "-C", path.dirname(nova), "program"]);
const buf = fs.readFileSync(arh), opis = (k, sha) => { const podatki = JSON.stringify({ aplikacija: "higifood", verzija: "2.3.0", izvorna: { url: "HACCP-portal-2.3.0.tar.gz", sha256: sha || crypto.createHash("sha256").update(buf).digest("hex"), velikost: buf.length } }); return JSON.stringify({ podatki, podpis: crypto.sign(null, Buffer.from(podatki), k || privateKey).toString("base64") }); };
const zazeni = (...a) => cp.spawnSync(process.execPath, [path.join(INST, "program", "scripts", "posodobi-streznik.js"), "--naslov", path.join(IZD, "posodobitev.json"), ...a], { encoding: "utf8" });
const verzija = () => JSON.parse(fs.readFileSync(path.join(INST, "program", "package.json"), "utf8")).version;
fs.writeFileSync(path.join(IZD, "posodobitev.json"), opis(tuj)); let r = zazeni();
ok(r.status === 1 && /Podpis/.test(r.stdout) && verzija() === "2.2.0", "izdaja s tujim podpisom zavrnjena, program nespremenjen");
fs.writeFileSync(path.join(IZD, "posodobitev.json"), opis(null, "0".repeat(64))); r = zazeni();
ok(r.status === 1 && /SHA-256/.test(r.stdout) && verzija() === "2.2.0", "arhiv, ki se ne ujema z izdajo, zavrnjen");
fs.writeFileSync(path.join(IZD, "posodobitev.json"), opis()); r = zazeni("--preveri");
ok(r.status === 0 && /Na voljo je različica 2.3.0/.test(r.stdout) && verzija() === "2.2.0", "»preveri« samo javi novo različico");
r = zazeni();
ok(r.status === 10 && verzija() === "2.3.0" && fs.existsSync(path.join(INST, "program", "NOVO.txt")), "nameščena nova različica 2.3.0 (izhodna koda 10)");
ok(fs.readFileSync(path.join(INST, "program", "streznik", ".env"), "utf8").includes("moj-zeton") && fs.readFileSync(path.join(INST, "program", "streznik", "Caddyfile"), "utf8").includes("moja-domena"), "nastavitve (.env, Caddyfile) ohranjene");
const kop = fs.readdirSync(INST).filter(x => x.startsWith("program-pred-posodobitvijo-"));
ok(kop.length === 1 && JSON.parse(fs.readFileSync(path.join(INST, kop[0], "package.json"), "utf8")).version === "2.2.0", "kopija prejšnje različice: " + kop[0]);
r = zazeni(); ok(r.status === 0 && /zadnja različica/.test(r.stdout), "ponovni zagon: ni ničesar za posodobiti");
// izdaja iz dejanske skripte izdaja.js (z začasnim ključem v kopiji programa) vsebuje arhiv za strežnik
{ const src = path.join(tmp, "izv", "program"); fs.mkdirSync(path.dirname(src), { recursive: true });
  cp.spawnSync("cp", ["-a", ROOT, src]); fs.rmSync(path.join(src, "exe"), { recursive: true, force: true }); fs.rmSync(path.join(src, "izdaja"), { recursive: true, force: true });
  fs.writeFileSync(path.join(src, "posodobitev.js"), fs.readFileSync(path.join(src, "posodobitev.js"), "utf8").replace(/-----BEGIN PUBLIC KEY-----[\s\S]+?-----END PUBLIC KEY-----/, pem));
  const kp = path.join(tmp, "zasebni.pem"); fs.writeFileSync(kp, privateKey.export({ type: "pkcs8", format: "pem" }));
  fs.writeFileSync(path.join(src, "streznik", ".env"), "TUNNEL_TOKEN=skrivno\n");
  const iz = path.join(tmp, "izd2"), x = cp.spawnSync(process.execPath, [path.join(src, "scripts", "izdaja.js"), "--kljuc", kp, "--brez-exe", "--izhod", iz], { encoding: "utf8" });
  const op = JSON.parse(JSON.parse(fs.readFileSync(path.join(iz, "posodobitev.json"), "utf8")).podatki), ime = op.izvorna && op.izvorna.url;
  const vs = cp.spawnSync("tar", ["-tzf", path.join(iz, ime || "x")], { encoding: "utf8" }).stdout || "";
  ok(x.status === 0 && /^HACCP-portal-[\d.]+\.tar\.gz$/.test(ime) && vs.includes("program/server.js") && vs.includes("program/scripts/posodobi-streznik.js"), "izdaja.js pripravi podpisan arhiv za strežnik");
  ok(!/podatki\/|\.pem$|streznik\/\.env$|program\/exe\//m.test(vs), "arhiv ne vsebuje podatkov, ključev, .env ali Windows gradnje"); }
console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
