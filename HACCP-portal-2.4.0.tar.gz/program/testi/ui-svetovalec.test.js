// Svetovalec vidi samo dodeljene stranke: seznami, podatki, priloge, uporabniki, koš, umiki, naročnine; dodeljevanje strank s profila stranke in pri uporabniku.
const fs = require("fs"), path = require("path");
const B = process.env.BASE, OUT = process.env.OUT || require("os").tmpdir(); fs.mkdirSync(OUT, { recursive: true });
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(); const errs = [];
  const mk = async () => { const p = await (await br.newContext()).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const out = {};
    for (const n of ["Moja d.o.o.", "Tuja d.o.o.", "Tretja d.o.o."]) {
      const s = await D.add("stranke", { naziv: n }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja " + n });
      await D.add("osebje", { stranka_id: s.id, ime: "Kuhar " + n }); await D.add("dogodki", { stranka_id: s.id, naslov: "Pregled " + n, datum: "2026-12-01" });
      await D.add("capa", { stranka_id: s.id, obrat_id: o.id, naslov: "Neskladnost " + n, opis: "x" });
      const pr = await api("POST", "/api/priloga", { stranka_id: s.id, ime: "zapis.txt", tip: "text/plain", podatki: btoa("zapis " + n) });
      out[n] = { sid: s.id, pr: pr.id };
    }
    const sv = await api("POST", "/api/uporabniki", { ime: "Sara Svetovalka", email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", stranke: [out["Moja d.o.o."].sid] });
    await api("POST", "/api/uporabniki", { ime: "Tone Tuji", email: "tt@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: out["Tuja d.o.o."].sid, stranke: [] });
    const dg = (await D.list("dogodki")).find(c => c.naslov === "Pregled Tuja d.o.o."); await D.del("dogodki", dg.id); // v koš
    out.sv = sv.id; return out; });
  const moja = ids["Moja d.o.o."].sid, tuja = ids["Tuja d.o.o."].sid, tretja = ids["Tretja d.o.o."].sid;
  const prijava = async email => { const z = await mk(); await z.goto(B + "/"); await z.fill("#le", email); await z.fill("#lp", "dolgogeslo123"); await z.click("#lf button"); await z.waitForSelector("#shell:not([hidden])"); await z.waitForSelector("#p0"); await z.fill("#p0", "dolgogeslo123"); await z.fill("#p1", "novogeslo12345"); await z.click("#dlg-f .btn:last-child"); await z.waitForSelector("#dlg", { state: "hidden" }); return z; };
  const s = await prijava("sv@t.si");
  const r = await s.evaluate(async ([tuja, prTuja]) => {
    const st = (m, u, b) => api(m, u, b).then(() => 200, e => e.status), txt = async u => JSON.stringify(await api("GET", u).catch(e => ({ napaka: e.status })));
    return {
      stranke: (await api("GET", "/api/d/stranke")).map(x => x.naziv),
      vse: [await txt("/api/d/obrati"), await txt("/api/d/osebje"), await txt("/api/d/dogodki"), await txt("/api/d/capa"), await txt("/api/d/priloge"), await txt("/api/uporabniki"), await txt("/api/kos")].join(" "),
      tujaEv: await st("GET", "/api/d/osebje?stranka_id=" + tuja).then(async s => s === 200 ? (await api("GET", "/api/d/osebje?stranka_id=" + tuja)).length : s),
      tujaStranka: await st("GET", "/api/d/stranke/" + tuja), dodaj: await st("POST", "/api/d/osebje", { stranka_id: tuja, ime: "Vsiljivec" }),
      priloga: (await fetch("/api/priloga/" + prTuja)).status, logo: (await fetch("/api/stranka-logo/" + tuja)).status,
      umiki: await st("GET", "/api/umiki?stranka_id=" + tuja), narocnina: await st("GET", "/api/narocnina?stranka_id=" + tuja), potrditve: await st("GET", "/api/potrditve?stranka_id=" + tuja),
      revizija: await st("GET", "/api/revizijska-sled"), novUporabnik: await st("POST", "/api/uporabniki", { ime: "X", email: "x@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: tuja, stranke: [] }),
      sebi: await st("PUT", "/api/uporabniki/" + (await api("GET", "/api/auth/jaz")).id, { stranke: [tuja] })
    }; }, [tuja, ids["Tuja d.o.o."].pr]);
  ok(JSON.stringify(r.stranke) === JSON.stringify(["Moja d.o.o."]), "seznam strank: samo dodeljena (" + r.stranke.join(", ") + ")");
  ok(!/Tuja|Tretja|Tone/.test(r.vse), "obrati, zaposleni, koledar, CAPA, priloge, uporabniki, koš: nič od tujih strank");
  ok(r.tujaEv === 403 || r.tujaEv === 0, "podatki tuje stranke niso dostopni (" + r.tujaEv + ")");
  ok(r.tujaStranka !== 200 && r.dodaj === 403, "tuje stranke ni mogoče odpreti ne spreminjati");
  ok(r.priloga === 404 && r.logo === 404, "priloga in logotip tuje stranke: 404");
  ok(r.umiki === 403 && r.narocnina === 403, "umiki in naročnina tuje stranke: 403");
  ok(r.potrditve !== 200, "potrditve tuje stranke niso dostopne (" + r.potrditve + ")");
  ok(r.revizija === 403 && r.novUporabnik === 403, "svetovalec ne vidi revizijske sledi in ne ustvari uporabnika za tujo stranko");
  ok(r.sebi !== 200, "svetovalec si ne more sam dodeliti stranke (" + r.sebi + ")");
  await s.goto(B + "/#/stranke"); await s.waitForSelector("text=Moja d.o.o."); ok(await s.locator("text=Tuja d.o.o.").count() === 0, "stran Stranke: samo dodeljena stranka");
  await s.goto(B + `/#/stranka/${tuja}/podatki`); await s.waitForTimeout(800); ok(!(await s.textContent("#view")).includes("Tuja d.o.o."), "profil tuje stranke se ne odpre");
  // dodeljevanje s profila stranke (administrator)
  await pg.goto(B + `/#/stranka/${tretja}/podatki`); await pg.waitForSelector("#sv-card"); await pg.check(`[data-sv="${ids.sv}"]`); await pg.waitForSelector(".toast.show:has-text('Svetovalec dodeljen')");
  await s.reload(); await s.waitForSelector("#shell:not([hidden])");
  ok(JSON.stringify((await s.evaluate(() => D.list("stranke"))).map(x => x.naziv).sort()) === JSON.stringify(["Moja d.o.o.", "Tretja d.o.o."]), "po dodelitvi s profila stranke svetovalec vidi tudi Tretja d.o.o.");
  await pg.uncheck(`[data-sv="${ids.sv}"]`); await pg.waitForSelector(".toast.show:has-text('Stranka odvzeta')");
  ok((await s.evaluate(() => api("GET", "/api/d/stranke"))).length === 1, "odvzem stranke deluje takoj");
  // dodeljevanje pri uporabniku: seznam s kljukicami in iskanjem
  await pg.goto(B + "/#/uporabniki"); await pg.waitForSelector(`tr[data-id="${ids.sv}"]`); await pg.click(`tr[data-id="${ids.sv}"]`);
  await pg.waitForSelector("#u_ss_q"); await pg.fill("#u_ss_q", "tuj"); ok(await pg.locator(".u-st:visible").count() === 1, "iskanje v seznamu strank pri uporabniku");
  await pg.check(`.u-st input[value="${tuja}"]`); await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector("#dlg", { state: "hidden" });
  ok((await s.evaluate(() => api("GET", "/api/d/stranke"))).map(x => x.naziv).sort().join() === "Moja d.o.o.,Tuja d.o.o.", "dodelitev pri urejanju uporabnika");
  await pg.waitForSelector(`tr[data-id="${ids.sv}"]:has-text("Tuja d.o.o.")`); ok(true, "seznam uporabnikov kaže dodeljene stranke");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.message); process.exit(2); });
