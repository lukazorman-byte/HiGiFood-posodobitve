// Paket za inšpekcijo: en PDF s pregledom stanja, celotnim HACCP načrtom, vsemi evidencami obdobja, usposabljanji in odstopanji.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Inšpekcija Šumnik d.o.o.", odgovorna_oseba: "Žan Čuk" }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja", naslov: "Glavna 1" });
    await D.add("nacrti", { stranka_id: s.id, obrat_id: o.id, naziv: "HACCP kuhinja", vsebina: { branza: "jedi", koraki: [{ id: "k1", naziv: "Prevzem" }, { id: "k2", naziv: "Toplotna obdelava" }], nevarnosti: [{ id: "h1", korak_id: "k2", tip: "B", nevarnost: "Preživetje salmonele", verjetnost: "3", teza: "5", potrjeno: true }], kontrole: { h1: { hid: "h1", vrsta: "CCP", kaj: "Temperatura v jedru", mejna: "≥ 72 °C" } } } });
    await D.add("nacrti", { stranka_id: s.id, naziv: "Star načrt", status: "zastarelo", vsebina: {} });
    await D.add("usposabljanja", { stranka_id: s.id, tema: "Higiena živil in alergeni", datum: new Date().toISOString().slice(0, 10), izvajalec: "HiGiFood" });
    const d = i => new Date(Date.now() - i * 864e5).toISOString();
    await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 3, min: 0, max: 4, cas: d(2) });
    await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 9, min: 0, max: 4, cas: d(1), opomba: "vrata odprta" });
    await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 2, min: 0, max: 4, cas: d(200) });
    await D.add("capa", { stranka_id: s.id, opis: "Hladilnik nad mejo – popravilo tesnila", status: "odprto", tveganje: "srednje" });
    return s.id;
  });
  await pg.goto(B + "/#/stranka/" + sid + "/inspekcija"); await pg.waitForSelector("#i_pak");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#i_pak")]); fs.mkdirSync(OUT, { recursive: true }); const f = path.join(OUT, "paket.pdf"); await dl.saveAs(f);
  ok(fs.readFileSync(f).slice(0, 5).toString() === "%PDF-" && fs.statSync(f).size > 5000, "en gumb izvozi PDF paketa");
  const pt = cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" });
  if (pt.error) { console.log("ok: (pdftotext ni nameščen – vsebina PDF ni preverjena)"); }
  else {
    const t = pt.stdout.replace(/\s+/g, " ");
    ok(/Stanje dokumentacije/.test(t) && /Neskladnosti in korektivni ukrepi/.test(t), "pregled stanja in CAPA");
    ok(/Priloga A: HACCP načrt – HACCP kuhinja/.test(t) && /A\.\d+\. Namen in obseg sistema HACCP/.test(t) && /Preživetje salmonele/.test(t) && !/Star načrt –/.test(t.split("Priloga A")[1] || ""), "priloga A: veljavni HACCP načrt v celoti (zastareli ne)");
    ok(/A\. Priloga: pravna podlaga/.test(t) && !/A\.Priloga/.test(t), "naslov priloge načrta s presledkom (A. Priloga: …)");
    ok(/Priloga B: Evidence v obdobju/.test(t) && /vrata odprta/.test(t) && (t.match(/Hladilnik 1 \d/g) || []).length >= 2, "priloga B: evidence obdobja s podatki in opombami");
    ok(/Higiena živil in alergeni/.test(t) && /Zabeležena odstopanja/.test(t) && /Hladilnik nad mejo – popravilo tesnila/.test(t), "usposabljanja, odstopanja in ukrep CAPA");
    ok(/Inšpekcija Šumnik d\.o\.o\./.test(t) && /Žan Čuk/.test(t), "šumniki v PDF");
  }
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
