// Popravki po testiranju: preverjanje polj stranke (brskalnik in strežnik), rok samo enkrat (zamuda ali 30 dni),
// zadnje aktivnosti (novo / urejeno), slovenske oblike števil, paket storitev kot izbirni seznam paketov.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1280, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // 1) obrazec stranke: napačni podatki se ne shranijo
  await pg.evaluate(() => openForm("stranke", null, null, () => {})); await pg.waitForSelector("#f_naziv"); await pg.fill("#f_naziv", "Preverjanje d.o.o.");
  const poskus = async (polje, vr, vzorec) => { await pg.fill("#f_" + polje, vr); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(([p, v]) => { const l = document.querySelector("#f_" + p).closest(".f"); return l.classList.contains("bad") && new RegExp(v).test(l.querySelector(".f-err").textContent) && document.activeElement.id === "f_" + p; }, [polje, vzorec]); await pg.fill("#f_" + polje, ""); };
  await poskus("maticna", "abc", "Matična"); await poskus("davcna", "123", "Davčna"); await poskus("email", "neveljaven-email", "E-naslov"); await poskus("telefon", "telefon xyz", "Telefon");
  ok(await pg.evaluate(async () => (await D.list("stranke")).length) === 0, "obrazec: matična »abc«, davčna »123«, e-naslov in telefon zavrnjeni z opozorilom pod poljem, rdečim okvirjem in fokusom");
  await pg.fill("#f_davcna", "123"); await pg.fill("#f_email", "x@"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector(".f.bad >> nth=1");
  ok(await pg.locator(".f.bad").count() === 2 && /Popravite 2 polji/.test(await pg.textContent("#ferr")) && await pg.evaluate(() => document.activeElement.id) === "f_davcna", "več napak hkrati: obe polji označeni, fokus na prvem, povzetek »Popravite 2 polji«");
  await pg.fill("#f_davcna", ""); await pg.fill("#f_email", ""); await pg.fill("#f_telefon", "(01) 234-56-78"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok(await pg.evaluate(async () => { const x = (await D.list("stranke"))[0]; await D.del("stranke", x.id); return x.telefon; }) === "(01) 234-56-78", "telefon z oklepaji je dovoljen");
  await pg.evaluate(() => openForm("stranke", null, null, () => {})); await pg.waitForSelector("#f_naziv"); await pg.fill("#f_naziv", "Preverjanje d.o.o.");
  await pg.fill("#f_maticna", "1234567000"); await pg.fill("#f_davcna", "SI 1234 5679"); await pg.fill("#f_email", "info@primer.si"); await pg.fill("#f_telefon", "+386 1 234-56/78");
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  const s = await pg.evaluate(async () => (await D.list("stranke"))[0]); ok(s && s.davcna === "12345679" && s.maticna === "1234567000", "veljavni podatki shranjeni (davčna poenotena na 8 števk)");
  // strežnik zavrne tudi mimo obrazca (uvoz, API)
  const api = await pg.evaluate(async id => { const r = []; for (const o of [{ naziv: "X", email: "neveljaven-email" }, { naziv: "X", davcna: "123" }, { naziv: "X", maticna: "abc" }, { naziv: "X", telefon: "telefon xyz" }]) { try { await D.add("stranke", o); r.push("shranjeno"); } catch (e) { r.push(e.message); } } try { await D.set("stranke", id, { email: "slab" }); r.push("shranjeno"); } catch (e) { r.push(e.message); } return r; }, s.id);
  ok(api.every(x => x !== "shranjeno"), "strežnik zavrne napačne podatke (ustvarjanje in urejanje): " + api.join(" | "));
  // 2) in 4) rok v zamudi se šteje samo enkrat; oblike števil
  await pg.evaluate(async id => { await D.set("stranke", id, { naslednji_pregled: new Date(Date.now() - 27 * 864e5).toISOString().slice(0, 10) }); await D.add("stranke", { naziv: "Druga d.o.o." }); }, s.id);
  await pg.goto(B + "/#/nadzorna"); await pg.reload(); await pg.waitForSelector(".kpi-bloki");
  const k = await pg.$$eval(".kpi", x => x.map(e => e.querySelector("b").textContent + " " + e.querySelector("span").textContent));
  ok(k.includes("1 rok v zamudi") && !k.some(t => /v 30 dneh/.test(t)), "rok v zamudi samo enkrat (ne tudi med roki v 30 dneh): " + k.join(", "));
  ok(k.includes("2 stranki"), "oblike števil: »2 stranki«, »1 rok«");
  ok(await pg.evaluate(() => [1, 2, 3, 4, 5, 11, 101, 102, 104, 111].map(n => n + " " + mn(n, ["stranka", "stranki", "stranke", "strank"])).join(", ")) === "1 stranka, 2 stranki, 3 stranke, 4 stranke, 5 strank, 11 strank, 101 stranka, 102 stranki, 104 stranke, 111 strank", "pravilo za oblike števil (1, 2, 3–4, 5+, tudi 101, 111)");
  // 3) zadnje aktivnosti: odprte, novo / urejeno
  ok(await pg.locator("details:has-text('Zadnje aktivnosti')[open]").count() === 1, "zadnje aktivnosti so odprte");
  const ak = (await pg.textContent("details:has-text('Zadnje aktivnosti')")).replace(/\s+/g, " ");
  ok(/Stranka: Preverjanje d.o.o. urejeno/.test(ak) && /Stranka: Druga d.o.o. novo/.test(ak), "zadnje aktivnosti: ustvarjena in urejena stranka (" + ak.slice(0, 160) + ")");
  // 5) paket storitev: izbirni seznam paketov iz Naročnin (+ brez paketa); strežnik zavrne neobstoječ paket
  const pkn = await pg.evaluate(async id => { try { await D.set("stranke", id, { paket: "1999-01-01" }); return "shranjeno"; } catch (e) { return e.message; } }, s.id);
  ok(/Paket storitev ne obstaja/.test(pkn), "strežnik zavrne paket, ki ga ni med paketi: " + pkn);
  await pg.evaluate(async id => openForm("stranke", (await D.list("stranke")).find(x => x.id === id), null, () => {}), s.id); await pg.waitForSelector("#f_paket option:nth-child(3)", { state: "attached" });
  const op = await pg.$$eval("#f_paket option", o => o.map(x => x.textContent));
  ok(op[0] === "brez paketa" && op.some(t => /Osnovni/.test(t)) && op.some(t => /Standard/.test(t)) && await pg.inputValue("#f_paket") === "", "paket: »brez paketa« in paketi iz naročnin");
  const pid = await pg.$$eval("#f_paket option", o => o.find(x => /Standard/.test(x.textContent)).value); await pg.selectOption("#f_paket", pid); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  await pg.goto(B + `/#/stranka/${s.id}/podatki`); await pg.waitForSelector("#tabbody th:has-text('Paket')"); ok(/Standard/.test(await pg.textContent("#tabbody tr:has(th:has-text('Paket'))")), "profil stranke prikaže ime paketa");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
