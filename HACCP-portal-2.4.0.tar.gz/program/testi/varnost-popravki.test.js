// Popravki po testiranju z agenti (varnost in izguba podatkov): preverjanje vnosov na strežniku (tipi, datumi, števila, velikost, XSS),
// napačni zahtevki brez obešanja, povabilo ne aktivira onemogočenega računa, nastavitve e-pošte ohranijo kopijo v oblak,
// 2FA se ne zamenja brez izklopa, GDPR po celih besedah, vloge s stranko, odjava z neposlanimi zapisi, urejevalnik baze ohrani polja.
const B = process.env.BASE, net = require("net"), http = require("http"), crypto = require("crypto");
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const seje = {};
const A = async (kdo, m, p, b, surovo) => { const r = await fetch(B + p, { method: m, headers: { "Content-Type": "application/json", Cookie: seje[kdo] || "", Origin: B }, body: surovo !== undefined ? surovo : b ? JSON.stringify(b) : undefined, signal: AbortSignal.timeout(8000) }); const sc = r.headers.get("set-cookie"); if (sc) seje[kdo] = sc.split(";")[0]; let j = null; try { j = await r.json(); } catch {} return { s: r.status, j }; };
const surov = (pot, m, telo, glave) => new Promise(ok2 => { const u = new URL(B + pot); const q = http.request({ host: u.hostname, port: u.port, path: pot, method: m, headers: Object.assign({ Origin: B, Cookie: seje.a || "" }, glave || {}) }, r => { r.resume(); r.on("end", () => ok2(r.statusCode)); }); q.on("error", e => ok2("napaka " + e.code)); q.setTimeout(8000, () => { q.destroy(); ok2("brez odgovora"); }); if (telo) q.write(telo); q.end(); });
const b32 = s => { const a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; let bits = "", out = []; for (const ch of s.replace(/\s/g, "")) bits += a.indexOf(ch).toString(2).padStart(5, "0"); for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2)); return Buffer.from(out); };
const totp = (key, ctr) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); const h = crypto.createHmac("sha1", key).update(b).digest(), o = h[h.length - 1] & 15; return String(((h.readUInt32BE(o) & 0x7fffffff) % 1e6)).padStart(6, "0"); };
// SMTP, ki shrani besedila sporočil (za povezavo iz povabila)
const posta = [];
const smtp = net.createServer(c => { let data = false, buf = "", body = []; c.on("error", () => {}); c.write("220 mock\r\n");
  c.on("data", d => { buf += d; let i; while ((i = buf.indexOf("\r\n")) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 2);
    if (data) { if (l === ".") { data = false; const t = body.join("\r\n"), k = t.indexOf("\r\n\r\n"); posta.push(Buffer.from(t.slice(k + 4).replace(/\s/g, ""), "base64").toString("utf8")); body = []; c.write("250 ok\r\n"); } else body.push(l); continue; }
    if (l === "DATA") { data = true; c.write("354 go\r\n"); } else if (l === "QUIT") { c.write("221 bye\r\n"); c.end(); } else c.write(/^EHLO/.test(l) ? "250 mock\r\n" : "250 ok\r\n"); } }); });
(async () => {
  await new Promise(r => smtp.listen(0, "127.0.0.1", r));
  ok((await A("a", "POST", "/api/auth/nastavi", { email: "a@t.si", geslo: "dolgogeslo123", ime: "Ana Admin" })).s === 200, "prvi administrator");
  const sid = (await A("a", "POST", "/api/d/stranke", { naziv: "Varna d.o.o." })).j.id, sid2 = (await A("a", "POST", "/api/d/stranke", { naziv: "Druga d.o.o." })).j.id;
  for (const [e, v] of [["z@t.si", "zaposleni"], ["o@t.si", "odgovorna"]]) await A("a", "POST", "/api/uporabniki", { ime: v, email: e, geslo: "dolgogeslo123", vloga: v, stranka_id: sid });
  await A("z", "POST", "/api/auth/prijava", { email: "z@t.si", geslo: "dolgogeslo123" });
  // 1) XSS in tipi: zaposleni ne more shraniti kode v polja, ki se izpišejo kot HTML
  const x = "<img src=x onerror=window.__xss=1>";
  const zav = [await A("z", "POST", "/api/d/capa", { opis: "x", tveganje: x }), await A("z", "POST", "/api/d/evidence", { vrsta: "temperatura", cas: x }), await A("a", "POST", "/api/d/urnik", { stranka_id: sid, vrsta: "temperatura", frekvenca_ur: x }), await A("a", "POST", "/api/d/usposabljanja", { stranka_id: sid, tema: "T", datum: x }), await A("a", "POST", "/api/d/ciscenje_nacrt", { stranka_id: sid, opravilo: "O", pogostost_dni: x })];
  ok(zav.every(r => r.s === 400), "koda v poljih tveganje, čas, frekvenca, datum, pogostost zavrnjena (" + zav.map(r => r.s + " " + (r.j && r.j.napaka)).join(" | ") + ")");
  const st = await A("z", "POST", "/api/d/evidence", { vrsta: "temperatura", status: "xyz" }); ok(st.s === 400, "neveljavno stanje zapisa zavrnjeno");
  const dob = [await A("a", "POST", "/api/d/stranke", { naziv: 12345 }), await A("a", "POST", "/api/d/stranke", { naziv: { a: 1 } }), await A("a", "POST", "/api/d/stranke", { naziv: "   " }), await A("a", "POST", "/api/d/stranke", { naziv: null })];
  ok(dob[0].s === 200 && dob[0].j.naziv === "12345" && dob.slice(1).every(r => r.s === 400), "naziv: število → besedilo; objekt, presledki, null zavrnjeni");
  const st2 = await A("a", "POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", vrednost: "3,5", max: "4", cas: "2026-10-01T08:00:00.000Z" }); ok(st2.s === 200 && st2.j.vrednost === 3.5 && st2.j.max === 4, "števila iz besedila (tudi z vejico) se shranijo kot števila");
  ok((await A("z", "POST", "/api/d/evidence", { vrsta: "drugo", opomba: "O".repeat(450000) })).s === 400, "predolgo polje (450 000 znakov) zavrnjeno");
  ok((await A("a", "POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", cas: "2999-01-01" })).s === 400 && (await A("a", "POST", "/api/d/evidence", { stranka_id: sid, vrsta: "temperatura", cas: "2026-99-99xx" })).s === 400, "nesmiselni datumi zavrnjeni");
  // 7) napačni zahtevki dobijo odgovor (ne visijo)
  const odg = []; for (const t of ["null", "0", "false", '""']) odg.push(await surov("/api/d/stranke", "POST", t, { "Content-Type": "application/json" }));
  ok(odg.every(s => s === 400), "telo null/0/false/\"\" → 400 (" + odg.join(",") + ")");
  ok(await surov("/api/d/stranke/%E0%A4%A", "GET") === 400, "pokvarjen naslov → 400");
  ok(await surov("/api/d/stranke", "POST", "[".repeat(100000), { "Content-Type": "application/json" }) === 400, "globoko gnezden JSON → 400");
  ok(await surov("/api/d/stranke", "POST", "x".repeat(21e6), { "Content-Type": "application/json" }) === 413, "telo nad 20 MB → 413");
  ok((await A("a", "POST", "/api/uporabniki", { ime: "x", email: ["a@b.si"], geslo: "dolgogeslo123", vloga: "svetovalec" })).s === 400, "e-naslov kot tabela → 400");
  ok((await A("a", "POST", "/api/priloga", { stranka_id: sid, ime: "x.txt", tip: "text/plain", podatki: { a: 1 } })).s === 400, "priloga brez vsebine → 400");
  ok((await A("a", "GET", "/api/health")).s === 200, "strežnik živ");
  // 3) nastavitve e-pošte ohranijo kopijo v oblak; skrivni ključ ni viden
  await A("a", "PUT", "/api/kopija/nastavitve", { geslo: "geslo-za-kopije-1" });
  await A("a", "PUT", "/api/kopija/oblak", { endpoint: "https://s3.example.com", regija: "eu", vedro: "moje-vedro", kljuc_id: "AKID", skrivnost: "zelo-skrivno" });
  await A("a", "PUT", "/api/nastavitve", { vklopljeno: true, streznik: "127.0.0.1", vrata: smtp.address().port, varnost: "brez", od: "x@t.si", naslov_aplikacije: B });
  const ob = (await A("a", "GET", "/api/kopija/oblak")).j, ns = (await A("a", "GET", "/api/nastavitve")).j;
  ok(ob && ob.vedro === "moje-vedro" && ob.kljuc_id === "AKID", "kopija v oblak po shranjevanju e-pošte ostane nastavljena (" + JSON.stringify(ob).slice(0, 120) + ")");
  ok(ns.oblak_skrivnost === "********" && !JSON.stringify(ns).includes("zelo-skrivno"), "skrivni ključ za oblak ni viden v nastavitvah");
  // 2) povezava iz povabila ne aktivira onemogočenega računa
  const pov = await A("a", "POST", "/api/uporabniki", { ime: "Pavel", email: "p@t.si", vloga: "svetovalec", povabilo: true });
  for (let i = 0; i < 50 && !posta.some(t => /#\/geslo\//.test(t)); i++) await new Promise(r => setTimeout(r, 100));
  const zeton = ((posta.find(t => /#\/geslo\//.test(t)) || "").match(/#\/geslo\/([\w-]+)/) || [])[1];
  await A("a", "PUT", "/api/uporabniki/" + pov.j.id, { aktiven: false });
  const ng = await A("x", "POST", "/api/auth/nastavi-geslo", { zeton, geslo: "novogeslo12345" }), pr = await A("p", "POST", "/api/auth/prijava", { email: "p@t.si", geslo: "novogeslo12345" });
  ok(zeton && ng.s === 404 && pr.s !== 200 && (await A("a", "GET", "/api/uporabniki")).j.find(u => u.id === pov.j.id).aktiven === false, "povabilo onemogočenega računa ne velja (" + ng.s + "/" + pr.s + ")");
  // 9) 2FA: vklopljene ni mogoče zamenjati samo s sejo
  await A("o", "POST", "/api/auth/prijava", { email: "o@t.si", geslo: "dolgogeslo123" });
  const z1 = (await A("o", "POST", "/api/auth/2fa/zacni")).j, k = b32(z1.skrivnost);
  ok((await A("o", "POST", "/api/auth/2fa/potrdi", { koda: totp(k, Math.floor(Date.now() / 30000)) })).s === 200, "2FA vklopljena");
  const z2 = await A("o", "POST", "/api/auth/2fa/zacni"); ok(z2.s === 400 && /že vklopljena/.test(z2.j.napaka), "zamenjava naprave 2FA brez izklopa zavrnjena");
  // 6) GDPR: cele besede, šumniki
  for (const ime of ["Jan Novak", "Jan Novakovič", "Žiga Šček"]) await A("a", "POST", "/api/d/osebje", { stranka_id: sid, ime });
  await A("a", "POST", "/api/gdpr/anonimiziraj", { ime: "Jan Novak", potrdi: true });
  let os = (await A("a", "GET", "/api/d/osebje?stranka_id=" + sid)).j.map(x => x.ime);
  ok(os.includes("Jan Novakovič") && !os.includes("Jan Novak") && os.includes("[izbrisana oseba]"), "anonimizacija »Jan Novak« ne spremeni »Jan Novakovič« (" + os.join(", ") + ")");
  const iz = (await A("a", "POST", "/api/gdpr/izvoz", { ime: "Ziga Scek" })).j; ok(((iz.zapisi || {}).osebje || []).length === 1, "izvoz najde »Žiga Šček« za »Ziga Scek«");
  await A("a", "POST", "/api/gdpr/anonimiziraj", { ime: "Ziga Scek", potrdi: true }); os = (await A("a", "GET", "/api/d/osebje?stranka_id=" + sid)).j.map(x => x.ime);
  ok(!os.includes("Žiga Šček"), "anonimizacija »Ziga Scek« zamenja »Žiga Šček«");
  // vloge: odgovorna oseba brez stranke ni dovoljena
  const oid = (await A("a", "GET", "/api/uporabniki")).j.find(u => u.email === "o@t.si").id;
  ok((await A("a", "PUT", "/api/uporabniki/" + oid, { stranka_id: null })).s === 400 && (await A("a", "PUT", "/api/uporabniki/" + oid, { stranka_id: "neobstaja" })).s === 400 && (await A("a", "PUT", "/api/uporabniki/" + oid, { stranka_id: sid2 })).s === 200, "odgovorna oseba mora imeti obstoječo stranko");
  // brskalnik: izpis neveljavnega datuma je ubežan; odjava z neposlanimi zapisi; urejevalnik baze
  const br = await chromium.launch(), ctx = await br.newContext(), pg = await ctx.newPage(), errs = []; pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  ok(await pg.evaluate(x => fdate(x).includes("&lt;img") && fdt(x).includes("&lt;img") && !dueBadge(x).includes("<img"), x), "fdate/fdt/dueBadge ubežijo neveljavno vrednost");
  await pg.goto(B + "/#/stranke"); await pg.waitForSelector("table.t"); ok(await pg.locator("tr:has-text('12345')").count() === 1, "seznam strank z nazivom-številom se izriše");
  await pg.evaluate(id => localStorage.setItem("haccp_offq", JSON.stringify([{ t: 1, c: "evidence", body: { stranka_id: id, vrsta: "temperatura", vrednost: 3 } }])), sid); await ctx.setOffline(true);
  let vpr = ""; pg.once("dialog", d => { vpr = d.message(); d.dismiss(); }); await pg.click("#logout"); await pg.waitForTimeout(500);
  ok(/1 zapis še ni poslanih/.test(vpr) && await pg.locator("#shell:not([hidden])").count() === 1 && await pg.evaluate(() => JSON.parse(localStorage.getItem("haccp_offq")).length) === 1, "odjava z neposlanim zapisom: vprašanje, preklic ohrani zapis in prijavo");
  await ctx.setOffline(false); await pg.evaluate(() => localStorage.removeItem("haccp_offq"));
  await pg.goto(B + "/baza/"); await pg.waitForSelector("nav button"); await pg.click("nav button:has-text('Temperaturni režimi')"); await pg.click("#tbl tr:has-text('alk_liker')"); await pg.click("button:has-text('Potrdi zapis')");
  ok(await pg.evaluate(() => { const r = DB.rezimi.find(x => x.id === "alk_liker"); return !!(r && r.enota && r.vir); }), "urejevalnik baze: »Potrdi zapis« ohrani polja, ki jih obrazec ne prikazuje (enota, vir)");
  let opoz = ""; pg.once("dialog", d => { opoz = d.message(); d.dismiss(); }); await pg.click("#upd"); await pg.waitForTimeout(300); ok(/neshranjene spremembe/.test(opoz), "uvoz posodobitve opozori na neshranjene spremembe");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); smtp.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
