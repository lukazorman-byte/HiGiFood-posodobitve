// Rednost vnosov (delež obdobij z vnosom v zadnjih 30 dneh) na seznamu strank in nadzorni plošči;
// »Iz predloge«: nova stranka prevzame opremo, načrt čiščenja in urnik evidenc obstoječe stranke.
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ viewport: { width: 1360, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // izračun: dnevni urnik 10 dni, vnosi v 7 celih obdobjih → 7 od 9 (tekoče obdobje brez vnosa se ne šteje)
  const r = await pg.evaluate(() => { const d = 864e5, z = Date.now(), u = [{ vrsta: "temperatura", naprava: "H1", frekvenca_ur: 24, ustvarjeno: new Date(z - 10 * d - 1000).toISOString() }];
    const ev = [1, 2, 3, 4, 5, 6, 7].map(i => ({ vrsta: "temperatura", oprema: "H1", cas: new Date(z - (i + 0.5) * d).toISOString() })).concat([{ vrsta: "temperatura", oprema: "H2", cas: new Date(z - 8.5 * d).toISOString() }]);
    return [rednostVnosov(u, [], ev), rednostVnosov(u, [], ev.concat([{ vrsta: "temperatura", oprema: "H1", cas: new Date(z - 3600e3).toISOString() }])), rednostVnosov([], [], ev), rednostVnosov([{ vrsta: "temperatura", frekvenca_ur: 24, ustvarjeno: new Date().toISOString() }], [], []),
      rednostVnosov([{ vrsta: "temperatura", frekvenca_ur: 168, ustvarjeno: new Date(z - 60 * d).toISOString() }], [], [{ vrsta: "temperatura", cas: new Date(z - 2 * d).toISOString() }, { vrsta: "temperatura", cas: new Date(z - 20 * d).toISOString() }]),
      (() => { const ur = (dni, h) => { const t = new Date(); t.setDate(t.getDate() - dni); t.setHours(h, 0, 0, 0); return t.toISOString(); }; return rednostVnosov([], [{ id: "n1", pogostost_dni: 1, zacetek: addDays(today(), -10) }], Array.from({ length: 10 }, (_, i) => ({ vrsta: "ciscenje", nacrt_id: "n1", izvedeno: true, cas: ur(i + 1, i % 2 ? 7 : 20) }))); })()]; });
  ok(r[0].ok === 7 && r[0].vse === 9 && r[0].pct === 78, "7 od 9 obdobij → 78 % (druga naprava se ne šteje): " + JSON.stringify(r[0]));
  ok(r[1].ok === 8 && r[1].vse === 10, "vnos v tekočem obdobju se šteje: " + JSON.stringify(r[1]));
  ok(r[2] === null && r[3].pct === null, "brez urnika: null; nov urnik: premalo podatkov");
  ok(r[5].ok === 10 && r[5].vse === 10, "čiščenje po koledarskih dneh (izmenično ob 7.00 in 20.00) je 100 %: " + JSON.stringify(r[5]));
  ok(r[4].vse === 4 && r[4].ok === 2, "tedenski urnik: 4 tedni v 30 dneh, 2 z vnosom: " + JSON.stringify(r[4]));
  // predloga: stranka z opremo, načrtom čiščenja (začetek pred 10 dnevi) in urnikom; vnosi čiščenja v 7 obdobjih
  const sid = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Gostilna Predloga d.o.o.", dejavnost: "Gostinstvo (restavracija, gostilna)" }), o = await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja" });
    await D.add("oprema", { stranka_id: s.id, obrat_id: o.id, naziv: "Hladilnik 1", tip: "hladilnik", meja_min: 0, meja_max: 4, naslednji_servis: "2027-01-01", interval_dni: 365 });
    await D.add("oprema", { stranka_id: s.id, naziv: "Zamrzovalnik", tip: "zamrzovalnik", meja_max: -18 });
    const n = await D.add("ciscenje_nacrt", { stranka_id: s.id, podrocje: "Kuhinja", opravilo: "Pranje tal", sredstvo: "Čistilo A", pogostost_dni: 1, zacetek: new Date(Date.now() - 10 * 864e5).toISOString().slice(0, 10) });
    await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", naprava: "Hladilnik 1", frekvenca_ur: 24 });
    for (const i of [1, 2, 3, 4, 5, 6, 7]) await D.add("evidence", { stranka_id: s.id, vrsta: "ciscenje", nacrt_id: n.id, izvedeno: true, kontrola_ok: true, cas: new Date(Date.now() - (i + 0.5) * 864e5).toISOString() });
    await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 3, min: 0, max: 4, cas: new Date().toISOString() });
    await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 9, min: 0, max: 4, cas: new Date().toISOString() });
    await D.add("stranke", { naziv: "Brez urnika d.o.o." }); return s.id;
  });
  await pg.goto(B + "/#/stranke"); await pg.waitForSelector("table.t th:has-text('Rednost vnosov')");
  const vr = await pg.textContent(`tr[data-id="${sid}"]`), vb = await pg.textContent("tr:has-text('Brez urnika')");
  ok(/\b70 %/.test(vr) && /ni urnika/.test(vb), "seznam strank: stolpec rednosti (" + vr.replace(/\s+/g, " ").trim() + " / " + vb.replace(/\s+/g, " ").trim() + ")");
  await pg.goto(B + "/#/nadzorna"); await pg.waitForSelector("#rednost .rd-bar");
  const kr = (await pg.textContent("#rednost")).replace(/\s+/g, " ");
  ok(/Gostilna Predloga/.test(kr) && /7 od 10/.test(kr) && /Brez urnika/.test(kr) && /določite pogostost vnosov/.test(kr), "nadzorna plošča: kartica rednosti vnosov (" + kr.slice(0, 200) + ")");
  // Iz predloge
  await pg.goto(B + "/#/stranke"); await pg.waitForSelector("#iz_pred"); await pg.click("#iz_pred"); await pg.waitForSelector("#pr_s");
  await pg.selectOption("#pr_s", sid); await pg.waitForFunction(() => document.querySelector('[data-pn="oprema"]').textContent === "(2)" && document.querySelector('[data-pn="urnik"]').textContent !== "");
  ok(await pg.textContent('[data-pn="ciscenje_nacrt"]') === "(1)" && await pg.textContent('[data-pn="urnik"]') === "(1)", "predloga: števila zapisov za kopiranje");
  await pg.uncheck('[data-pz="urnik"]'); await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector("#f_naziv");
  ok(await pg.inputValue("#f_dejavnost") === "Gostinstvo (restavracija, gostilna)", "dejavnost prevzeta iz predloge");
  await pg.fill("#f_naziv", "Nova Gostilna d.o.o."); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => /\/oprema$/.test(location.hash)); await pg.waitForSelector(".toast.show:has-text('predloge')");
  ok(/Oprema in instrumenti \(z mejnimi vrednostmi\): 2/.test(await pg.textContent("#toast")) && /Načrt čiščenja: 1/.test(await pg.textContent("#toast")), "obvestilo o prevzetem: " + await pg.textContent("#toast"));
  const nov = await pg.evaluate(async () => { const s = (await D.list("stranke")).find(x => x.naziv === "Nova Gostilna d.o.o."); const g = c => D.list(c, { stranka_id: s.id }); return { op: await g("oprema"), cn: await g("ciscenje_nacrt"), ur: await g("urnik"), ev: await g("evidence"), ob: await g("obrati") }; });
  const h = nov.op.find(o => o.naziv === "Hladilnik 1");
  ok(nov.op.length === 2 && h && h.meja_max === 4 && h.interval_dni === 365 && !h.naslednji_servis && !h.obrat_id && h.stranka_id !== sid, "oprema prevzeta z mejami, brez datuma servisa in obrata");
  ok(nov.cn.length === 1 && nov.cn[0].opravilo === "Pranje tal" && !nov.cn[0].zacetek && nov.ur.length === 0 && nov.ev.length === 0 && nov.ob.length === 0, "načrt čiščenja prevzet; urnik (ni izbran), zapisi in obrati ne");
  const izv = await pg.evaluate(async id => ({ op: (await D.list("oprema", { stranka_id: id })).length, ev: (await D.list("evidence", { stranka_id: id })).length }), sid);
  ok(izv.op === 2 && izv.ev === 9, "izvorna stranka nespremenjena");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
