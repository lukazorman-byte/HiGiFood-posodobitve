// Nalepke QR za tisk: PDF A4 v treh velikostih, več nalepk na napravo, začetek na načeti poli, izbira naprav.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ acceptDownloads: true })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Nalepke Čuk d.o.o." }); for (const [n, t, l] of [["Hladilnik Šank 1", "hladilnik", "Kuhinja – za pultom"], ["Zamrzovalnik Ž", "zamrzovalnik", "Skladišče"], ["Tehtnica", "tehtnica", ""]]) await D.add("oprema", { stranka_id: s.id, naziv: n, tip: t, lokacija: l }); return s.id; });
  await pg.goto(B + "/#/qr/" + sid); await pg.waitForSelector("#qn_pdf"); fs.mkdirSync(OUT, { recursive: true });
  const prenesi = async ime => { const [d] = await Promise.all([pg.waitForEvent("download"), pg.click("#qn_pdf")]); const f = path.join(OUT, ime); await d.saveAs(f); return f; };
  const strani = f => (fs.readFileSync(f, "latin1").match(/\/Type \/Page\b/g) || []).length;
  const besedilo = f => { const r = cp.spawnSync("pdftotext", ["-layout", f, "-"], { encoding: "utf8" }); return r.error ? null : r.stdout; };
  // srednje (21 na A4), 1 na napravo, brez tehtnice
  await pg.uncheck('#qg .card:has(b:text-is("Tehtnica")) [data-qn]');
  let f = await prenesi("srednje.pdf"), t = besedilo(f);
  ok(strani(f) === 1, "srednje: 1 stran A4");
  if (t !== null) ok(/Hladilnik Šank 1/.test(t) && /Zamrzovalnik Ž/.test(t) && !/Tehtnica/.test(t) && /Skenirajte za vnos/.test(t) && /Kuhinja – za/.test(t), "nalepke: izbrane naprave, šumniki, lokacija");
  ok(/595\.28 841\.89/.test(fs.readFileSync(f, "latin1")) && !/Stran 1 \//.test(t || ""), "format A4, brez noge dokumenta");
  // velike (8 na A4), 5 na napravo, začetek na 7. nalepki → 6 + 10 = 16 mest → 2 strani
  await pg.selectOption("#qn_f", "velike"); await pg.fill("#qn_k", "5"); await pg.fill("#qn_z", "7");
  f = await prenesi("velike.pdf"); t = besedilo(f);
  ok(strani(f) === 2, "velike: 10 nalepk od 7. mesta → 2 strani (" + strani(f) + ")");
  if (t !== null) ok((t.match(/Hladilnik Šank 1/g) || []).length === 5, "5 nalepk na napravo");
  // majhne (40 na A4)
  await pg.selectOption("#qn_f", "majhne"); await pg.fill("#qn_k", "20"); await pg.fill("#qn_z", "1");
  f = await prenesi("majhne.pdf"); ok(strani(f) === 1, "majhne: 40 nalepk na eni strani");
  // kode QR so v PDF kot vektorski kvadratki (natisnejo se ostro); vsebina kode = naslov za vnos naprave
  const pdf = fs.readFileSync(f, "latin1"); ok((pdf.match(/ re /g) || []).length > 2000, "kode QR so izrisane");
  const url = await pg.evaluate(id => { const M = QR.encode(location.origin + "/#/vnos/" + id, "M"); return M.length; }, await pg.$eval("[data-qn]", x => x.dataset.qn)); ok(url >= 25, "koda vsebuje naslov za vnos (" + url + " modulov)");
  await pg.evaluate(() => $$("[data-qn]").forEach(x => x.checked = false)); await pg.click("#qn_pdf"); await pg.waitForSelector(".toast.show:has-text('vsaj eno')"); ok(true, "brez izbranih naprav: opozorilo");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
