// Obstoječa namestitev: nove predloge dejavnosti in merila iz privzete baze se dodajo ob zagonu, vaše spremembe ostanejo,
// izbrisane predloge se ne vrnejo; starejši ročno vneseni zapisi nevarnosti ostanejo potrjeni.
const fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const ROOT = path.join(__dirname, ".."), DEF = path.join(ROOT, "baza");
const NOVE_B = ["vino", "pivo", "zganje", "liker", "sokovi"];
(async () => {
  // stara namestitev: baza brez novih predlog in meril, z lastno spremembo predloge »alko«
  const data = fs.mkdtempSync(path.join(os.tmpdir(), "bd-")), db = path.join(data, "baza"); fs.mkdirSync(db);
  for (const f of fs.readdirSync(DEF).filter(f => f.endsWith(".json"))) fs.copyFileSync(path.join(DEF, f), path.join(db, f));
  const b = JSON.parse(fs.readFileSync(path.join(db, "branze.json"))).filter(x => !NOVE_B.includes(x.id)); b.find(x => x.id === "alko").naziv = "Moja predloga za alkohol";
  fs.writeFileSync(path.join(db, "branze.json"), JSON.stringify(b)); fs.writeFileSync(path.join(db, "rezimi.json"), JSON.stringify(JSON.parse(fs.readFileSync(path.join(db, "rezimi.json"))).filter(r => !r.enota)));
  const zagon = async () => {
    const port = 4300 + Math.floor(Math.random() * 300), s = cp.spawn(process.execPath, [path.join(ROOT, "server.js"), "--tiho"], { env: Object.assign({}, process.env, { PORT: String(port), HACCP_DATA: data, HOST: "127.0.0.1" }), stdio: "ignore" });
    for (let i = 0; i < 50; i++) { try { if ((await fetch("http://127.0.0.1:" + port + "/api/health")).ok) break; } catch {} await new Promise(r => setTimeout(r, 200)); }
    s.kill("SIGTERM"); await new Promise(r => s.on("exit", r));
  };
  await zagon();
  let bb = JSON.parse(fs.readFileSync(path.join(db, "branze.json"))), rr = JSON.parse(fs.readFileSync(path.join(db, "rezimi.json")));
  ok(NOVE_B.every(id => bb.some(x => x.id === id)) && rr.filter(r => r.enota).length === 10, "nove predloge (vino, pivo, žganje, liker, sokovi) in 10 meril dodanih ob zagonu");
  ok(bb.find(x => x.id === "alko").naziv === "Moja predloga za alkohol" && bb.length === b.length + 5, "lastna sprememba predloge ostane, nič podvojenega");
  // uporabnik izbriše predlogo »pivo« → ob naslednjem zagonu se ne vrne
  fs.writeFileSync(path.join(db, "branze.json"), JSON.stringify(bb.filter(x => x.id !== "pivo"))); await zagon();
  bb = JSON.parse(fs.readFileSync(path.join(db, "branze.json"))); ok(!bb.some(x => x.id === "pivo") && bb.some(x => x.id === "vino"), "izbrisana predloga se ne vrne");
  // stari zapisi nevarnosti (brez oznak) veljajo za potrjene; predlog brez potrditve ne
  const src = fs.readFileSync(path.join(ROOT, "portal", "m-wizard.js"), "utf8"), m = {};
  new Function("m", src.slice(src.indexOf("const HSTAT"), src.indexOf("const hazBadge")) + "m.hazStatus = hazStatus;")(m);
  ok(m.hazStatus({ nevarnost: "star ročni zapis" }) === "potrjeno" && m.hazStatus({ predlog: true, potrjeno: true }) === "potrjeno" && m.hazStatus({ predlog: true, potrjeno: false }) === "predlog" && m.hazStatus({ potrjeno: false }) === "nepotrjeno" && m.hazStatus({ predlog: true, urejeno: true, potrjeno: false }) === "urejeno" && m.hazStatus({ potrjeno: true, preveri_korak: "preimenovan" }) === "preveri", "stanje nevarnosti: stari zapisi potrjeni, novi po pravilih");
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
