// Starejši prosti vnosi »Paket storitev« ob zagonu: ime paketa → izbira paketa, ostalo v interne opombe (nič se ne izgubi).
const fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const ROOT = path.join(__dirname, "..");
(async () => {
  const data = fs.mkdtempSync(path.join(os.tmpdir(), "pk-")), pod = path.join(data, "podatki"); fs.mkdirSync(pod);
  fs.writeFileSync(path.join(pod, "stranke.json"), JSON.stringify([
    { id: "a", naziv: "A d.o.o.", paket: "1999-01-01", notranje: "stara opomba" }, { id: "b", naziv: "B d.o.o.", paket: "standard " }, { id: "c", naziv: "C d.o.o.", paket: "pro" }, { id: "d", naziv: "D d.o.o." }]));
  const port = 4600 + Math.floor(Math.random() * 300), s = cp.spawn(process.execPath, [path.join(ROOT, "server.js"), "--tiho"], { env: Object.assign({}, process.env, { PORT: String(port), HACCP_DATA: data, HOST: "127.0.0.1", HACCP_SHRAMBA: "json" }), stdio: "ignore" });
  for (let i = 0; i < 50; i++) { try { if ((await fetch("http://127.0.0.1:" + port + "/api/health")).ok) break; } catch {} await new Promise(r => setTimeout(r, 200)); }
  s.kill("SIGTERM"); await new Promise(r => s.on("exit", r));
  const st = Object.fromEntries(JSON.parse(fs.readFileSync(path.join(pod, "stranke.json"), "utf8")).map(x => [x.id, x]));
  ok(st.a.paket === "" && st.a.notranje === "stara opomba\nPrejšnji vnos »Paket storitev«: 1999-01-01", "neujemajoč vnos prestavljen v interne opombe: " + JSON.stringify(st.a));
  ok(st.b.paket === "standard" && st.c.paket === "pro" && st.d.paket === undefined && !st.b.notranje, "ime paketa → paket; veljaven paket in prazno polje ostaneta");
  fs.rmSync(data, { recursive: true, force: true });
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
