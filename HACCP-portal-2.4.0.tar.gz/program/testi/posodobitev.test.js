// Posodobitev programa: podpis izdaje (Ed25519), primerjava različic, zavrnitev spremenjenih/tujih izdaj in nevarnih naslovov, pravice API.
const http = require("http"), crypto = require("crypto"), fs = require("fs"), os = require("os"), path = require("path");
const B = process.env.BASE;
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync("ed25519"), tuj = crypto.generateKeyPairSync("ed25519").privateKey;
  const exe = Buffer.concat([Buffer.from("MZ"), crypto.randomBytes(5000)]), sha = crypto.createHash("sha256").update(exe).digest("hex");
  let izdaja = null;
  const srv = http.createServer((q, s) => { if (q.url === "/posodobitev.json") { s.writeHead(200, { "Content-Type": "application/json" }); s.end(JSON.stringify(izdaja)); } else if (q.url === "/nov.exe") { s.end(exe); } else { s.writeHead(404); s.end(); } });
  await new Promise(r => srv.listen(0, "127.0.0.1", r)); const base = "http://127.0.0.1:" + srv.address().port;
  const podpisi = (d, k) => { const podatki = JSON.stringify(d); return { podatki, podpis: crypto.sign(null, Buffer.from(podatki), k || privateKey).toString("base64") }; };
  const opis = v => ({ aplikacija: "higifood", verzija: v, datum: "2026-10-22", opis: "Popravki", windows: { url: base + "/nov.exe", sha256: sha, velikost: exe.length } });
  process.env.HACCP_PROGRAM_URL = base + "/posodobitev.json";
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "pos-"));
  const POS = require("../posodobitev.js")({ DIR: dir, VERZIJA: "2.2.0", PACKED: false, kljuc: publicKey.export({ type: "spki", format: "pem" }) });
  const napaka = async () => { try { await POS.preveri(); return null; } catch (e) { return e.message; } };
  izdaja = podpisi(opis("2.3.0")); let r = await POS.preveri();
  ok(r.nova && r.zadnja === "2.3.0" && r.opis === "Popravki" && r.mozna_namestitev === false && r.nacin !== "exe", "nova podpisana različica zaznana (izvorna namestitev: samo navodila)");
  izdaja = podpisi(opis("2.2.0")); r = await POS.preveri(); ok(!r.nova, "ista različica ni nova");
  izdaja = podpisi(opis("2.10.0")); r = await POS.preveri(); ok(r.nova, "2.10.0 je novejša od 2.2.0 (številčna primerjava)");
  izdaja = podpisi(opis("2.3.0")); izdaja.podatki = izdaja.podatki.replace(sha, "0".repeat(64)); ok(/Podpis/.test(await napaka()), "spremenjena izdaja (drug SHA-256) zavrnjena");
  izdaja = podpisi(opis("2.3.0"), tuj); ok(/Podpis/.test(await napaka()), "izdaja, podpisana s tujim ključem, zavrnjena");
  izdaja = podpisi(Object.assign(opis("2.3.0"), { aplikacija: "drugo" })); ok(/ni za ta program/.test(await napaka()), "izdaja za drug program zavrnjena");
  izdaja = { podatki: "{}" }; ok(/obliki/.test(await napaka()), "nepodpisan opis zavrnjen");
  ok(/samo pri Windows/.test(await POS.namesti().then(() => "", e => e.message)), "samodejna namestitev samo pri Windows programu");
  process.env.HACCP_PROGRAM_URL = "http://primer.si/posodobitev.json"; ok(/https/.test(await napaka()), "http na zunanji naslov ni dovoljen");
  delete process.env.HACCP_PROGRAM_URL; POS.nastavi("https://primer.si/p.json"); ok(POS.naslov() === "https://primer.si/p.json", "nastavljen naslov se uporabi"); POS.nastavi(""); ok(POS.naslov() === POS.PRIVZETI_URL, "prazen naslov = privzeti");
  // prenosna izdaja v mapi (USB): opis s samim imenom datoteke, pot do opisa kot naslov
  const md = fs.mkdtempSync(path.join(os.tmpdir(), "usb-")); fs.writeFileSync(path.join(md, "nov.exe"), exe);
  fs.writeFileSync(path.join(md, "posodobitev.json"), JSON.stringify(podpisi(Object.assign(opis("2.4.0"), { windows: { url: "nov.exe", sha256: sha, velikost: exe.length } }))));
  POS.nastavi(path.join(md, "posodobitev.json")); r = await POS.preveri(); ok(r.nova && r.zadnja === "2.4.0" && r.vir === "mapa", "izdaja iz mape na disku (USB) zaznana");
  POS.nastavi(require("url").pathToFileURL(path.join(md, "posodobitev.json")).href); r = await POS.preveri(); ok(r.zadnja === "2.4.0", "izdaja z naslovom file://");
  POS.nastavi(path.join(md, "ni.json")); ok(/ni mogoče prebrati/.test(await napaka()), "manjkajoča datoteka: razumljivo sporočilo");
  POS.nastavi("");
  srv.close();
  // API: samo administrator, različica iz package.json
  if (B) {
    const j = async (m, u, b, c) => { const r = await fetch(B + u, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, c ? { Cookie: c } : {}), body: b ? JSON.stringify(b) : undefined }); return { s: r.status, j: await r.json().catch(() => ({})), c: (r.headers.get("set-cookie") || "").split(";")[0] }; };
    const a = await j("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "A", geslo: "dolgogeslo123" });
    const p = await j("GET", "/api/posodobitev-programa", null, a.c);
    ok(p.s === 200 && p.j.trenutna === require("../package.json").version && p.j.nacin === "izvorna", "API: različica " + p.j.trenutna + ", način " + p.j.nacin);
    ok((await j("PUT", "/api/posodobitev-programa/nastavitve", { url: "http://zlo.si/x.json" }, a.c)).s === 400, "API: naslov brez https zavrnjen");
    ok((await j("PUT", "/api/posodobitev-programa/nastavitve", { url: "E:\\posodobitev\\posodobitev.json" }, a.c)).s === 200, "API: pot do datoteke na USB sprejeta");
    await j("PUT", "/api/posodobitev-programa/nastavitve", { url: "" }, a.c);
    ok((await j("GET", "/api/posodobitev-programa")).s === 401, "API: brez prijave ni dostopa");
  }
  console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
