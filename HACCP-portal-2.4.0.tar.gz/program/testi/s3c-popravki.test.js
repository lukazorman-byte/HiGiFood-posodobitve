// Popravki S3c: ujemanje umikov po celih besedah, razumljive napake omrežja, naročnine (datumi, cena, pretekli začetek),
// storniran predračun, opomniki in vloge, mobilni meni, napake v obrazcu uporabnika, račun izbrisane stranke, dostop do strani po vlogi,
// predloga uvoza ob onemogočenem tisku, pregled zapisov (straničenje, oznake), iskanje (combobox), CSRF brez izvora.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; fs.mkdirSync(OUT, { recursive: true });
  const mk = async o => { const p = await (await br.newContext(Object.assign({ acceptDownloads: true }, o || {}))).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const login = async (p, em, pw) => { await p.goto(B + "/"); await p.fill("#le", em); await p.fill("#lp", pw); await p.click("#lf button"); await p.waitForSelector("#shell:not([hidden])"); };
  const pg = await mk({ viewport: { width: 1280, height: 900 } });
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");

  // --- umiki: cele besede, pravna oblika dobavitelja, točna šarža ---
  const um = await pg.evaluate(async () => {
    await api("PUT", "/api/umiki/rasff", { vklopljeno: false }); await api("PUT", "/api/umiki/viri", { viri: [{ ime: "Mrtev vir", url: "http://127.0.0.1:59999/rss" }] });
    const s = await D.add("stranke", { naziv: "Umiki S3c d.o.o." });
    await D.add("sarze", { stranka_id: s.id, izdelek: "Mleko", sarza: "LOT-1" }); await D.add("dobavitelji", { stranka_id: s.id, naziv: "Mlekarna Celeia d.o.o." });
    for (const n of ["Odpoklic: jogurt proizvajalca Mlekarna Celeia, šarža LOT-12", "Umik: sir iz mlekarne Kras", "Odpoklic: mleko, šarža LOT-1"]) await api("POST", "/api/umiki", { naslov: n });
    const l = (await api("GET", "/api/umiki?stranka_id=" + s.id)).obvestila, z = t => (l.find(n => n.naslov.startsWith(t)) || {}).zadetki || [];
    const o = await api("POST", "/api/umiki/osvezi"); return { a: z("Odpoklic: jogurt"), b: z("Umik: sir"), c: z("Odpoklic: mleko"), nap: o.napake.join(" ") };
  });
  ok(um.a.length === 1 && /dobavitelj/.test(um.a[0]), "dobavitelj brez »d.o.o.« zadene, šarža LOT-1 ne zadene LOT-12: " + JSON.stringify(um.a));
  ok(!um.b.length, "»Mleko« ne zadene besede »mlekarne«: " + JSON.stringify(um.b));
  ok(um.c.length === 2, "izdelek in šarža zadeneta točno: " + JSON.stringify(um.c));
  ok(/zavrnil povezavo/.test(um.nap), "nedosegljiv vir: razumljivo sporočilo (" + um.nap + ")");

  // --- naročnine ---
  const nr = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Naročnik d.o.o." }), pk = (await api("GET", "/api/narocnine")).paketi || [], pid = (pk[0] || {}).id || "osnovni";
    const put = b => api("PUT", "/api/narocnine/" + s.id, Object.assign({ paket: pid, obdobje: "mesecno", cena_mesec: 20 }, b)).then(() => 200, e => e.message);
    const r = { feb: await put({ zacetek: "2026-02-30" }), prazna: await put({ cena_mesec: "" }), star: await put({ zacetek: "2020-01-15" }) };
    const pr = await api("POST", "/api/narocnine/" + s.id + "/predracun", {}); r.od = pr.od; r.danes = new Date().toISOString().slice(0, 10);
    const st = await api("POST", "/api/predracun/" + pr.id + "/storno", {}); window._pr = st; return r;
  });
  ok(/dan mora obstajati/.test(nr.feb), "30. februar zavrnjen: " + nr.feb);
  ok(/cena/i.test(nr.prazna), "prazna cena zavrnjena (ni 0 €): " + nr.prazna);
  ok(nr.star === 200 && Math.abs(Date.parse(nr.od) - Date.parse(nr.danes)) <= 864e5, "začetek leta 2020: predračun za tekoče obdobje (" + nr.od + ")");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.evaluate(() => predracunPdf(window._pr, {}))]); const fp = path.join(OUT, "storno.pdf"); await dl.saveAs(fp);
  const t = cp.spawnSync("pdftotext", [fp, "-"], { encoding: "utf8" }); if (!t.error) ok(/STORNIRAN/.test(t.stdout) && /0\.766 0\.643 -0\.643 0\.766/.test(fs.readFileSync(fp, "latin1")), "storniran predračun: naslov in vodni žig STORNIRAN");

  // --- uporabniki: napake ob poljih ---
  await pg.goto(B + "/#/uporabniki"); await pg.click("#un"); await pg.waitForSelector("#u_i"); await pg.selectOption("#u_v", "zaposleni");
  await pg.fill("#u_e", "ni-naslov"); await pg.click("#dlg-f .btn:not(.ghost)");
  const fe = await pg.$$eval("#dlg .f-err", x => x.map(e => e.textContent));
  ok(fe.some(x => /ime/.test(x)) && fe.some(x => /e-naslov/.test(x)) && fe.some(x => /stranko/.test(x)) && fe.some(x => /10 znakov/.test(x)), "obrazec uporabnika: napake ob poljih (" + fe.join(" | ") + ")");
  ok(await pg.getAttribute("#u_i", "aria-invalid") === "true", "polje z napako ima aria-invalid");
  await pg.keyboard.press("Escape");

  // --- vloge: zaposleni, odgovorna izbrisane stranke ---
  const ids = await pg.evaluate(async () => {
    const A = await D.add("stranke", { naziv: "Vloge A" }), X = await D.add("stranke", { naziv: "Izbrisana X" });
    const u = (ime, email, vloga, sid) => api("POST", "/api/uporabniki", { ime, email, geslo: "dolgogeslo123", vloga, stranka_id: sid, stranke: [] });
    await u("Zan", "zan3@t.si", "zaposleni", A.id); const ox = await u("OdX", "odx@t.si", "odgovorna", X.id);
    for (let i = 0; i < 105; i++) await D.add("evidence", { stranka_id: A.id, vrsta: "temperatura", oprema: "H" + i, vrednost: 3, min: 0, max: 5, cas: new Date(Date.now() - i * 6e4).toISOString(), status: "vneseno" });
    return { a: A.id, x: X.id, ox: ox.id };
  });
  const z = await mk({ viewport: { width: 390, height: 800 }, hasTouch: true }); await login(z, "zan3@t.si", "dolgogeslo123");
  ok(await z.evaluate(() => api("POST", "/api/auth/opomniki", { pogostost: "izklop" }).then(() => 200, e => e.message)) !== 200, "zaposleni: strežnik zavrne nastavitev opomnikov");
  await z.evaluate(() => $("#whoami").click()); await z.waitForSelector("#dlg[open]"); ok(await z.locator("#op_p").count() === 0, "zaposleni: v Moj račun ni nastavitev opomnikov"); await z.keyboard.press("Escape");
  // mobilni meni
  ok(await z.evaluate(() => $("#nav").inert && $("#burger").getAttribute("aria-expanded") === "false"), "mobilni meni zaprt: inert, aria-expanded=false");
  await z.click("#burger"); await z.waitForTimeout(300);
  ok(await z.evaluate(() => !$("#nav").inert && $("#burger").getAttribute("aria-expanded") === "true" && $("#nav").contains(document.activeElement)), "odprt meni: fokus v meniju");
  await z.keyboard.press("Escape"); ok(await z.evaluate(() => $("#nav").inert && document.activeElement === $("#burger") && $("#burger").getAttribute("aria-expanded") === "false"), "Esc zapre meni in vrne fokus na gumb");
  ok(await z.evaluate(() => getComputedStyle($("#burger")).minHeight === "44px"), "gumbi na zaslonu na dotik vsaj 44 px");
  // strani, ki jih vloga nima v meniju
  await z.goto(B + "/#/vidnost"); await z.waitForFunction(() => location.hash === "#/nadzorna"); ok(true, "zaposleni: #/vidnost preusmeri na nadzorno ploščo");
  await z.goto(B + "/#/strokovni-pregled"); await z.waitForFunction(() => location.hash === "#/nadzorna"); ok(true, "zaposleni: #/strokovni-pregled preusmeri");
  ok(await z.evaluate(() => { const p = PRINT.moje; PRINT.moje = {}; const r = [canPrint("predloga-oprema.xlsx"), canPrint("haccp-nacrt.pdf")]; PRINT.moje = p; return r[0] === true && r[1] === false; }), "onemogočen tisk ne blokira predloge za uvoz");
  // račun izbrisane stranke
  await pg.evaluate(id => D.del("stranke", id), ids.x);
  const r403 = await (await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "application/json", Origin: B }, body: JSON.stringify({ email: "odx@t.si", geslo: "dolgogeslo123" }) })).json();
  ok(/ne obstaja več/.test(r403.napaka || ""), "prijava odgovorne osebe izbrisane stranke zavrnjena: " + r403.napaka);
  ok(await pg.evaluate(id => api("PUT", "/api/uporabniki/" + id, { ime: "OdX", aktiven: false, stranka_id: "" }).then(() => 200, e => e.message), ids.ox) === 200, "administrator jo lahko onemogoči");

  // --- pregled zapisov ---
  await pg.goto(B + "/#/pregled-zapisov"); await pg.waitForSelector("#pvec");
  ok(await pg.locator(".pc").count() === 100 && /od 10[5-9]/.test(await pg.textContent("#view")), "pregled zapisov: prvih 100 in »Pokaži več«");
  ok(/Označi zapis/.test(await pg.getAttribute(".pc >> nth=0", "aria-label")) && await pg.getAttribute("#pall", "aria-label"), "potrditvena polja imajo oznake");
  await pg.click("#pvec"); await pg.waitForFunction(() => $$(".pc").length >= 105); await pg.check("#pall"); await pg.click("#pa"); await pg.waitForSelector(".toast.show:has-text('Potrjeno')");
  ok(/Potrjeno: 10[5-9]/.test(await pg.textContent("#toast")), "paketna potrditev: " + await pg.textContent("#toast"));
  const pz = await z.evaluate(() => api("POST", "/api/d/evidence/_potrdi", { ids: ["x"] }).then(() => 200, e => e.message));
  ok(pz !== 200, "zaposleni ne more paketno potrditi zapisov: " + pz);
  const rv = await pg.evaluate(async () => { const e = (await D.list("evidence")).find(x => x.oprema === "H0"); return [e.status, e.verzija, (e.revizije || []).length]; });
  ok(rv[0] === "potrjeno" && rv[1] === 2 && rv[2] === 1, "paketna potrditev zapiše revizijo (" + rv + ")");

  // --- iskanje: combobox ---
  await pg.fill("#gs", "Vloge"); await pg.waitForSelector("#gs-p:not([hidden]) .gs-i"); await pg.press("#gs", "ArrowDown");
  ok(await pg.evaluate(() => $("#gs").getAttribute("role") === "combobox" && $("#gs").getAttribute("aria-expanded") === "true" && $("#gs").getAttribute("aria-activedescendant") === "gs-i0" && $("#gs-i0").getAttribute("aria-selected") === "true"), "iskanje: combobox z aria-activedescendant");

  // --- e-pošta: napačno geslo in zavrnjen prejemnik (lažni strežnik SMTP) ---
  const net = require("net"); let nacin = "geslo";
  const smtp = net.createServer(c => { let buf = "", auth = 0; c.on("error", () => {}); c.write("220 mock\r\n"); c.on("data", d => { buf += d; let i; while ((i = buf.indexOf("\r\n")) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 2);
    if (/^EHLO/.test(l)) c.write("250-mock\r\n250 AUTH LOGIN\r\n"); else if (l === "AUTH LOGIN") { auth = 1; c.write("334 VXNlcm5hbWU6\r\n"); } else if (auth === 1) { auth = 2; c.write("334 UGFzc3dvcmQ6\r\n"); }
    else if (auth === 2) { auth = 3; c.write(nacin === "geslo" ? "535 5.7.8 Authentication credentials invalid\r\n" : "235 ok\r\n"); } else if (/^MAIL/.test(l)) c.write("250 ok\r\n"); else if (/^RCPT/.test(l)) c.write("550 5.1.1 No such user\r\n"); else if (l === "QUIT") { c.write("221 bye\r\n"); c.end(); } } }); }).listen(2526);
  await pg.evaluate(() => api("PUT", "/api/nastavitve", { streznik: "127.0.0.1", vrata: 2526, varnost: "brez", uporabnik: "u", geslo: "napacno", od: "HiGiFood <n@t.si>" }));
  const sm1 = await pg.evaluate(() => api("POST", "/api/obvestila/test", { komu: "x@t.si" }).then(() => "ok", e => e.message)); nacin = "prejemnik";
  const sm2 = await pg.evaluate(() => api("POST", "/api/obvestila/test", { komu: "x@t.si" }).then(() => "ok", e => e.message)); smtp.close();
  ok(/uporabniško ime in geslo/.test(sm1), "SMTP napačno geslo: razumljivo sporočilo (" + sm1 + ")");
  ok(/zavrnil prejemnika/.test(sm2), "SMTP zavrnjen prejemnik: razumljivo sporočilo (" + sm2 + ")");

  // --- CSRF: obrazec brez izvora ---
  const cs = await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "text/plain" }, body: '{"email":"a@t.si","geslo":"x"}' });
  ok(cs.status === 403, "pisanje brez Origin z vrsto vsebine obrazca zavrnjeno (" + cs.status + ")");
  const cj = await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "application/json" }, body: '{"email":"a@t.si","geslo":"x"}' });
  ok(cj.status === 401, "JSON brez Origin (skripte) deluje kot prej (" + cj.status + ")");

  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
