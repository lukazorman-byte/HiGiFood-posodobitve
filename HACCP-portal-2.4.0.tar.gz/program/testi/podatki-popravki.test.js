// Popravki po testiranju z agenti (napačni podatki): znaki ≤ ≥ − … v PDF, dolga vrstica tabele čez stran, lokalni dan namesto UTC in premik ure,
// ocena prevzema/hlajenja s števili, zaklep potrjenega načrta, obnova šifrirane kopije z geslom s šumniki (binarno), CSV v Windows-1250,
// mesečni list temperatur z več kot 6 napravami, kartoteke po celem imenu, paket stranke = naročnina, umiki v opomnikih po paketu.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const seje = {};
const A = async (kdo, m, p, b) => { const r = await fetch(B + p, { method: m, headers: { "Content-Type": "application/json", Cookie: seje[kdo] || "", Origin: B }, body: b ? JSON.stringify(b) : undefined }); const sc = r.headers.get("set-cookie"); if (sc) seje[kdo] = sc.split(";")[0]; let j = null; try { j = await r.json(); } catch {} return { s: r.status, j }; };
const besedilo = f => { const r = cp.spawnSync("pdftotext", ["-layout", f, "-"], { encoding: "utf8" }); return r.error ? null : r.stdout; };
(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  await A("a", "POST", "/api/auth/nastavi", { email: "a@t.si", geslo: "dolgogeslo123", ime: "Ana Admin" });
  const sid = (await A("a", "POST", "/api/d/stranke", { naziv: "Podatki d.o.o. – zelo dolgo ime podjetja za preizkus glave obrazca, ki se mora prelomiti v več vrstic brez izgube" })).j.id;
  // 13) ocena s števili, hlajenje brez mej
  const ev = async o => (await A("a", "POST", "/api/d/evidence", Object.assign({ stranka_id: sid }, o))).j.skladno;
  ok(await ev({ vrsta: "prevzem", vrednost: "10", max: "4", embalaza_ok: true, dokumenti_ok: true }) === false && await ev({ vrsta: "hlajenje", izdelek: "G", vrednost: "9", max: "10" }) === true && await ev({ vrsta: "hlajenje", izdelek: "G", vrednost: 25, trajanje: 300 }) === null, "prevzem 10 > 4 odstopanje, hlajenje 9 ≤ 10 skladno, hlajenje brez mej brez ocene");
  // 14) potrjen načrt je zaklenjen tudi prek API
  const n = (await A("a", "POST", "/api/d/nacrti", { stranka_id: sid, naziv: "Načrt", vsebina: { koraki: [] } })).j; await A("a", "PUT", "/api/d/nacrti/" + n.id, { status: "potrjeno" });
  const z1 = await A("a", "PUT", "/api/d/nacrti/" + n.id, { vsebina: { koraki: [{ id: "x", naziv: "Skrita sprememba" }] } }), z2 = await A("a", "PUT", "/api/d/nacrti/" + n.id, { status: "osnutek" }), z3 = await A("a", "PUT", "/api/d/nacrti/" + n.id, { status: "osnutek", _razlog: "posodobitev" }), z4 = await A("a", "PUT", "/api/d/nacrti/" + n.id, { vsebina: { koraki: [{ id: "x", naziv: "Odobrena sprememba" }] } });
  ok(z1.s === 409 && z2.s === 400 && z3.s === 200 && z4.s === 200, `potrjen načrt: sprememba vsebine 409, odklep brez razloga 400, z razlogom 200, nato urejanje 200 (${z1.s}/${z2.s}/${z3.s}/${z4.s})`);
  // 20) paket v obrazcu stranke = naročnina; umiki v opomnikih samo, če jih paket vsebuje
  const sp = (await A("a", "POST", "/api/d/stranke", { naziv: "Paketna d.o.o.", paket: "osnovni" })).j.id, sb = (await A("a", "POST", "/api/d/stranke", { naziv: "Brez paketa d.o.o." })).j.id;
  for (const [e, s] of [["op@t.si", sp], ["ob@t.si", sb]]) await A("a", "POST", "/api/uporabniki", { ime: e, email: e, geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s });
  await A("op", "POST", "/api/auth/prijava", { email: "op@t.si", geslo: "dolgogeslo123" });
  const ns = ((await A("a", "GET", "/api/narocnine")).j.stranke || {})[sp];
  ok(ns && ns.paket === "osnovni" && (await A("op", "GET", "/api/umiki")).s === 403, "paket »Osnovni« iz obrazca stranke ustvari naročnino; umiki so zaklenjeni (" + JSON.stringify(ns).slice(0, 80) + ")");
  await A("a", "PUT", "/api/narocnine/" + sp, { paket: "pro", obdobje: "mesecno", cena_mesec: 49 });
  ok((await A("a", "GET", "/api/d/stranke")).j.find(x => x.id === sp).paket === "pro", "sprememba paketa v Naročninah se pokaže pri stranki");
  await A("a", "PUT", "/api/narocnine/" + sp, { paket: "osnovni", obdobje: "mesecno", cena_mesec: 19 });
  for (const s of [sp, sb]) await A("a", "POST", "/api/d/sarze", { stranka_id: s, izdelek: "Mleti sir", sarza: "LOT-ODP-77" });
  await A("a", "POST", "/api/umiki", { naslov: "Odpoklic: Mleti sir LOT-ODP-77", opis: "test" });
  const pr = Object.fromEntries((await A("a", "POST", "/api/obvestila/zdaj", {})).j.predogled.map(x => [x.komu, x]));
  ok(pr["ob@t.si"] && /OBVESTILA \(1\)/.test(pr["ob@t.si"].besedilo) && /Možen umik/.test(pr["ob@t.si"].besedilo) && !(pr["op@t.si"] && /Možen umik/.test(pr["op@t.si"].besedilo)), "umik v opomniku samo za stranko, ki ima umike v paketu (skupina OBVESTILA)");
  await A("a", "PUT", "/api/d/stranke/" + sp, { paket: "" }); ok(!((await A("a", "GET", "/api/narocnine")).j.stranke || {})[sp], "»brez paketa« v obrazcu stranke odstrani naročnino");
  // brskalnik v pasu Europe/Ljubljana
  const br = await chromium.launch(), ctx = await br.newContext({ timezoneId: "Europe/Ljubljana", acceptDownloads: true }), pg = await ctx.newPage(), errs = []; pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // 12) lokalni dan: čiščenje ob 00:30 je današnje
  const r12 = await pg.evaluate(() => { const t = new Date(); t.setHours(0, 30, 0, 0); const st = ciscenjeStanje([{ id: "n1", pogostost_dni: 1, opravilo: "x" }], [{ vrsta: "ciscenje", nacrt_id: "n1", izvedeno: true, cas: t.toISOString() }]); return { lok: lokDan(t.toISOString()), danes: today(), last: st[0].last, danesNa: st[0].danes }; });
  ok(r12.lok === r12.danes && r12.last === r12.danes && r12.danesNa === false, "čiščenje ob 00:30 po lokalnem času je današnje (" + JSON.stringify(r12) + ")");
  // 15) + 11) PDF: znaki in vrstica, daljša od strani
  const dolg = Array.from({ length: 900 }, (_, i) => "beseda" + i).join(" ") + " KONEC-VRSTICE";
  const b64 = await pg.evaluate(async t => { const b = pdfBuild({ naslov: "Znaki" }, d => { d.p("Meje: ≤ 4 °C, ≥ 72 °C, −18 °C, ≠ 0 … konec"); d.table(["Čas", "Opomba"], [["1", t], ["2", "naslednja vrstica"]], [20, 80]); }); const u = new Uint8Array(await b.arrayBuffer()); let s = ""; for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode.apply(null, u.subarray(i, i + 32768)); return btoa(s); }, dolg);
  const fz = path.join(OUT, "znaki.pdf"); fs.writeFileSync(fz, Buffer.from(b64, "base64")); const tz = besedilo(fz);
  if (tz !== null) { ok(/≤ 4 °C, ≥ 72 °C, −18 °C, ≠ 0 … konec/.test(tz), "PDF: ≤ ≥ − ≠ … izpisani pravilno"); ok(/KONEC-VRSTICE/.test(tz) && /beseda899/.test(tz) && /naslednja vrstica/.test(tz) && !/\?\s?4 °C/.test(tz), "PDF: vrstica, daljša od strani, se nadaljuje na naslednji strani brez izgube besedila"); }
  // 12) premik ure: 29. 3. 2027 je 28. 3. včeraj
  await ctx.clock.setFixedTime(new Date("2027-03-29T10:00:00+02:00")); ok(await pg.evaluate(() => daysTo("2027-03-28") === -1 && daysTo("2027-01-01") === -87 && daysTo("2027-03-30") === 1), "daysTo pravilen ob premiku ure (zamuda 1 d, ne »danes«)");
  await ctx.clock.setFixedTime(new Date());
  // 17) CSV v Windows-1250 in ključ uvoza
  const w1250 = Buffer.from([0x49, 0x6d, 0x65, 0x3b, 0x4d, 0x65, 0x73, 0x74, 0x6f, 0x0a, 0x4d, 0x61, 0x74, 0x6a, 0x61, 0x9e, 0x20, 0x8a, 0x75, 0x9a, 0x74, 0x61, 0x72, 0x3b, 0xc8, 0x72, 0x6e, 0x6f, 0x6d, 0x65, 0x6c, 0x6a]);
  ok(await pg.evaluate(a => beriBesedilo(new Uint8Array(a).buffer) === "Ime;Mesto\nMatjaž Šuštar;Črnomelj", [...w1250]) && await pg.evaluate(() => beriBesedilo(new TextEncoder().encode("﻿čšž").buffer) === "čšž"), "CSV: Windows-1250 in UTF-8 (z BOM) pravilno prebrana");
  ok(await pg.evaluate(() => kljucUvoza("Ana Kos") !== kljucUvoza("Ana Koš") && kljucUvoza("V-1") !== kljucUvoza("V1") && kljucUvoza(" Ana  KOS ") === kljucUvoza("ana kos")), "uvoz: »Ana Kos« ni dvojnik »Ana Koš«");
  // 18) mesečni list temperatur: vseh 9 naprav (2 lista), glava se prelomi
  await pg.evaluate(async id => { for (let i = 1; i <= 9; i++) await D.add("oprema", { stranka_id: id, naziv: "Šank " + i, tip: "hladilnik" }); }, sid);
  await pg.goto(B + "/#/obrazci"); await pg.waitForSelector("#o_s", { state: "attached" }); await pg.selectOption("#o_s", sid); await pg.fill("#o_m", "11/2026");
  const [d1] = await Promise.all([pg.waitForEvent("download"), pg.click('[data-p="@temp"]')]); const ft = path.join(OUT, "temp.pdf"); await d1.saveAs(ft); const tt = besedilo(ft);
  if (tt !== null) ok(/Šank 9/.test(tt) && /Šank 6/.test(tt) && /list 2 od 2/.test(tt) && /Mesec\/leto:\s+11\/2026/.test(tt), "mesečni list temperatur: vseh 9 naprav na 2 listih, »Mesec/leto« viden pri dolgem nazivu");
  // 19) kartoteke: »Ana« ne dobi usposabljanja »Jane Novak«
  await pg.evaluate(async id => { await D.add("osebje", { stranka_id: id, ime: "Ana" }); await D.add("osebje", { stranka_id: id, ime: "Jana Novak" }); await D.add("usposabljanja", { stranka_id: id, tema: "Higiena živil XYZ", udelezenci: "Jana Novak, Peter Kos" }); }, sid);
  await pg.goto(B + "/#/stranka/" + sid + "/osebje"); await pg.waitForSelector("#kart");
  const [d2] = await Promise.all([pg.waitForEvent("download"), pg.click("#kart")]); const fk = path.join(OUT, "kart.pdf"); await d2.saveAs(fk); const tk = besedilo(fk);
  if (tk !== null) { const strani = tk.split("\f"), ana = strani.find(s => /^\s*\d*\.?\s*Ana\s*$/m.test(s)), jana = strani.find(s => /Jana Novak/.test(s) && /Delovno mesto/.test(s)); ok(ana && !/Higiena živil XYZ/.test(ana) && /Ni zabeleženih/.test(ana) && jana && /Higiena živil XYZ/.test(jana), "kartoteke: usposabljanje samo pri »Jana Novak«, ne pri »Ana«"); }
  // 16) šifrirana kopija z geslom s šumniki: prenos in obnova v aplikaciji
  await pg.goto(B + "/#/admin/kopije"); await pg.waitForSelector("#kenc"); await pg.click("#kenc"); await pg.fill("#kg1", "Žabica-čšž1"); await pg.fill("#kg2", "Žabica-čšž1");
  const [d3] = await Promise.all([pg.waitForEvent("download"), pg.click("#dlg-f .btn:last-child")]); const fh = path.join(OUT, "kopija.hfbk"); await d3.saveAs(fh);
  await pg.evaluate(async () => D.add("stranke", { naziv: "Po kopiji d.o.o." }));
  await pg.setInputFiles("#rf", fh); await pg.waitForSelector("#kg0"); await pg.fill("#kg0", "Žabica-čšž1"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(300); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector(".toast.show:has-text('Obnovljeno')", { timeout: 20000 }); await pg.waitForTimeout(1500);
  ok(!(await A("a", "GET", "/api/d/stranke")).j.some(x => x.naziv === "Po kopiji d.o.o."), "obnova šifrirane kopije z geslom s šumniki (binarni prenos) uspe");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
