// Podatki podjetja: seznam zavezancev FURS (posnet) – branje različnih oblik datoteke, dnevni prenos, izpolnitev matične številke
// in dejavnosti, predlogi po nazivu; register EU VIES (posnet) kot rezerva; preverjanje davčne številke, napake, pravice dostopa.
const http = require("http"), zlib = require("zlib");
const B = process.env.BASE;
const { chromium } = require("./pw.js");
const { preveriDavcno, preberiSeznam, dejavnostIzSkd } = require("../register.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
// veljavne davčne številke za preizkus
const dav = []; for (let i = 1000000; dav.length < 6; i++) { for (let k = 0; k < 10; k++) if (preveriDavcno(String(i) + k)) { dav.push(String(i) + k); break; } }
const [D1, D2, D3, D4, D5] = dav;
// zip z deflate (kot datoteke FURS)
function zip(ime, vsebina) {
  const data = Buffer.from(vsebina, "utf8"), c = zlib.deflateRawSync(data), n = Buffer.from(ime), crc = zlib.crc32(data);
  const loc = Buffer.alloc(30); loc.writeUInt32LE(0x04034b50, 0); loc.writeUInt16LE(20, 4); loc.writeUInt16LE(8, 8); loc.writeUInt32LE(crc, 14); loc.writeUInt32LE(c.length, 18); loc.writeUInt32LE(data.length, 22); loc.writeUInt16LE(n.length, 26);
  const cen = Buffer.alloc(46); cen.writeUInt32LE(0x02014b50, 0); cen.writeUInt16LE(20, 4); cen.writeUInt16LE(20, 6); cen.writeUInt16LE(8, 10); cen.writeUInt32LE(crc, 16); cen.writeUInt32LE(c.length, 20); cen.writeUInt32LE(data.length, 24); cen.writeUInt16LE(n.length, 28);
  const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(1, 8); end.writeUInt16LE(1, 10); end.writeUInt32LE(46 + n.length, 12); end.writeUInt32LE(30 + n.length + c.length, 16);
  return Buffer.concat([loc, n, c, cen, n, end]);
}
const csvGlava = `"Zavezanec za DDV";"Davčna številka";"Matična številka";"Datum registracije";"Šifra dejavnosti";"Naziv";"Naslov";"Finančni urad"\n` +
  `"*";"${D1}";"1234567000";"2010-01-01";"I56.101";"GOSTILNA PRI LIPI D.O.O.";"TRŽAŠKA CESTA 12, 1000 LJUBLJANA";"10"\n` +
  `"";"${D2}";"7654321000";"";"C10.710";"PEKARNA ZRNO D.O.O.";"GLAVNA ULICA 3, 2000 MARIBOR";"12"\n` +
  `"*";"${D3}";"1111111000";"2015-05-05";"G47.110";"TRGOVINA LIPA D.O.O.";"LIPOVA 7, 4000 KRANJ";"11"\n`;
const bezGlave = `* ${D4}  2222222000  2012-03-03  I56.290  SLAŠČIČARNA SONČEK D.O.O.  SONČNA 1, 3000 CELJE  05\n  ${D5}  3333333000              A01.410  KMETIJA KOVAČ  VAS 5, 8000 NOVO MESTO  07\n`;
let furs = zip("DURS_zavezanci_PO.csv", csvGlava), izpad = false;
const zahtevki = [];
const srv = http.createServer((q, r) => {
  if (q.url === "/furs.zip") { r.setHeader("Content-Type", "application/zip"); return r.end(furs); }
  const d = q.url.split("/").pop(); zahtevki.push(d); r.setHeader("Content-Type", "application/json");
  if (izpad) return r.end(JSON.stringify({ isValid: false, userError: "MS_UNAVAILABLE" }));
  if (d === "12345679") return r.end(JSON.stringify({ isValid: true, userError: "VALID", name: "HIGIFOOD TEST D.O.O.", address: "TRŽAŠKA CESTA 1\n1000 LJUBLJANA" }));
  r.end(JSON.stringify({ isValid: false, userError: "INVALID", name: "---", address: "---" }));
});
(async () => {
  // bralnik: oblike datoteke
  ok(preveriDavcno("SI 1234 5679") === "12345679" && preveriDavcno("12345678") === null, "kontrolna števka davčne številke (modul 11)");
  const a = preberiSeznam(zip("x.csv", csvGlava)), g = a.find(z => z.davcna === D1);
  ok(a.length === 3 && g.maticna === "1234567000" && g.skd === "I56.101" && g.naziv === "GOSTILNA PRI LIPI D.O.O." && g.naslov === "TRŽAŠKA CESTA 12, 1000 LJUBLJANA" && g.ddv === 1 && a.find(z => z.davcna === D2).ddv === 0, "CSV z glavo (;, narekovaji, zip deflate)");
  const b = preberiSeznam(Buffer.from(csvGlava.split("\n").slice(1).join("\n").replace(/"/g, "").replace(/;/g, "\t")));
  ok(b.length === 3 && b[0].naziv === "GOSTILNA PRI LIPI D.O.O." && b[0].maticna === "1234567000" && b[0].skd === "I56.101" && b[0].naslov.startsWith("TRŽAŠKA"), "brez glave, ločilo tabulator (stolpci po vsebini)");
  const c = preberiSeznam(Buffer.from(bezGlave));
  ok(c.length === 2 && c[0].naziv === "SLAŠČIČARNA SONČEK D.O.O." && c[0].maticna === "2222222000" && c[1].skd === "A01.410", "stolpci, ločeni s presledki (stara oblika TXT)");
  const d1250 = Buffer.from(new TextEncoder().encode(csvGlava)).toString("utf8"); ok(preberiSeznam(Buffer.from(d1250)).length === 3, "UTF-8 brez zip");
  ok(dejavnostIzSkd("I56.101") === "Gostinstvo (restavracija, gostilna)" && dejavnostIzSkd("C10.710") === "Pekarna / slaščičarna" && dejavnostIzSkd("I56.290") === "Catering / priprava obrokov" && dejavnostIzSkd("K64.190") === "", "šifra SKD → vrsta dejavnosti");
  let napaka = ""; try { preberiSeznam(Buffer.from("a;b;c;d\n1;2;3;4\n")); } catch (e) { napaka = e.message; } ok(/davčnimi/.test(napaka), "neprepoznana datoteka: razumljiva napaka");

  await new Promise(r => srv.listen(4952, "127.0.0.1", r));
  const br = await chromium.launch(); const errs = [];
  const mk = async () => { const p = await (await br.newContext()).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const forma = async (pp, rec) => { await pp.evaluate(r => openForm("stranke", r, null, () => {}), rec || null); await pp.waitForSelector("dialog[open]"); };
  // 1) seznam še ni prenesen: VIES
  await forma(pg); await pg.waitForSelector("#f_vies");
  await pg.fill("#f_davcna", "12345678"); await pg.click("#f_vies"); await pg.waitForFunction(() => /ni veljavna/.test(document.querySelector("#vies_r").textContent));
  ok(!zahtevki.length, "napačna kontrolna števka: opozorilo brez poizvedbe");
  await pg.fill("#f_davcna", "SI 12345679"); await pg.click("#f_vies"); await pg.waitForFunction(() => /Izpolnjeno/.test(document.querySelector("#vies_r").textContent));
  ok(await pg.inputValue("#f_naziv") === "HIGIFOOD TEST D.O.O." && await pg.inputValue("#f_naslov") === "TRŽAŠKA CESTA 1, 1000 LJUBLJANA", "brez seznama FURS: naziv in naslov iz VIES");
  izpad = true; await pg.fill("#f_davcna", D3); await pg.click("#f_vies"); await pg.waitForFunction(() => /ni dosegljiv/.test(document.querySelector("#vies_r").textContent)); izpad = false;
  ok(true, "VIES nedosegljiv: razumljivo sporočilo");
  await pg.keyboard.press("Escape");
  // 2) administrator prenese seznam FURS
  await pg.goto(B + "/#/admin/podatki"); await pg.waitForSelector("#zav_o"); ok(/še ni prenesen/.test(await pg.textContent("#zav_s")), "kartica: seznam še ni prenesen");
  await pg.click("#zav_o"); await pg.waitForFunction(() => /3 podjetja ali s\.p\./.test(document.querySelector("#zav_s").textContent));
  ok(true, "»Prenesi zdaj«: 3 podjetja iz datoteke FURS");
  const kop = await pg.evaluate(async () => new Uint8Array(await (await fetch("/api/kopija")).arrayBuffer()));
  ok(!Buffer.from(kop).includes(Buffer.from("zavezanci")), "seznam ni del varnostne kopije");
  // ročni uvoz (stara oblika TXT) zamenja seznam
  require("fs").writeFileSync(process.env.TMP + "/seznam.txt", bezGlave);
  await pg.setInputFiles("#zav_f", process.env.TMP + "/seznam.txt"); await pg.waitForFunction(() => /2 podjetji ali s\.p\./.test(document.querySelector("#zav_s").textContent));
  ok(true, "ročni uvoz datoteke (TXT): 2 zapisa");
  await pg.click("#zav_o"); await pg.waitForFunction(() => /3 podjetja ali s\.p\./.test(document.querySelector("#zav_s").textContent));
  // 3) obrazec: po davčni številki iz seznama FURS (tudi ne-zavezanec za DDV) z matično in dejavnostjo
  await forma(pg); await pg.waitForSelector("#f_vies"); const nVies = zahtevki.length;
  await pg.fill("#f_davcna", D2); await pg.click("#f_vies"); await pg.waitForFunction(() => /Izpolnjeno iz registra FURS/.test(document.querySelector("#vies_r").textContent));
  const v = await pg.evaluate(() => ({ n: $("#f_naziv").value, a: $("#f_naslov").value, m: $("#f_maticna").value, d: $("#f_dejavnost").value, t: $("#vies_r").textContent }));
  ok(v.n === "PEKARNA ZRNO D.O.O." && v.a === "GLAVNA ULICA 3, 2000 MARIBOR" && v.m === "7654321000" && v.d === "Pekarna / slaščičarna" && /ni zavezanec za DDV/.test(v.t) && zahtevki.length === nVies, "FURS: naziv, naslov, matična, dejavnost (tudi ne-zavezanec za DDV), brez poizvedbe VIES");
  await pg.keyboard.press("Escape");
  // 4) predlogi po nazivu
  await forma(pg); await pg.waitForSelector("#f_naziv");
  await pg.fill("#f_naziv", "gostilna lip"); await pg.waitForSelector("#naz_p:not([hidden]) button");
  ok(/GOSTILNA PRI LIPI/.test(await pg.textContent("#naz_p")) && !/TRGOVINA/.test(await pg.textContent("#naz_p")), "predlogi po nazivu (brez šumnikov, več besed)");
  await pg.click("#naz_p button"); const w = await pg.evaluate(() => ({ n: $("#f_naziv").value, dv: $("#f_davcna").value, d: $("#f_dejavnost").value, m: $("#f_maticna").value, h: $("#naz_p").hidden }));
  ok(w.n === "GOSTILNA PRI LIPI D.O.O." && w.dv === D1 && w.m === "1234567000" && w.d === "Gostinstvo (restavracija, gostilna)" && w.h, "izbira predloga izpolni davčno, matično, dejavnost");
  await pg.fill("#f_naziv", "lipa"); await pg.waitForFunction(() => /TRGOVINA LIPA/.test(document.querySelector("#naz_p").textContent));
  await pg.keyboard.press("Escape"); ok(await pg.locator("dialog[open]").count() === 1 && await pg.evaluate(() => $("#naz_p").hidden), "Escape zapre predloge, obrazec ostane odprt");
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  const st = await pg.evaluate(async () => (await D.list("stranke")).find(s => s.naziv === "lipa"));
  // urejanje: vpisani podatki se ne prepišejo brez potrditve
  await forma(pg, Object.assign({}, st, { davcna: D3 })); await pg.click("#f_vies"); await pg.waitForSelector("#vies_u");
  ok(await pg.inputValue("#f_naziv") === "lipa", "obstoječi naziv ostane, prikaže se razlika");
  await pg.click("#vies_u"); ok(await pg.inputValue("#f_naziv") === "TRGOVINA LIPA D.O.O.", "»Uporabi podatke iz registra« prepiše naziv");
  await pg.keyboard.press("Escape");
  // 5) pravice: uporabnik stranke ne more poizvedovati, gumba ni; svetovalec lahko
  await pg.evaluate(async id => { await api("POST", "/api/uporabniki", { ime: "Oda", email: "oda@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: id }); await api("POST", "/api/uporabniki", { ime: "Sv", email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", stranke: [id] }); }, st.id);
  const prijava = async em => { const o = await mk(); await o.goto(B + "/"); await o.fill("#le", em); await o.fill("#lp", "dolgogeslo123"); await o.click("#lf button"); await o.waitForSelector("#shell:not([hidden])"); return o; };
  const o = await prijava("oda@t.si");
  const s403 = await o.evaluate(async d => [(await fetch("/api/podjetje/" + d)).status, (await fetch("/api/podjetje?q=lipa")).status, (await fetch("/api/zavezanci")).status], D1);
  await forma(o, st); ok(s403.every(x => x === 403) && await o.locator("#f_vies").count() === 0, "odgovorna oseba stranke: poizvedbe zavrnjene (403), gumba ni");
  const sv = await prijava("sv@t.si"); const ss = await sv.evaluate(async d => [(await fetch("/api/podjetje/" + d)).status, (await fetch("/api/zavezanci")).status], D1);
  ok(ss[0] === 200 && ss[1] === 403, "svetovalec: poizvedba dovoljena, nastavitve seznama ne");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); srv.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
