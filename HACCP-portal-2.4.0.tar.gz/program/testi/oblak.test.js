// Kopija v oblak (S3): podpisani zahtevki, šifrirana kopija, ki jo je mogoče odšifrirati, brisanje kopij, starejših od 30 dni,
// skrivni ključ šifriran na disku, napake in opozorila. Posnemana shramba S3 preveri podpis vsakega zahtevka.
const http = require("http"), crypto = require("crypto"), fs = require("fs"), path = require("path");
const B = process.env.BASE, TMP = process.env.TMP;
const { podpisi } = require("../oblak.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const KID = "003testKEY", SK = "K003skrivni/+klju=c", objekti = new Map(); let pokvarjeno = false;
const s3 = http.createServer((q, r) => { const deli = []; q.on("data", d => deli.push(d)); q.on("end", () => {
  const telo = Buffer.concat(deli), a = q.headers.authorization || "", dat = q.headers["x-amz-date"] || "";
  const imena = (/SignedHeaders=([^,]+)/.exec(a) || [])[1] || "", glave = {}; for (const k of imena.split(";")) if (!["host", "x-amz-date", "x-amz-content-sha256"].includes(k)) glave[k] = q.headers[k];
  const cas = new Date(dat.replace(/^(\d{4})(\d\d)(\d\d)T(\d\d)(\d\d)(\d\d)Z$/, "$1-$2-$3T$4:$5:$6Z"));
  const prav = podpisi({ metoda: q.method, host: q.headers.host, pot: decodeURIComponent(q.url.split("?")[0]), telo: q.method === "PUT" ? telo : "", regija: "eu-central-003", kljucId: KID, skrivnost: SK, cas, glave }).authorization;
  if (a !== prav || q.headers["x-amz-content-sha256"] !== crypto.createHash("sha256").update(telo).digest("hex")) { r.writeHead(403); return r.end("<Error><Code>SignatureDoesNotMatch</Code><Message>The request signature we calculated does not match</Message></Error>"); }
  if (pokvarjeno) { r.writeHead(500); return r.end("<Error><Code>InternalError</Code><Message>Shramba ne deluje</Message></Error>"); }
  const k = decodeURIComponent(q.url);
  if (q.method === "PUT") { objekti.set(k, telo); r.writeHead(200); return r.end(); }
  if (q.method === "GET") { if (!objekti.has(k)) { r.writeHead(404); return r.end("<Error><Code>NoSuchKey</Code></Error>"); } r.writeHead(200); return r.end(objekti.get(k)); }
  if (q.method === "DELETE") { objekti.delete(k); r.writeHead(204); return r.end(); }
  r.writeHead(405); r.end(); }); });
// odšifriranje kopije .hfbk: HFBK1 | sol(16) | iv(12) | oznaka(16) | šifrat (AES-256-GCM, ključ scrypt)
const odsifriraj = (buf, g) => { const k = crypto.scryptSync(g, buf.subarray(5, 21), 32, { N: 1 << 15, r: 8, p: 1, maxmem: 128 * 1024 * 1024 }), d = crypto.createDecipheriv("aes-256-gcm", k, buf.subarray(21, 33)); d.setAuthTag(buf.subarray(33, 49)); return Buffer.concat([d.update(buf.subarray(49)), d.final()]); };
(async () => {
  // uradni testni primeri AWS Signature V4 za S3 (dokumentacija AWS, primeri GET, PUT in seznam)
  { const k = { regija: "us-east-1", kljucId: "AKIAIOSFODNN7EXAMPLE", skrivnost: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY", cas: new Date("2013-05-24T00:00:00Z"), host: "examplebucket.s3.amazonaws.com" };
    const g = podpisi(Object.assign({ metoda: "GET", pot: "/test.txt", glave: { Range: "bytes=0-9" }, telo: "" }, k)).authorization, p = podpisi(Object.assign({ metoda: "PUT", pot: "/test$file.text", glave: { Date: "Fri, 24 May 2013 00:00:00 GMT", "x-amz-storage-class": "REDUCED_REDUNDANCY" }, telo: "Welcome to Amazon S3." }, k)).authorization, l = podpisi(Object.assign({ metoda: "GET", pot: "/", poizvedba: { "max-keys": "2", prefix: "J" }, telo: "" }, k)).authorization;
    ok(g.endsWith("f0e8bdb87c964420e857bd35b5d6ed310bd44f0170aba48dd91039c6036bdb41") && p.endsWith("98ad721746da40c64f1a55b78f14c238d841ea1380cd77a1b5971af0ece108bd") && l.endsWith("34b48302e7b5fa45bde8084f4b7868a86f0a534bc59db6670ed5711ef69dc6f7"), "podpis AWS Signature V4 ustreza uradnim testnim primerom AWS"); }
  await new Promise(r => s3.listen(0, "127.0.0.1", r)); const EP = "http://127.0.0.1:" + s3.address().port;
  let ck = ""; const A = async (m, p, b) => { const r = await fetch(B + p, { method: m, headers: { "Content-Type": "application/json", Cookie: ck, Origin: B }, body: b ? JSON.stringify(b) : undefined }); const sc = r.headers.get("set-cookie"); if (sc) ck = sc.split(";")[0]; let j = null; try { j = await r.json(); } catch {} return { s: r.status, j }; };
  await A("POST", "/api/auth/nastavi", { email: "a@t.si", geslo: "dolgogeslo123", ime: "A" });
  await A("POST", "/api/d/stranke", { naziv: "Oblak d.o.o." });
  const nas = { endpoint: EP, regija: "eu-central-003", vedro: "higifood-kopije", kljuc_id: KID, skrivnost: SK, predpona: "streznik1" };
  let r = await A("PUT", "/api/kopija/oblak", nas); ok(r.s === 400 && /geslo za šifriranje/.test(r.j.napaka), "brez gesla za šifriranje kopija v oblak ni mogoča");
  await A("PUT", "/api/kopija/nastavitve", { mapa: "", geslo: "kopijsko-geslo-1" });
  r = await A("POST", "/api/kopija/oblak/preizkus", Object.assign({}, nas, { skrivnost: "napacen" })); ok(r.s === 400 && /signature/i.test(r.j.napaka), "napačen skrivni ključ: razumljiva napaka (" + r.j.napaka + ")");
  r = await A("POST", "/api/kopija/oblak/preizkus", nas); ok(r.s === 200 && objekti.size === 0, "preizkus povezave: zapis, branje in brisanje (podpis preverjen)");
  r = await A("PUT", "/api/kopija/oblak", nas); ok(r.s === 200 && r.j.skrivnost === "********", "nastavitve shranjene, skrivni ključ se ne vrača");
  const nf = fs.readFileSync(path.join(TMP, "podatki", "_nastavitve.json"), "utf8"); ok(!nf.includes(SK) && /oblak_skrivnost":\s*"enc1:/.test(nf), "skrivni ključ je na disku šifriran");
  const star = new Date(Date.now() - 31 * 864e5).toISOString().slice(0, 10); objekti.set("/higifood-kopije/streznik1/kopija-" + star + ".hfbk", Buffer.from("stara"));
  r = await A("POST", "/api/kopija/oblak/zdaj", {}); const danes = "/higifood-kopije/streznik1/kopija-" + new Date().toISOString().slice(0, 10) + ".hfbk";
  ok(r.s === 200 && objekti.has(danes) && !objekti.has("/higifood-kopije/streznik1/kopija-" + star + ".hfbk"), "kopija naložena v mapo vedra, kopija izpred 31 dni izbrisana");
  const zip = odsifriraj(objekti.get(danes), "kopijsko-geslo-1");
  ok(zip.subarray(0, 2).toString() === "PK" && zip.includes(Buffer.from("podatki/uporabniki.json")) && zip.includes(Buffer.from("podatki/stranke.json")), "kopijo v oblaku je mogoče odšifrirati z geslom (zip z uporabniki in strankami)");
  r = await A("GET", "/api/sistem"); ok(!r.j.opozorila.some(o => /oblak/.test(o)), "brez opozoril o kopiji v oblak");
  pokvarjeno = true; r = await A("POST", "/api/kopija/oblak/zdaj", {}); ok(r.s === 502 && /Shramba ne deluje/.test(r.j.napaka), "napaka shrambe se pokaže");
  r = await A("GET", "/api/sistem"); ok(r.j.opozorila.some(o => /Kopija v oblak ni uspela/.test(o)), "opozorilo sistema: kopija v oblak ni uspela");
  pokvarjeno = false; r = await A("GET", "/api/kopija/oblak"); ok(r.j.stanje.ok === false && r.j.vedro === "higifood-kopije", "stanje vidno v nastavitvah");
  r = await A("PUT", "/api/kopija/oblak", { endpoint: "", vedro: "", kljuc_id: "", skrivnost: "", predpona: "" }); ok(r.s === 200 && !r.j.vedro, "kopijo v oblak je mogoče izklopiti");
  s3.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
