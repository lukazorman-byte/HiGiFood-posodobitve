// Ponovni pregled agentov – srednje in nizke napake: naročnine, umiki, robustnost API, evidence (čas, revizije, preimenovanje,
// straničenje), Danes, QR vnos, PDF (alineje, kazalo, vezaji, obrazci na en list), GDPR koš, obvezna menjava ponastavljenega gesla.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const strani = f => (fs.readFileSync(f, "latin1").match(/\/Type \/Page\b/g) || []).length;
(async () => {
  const br = await chromium.launch(), errs = []; fs.mkdirSync(OUT, { recursive: true });
  const mk = async o => { const p = await (await br.newContext(Object.assign({ acceptDownloads: true }, o || {}))).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const login = async (p, em, pw) => { await p.goto(B + "/"); await p.fill("#le", em); await p.fill("#lp", pw); await p.click("#lf button"); await p.waitForSelector("#shell:not([hidden])"); };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const pdf = async (fn, ime) => { const b64 = await pg.evaluate(fn); const f = path.join(OUT, ime); fs.writeFileSync(f, Buffer.from(b64, "base64")); return f; };
  const B64 = "const u = new Uint8Array(await blob.arrayBuffer()); let r = ''; for (let i = 0; i < u.length; i += 8192) r += String.fromCharCode(...u.subarray(i, i + 8192)); return btoa(r);";

  // --- naročnine ---
  const nr = await pg.evaluate(async () => {
    const S = await D.add("stranke", { naziv: "Paketna d.o.o.", paket: "pro" }), r = {};
    await D.set("stranke", S.id, { paket: "osnovni" }); r.cena = (await api("GET", "/api/narocnina?stranka_id=" + S.id)).narocnina.cena_mesec;
    const pk = await api("PUT", "/api/narocnine/paketi/", { ime: "Mini test", cena: 5, moduli: ["danes"] }); const S2 = await D.add("stranke", { naziv: "Mini d.o.o.", paket: pk.id }); await D.del("stranke", S2.id);
    r.brisi = await api("DELETE", "/api/narocnine/paketi/" + pk.id).then(() => 200, e => e.message);
    const pr = await api("POST", "/api/narocnine/" + S.id + "/predracun", {});
    r.placan = await api("POST", "/api/predracun/" + pr.id + "/placan", { datum: "2026-02-30" }).then(() => 200, e => e.message);
    await api("POST", "/api/predracun/" + pr.id + "/storno", {}); r.storno2 = await api("POST", "/api/predracun/" + pr.id + "/storno", {}).then(() => 200, e => e.message);
    r.ddv = await api("PUT", "/api/narocnine/nastavitve", { cenik: { ddv: 500 } }).then(() => 200, e => e.message);
    return r;
  });
  ok(nr.cena === 20, "menjava paketa v obrazcu stranke: cena po novem paketu (" + nr.cena + " €)");
  ok(nr.brisi === 200, "paket izbrisane stranke je mogoče izbrisati: " + nr.brisi);
  ok(/datum/i.test(nr.placan) && /že storniran/.test(nr.storno2) && /ceniku/.test(nr.ddv), "neobstoječ datum plačila, dvojni storno, DDV 500 % zavrnjeni");

  // --- umiki: kratke šarže in dobavitelji, LOT-1/2026 ---
  const um = await pg.evaluate(async () => {
    await api("PUT", "/api/umiki/rasff", { vklopljeno: false }); await api("PUT", "/api/umiki/viri", { viri: [] });
    const s = await D.add("stranke", { naziv: "Umiki R2 d.o.o." });
    await D.add("sarze", { stranka_id: s.id, izdelek: "Namaz", sarza: "A12" }); await D.add("sarze", { stranka_id: s.id, izdelek: "Sir", sarza: "LOT-1" }); await D.add("dobavitelji", { stranka_id: s.id, naziv: "Ika d.o.o." });
    for (const n of ["R2 šarža A12 umik", "R2 Odpoklic Ika testenine", "R2 sir lot-1/2026"]) await api("POST", "/api/umiki", { naslov: n });
    const l = (await api("GET", "/api/umiki?stranka_id=" + s.id)).obvestila, z = t => ((l.find(n => n.naslov === t) || {}).zadetki || []).join(",");
    return [z("R2 šarža A12 umik"), z("R2 Odpoklic Ika testenine"), z("R2 sir lot-1/2026")];
  });
  ok(/A12/.test(um[0]) && /Ika/.test(um[1]) && !/LOT-1/.test(um[2]), "umiki: kratka šarža in dobavitelj zadeneta, LOT-1/2026 ne zadene LOT-1: " + JSON.stringify(um));

  // --- robustnost API ---
  const api = async (m, p, body, h) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B, Cookie: await pg.evaluate(() => document.cookie).then(() => "") }, h || {}), body }); return r.status; };
  const ck = (await pg.context().cookies()).map(c => c.name + "=" + c.value).join("; ");
  const A = async (m, p, body) => (await fetch(B + p, { method: m, headers: { "Content-Type": "application/json", Origin: B, Cookie: ck }, body })).status;
  const sid0 = await pg.evaluate(async () => (await D.list("stranke"))[0].id);
  ok(await A("PUT", "/api/d/stranke/" + sid0, '["x",{"a":1}]') === 400, "seznam kot telo zahtevka → 400");
  ok(await A("POST", "/api/d/stranke", '{"naziv":"P","constructor":1}') !== 500 && await A("GET", "/api/d/constructor") === 404 && await A("GET", "/api/d/__proto__") === 404, "polje/zbirka »constructor« ne povzroči 500");
  ok((await fetch(B + "/api/auth/prijava", { method: "POST", headers: { "Content-Type": "application/json", Origin: B }, body: JSON.stringify({ email: "x".repeat(300000) }) })).status === 413, "brez prijave: veliko telo → 413");
  ok(await A("POST", "/api/d/stranke", JSON.stringify({ naziv: "​" })) === 400, "naziv iz nevidnega znaka zavrnjen");
  ok(await A("POST", "/api/d/dogodki", JSON.stringify({ stranka_id: sid0, naslov: "D", datum: "2024-02-31" })) === 400, "neobstoječ datum 2024-02-31 zavrnjen");

  // --- evidence: čas v prihodnosti, revizija brez spremembe, pogostost 0, preimenovanje naprave ---
  const ev = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Evidence R2 d.o.o." }), r = { sid: s.id };
    const e = await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Zamrzovalnik 1", vrednost: -20, min: -25, max: -18, cas: "2099-12-31T10:00:00Z" });
    r.prihodnost = e.cas < "2030" && e.cas_naprave === "2099-12-31T10:00:00Z";
    const e2 = await D.set("evidence", e.id, { vrednost: -20, cas: "2020-01-01T00:00:00Z", _razlog: "x" }); r.ver = e2.verzija;
    r.urnik = await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", frekvenca_ur: 0 }).then(() => 200, x => x.message);
    const op = await D.add("oprema", { stranka_id: s.id, naziv: "Zamrzovalnik 1", tip: "zamrzovalnik", meja_min: -25, meja_max: -18 });
    await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", naprava: "Zamrzovalnik 1", frekvenca_ur: 24 });
    await D.set("oprema", op.id, { naziv: "Zamrzovalnik A" }); r.op = op.id;
    for (let i = 0; i < 230; i++) await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Drugo", vrednost: 3, min: 0, max: 5, cas: new Date(Date.now() - (i + 2) * 36e5).toISOString() });
    return r;
  });
  ok(ev.prihodnost, "čas zapisa v prihodnosti popravljen na zdaj (prvotni shranjen)");
  ok(ev.ver === 1, "PUT brez dejanske spremembe ne ustvari nove različice (" + ev.ver + ")");
  ok(/več kot 0/.test(ev.urnik), "pogostost 0 ur zavrnjena: " + ev.urnik);
  await pg.goto(B + "/#/stranka/" + ev.sid + "/evidence"); await pg.waitForSelector("#enew");
  ok(!/Manjka vnos .*Zamrzovalnik A/.test(await pg.textContent("#view")), "po preimenovanju naprave stari zapisi še štejejo (ni »Manjka vnos«)");
  const nvr = await pg.$$eval("#view table.t", t => t[0].querySelectorAll("tbody tr").length);
  ok(nvr === 200 && await pg.locator("#emore").count() === 1, "zavihek Evidence: prvih 200 zapisov in »Pokaži več« (" + nvr + ")");
  // QR vnos: odstopanje v obvestilu
  await pg.goto(B + "/#/vnos/" + ev.op); await pg.waitForSelector("#f_vrednost"); await pg.fill("#f_vrednost", "-5"); await pg.click("#dlg-f .btn:not(.ghost)");
  await pg.waitForSelector(".toast.show"); ok(/ODSTOPANJE/.test(await pg.textContent("#toast")), "QR vnos: obvestilo o odstopanju (" + await pg.textContent("#toast") + ")");
  ok(/Zadnji zapisi/.test(await pg.textContent("#vl")) && (await pg.locator("#vl tr").count()) >= 2, "QR: zadnji zapisi vključujejo zapise pred preimenovanjem");
  // Danes: Infinity in 1e3 zavrnjena
  await pg.evaluate(id => sessionStorage.setItem("danes_sid", id), ev.sid); await pg.goto(B + "/#/danes"); await pg.waitForSelector("[data-ht]");
  await pg.fill("#ht_0", "Infinity"); await pg.click("[data-ht='0']"); await pg.waitForSelector(".toast.show:has-text('Vpišite število')"); ok(true, "Danes: »Infinity« zavrnjen");

  // --- Pregled zapisov: brez zapisov izbrisane stranke ---
  const pz = await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Izbrisana R2" }); await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "X", vrednost: 3, min: 0, max: 5, opomba: "IZBRISANA-R2" }); await D.del("stranke", s.id); });
  await pg.goto(B + "/#/pregled-zapisov"); await pg.waitForSelector("#pa"); ok(!/Izbrisana R2/.test(await pg.textContent("#view")), "Pregled zapisov ne kaže zapisov izbrisane stranke");

  // --- PDF: alineje navodila, kazalo pri dolgih naslovih, vezaji, obrazci na en list ---
  const fN = await pdf(`(async () => { const blob = navodiloPdf({ naslov: "Navodilo R2", vsebina: "1. NAMEN\\nUvod.\\n- ALINEJA-ENA prva\\n- ALINEJA-DVA druga\\nKonec.", status: "osnutek" }, { naziv: "S" }, await baza()); ${B64} })()`, "navodilo.pdf");
  const tN = cp.spawnSync("pdftotext", [fN, "-"], { encoding: "utf8" });
  if (!tN.error) ok(/ALINEJA-ENA/.test(tN.stdout) && /ALINEJA-DVA/.test(tN.stdout), "navodilo: alineje so v PDF");
  const fK = await pdf(`(async () => { const blob = pdfBuild({ naslov: "Kazalo", stranka: "S" }, d => { for (let i = 0; i < 80; i++) { d.h(i % 3 ? 2 : 1, "Poglavje " + i + " z zelo dolgim naslovom, ki se zagotovo prelomi v dve vrstici kazala in preveri razporeditev po straneh"); d.p("x"); } }); ${B64} })()`, "kazalo.pdf");
  const bb = cp.spawnSync("pdftotext", ["-bbox", "-f", "2", "-l", "6", fK, "-"], { encoding: "utf8" });
  if (!bb.error) { const ys = [...bb.stdout.matchAll(/yMax="([\d.]+)"/g)].map(x => +x[1]); ok(ys.every(y => y > 0 && y < 842) && /Poglavje 79/.test(cp.spawnSync("pdftotext", [fK, "-"], { encoding: "utf8" }).stdout), "kazalo z dolgimi naslovi: nič pod robom strani, vsi vnosi prisotni"); }
  const fH = await pdf(`(async () => { const blob = pdfBuild({ naslov: "V", stranka: "S", plain: true }, d => d.table(["Vrsta", "B"], [["Navzkrižnakontaminacijazelodolga", "b"]], [12, 88])); ${B64} })()`, "vezaj.pdf");
  const tH = cp.spawnSync("pdftotext", ["-bbox", fH, "-"], { encoding: "utf8" }); if (!tH.error) ok(/>Navzkrižna?k?-<\/word>/.test(tH.stdout) || /[a-zž]-<\/word>/.test(tH.stdout), "predolga beseda v stolpcu se razdeli z vezajem");
  await pg.goto(B + "/#/obrazci"); await pg.waitForSelector("[data-p=temperatura]");
  for (const [k, ime] of [["temperatura", "obr1.pdf"], ["@temp", "obr2.pdf"]]) { const [d] = await Promise.all([pg.waitForEvent("download"), pg.click(`[data-p="${k}"]`)]); const f = path.join(OUT, ime); await d.saveAs(f); ok(strani(f) === 1, "obrazec " + k + " na enem listu (" + strani(f) + ")"); }

  // --- GDPR: koš ---
  const gd = await pg.evaluate(async () => { const s = (await D.list("stranke"))[0]; const o = await D.add("osebje", { stranka_id: s.id, ime: "Janez Šmid", email: "janez.smid@t.si" }); await D.del("osebje", o.id); const r = await api("POST", "/api/gdpr/izvoz", { ime: "Janez Smid", email: "janez.smid@t.si" }); return Object.keys(r.zapisi); });
  ok(gd.some(k => /koš/.test(k)), "GDPR izvoz najde osebo tudi v košu: " + gd);

  // --- ponastavljeno geslo: dokler ga ne zamenja, API ni dosegljiv ---
  const uid = await pg.evaluate(async () => { const s = (await D.list("stranke"))[0]; const u = await api("POST", "/api/uporabniki", { ime: "Ponastavljen", email: "pon@t.si", geslo: "dolgogeslo123", vloga: "odgovorna", stranka_id: s.id }); await api("PUT", "/api/uporabniki/" + u.id, { geslo: "zacasnogeslo1" }); return u.id; });
  const pp = await mk(); await pp.goto(B + "/"); await pp.fill("#le", "pon@t.si"); await pp.fill("#lp", "zacasnogeslo1"); await pp.click("#lf button"); await pp.waitForSelector("#dlg[open] #p1");
  ok(await pp.evaluate(() => api("GET", "/api/d/stranke").then(() => 200, e => e.message)) !== 200, "po ponastavitvi gesla API ni dosegljiv do menjave");
  await pp.fill("#p0", "zacasnogeslo1"); await pp.fill("#p1", "novogesloR2xx"); await pp.click("#dlg-f .btn:not(.ghost)"); await pp.waitForSelector(".toast.show:has-text('Geslo spremenjeno')");
  ok(await pp.evaluate(() => api("GET", "/api/d/stranke").then(r => r.length, e => e.message)) === 1, "po menjavi gesla deluje normalno");

  // --- SMTP: neveljaven prejemnik ---
  await pg.evaluate(() => api("PUT", "/api/nastavitve", { streznik: "127.0.0.1", vrata: 2599, varnost: "brez", od: "HiGiFood <n@t.si>" }));
  const sm = await pg.evaluate(() => api("POST", "/api/obvestila/test", { komu: "a@b.si>\r\nRCPT TO:<evil@c.si" }).then(() => 200, e => e.message));
  ok(/Neveljaven e-naslov prejemnika/.test(sm), "SMTP: naslov s CRLF zavrnjen pred povezavo: " + sm);

  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
