// Izboljšave po testiranju: umiki brez strank, zložljive skupine menija, predlogi iskanja, koledar (dolgi nazivi),
// zadnje aktivnosti (kdo, povezava), odstopanje na nadzorni plošči, mobilni prikaz; vse strani menija brez napak JavaScript.
const B = process.env.BASE;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const ctx = await br.newContext({ viewport: { width: 1280, height: 900 } }), pg = await ctx.newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e))); pg.on("dialog", d => d.accept());
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Ana Admin"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // 7) umiki brez strank
  await pg.goto(B + "/#/umiki"); await pg.waitForSelector("text=Najprej dodajte stranko"); ok(!/ni ujemanj/.test(await pg.textContent("#view")), "umiki brez strank: »Najprej dodajte stranko« namesto »ni ujemanj«");
  await pg.click("#um_dodaj"); await pg.waitForSelector("#f_naziv"); await pg.fill("#f_naziv", "Prevzem Kuhinja d.o.o."); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => /#\/stranka\/.+\/podatki/.test(location.hash));
  ok(true, "gumb »Dodaj stranko« odpre obrazec in po shranitvi profil stranke");
  // 10) meni: vse skupine zložljive, stanje se zapomni
  const sk = await pg.$$eval("#menu details.nav-sk", d => d.map(x => x.dataset.sk + ":" + x.open));
  ok(sk.length >= 4 && sk.includes("Orodja:true") && sk.includes("Administracija:false"), "skupine menija zložljive (" + sk.join(", ") + ")");
  await pg.click('#menu details[data-sk="Orodja"] summary'); await pg.waitForFunction(() => (JSON.parse(localStorage.getItem("nav_skupine") || "{}")).Orodja === false); await pg.reload(); await pg.waitForSelector("#menu details.nav-sk");
  ok(await pg.$eval('#menu details[data-sk="Orodja"]', d => !d.open), "zaprta skupina ostane zaprta po osvežitvi");
  await pg.goto(B + "/#/kos"); await pg.waitForTimeout(300); ok(await pg.$eval('#menu details[data-sk="Orodja"]', d => d.open), "skupina trenutne strani se odpre");
  // 3) zadnje aktivnosti: kdo in povezava; odstopanje (hladilnik 9 °C) na nadzorni plošči
  const sid = await pg.evaluate(async () => { const s = (await D.list("stranke"))[0]; await D.add("evidence", { stranka_id: s.id, vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: 9, min: 0, max: 4, cas: new Date().toISOString() });
    await D.add("dogodki", { stranka_id: s.id, naslov: "Pregled: zelo dolg naziv dogodka za letni pregled HACCP sistema v kuhinji", datum: new Date().toISOString().slice(0, 10) }); return s.id; });
  await pg.goto(B + "/#/nadzorna"); await pg.reload(); await pg.waitForSelector(".kpi-bloki");
  const k = await pg.$$eval(".kpi", x => x.map(e => e.querySelector("b").textContent + " " + e.querySelector("span").textContent));
  ok(k.includes("1 odstopanje v zapisih") && k.includes("1 stranka"), "hladilnik 9 °C (meja 4 °C) → odstopanje na nadzorni plošči: " + k.join(", "));
  const ak = (await pg.textContent("details:has-text('Zadnje aktivnosti')")).replace(/\s+/g, " ");
  ok(/Ana Admin/.test(ak) && await pg.locator(`details:has-text('Zadnje aktivnosti') a[href="#/stranka/${sid}/podatki"]`).count() === 1, "zadnje aktivnosti: kdo in povezava na zapis");
  // 8) koledar: dolgi nazivi se prelomijo, celoten naziv v namigu
  await pg.goto(B + "/#/koledar"); await pg.waitForSelector(".cal .ev");
  const ev = await pg.$eval(".cal .ev", e => ({ ws: getComputedStyle(e).whiteSpace, t: e.title, h: e.offsetHeight }));
  ok(ev.ws === "normal" && /letni pregled HACCP sistema v kuhinji/.test(ev.t) && ev.h > 20, "koledar: naziv v več vrsticah in v namigu");
  // 11) predlogi iskanja
  await pg.click("#gs"); await pg.keyboard.type("Pr"); await pg.waitForSelector("#gs-p:not([hidden]) .gs-i");
  ok(/Prevzem Kuhinja/.test(await pg.textContent("#gs-p")), "predlogi po 2 znakih");
  await pg.keyboard.press("ArrowDown"); await pg.keyboard.press("Enter"); await pg.waitForFunction(id => location.hash === "#/stranka/" + id + "/podatki", sid); ok(true, "puščica + Enter odpre predlog");
  await pg.fill("#gs", "kuhinja"); await pg.waitForSelector("#gs-p:not([hidden])"); await pg.keyboard.press("Enter"); await pg.waitForFunction(() => location.hash === "#/iskanje/kuhinja"); ok(true, "Enter brez izbire odpre vse rezultate");
  // vse strani menija brez napak JavaScript
  await pg.$$eval("#menu details.nav-sk", d => d.forEach(x => x.open = true));
  const hrefs = await pg.$$eval("#menu a[href^='#/']", a => a.map(x => x.getAttribute("href")));
  for (const h of hrefs) { await pg.goto(B + "/" + h); await pg.waitForTimeout(400); }
  ok(hrefs.length >= 15 && !errs.length, `${hrefs.length} strani menija brez napak` + (errs.length ? ": " + errs[0] : ""));
  // PDF: šumniki in dolgi nazivi (mesečni list čiščenja)
  await pg.evaluate(async id => { await D.add("ciscenje_nacrt", { stranka_id: id, podrocje: "Kuhinja – delovni pult", opravilo: "Čiščenje in razkuževanje površin za pripravo živil: žličnice, šibe, ščetke in drobni pribor ČŠŽ", sredstvo: "Čistilo Ž", pogostost_dni: 1 }); }, sid);
  await pg.goto(B + "/#/obrazci"); await pg.waitForSelector('[data-p="@ciscenje"]');
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click('[data-p="@ciscenje"]')]); fs.mkdirSync(process.env.OUT, { recursive: true }); const f = path.join(process.env.OUT, "cisc.pdf"); await dl.saveAs(f);
  const pt = cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" });
  if (pt.error) console.log("ok: (pdftotext ni nameščen – preverjanje šumnikov v PDF preskočeno)");
  else { const t = pt.stdout.replace(/\s+/g, " "); ok(/Čiščenje in razkuževanje/.test(t) && /žličnice, šibe, ščetke/.test(t) && /drobni pribor ČŠŽ/.test(t) && !/\?\?/.test(t), "PDF: šumniki (č, š, ž, Č, Š, Ž) in celoten dolg naziv"); }
  // vloge: odgovorna oseba in zaposleni vidita samo svojo stranko; skriti razdelki niso dostopni niti z neposrednim naslovom
  const tuja = await pg.evaluate(async id => { const t = await D.add("stranke", { naziv: "Tuja d.o.o." }); for (const [ime, email, vloga] of [["Olga Odgovorna", "o@t.si", "odgovorna"], ["Zala Zaposlena", "z@t.si", "zaposleni"]]) await api("POST", "/api/uporabniki", { ime, email, geslo: "dolgogeslo123", vloga, stranka_id: id, stranke: [] }); return t.id; }, sid);
  for (const [em, vloga] of [["o@t.si", "odgovorna"], ["z@t.si", "zaposleni"]]) {
    const u = await (await br.newContext()).newPage(); u.on("pageerror", e => errs.push(String(e.stack || e)));
    await u.goto(B + "/"); await u.fill("#le", em); await u.fill("#lp", "dolgogeslo123"); await u.click("#lf button"); await u.waitForSelector("#shell:not([hidden])");
    const vid = await u.evaluate(async () => (await D.list("stranke")).map(x => x.naziv)); ok(vid.length === 1 && vid[0] === "Prevzem Kuhinja d.o.o.", vloga + ": vidi samo svojo stranko (" + vid.join(", ") + ")");
    const st = await u.evaluate(async t => { const r = await fetch("/api/d/evidence?stranka_id=" + t); return r.status + " " + (await r.text()).slice(0, 80); }, tuja); ok(/^(403|404)|^200 \[\]$/.test(st), vloga + ": API tuje stranke zavrnjen (" + st + ")");
    await u.goto(B + "/#/stranka/" + tuja + "/podatki"); await u.waitForTimeout(600); ok(!/Tuja d\.o\.o\./.test(await u.textContent("#view")), vloga + ": tuja stranka z neposrednim naslovom ni dostopna");
    await u.goto(B + "/#/admin/varnost"); await u.waitForTimeout(600); ok(!/Veriga zgoščenk/.test(await u.textContent("#view")), vloga + ": administracija z neposrednim naslovom ni dostopna");
    if (vloga === "zaposleni") { await u.goto(B + "/#/stranka/" + sid + "/storitve"); await u.waitForTimeout(600); ok(!/#\/stranka\/[^/]+\/storitve/.test(await u.evaluate(() => location.hash)), "zaposleni: skriti razdelek (Storitve) z neposrednim naslovom preusmeri"); }
    await u.context().close();
  }
  // 12) mobilni prikaz
  const m = await (await br.newContext({ viewport: { width: 390, height: 800 }, storageState: await ctx.storageState() })).newPage(); m.on("pageerror", e => errs.push(String(e.stack || e)));
  await m.goto(B + "/#/stranke"); await m.waitForSelector("#shell:not([hidden])"); await m.waitForSelector("table.t");
  const vidnoNav = () => m.$eval("#nav", n => n.getBoundingClientRect().right > 0);
  ok(!(await vidnoNav()) && await m.locator("#burger").isVisible(), "mobilno: meni skrit za gumbom ☰");
  await m.click("#burger"); await m.waitForTimeout(300); ok(await vidnoNav(), "☰ odpre meni"); await m.mouse.click(370, 400); await m.waitForTimeout(300); ok(!(await vidnoNav()), "klik izven menija ga zapre");
  ok(await m.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), "mobilno: stran se ne drsi vodoravno (tabele se drsijo v svojem okvirju)");
  await m.evaluate(() => openForm("stranke", null, null, () => {})); await m.waitForSelector("#f_naziv");
  ok(await m.$eval("#dlg-b .fgrid", g => getComputedStyle(g).gridTemplateColumns.split(" ").length) === 1, "mobilno: obrazec v enem stolpcu");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
