// Ponovni pregled agentov – visoke napake: shranjeni XSS (tloris, čarovnik), paket/naročnina samo za administratorja,
// svetovalec ne more prevzeti računa drugega svetovalca, PDF znaka € in „ ter puščica.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [], dialogi = []; fs.mkdirSync(OUT, { recursive: true });
  const mk = async () => { const p = await (await br.newContext({ acceptDownloads: true })).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => { dialogi.push(d.message()); d.accept(); }); return p; };
  const login = async (p, em, pw) => { await p.goto(B + "/"); await p.fill("#le", em); await p.fill("#lp", pw); await p.click("#lf button"); await p.waitForSelector("#shell:not([hidden])"); };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const ids = await pg.evaluate(async () => {
    const S = await D.add("stranke", { naziv: "Naročnik „Pri Žanu“ d.o.o." }), S2 = await D.add("stranke", { naziv: "Druga stranka" });
    const u = (ime, email, vloga, sid, stranke) => api("POST", "/api/uporabniki", { ime, email, geslo: "dolgogeslo123", vloga, stranka_id: sid, stranke: stranke || [] });
    await u("Odg", "odg@t.si", "odgovorna", S.id); await u("Sv1", "sv1@t.si", "svetovalec", null, [S.id]);
    // prej: svetovalec s skrito povezavo na stranko (obrazec je poslal stranka_id) – zdaj se ne shrani
    const sv2 = await u("Sv2", "sv2@t.si", "svetovalec", S.id, [S2.id]);
    await api("PUT", "/api/narocnine/" + S.id, { paket: "pro", obdobje: "letno", cena_mesec: 99, placano_do: "2027-06-30" });
    return { s: S.id, s2: S2.id, sv2: sv2.id, sv2sid: sv2.stranka_id };
  });
  ok(ids.sv2sid === null, "svetovalec ni vezan na stranko (stranka_id = null)");

  // --- XSS: tloris in čarovnik (odgovorna shrani, admin odpre) ---
  const o = await mk(); await login(o, "odg@t.si", "dolgogeslo123");
  const x = await o.evaluate(async () => {
    const r = {};
    r.tl = await api("POST", "/api/d/tlorisi", { naziv: "T", sirina_m: 10, visina_m: 8, elementi: [{ t: "besedilo", id: "e1", x: 1, y: 1, text: "a", vel: '14"></text></svg><img src=x onerror=alert(1)><svg><text>' }] }).then(() => 200, e => e.message);
    r.tl2 = await api("POST", "/api/d/tlorisi", { naziv: "T", sirina_m: 10, visina_m: 8, elementi: [{ t: "soba", id: 's"><img src=x onerror=alert(2)>', x: 2, y: 2, w: 2, h: 2 }] }).then(() => 200, e => e.message);
    r.wz = await api("POST", "/api/d/nacrti", { naziv: "N", vsebina: { koraki: [{ id: "k1", naziv: "P" }], nevarnosti: [{ id: "h1", korak_id: "k1", tip: "B", nevarnost: "x", verjetnost: "<img src=x onerror=alert(3)>", teza: "2" }] } }).then(() => 200, e => e.message);
    const ok1 = await api("POST", "/api/d/tlorisi", { naziv: "Kuhinja", sirina_m: 10, visina_m: 8, elementi: [{ t: "soba", id: "s1", x: 1, y: 1, w: 3, h: 3, ime: '<img src=x onerror=alert(4)>' }] });
    const ok2 = await api("POST", "/api/d/nacrti", { naziv: "Načrt <b>", vsebina: { koraki: [{ id: "k1", naziv: "<img src=x onerror=alert(5)>" }], nevarnosti: [{ id: "h1", korak_id: "k1", tip: "B", nevarnost: "<img src=x onerror=alert(6)>", verjetnost: "3", teza: "4" }] } });
    r.t = ok1.id; r.n = ok2.id; return r;
  });
  ok(/tlorisa/.test(x.tl) && /tlorisa/.test(x.tl2), "strežnik zavrne kodo v meri in id elementa tlorisa: " + x.tl + " | " + x.tl2);
  ok(/1 do 5/.test(x.wz), "strežnik zavrne kodo v verjetnosti nevarnosti: " + x.wz);
  await pg.goto(B + "/#/tloris/" + x.t); await pg.waitForSelector("svg [data-id]"); await pg.waitForTimeout(300);
  await pg.goto(B + "/#/carovnik/" + x.n); await pg.waitForSelector(".stepper"); await pg.click(".stepper button >> nth=3"); await pg.waitForTimeout(500); await pg.click(".stepper button >> nth=4"); await pg.waitForTimeout(500);
  ok(!dialogi.length, "besedilo s kodo v tlorisu in čarovniku se prikaže, koda se ne izvede (" + dialogi.join(",") + ")");

  // --- naročnina: svetovalec je prek obrazca stranke ne more spremeniti ali izbrisati ---
  const s1 = await mk(); await login(s1, "sv1@t.si", "dolgogeslo123");
  await s1.evaluate(async id => { await D.set("stranke", id, { naziv: "Naročnik „Pri Žanu“ d.o.o.", paket: "" }); await D.set("stranke", id, { naziv: "Naročnik „Pri Žanu“ d.o.o.", paket: "osnovni" }); }, ids.s).catch(() => {});
  const nn = await pg.evaluate(async id => { const r = await api("GET", "/api/narocnina?stranka_id=" + id); return r.narocnina && r.narocnina.paket === "pro" && r.narocnina.cena_mesec === 99; }, ids.s);
  ok(nn, "naročnina (pro, 99 €) ostane po poskusu svetovalca");
  await s1.goto(B + "/#/stranka/" + ids.s + "/podatki"); await s1.waitForTimeout(500);
  const imaPaket = await s1.evaluate(async id => { await new Promise(r => setTimeout(r, 200)); openForm("stranke", (await D.list("stranke")).find(x => x.id === id), {}, () => {}); await new Promise(r => setTimeout(r, 300)); return !!document.querySelector("#f_paket"); }, ids.s);
  ok(!imaPaket, "svetovalec v obrazcu stranke nima polja Paket");

  // --- prevzem računa: svetovalec ne more spremeniti gesla drugemu svetovalcu ---
  const pr = await s1.evaluate(id => api("PUT", "/api/uporabniki/" + id, { geslo: "novogeslo12345" }).then(() => 200, e => e.message), ids.sv2);
  ok(pr !== 200, "svetovalec ne more spremeniti gesla drugemu svetovalcu: " + pr);
  const vidi = await s1.evaluate(async () => (await api("GET", "/api/uporabniki")).map(u => u.vloga));
  ok(vidi.every(v => v === "odgovorna" || v === "zaposleni"), "svetovalec na seznamu uporabnikov vidi samo odgovorne in zaposlene: " + vidi);
  const ime = await pg.evaluate(() => api("POST", "/api/uporabniki", { ime: "   ", email: "prazno@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: null }).then(() => 200, e => e.message));
  ok(/ime/i.test(ime), "prazno ime novega uporabnika zavrnjeno: " + ime);
  const gs = await pg.evaluate(id => api("POST", "/api/uporabniki", { ime: "P", email: "p2@t.si", geslo: "          ", vloga: "zaposleni", stranka_id: id }).then(() => 200, e => e.message), ids.s);
  ok(gs !== 200, "geslo iz samih presledkov zavrnjeno");

  // --- PDF: € in „ ter puščica ---
  const b64 = await pg.evaluate(async () => { const blob = pdfBuild({ naslov: "Test „Pri Žanu“", stranka: "Č", plain: true }, d => { d.p("Cena popravila 120 € – „Pri Žanu“ čšž ČŠŽ ćđ ĆĐ ≤ 4 °C, ≥ 72 °C, Prevzem → Skladiščenje"); });
    const u = new Uint8Array(await blob.arrayBuffer()); let r = ""; for (const c of u) r += String.fromCharCode(c); return btoa(r); });
  const f = path.join(OUT, "znaki.pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" });
  if (!t.error) ok(/120 €/.test(t.stdout) && /„Pri Žanu“/.test(t.stdout) && /čšž ČŠŽ ćđ ĆĐ/.test(t.stdout) && /≤ 4/.test(t.stdout) && /Prevzem -> Skladiščenje/.test(t.stdout), "PDF: € „ šumniki ≤ in puščica (" + t.stdout.split("\n").find(l => /Cena/.test(l)) + ")");

  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
