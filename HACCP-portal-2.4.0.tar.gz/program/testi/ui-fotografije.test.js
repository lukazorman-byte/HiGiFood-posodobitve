// Fotografije: velike fotografije se pred pošiljanjem zmanjšajo, sličice v seznamih in obrazcih, fotografije odstopanj v paketu za inšpekcijo.
const B = process.env.BASE, OUT = process.env.OUT;
const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const pg = await (await br.newContext({ acceptDownloads: true, viewport: { width: 1280, height: 900 } })).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // velika »fotografija s telefona« (4000 × 3000, šum → velika datoteka)
  const b64 = await pg.evaluate(async () => { const c = document.createElement("canvas"); c.width = 4000; c.height = 3000; const g = c.getContext("2d"), im = g.createImageData(4000, 3000); for (let i = 0; i < im.data.length; i += 4) { const v = (Math.random() * 255) | 0; im.data[i] = v; im.data[i + 1] = (v * 7) & 255; im.data[i + 2] = 255 - v; im.data[i + 3] = 255; } g.putImageData(im, 0, 0);
    const b = await new Promise(r => c.toBlob(r, "image/jpeg", 0.92)); const u = new Uint8Array(await b.arrayBuffer()); let s = ""; for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode.apply(null, u.subarray(i, i + 32768)); return btoa(s); });
  fs.mkdirSync(OUT, { recursive: true }); const velika = path.join(OUT, "telefon.jpg"); fs.writeFileSync(velika, Buffer.from(b64, "base64")); const izv = fs.statSync(velika).size;
  const sid = await pg.evaluate(async () => (await D.add("stranke", { naziv: "Foto d.o.o." })).id);
  await pg.goto(B + "/#/stranka/" + sid + "/evidence"); await pg.waitForSelector("#enew"); await pg.click("#enew"); await pg.click("button[data-v=temperatura]");
  await pg.fill("#f_vrednost", "9"); await pg.fill("#f_max", "4"); await pg.setInputFiles("#f_slika", velika); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector("tbody img.thumb"); await pg.waitForFunction(() => document.querySelector("tbody img.thumb").naturalWidth > 0);
  const pr = await pg.evaluate(async id => { const e = (await D.list("evidence", { stranka_id: id }))[0]; const p = (await D.list("priloge", { stranka_id: id })).find(x => x.id === e.slike[0]); const im = document.querySelector("tbody img.thumb"); return { vel: p.velikost, tip: p.tip, w: im.naturalWidth, h: im.naturalHeight }; }, sid);
  ok(pr.vel < izv / 3 && pr.tip === "image/jpeg" && Math.max(pr.w, pr.h) === 1600, `fotografija zmanjšana pred pošiljanjem: ${Math.round(izv / 1024)} kB → ${Math.round(pr.vel / 1024)} kB, ${pr.w}×${pr.h}`);
  ok(await pg.locator("tbody tr a[href^='/api/priloga/'] img.thumb").count() === 1, "sličica v seznamu evidenc (povezava na polno velikost)");
  await pg.click("tbody tr td >> nth=0"); await pg.waitForSelector(".dlg-b img.thumb"); ok(true, "sličica v obrazcu zapisa"); await pg.click("#dlg-x");
  // majhna slika ostane nespremenjena
  const majhna = await pg.evaluate(async () => { const c = document.createElement("canvas"); c.width = 200; c.height = 100; const b = await new Promise(r => c.toBlob(r, "image/png")); const f = new File([b], "m.png", { type: "image/png" }); return (await zmanjsajSliko(f)) === f; });
  ok(majhna, "majhna slika se ne spreminja");
  // CAPA s fotografijo → sličica v seznamu; paket za inšpekcijo s fotografijami odstopanj
  await pg.goto(B + "/#/stranka/" + sid + "/capa"); await pg.waitForSelector("#ladd"); await pg.click("#ladd"); await pg.waitForSelector("#f_opis"); await pg.fill("#f_opis", "Hladilnik nad mejo – menjava tesnila"); await pg.setInputFiles("#f__foto", velika); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector("table.t img.thumb"); ok(true, "sličica v seznamu CAPA");
  await pg.goto(B + "/#/stranka/" + sid + "/inspekcija"); await pg.waitForSelector("#i_pak");
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click("#i_pak")]); const f = path.join(OUT, "paket.pdf"); await dl.saveAs(f);
  const pt = cp.spawnSync("pdftotext", [f, "-"], { encoding: "utf8" }), pim = cp.spawnSync("pdfimages", ["-list", f], { encoding: "utf8" });
  if (pt.error) console.log("ok: (pdftotext ni nameščen – preverjanje preskočeno)");
  else ok(/Fotografije odstopanj in korektivnih ukrepov/.test(pt.stdout) && /menjava tesnila/.test(pt.stdout) && (pim.error || (pim.stdout.match(/jpeg|image/g) || []).length >= 2), "paket za inšpekcijo: fotografije odstopanja in ukrepa CAPA");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
