// Obvezna dvostopenjska prijava po vlogah: nastavitev v Administraciji, zaklep do nastavitve, nastavitev s kodo, nato normalno delo.
const crypto = require("crypto");
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const dec = s => { let bits = 0, val = 0; const out = []; for (const ch of s.toUpperCase().replace(/[^A-Z2-7]/g, "")) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); };
const totp = (key, ctr) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); const h = crypto.createHmac("sha1", key).update(b).digest(), o = h[h.length - 1] & 15; return String(((h.readUInt32BE(o) & 0x7fffffff) % 1e6)).padStart(6, "0"); };
(async () => {
  const br = await chromium.launch(); const errs = [];
  const mk = async () => { const p = await (await br.newContext()).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  await pg.evaluate(async () => { const s = await D.add("stranke", { naziv: "Varna d.o.o." }); await api("POST", "/api/uporabniki", { ime: "Sv", email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", stranke: [s.id] }); await api("POST", "/api/uporabniki", { ime: "Zap", email: "z@t.si", geslo: "dolgogeslo123", vloga: "zaposleni", stranka_id: s.id, stranke: [] }); });
  await pg.goto(B + "/#/admin/varnost"); await pg.waitForSelector("#var-card"); ok((await pg.textContent("#var-card")).includes("1 brez dvostopenjske prijave"), "Administracija: število uporabnikov brez dvostopenjske prijave po vlogah");
  await pg.check('[data-o2="svetovalec"]'); await pg.click("#var_s"); await pg.waitForSelector(".toast.show:has-text('Shranjeno')");
  // svetovalec: zaklenjen, dokler ne nastavi
  const s = await mk(); await s.goto(B + "/"); await s.fill("#le", "sv@t.si"); await s.fill("#lp", "dolgogeslo123"); await s.click("#lf button"); await s.waitForSelector("#shell:not([hidden])");
  await s.waitForSelector("#p0"); await s.fill("#p0", "dolgogeslo123"); await s.fill("#p1", "novogeslo12345"); await s.click("#dlg-f .btn:last-child"); await s.waitForSelector("#dlg", { state: "hidden" }); // obvezna zamenjava začasnega gesla (dovoljena tudi brez 2FA)
  await s.waitForSelector("text=Nastavite dvostopenjsko prijavo"); ok(true, "svetovalec po prijavi vidi samo navodila za nastavitev");
  const zak = await s.evaluate(() => api("GET", "/api/d/stranke").then(() => null, e => ({ s: e.status, m: e.message })));
  ok(zak && zak.s === 403 && /obvezna dvostopenjska/.test(zak.m), "strežnik zavrne podatke brez dvostopenjske prijave");
  await s.click("#o2_n"); await s.waitForSelector("#f2k"); const key = dec(await s.textContent("#f2k"));
  await s.fill("#f2c", totp(key, Math.floor(Date.now() / 30000))); await s.click("#dlg-f .btn:last-child"); await s.waitForSelector("#f2r"); await s.click("#dlg-f .btn");
  await s.waitForFunction(() => document.querySelector("#title").textContent === "Nadzorna plošča" && !document.querySelector("#o2_n"));
  await s.goto(B + "/#/stranke"); await s.waitForSelector("text=Varna d.o.o."); ok(true, "po nastavitvi svetovalec normalno dela (nadzorna plošča, svoja stranka)");
  ok(await s.evaluate(() => api("GET", "/api/d/stranke").then(r => r.length)) === 1, "API spet dostopen");
  // zaposleni (vloga ni obvezna): dela brez
  const z = await mk(); await z.goto(B + "/"); await z.fill("#le", "z@t.si"); await z.fill("#lp", "dolgogeslo123"); await z.click("#lf button"); await z.waitForSelector("#shell:not([hidden])");
  await z.waitForSelector("#p0"); await z.fill("#p0", "dolgogeslo123"); await z.fill("#p1", "novogeslo12345"); await z.click("#dlg-f .btn:last-child"); await z.waitForSelector("#dlg", { state: "hidden" });
  ok(await z.locator("text=Nastavite dvostopenjsko prijavo").count() === 0 && await z.evaluate(() => api("GET", "/api/d/stranke").then(r => r.length)) === 1, "zaposleni (vloga ni izbrana) dela brez dvostopenjske prijave");
  ok(await z.evaluate(() => api("PUT", "/api/varnost", { obvezna_2fa: [] }).then(() => 200, e => e.status)) === 403, "samo administrator spreminja nastavitev");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.message); process.exit(2); });
