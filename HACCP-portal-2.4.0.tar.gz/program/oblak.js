// Kopija izven strežnika: nalaganje šifrirane varnostne kopije v shrambo, združljivo s S3 (Backblaze B2, Cloudflare R2, AWS S3, Wasabi, MinIO …).
// Podpis zahtevkov AWS Signature V4 brez dodatnih knjižnic; naslov v obliki https://<končna točka>/<vedro>/<ključ> (path-style).
const crypto = require("crypto"), https = require("https"), http = require("http");
const sha = b => crypto.createHash("sha256").update(b).digest("hex");
const hmac = (k, s) => crypto.createHmac("sha256", k).update(s).digest();
const enc = s => encodeURIComponent(s).replace(/[!'()*]/g, c => "%" + c.charCodeAt(0).toString(16).toUpperCase());

// podpis: vrne glave za zahtevek (Authorization, x-amz-date, x-amz-content-sha256, host)
function podpisi({ metoda, host, pot, poizvedba, glave, telo, regija, kljucId, skrivnost, cas, storitev }) {
  const amzDate = (cas || new Date()).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, ""), dan = amzDate.slice(0, 8);
  const hashTelesa = telo === "UNSIGNED-PAYLOAD" ? telo : sha(telo || "");
  const h = Object.assign({}, glave || {}, { host, "x-amz-date": amzDate, "x-amz-content-sha256": hashTelesa });
  const imena = Object.keys(h).map(k => k.toLowerCase()).sort(), vred = Object.fromEntries(Object.entries(h).map(([k, v]) => [k.toLowerCase(), String(v).trim().replace(/\s+/g, " ")]));
  const kanPot = pot.split("/").map(enc).join("/");
  const kanPoizv = Object.entries(poizvedba || {}).map(([k, v]) => [enc(k), enc(v)]).sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : a[1] < b[1] ? -1 : 1).map(x => x.join("=")).join("&");
  const kanZahtevek = [metoda, kanPot, kanPoizv, imena.map(k => k + ":" + vred[k] + "\n").join(""), imena.join(";"), hashTelesa].join("\n");
  const obseg = [dan, regija, storitev || "s3", "aws4_request"].join("/");
  const zaPodpis = ["AWS4-HMAC-SHA256", amzDate, obseg, sha(kanZahtevek)].join("\n");
  const kSign = hmac(hmac(hmac(hmac("AWS4" + skrivnost, dan), regija), storitev || "s3"), "aws4_request");
  const podpis = crypto.createHmac("sha256", kSign).update(zaPodpis).digest("hex");
  return Object.assign(h, { authorization: `AWS4-HMAC-SHA256 Credential=${kljucId}/${obseg}, SignedHeaders=${imena.join(";")}, Signature=${podpis}` });
}

// nastavitve: { endpoint: "https://s3.eu-central-003.backblazeb2.com", regija, vedro, kljucId, skrivnost, predpona }
function zahtevek(n, metoda, kljuc, telo) {
  return new Promise((ok, ne) => {
    let u; try { u = new URL(String(n.endpoint || "").replace(/\/+$/, "")); } catch { return ne(new Error("Neveljaven naslov shrambe.")); }
    if (u.protocol !== "https:" && !(u.protocol === "http:" && ["127.0.0.1", "localhost"].includes(u.hostname))) return ne(new Error("Naslov shrambe mora biti https://"));
    const pot = (u.pathname.replace(/\/+$/, "") + "/" + n.vedro + "/" + kljuc).replace(/\/{2,}/g, "/"), host = u.host;
    const glave = podpisi({ metoda, host, pot, telo: telo || "", regija: n.regija || "us-east-1", kljucId: n.kljucId, skrivnost: n.skrivnost, glave: telo ? { "content-length": telo.length, "content-type": "application/octet-stream" } : {} });
    const lib = u.protocol === "https:" ? https : http;
    const rq = lib.request({ method: metoda, hostname: u.hostname, port: u.port || undefined, path: pot.split("/").map(enc).join("/"), headers: glave, timeout: 120e3 }, r => {
      const deli = []; r.on("data", d => deli.push(d)); r.on("end", () => { const b = Buffer.concat(deli); if (r.statusCode >= 200 && r.statusCode < 300) ok(b); else { const m = /<Message>([^<]*)<\/Message>/.exec(b.toString()) || /<Code>([^<]*)<\/Code>/.exec(b.toString()); ne(new Error("Shramba: HTTP " + r.statusCode + (m ? " – " + m[1] : ""))); } });
    });
    rq.on("timeout", () => rq.destroy(new Error("časovna omejitev")));
    rq.on("error", e => ne(new Error("Povezava s shrambo ni uspela: " + (e.code || e.message))));
    if (telo) rq.end(telo); else rq.end();
  });
}
const kljucOf = (n, ime) => (String(n.predpona || "").replace(/^\/+|\/+$/g, "") ? String(n.predpona).replace(/^\/+|\/+$/g, "") + "/" : "") + ime;
module.exports = {
  podpisi,
  nalozi: (n, ime, buf) => zahtevek(n, "PUT", kljucOf(n, ime), buf),
  prenesi: (n, ime) => zahtevek(n, "GET", kljucOf(n, ime)),
  izbrisi: (n, ime) => zahtevek(n, "DELETE", kljucOf(n, ime)),
  // preizkus nastavitev: zapiše, prebere in izbriše majhno datoteko
  async preizkusi(n) { const ime = "higifood-preizkus-" + Date.now() + ".txt", vs = Buffer.from("HiGiFood preizkus " + new Date().toISOString()); await this.nalozi(n, ime, vs); const nazaj = await this.prenesi(n, ime); await this.izbrisi(n, ime).catch(() => {}); if (!nazaj.equals(vs)) throw new Error("Prebrana vsebina se ne ujema."); return true; }
};
