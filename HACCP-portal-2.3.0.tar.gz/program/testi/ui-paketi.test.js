// Plačljivi paketi: zaklepanje funkcij po paketu stranke (meni, zavihki, API), naročnina, predračun, plačilo, opozorila in pravice.
const fs = require("fs"), path = require("path");
const B = process.env.BASE, OUT = process.env.OUT || require("os").tmpdir(); fs.mkdirSync(OUT, { recursive: true });
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(); const errs = [];
  const mk = async () => { const p = await (await br.newContext({ acceptDownloads: true })).newPage(); p.on("pageerror", e => errs.push(String(e.stack || e))); p.on("dialog", d => d.accept()); return p; };
  const pg = await mk();
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "A"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const sid = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Paket d.o.o.", naslov: "Glavna 1, Ljubljana", davcna: "SI12345678" });
    await D.add("obrati", { stranka_id: s.id, naziv: "Kuhinja" }); await D.add("obrati", { stranka_id: s.id, naziv: "Bife" });
    for (const [ime, email, vloga] of [["Oda", "oda@t.si", "odgovorna"], ["Zan", "zan@t.si", "zaposleni"]]) await api("POST", "/api/uporabniki", { ime, email, geslo: "dolgogeslo123", vloga, stranka_id: s.id, stranke: [] });
    return s.id; });
  const prijava = async email => { const z = await mk(); await z.goto(B + "/"); await z.fill("#le", email); await z.fill("#lp", "dolgogeslo123"); await z.click("#lf button"); await z.waitForSelector("#shell:not([hidden])"); await z.waitForSelector("#p0"); await z.fill("#p0", "dolgogeslo123"); await z.fill("#p1", "novogeslo12345"); await z.click("#dlg-f .btn:last-child"); await z.waitForSelector("#dlg", { state: "hidden" }); return z; };
  const status = (p, m, u, b) => p.evaluate(async ([m, u, b]) => api(m, u, b).then(() => 200, e => e.status), [m, u, b]);
  const z = await prijava("zan@t.si"), o = await prijava("oda@t.si");
  // brez paketa: vse kot prej
  ok(await status(z, "GET", "/api/d/sarze?stranka_id=" + sid) === 200 && await z.locator("#menu a.zaklep").count() === 0, "stranka brez paketa: vse funkcije, nič zaklenjenega");
  // administrator določi paket Osnovni (predlog cene upošteva 2 obrata)
  const nar = await pg.evaluate(() => api("GET", "/api/narocnine"));
  ok(nar.predlogi[sid].standard === 64 && nar.predlogi[sid].osnovni === 32, `predlog cene po obratih (Standard ${nar.predlogi[sid].standard} €, Osnovni ${nar.predlogi[sid].osnovni} €)`);
  await pg.goto(B + "/#/narocnine"); await pg.waitForSelector(`[data-ur="${sid}"]`); await pg.click(`[data-ur="${sid}"]`);
  await pg.selectOption("#nr_p", "osnovni"); await pg.click("#nr_up"); ok(await pg.inputValue("#nr_c") === "32", "predlog cene prenesen v obrazec");
  await pg.fill("#nr_op", "interna opomba"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector(`[data-pr="${sid}"]`);
  ok((await pg.textContent("#view")).includes("Osnovni"), "naročnina shranjena (paket Osnovni)");
  // zaposleni: zaklenjeno v meniju, zavihkih in API
  await z.reload(); await z.waitForSelector("#shell:not([hidden])");
  ok(await z.locator('#menu a.zaklep[data-id="umiki"]').count() === 1, "meni: Umiki in odpoklici z ključavnico");
  await z.goto(B + `/#/stranka/${sid}/sledljivost`); await z.waitForSelector("text=ni vključeno v vaš paket");
  ok((await z.textContent("#tabbody")).includes("Standard") && await z.locator(".tabs a.zaklep").count() >= 3, "zavihek Sledljivost: obvestilo o paketu Standard, zavihki z ključavnico");
  await z.goto(B + "/#/umiki"); await z.waitForSelector("text=ni vključeno v vaš paket"); ok(z.url().includes("#/paket/umiki"), "zaklenjena stran preusmeri na obvestilo o paketu");
  ok(await status(z, "GET", "/api/d/sarze?stranka_id=" + sid) === 403 && await status(z, "GET", "/api/umiki") === 403, "API: zaklenjene zbirke in umiki vrnejo 403");
  ok(await status(z, "GET", "/api/d/evidence?stranka_id=" + sid) === 200, "API: funkcije iz paketa delujejo");
  // pravice: stranka ne more spreminjati naročnine, zaposleni je ne vidi, odgovorna ne vidi interne opombe
  ok(await status(o, "PUT", "/api/narocnine/" + sid, { paket: "pro", obdobje: "mesecno", cena_mesec: 0 }) === 403 && await status(o, "GET", "/api/narocnine") === 403, "odgovorna oseba ne more spremeniti paketa");
  ok(await status(z, "GET", "/api/narocnina?stranka_id=" + sid) === 403, "zaposleni ne vidi naročnine");
  const on = await o.evaluate(sid => api("GET", "/api/narocnina?stranka_id=" + sid), sid);
  ok(on.paket === "osnovni" && on.narocnina && on.narocnina.opomba === undefined, "odgovorna vidi paket brez interne opombe");
  // predračun
  const [dl] = await Promise.all([pg.waitForEvent("download"), pg.click(`[data-pr="${sid}"]`)]); const f = path.join(OUT, "predracun.pdf"); await dl.saveAs(f);
  ok(fs.readFileSync(f).slice(0, 4).toString() === "%PDF" && fs.statSync(f).size > 1500, "predračun izdan in prenesen kot PDF");
  const pr = (await pg.evaluate(() => api("GET", "/api/narocnine"))).predracuni[0];
  ok(/^PR-\d{4}-001$/.test(pr.stevilka) && pr.neto === 32 && pr.ddv === 7.04 && pr.skupaj === 39.04 && pr.status === "izdan", `predračun ${pr.stevilka}: ${pr.neto} + ${pr.ddv} DDV = ${pr.skupaj} €`);
  ok(await status(pg, "POST", "/api/narocnine/" + sid + "/predracun", {}) === 409, "dvojni predračun za isto obdobje ni mogoč");
  await pg.goto(B + "/#/narocnine"); await pg.waitForSelector(`[data-pl="${pr.id}"]`); await pg.click(`[data-pl="${pr.id}"]`); await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector(`[data-pl="${pr.id}"]`, { state: "detached" });
  const po = await pg.evaluate(sid => api("GET", "/api/narocnine").then(d => d.stranke[sid]), sid);
  ok(po.placano_do === pr.do && po.stanje.koda === "aktivna", "plačilo podaljša naročnino do " + pr.do);
  // opozorilo pred iztekom: odgovorna na nadzorni plošči, administrator v e-poštnem opomniku
  const jutri = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  await pg.evaluate(([sid, d]) => api("PUT", "/api/narocnine/" + sid, { paket: "osnovni", obdobje: "mesecno", cena_mesec: 32, placano_do: d }), [sid, jutri]);
  await o.goto(B + "/#/nadzorna"); await o.reload(); await o.waitForSelector("text=kmalu poteče"); ok(true, "odgovorna: opozorilo, da naročnina kmalu poteče");
  const ob = await pg.evaluate(() => api("POST", "/api/obvestila/zdaj", {}));
  ok(JSON.stringify(ob.predogled).includes("Naročnina (Osnovni) poteče"), "administrator: opomnik o izteku v e-poštnih obvestilih");
  // nadgradnja odklene funkcije, odstranitev paketa vrne vse
  await pg.evaluate(sid => api("PUT", "/api/narocnine/" + sid, { paket: "standard", obdobje: "letno", cena_mesec: 64 }), sid);
  ok(await status(z, "GET", "/api/d/sarze?stranka_id=" + sid) === 200 && await status(z, "GET", "/api/d/certifikacija?stranka_id=" + sid) === 403, "Standard: sledljivost odklenjena, certifikacija še zaklenjena");
  const pr2 = await pg.evaluate(sid => api("POST", "/api/narocnine/" + sid + "/predracun", {}), sid);
  ok(pr2.neto === 640 && pr2.postavke[0].kolicina === 10, "letni predračun: 10 × mesečna cena (2 meseca brezplačno)");
  await pg.evaluate(sid => api("PUT", "/api/narocnine/" + sid, { paket: null }), sid);
  ok(await status(z, "GET", "/api/umiki") === 200, "odstranitev paketa: vse funkcije spet dostopne");
  await z.reload(); await z.waitForSelector("#shell:not([hidden])"); ok(await z.locator("#menu a.zaklep").count() === 0, "brez paketa ni več ključavnic");
  // urejanje paketov: nov paket, sprememba cene (tudi pri obstoječih strankah), brisanje
  await pg.goto(B + "/#/narocnine"); await pg.waitForSelector("#pk_nov"); await pg.click("#pk_nov");
  await pg.fill("#pk_i", "Mini"); await pg.fill("#pk_c", "12"); await pg.fill("#pk_o", "Samo evidence in Danes");
  for (const m of ["danes", "tab:evidence", "tab:obrati"]) await pg.check(`[data-pkm="${m}"]`);
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector("text=Samo evidence in Danes");
  const pk = await pg.evaluate(() => api("GET", "/api/narocnine")), mini = pk.paketi.find(p => p.ime === "Mini");
  ok(mini && mini.cena === 12 && mini.moduli.length === 3 && pk.paketi[0].id === mini.id, "nov paket Mini (12 €, 3 funkcije) ustvarjen in razvrščen po ceni");
  await pg.evaluate(([sid, id]) => api("PUT", "/api/narocnine/" + sid, { paket: id, obdobje: "mesecno", cena_mesec: 12 }), [sid, mini.id]);
  await z.reload(); await z.waitForSelector("#shell:not([hidden])");
  ok(await status(z, "GET", "/api/d/evidence?stranka_id=" + sid) === 200 && await status(z, "GET", "/api/d/osebje?stranka_id=" + sid) === 403, "paket Mini: evidence dostopne, zaposleni zaklenjeni");
  await pg.reload(); await pg.waitForSelector(`[data-pku="${mini.id}"]`); await pg.click(`[data-pku="${mini.id}"]`);
  await pg.fill("#pk_c", "15"); await pg.check("#pk_pos"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForSelector(".toast.show:has-text('posodobljenih strank: 1')");
  const po2 = await pg.evaluate(sid => api("GET", "/api/narocnine").then(d => ({ n: d.stranke[sid], p: d.paketi.find(p => p.ime === "Mini") })), sid);
  ok(po2.p.cena === 15 && po2.n.cena_mesec === 24, `nova cena paketa (15 €) uporabljena tudi pri stranki z 2 obratoma (${po2.n.cena_mesec} €)`);
  ok(await status(pg, "DELETE", "/api/narocnine/paketi/" + mini.id) === 409, "paketa, ki ga uporablja stranka, ni mogoče izbrisati");
  ok(await status(o, "PUT", "/api/narocnine/paketi/", { ime: "Zastonj", cena: 0, moduli: ["danes"] }) === 403, "odgovorna oseba ne more ustvariti paketa");
  await pg.evaluate(sid => api("PUT", "/api/narocnine/" + sid, { paket: null }), sid);
  ok(await status(pg, "DELETE", "/api/narocnine/paketi/" + mini.id) === 200, "neuporabljen paket izbrisan");
  // prikaz gesla
  const pz = await mk(); await pz.goto(B + "/"); await pz.waitForSelector("#lp"); await pz.fill("#lp", "skrito123");
  ok(await pz.getAttribute("#lp", "type") === "password", "geslo je privzeto skrito");
  await pz.click("#lp ~ .oko"); ok(await pz.getAttribute("#lp", "type") === "text" && await pz.getAttribute("#lp ~ .oko", "aria-pressed") === "true", "gumb z očesom pokaže geslo");
  await pz.click("#lp ~ .oko"); ok(await pz.getAttribute("#lp", "type") === "password", "ponovni klik geslo skrije");
  ok(await pg.evaluate(() => api("GET", "/api/revizijska-sled?n=40").then(r => ["narocnina", "predracun-izdan", "predracun-placan", "narocnina-odstranjena", "paket-nov", "paket-spremenjen", "paket-izbrisan"].every(a => r.vnosi.some(e => e.akcija === a)))), "spremembe naročnin v revizijski sledi");
  console.log("napake", errs); if (errs.length) fails++; await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.message); process.exit(2); });
