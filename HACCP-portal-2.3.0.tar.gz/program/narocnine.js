// Plačljivi paketi, naročnine strank in predračuni.
// Paket stranke določa, katere module vidijo njeni uporabniki (odgovorna oseba, zaposleni); administrator in svetovalec vidita vse.
// Podatki: _narocnine.json v mapi s podatki (cenik, izdajatelj, naročnine po strankah, predračuni). Plačilo ureja administrator sam (TRR/UPN).
const fs = require("fs"), path = require("path");

// privzeti paketi (prvi zagon); administrator jih lahko spremeni, doda nove ali izbriše (shranjeni v _narocnine.json)
const PRIVZETI = [
  { id: "osnovni", ime: "Osnovni", opis: "Digitalne evidence, Danes, čiščenje, opomniki, obrazci in izpisi",
    moduli: ["danes", "koledar", "pregled-zapisov", "obrazci", "kos", "tab:obrati", "tab:tloris", "tab:osebje", "tab:dobavitelji", "tab:oprema", "tab:evidence", "tab:higiena", "tab:capa", "tab:koledar", "tab:priloge", "tab:storitve", "tab:uporabniki"] },
  { id: "standard", ime: "Standard", opis: "Osnovni + HACCP čarovnik in navodila, sledljivost, alergeni in jedilnik, umiki in odpoklici, potrditve",
    dodatno: ["generator", "tab:nacrti", "tab:navodila", "tab:sledljivost", "tab:alergeni", "umiki", "tab:potrditve"] },
  { id: "pro", ime: "Pro", opis: "Standard + certifikacija, inšpekcijska mapa in uvoz podatkov", dodatno: ["tab:certifikacija", "tab:inspekcija", "uvoz"] },
  { id: "svetovanje", ime: "S svetovanjem", opis: "Vse funkcije Pro in redne storitve svetovalca", dodatno: [] }
];
for (let i = 1; i < PRIVZETI.length; i++) PRIVZETI[i].moduli = PRIVZETI[i - 1].moduli.concat(PRIVZETI[i].dodatno);
const PRIVZETE_CENE = { osnovni: 20, standard: 40, pro: 65, svetovanje: 140 };
const CENIK = { popust_obrat: 40, brezplacni_meseci: 2, ddv: 22, rok_dni: 8, opozorilo_dni: 14 };
const IZDAJATELJ = { naziv: "", naslov: "", davcna: "", trr: "", banka: "", email: "", telefon: "" };

const dan = d => new Date(d + "T00:00:00Z");
const iso = d => d.toISOString().slice(0, 10);
const plusDni = (d, n) => { const x = dan(d); x.setUTCDate(x.getUTCDate() + n); return iso(x); };
// konec obdobja: isti dan naslednjega meseca (ali leta) minus en dan
const konecObdobja = (od, mes) => { const x = dan(od), y = new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth() + mes, 1)), zad = new Date(Date.UTC(y.getUTCFullYear(), y.getUTCMonth() + 1, 0)).getUTCDate(); y.setUTCDate(Math.min(x.getUTCDate(), zad)); return plusDni(iso(y), -1); };
const r2 = x => Math.round(x * 100) / 100;

module.exports = function narocnine({ DIR, load, audit, send, bad, jbody, tenantOk, now, uid, osveziPodatke, moduli }) {
  const MODULI = new Set(moduli || []);
  const F = path.join(DIR, "_narocnine.json");
  let cache = null;
  const preberi = () => { if (!cache) { try { cache = JSON.parse(fs.readFileSync(F, "utf8")); } catch { cache = {}; } cache = Object.assign({ cenik: {}, izdajatelj: {}, stranke: {}, predracuni: [] }, cache); } return cache; };
  const shrani = () => { const tmp = F + ".tmp", fd = fs.openSync(tmp, "w"); try { fs.writeSync(fd, JSON.stringify(cache, null, 1)); fs.fsyncSync(fd); } finally { fs.closeSync(fd); } fs.renameSync(tmp, F); if (osveziPodatke) osveziPodatke(); };
  const cenik = () => { const c = preberi().cenik, o = {}; for (const k of Object.keys(CENIK)) o[k] = c[k] !== undefined ? c[k] : CENIK[k]; return o; };
  // paketi, urejeni po ceni; ob prvem branju iz privzetih (cene iz starega cenika, če so bile spremenjene)
  const paketi = () => {
    const d = preberi();
    if (!Array.isArray(d.paketi)) d.paketi = PRIVZETI.map(p => ({ id: p.id, ime: p.ime, opis: p.opis, moduli: p.moduli.slice(), cena: Number(d.cenik[p.id]) >= 0 && d.cenik[p.id] !== undefined ? Number(d.cenik[p.id]) : PRIVZETE_CENE[p.id] }));
    return d.paketi.slice().sort((a, b) => a.cena - b.cena || a.ime.localeCompare(b.ime, "sl"));
  };
  const paket = id => paketi().find(p => p.id === id) || null;
  const izdajatelj = () => Object.assign({}, IZDAJATELJ, preberi().izdajatelj);
  const danes = () => now().slice(0, 10);

  // id paketa stranke ali null (paket ni določen: vse funkcije, kot pred uvedbo paketov)
  const paketOf = sid => { const n = sid && preberi().stranke[sid]; return n && paket(n.paket) ? n.paket : null; };
  // modul ni v paketu stranke → id najcenejšega paketa, ki ga vsebuje (za prikaz »na voljo v paketu …«), sicer null
  function zaklenjeno(sid, modul) {
    const p = paketOf(sid); if (!p || paket(p).moduli.includes(modul)) return null;
    const v = paketi().find(x => x.moduli.includes(modul)); return v ? v.id : null; // najcenejši, ki ga vsebuje
  }
  function stanje(n) {
    if (!n || !n.placano_do) return { koda: "neplacano", besedilo: "ni plačila" };
    const c = cenik(), d = Math.round((dan(n.placano_do) - dan(danes())) / 864e5);
    if (d < 0) return { koda: "zapadla", besedilo: "zapadla pred " + -d + " d", dni: d };
    if (d <= c.opozorilo_dni) return { koda: "poteka", besedilo: "poteče čez " + d + " d", dni: d };
    return { koda: "aktivna", besedilo: "aktivna", dni: d };
  }
  // predlagana mesečna cena po ceniku: prvi obrat polna cena, vsak dodatni s popustom
  const paket_ = paket;
  function predlogCene(paket, sid) {
    const c = cenik(), osnova = Number((paket_(paket) || {}).cena) || 0, obrati = sid ? load("obrati").filter(o => o.stranka_id === sid).length : 1;
    return r2(osnova + Math.max(0, obrati - 1) * osnova * (1 - (Number(c.popust_obrat) || 0) / 100));
  }
  function novaStevilka() {
    const leto = danes().slice(0, 4), pr = preberi().predracuni.filter(x => (x.stevilka || "").startsWith("PR-" + leto + "-"));
    const n = pr.reduce((m, x) => Math.max(m, parseInt(x.stevilka.split("-")[2], 10) || 0), 0) + 1;
    return "PR-" + leto + "-" + String(n).padStart(3, "0");
  }
  // opomniki za administratorja (e-pošta in nadzorna plošča): naročnine, ki potečejo ali so zapadle
  function opomniki() {
    const out = [], c = cenik(), sm = Object.fromEntries(load("stranke").map(s => [s.id, s.naziv]));
    for (const [sid, n] of Object.entries(preberi().stranke)) {
      if (!sm[sid] || !n.placano_do) continue; const st = stanje(n);
      if (st.koda === "zapadla" || st.koda === "poteka") out.push({ datum: n.placano_do, dni: st.dni, stranka_id: sid, stranka: sm[sid], naslov: "Naročnina (" + (paket(n.paket) || { ime: n.paket }).ime + ") " + (st.koda === "zapadla" ? "je zapadla" : "poteče") + " " + n.placano_do + ": " + sm[sid] });
    }
    return out.sort((a, b) => a.dni - b.dni).slice(0, 200).map(x => Object.assign(x, { opozorilo_dni: c.opozorilo_dni }));
  }
  const javnaNarocnina = (sid, zaAdmina) => {
    const n = preberi().stranke[sid] || null; if (!n) return null;
    const o = Object.assign({}, n, { stanje: stanje(n) }); if (!zaAdmina) delete o.opomba; return o;
  };

  async function rNarocnine(req, res, p, url, me, ip) {
    if (!p.startsWith("/api/narocnin") && !p.startsWith("/api/predracun") && p !== "/api/paketi") return undefined;
    const admin = me.vloga === "admin";
    if (p === "/api/paketi" && req.method === "GET") { send(res, 200, { paketi: paketi(), cenik: cenik() }); return true; }
    // pregled za stranko (odgovorna oseba in osebje HiGiFood): paket, stanje, predračuni, kontakt izdajatelja
    if (p === "/api/narocnina" && req.method === "GET") {
      const sid = url.searchParams.get("stranka_id") || me.stranka_id;
      if (!sid || !tenantOk(me, sid) || me.vloga === "zaposleni") { bad(res, 403, "prepovedano"); return true; }
      const iz = izdajatelj();
      send(res, 200, { paket: paketOf(sid), narocnina: javnaNarocnina(sid, admin), predracuni: preberi().predracuni.filter(x => x.stranka_id === sid).sort((a, b) => b.datum.localeCompare(a.datum)), izdajatelj: iz, paketi: paketi(), cenik: cenik() }); return true;
    }
    if (!admin) { bad(res, 403, "samo administrator"); return true; }
    if (p === "/api/narocnine" && req.method === "GET") {
      const d = preberi(), st = {}; for (const sid of Object.keys(d.stranke)) st[sid] = javnaNarocnina(sid, true);
      const predlogi = {}; for (const s of load("stranke")) predlogi[s.id] = Object.fromEntries(paketi().map(x => [x.id, predlogCene(x.id, s.id)]));
      const upor = {}; for (const n of Object.values(d.stranke)) upor[n.paket] = (upor[n.paket] || 0) + 1;
      send(res, 200, { paketi: paketi(), uporaba: upor, moduli: [...MODULI], cenik: cenik(), izdajatelj: izdajatelj(), stranke: st, predracuni: d.predracuni, predlogi }); return true;
    }
    if (p === "/api/narocnine/nastavitve" && req.method === "PUT") {
      const b = await jbody(req, res); if (!b) return true; paketi(); const d = preberi(); // paketi(): prenos starih cen paketov iz cenika
      if (b.cenik) { const c = {}; for (const k of Object.keys(CENIK)) if (b.cenik[k] !== undefined && b.cenik[k] !== "") { const v = Number(b.cenik[k]); if (!isFinite(v) || v < 0 || v > 100000) { bad(res, 400, "Neveljavna vrednost v ceniku: " + k); return true; } c[k] = v; } d.cenik = c; }
      if (b.izdajatelj) { const z = {}; for (const k of Object.keys(IZDAJATELJ)) z[k] = String(b.izdajatelj[k] || "").slice(0, 200); d.izdajatelj = z; }
      shrani(); audit(me, "narocnine-nastavitve", "", "", "cenik/izdajatelj", ip); send(res, 200, { ok: true }); return true;
    }
    // paketi: ustvari ali uredi (ime, opis, funkcije, cena), izbriši (če ga nobena stranka ne uporablja)
    const mk = p.match(/^\/api\/narocnine\/paketi\/([\w-]*)$/);
    if (mk && req.method === "PUT") {
      const b = await jbody(req, res); if (!b) return true; const vsi = paketi(), d = preberi();
      const ime = String(b.ime || "").trim().slice(0, 60), cena = Number(b.cena), mod = Array.isArray(b.moduli) ? [...new Set(b.moduli.map(String))] : null;
      if (!ime) { bad(res, 400, "Vpišite ime paketa."); return true; }
      if (!isFinite(cena) || cena < 0 || cena > 100000) { bad(res, 400, "Neveljavna cena."); return true; }
      if (!mod || !mod.length || mod.some(m => !MODULI.has(m))) { bad(res, 400, "Izberite vsaj eno funkcijo (in samo obstoječe)."); return true; }
      let id = mk[1];
      if (id && !vsi.some(x => x.id === id)) { bad(res, 404, "Paket ne obstaja."); return true; }
      if (vsi.some(x => x.id !== id && x.ime.toLowerCase() === ime.toLowerCase())) { bad(res, 400, "Paket s tem imenom že obstaja."); return true; }
      if (!id) id = (ime.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) || "paket") + "-" + uid().slice(0, 4).toLowerCase().replace(/[^a-z0-9]/g, "x");
      const prej = vsi.find(x => x.id === id), nov = { id, ime, opis: String(b.opis || "").slice(0, 300), moduli: mod, cena: r2(cena) };
      d.paketi = vsi.filter(x => x.id !== id).concat([nov]);
      let posodobljenih = 0; // nova cena tudi pri obstoječih strankah s tem paketom (po želji)
      if (b.posodobi_stranke) for (const [sid, n] of Object.entries(d.stranke)) if (n.paket === id) { n.cena_mesec = predlogCene(id, sid); n.spremenjeno = now(); posodobljenih++; }
      shrani(); audit(me, prej ? "paket-spremenjen" : "paket-nov", "", id, ime + ", " + r2(cena) + " €/mes" + (prej && prej.cena !== nov.cena ? " (prej " + prej.cena + " €)" : "") + (posodobljenih ? ", posodobljenih strank: " + posodobljenih : ""), ip);
      send(res, 200, Object.assign({ posodobljenih }, nov)); return true;
    }
    if (mk && mk[1] && req.method === "DELETE") {
      const d = preberi(), id = mk[1], vsi = paketi(); if (!vsi.some(x => x.id === id)) { bad(res, 404, "Paket ne obstaja."); return true; }
      const n = Object.values(d.stranke).filter(x => x.paket === id).length; if (n) { bad(res, 409, "Paket uporablja " + n + " strank. Najprej jim določite drug paket."); return true; }
      d.paketi = vsi.filter(x => x.id !== id); shrani(); audit(me, "paket-izbrisan", "", id, "", ip); send(res, 200, { ok: true }); return true;
    }
    const mn = p.match(/^\/api\/narocnine\/([\w-]+)$/);
    if (mn && req.method === "PUT") {
      const sid = mn[1]; if (!load("stranke").some(s => s.id === sid)) { bad(res, 404, "Stranka ne obstaja."); return true; }
      const b = await jbody(req, res); if (!b) return true; const d = preberi();
      if (b.paket === null || b.paket === "") { delete d.stranke[sid]; shrani(); audit(me, "narocnina-odstranjena", "stranke", sid, "", ip); send(res, 200, { ok: true }); return true; }
      if (!paket(b.paket)) { bad(res, 400, "Neznan paket."); return true; }
      const datum = x => x === undefined || x === null || x === "" ? null : /^\d{4}-\d{2}-\d{2}$/.test(x) ? x : false;
      const zac = datum(b.zacetek), pd = datum(b.placano_do), cena = Number(b.cena_mesec);
      if (zac === false || pd === false) { bad(res, 400, "Datum mora biti v obliki LLLL-MM-DD."); return true; }
      if (!isFinite(cena) || cena < 0 || cena > 100000) { bad(res, 400, "Neveljavna cena."); return true; }
      if (!["mesecno", "letno"].includes(b.obdobje)) { bad(res, 400, "Obdobje je mesečno ali letno."); return true; }
      const prej = d.stranke[sid] || {};
      d.stranke[sid] = { paket: b.paket, obdobje: b.obdobje, cena_mesec: r2(cena), zacetek: zac || prej.zacetek || danes(), placano_do: pd, opomba: String(b.opomba || "").slice(0, 500), spremenjeno: now() };
      shrani(); audit(me, "narocnina", "stranke", sid, (prej.paket || "-") + " → " + b.paket + ", " + r2(cena) + " €/mes, " + b.obdobje, ip); send(res, 200, javnaNarocnina(sid, true)); return true;
    }
    const mp = p.match(/^\/api\/narocnine\/([\w-]+)\/predracun$/);
    if (mp && req.method === "POST") {
      const sid = mp[1], s = load("stranke").find(x => x.id === sid), n = preberi().stranke[sid];
      if (!s || !n) { bad(res, 400, "Stranka nima naročnine (najprej določite paket)."); return true; }
      const c = cenik(), letno = n.obdobje === "letno", mes = letno ? 12 : 1, placljivih = letno ? Math.max(1, 12 - (Number(c.brezplacni_meseci) || 0)) : 1;
      const od = n.placano_do && n.placano_do >= plusDni(danes(), -1) ? plusDni(n.placano_do, 1) : (n.placano_do ? danes() : n.zacetek || danes());
      const dvojnik = preberi().predracuni.find(x => x.stranka_id === sid && x.status === "izdan" && x.od === od);
      if (dvojnik) { bad(res, 409, "Za to obdobje je predračun že izdan: " + dvojnik.stevilka + "."); return true; }
      const doo = konecObdobja(od, mes), neto = r2(n.cena_mesec * placljivih), ddv = r2(neto * (Number(c.ddv) || 0) / 100), d = danes();
      const opis = "Naročnina HiGiFood HACCP – paket " + (paket(n.paket) || { ime: n.paket }).ime + (letno ? " (letno plačilo, " + placljivih + " × mesečna cena)" : "");
      const pr = { id: uid(), stevilka: novaStevilka(), stranka_id: sid, stranka: { naziv: s.naziv || "", naslov: s.naslov || "", davcna: s.davcna || "" }, datum: d, rok: plusDni(d, Number(c.rok_dni) || 8), od, do: doo, paket: n.paket, obdobje: n.obdobje,
        postavke: [{ opis, obdobje: od + " – " + doo, kolicina: placljivih, cena: n.cena_mesec, znesek: neto }], neto, ddv_stopnja: Number(c.ddv) || 0, ddv, skupaj: r2(neto + ddv), status: "izdan", ustvarjeno: now(), ustvaril: me.id };
      preberi().predracuni.push(pr); shrani(); audit(me, "predracun-izdan", "stranke", sid, pr.stevilka + " " + pr.skupaj + " €", ip); send(res, 200, pr); return true;
    }
    const mpl = p.match(/^\/api\/predracun\/([\w-]+)\/(placan|storno)$/);
    if (mpl && req.method === "POST") {
      const pr = preberi().predracuni.find(x => x.id === mpl[1]); if (!pr) { bad(res, 404, "ni najdeno"); return true; }
      const b = await jbody(req, res); if (!b) return true;
      if (mpl[2] === "storno") { if (pr.status === "placan") { bad(res, 400, "Plačanega predračuna ni mogoče stornirati."); return true; } pr.status = "storniran"; pr.storno = now(); }
      else {
        if (pr.status !== "izdan") { bad(res, 400, "Predračun ni v stanju »izdan«."); return true; }
        const dd = b.datum && /^\d{4}-\d{2}-\d{2}$/.test(b.datum) ? b.datum : danes();
        pr.status = "placan"; pr.placano_dne = dd;
        const n = preberi().stranke[pr.stranka_id]; if (n && (!n.placano_do || n.placano_do < pr.do)) n.placano_do = pr.do;
      }
      shrani(); audit(me, mpl[2] === "storno" ? "predracun-storniran" : "predracun-placan", "stranke", pr.stranka_id, pr.stevilka, ip); send(res, 200, pr); return true;
    }
    bad(res, 404, "ni najdeno"); return true;
  }
  return { paketi, paketOf, zaklenjeno, opomniki, rNarocnine };
};
