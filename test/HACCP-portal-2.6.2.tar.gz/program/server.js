// Strežnik: postreže aplikaciji in urejevalniku baze ter ponuja API nad datotekami v mapi baza/.
// Brez odvisnosti, potrebuje samo Node.js 18+.  Zagon: node server.js
const http = require("http");
const fs = require("fs");
const path = require("path");
const { hasRole } = require("./vloge");

// nastavitve iz datoteke .env (ob server.js, pri Windows programu ob .exe, ali v mapi zagona); že nastavljene spremenljivke okolja imajo prednost.
// Skrivnosti (npr. HACCP_KLJUC) sodijo samo v .env, ki ni v gitu – glej .env.example. Prazna vrednost pomeni privzeto.
// ime je v spremenljivki: gradnja .exe (pkg) sicer najde datoteko in jo s skrivnostmi vred vključi v program; v .exe se .env bere samo ob programu
const ENV_IME = [".", "env"].join("");
for (const f of [...new Set([process.pkg ? null : path.join(__dirname, ENV_IME), process.pkg ? path.join(path.dirname(process.execPath), ENV_IME) : null, path.join(process.cwd(), ENV_IME)].filter(Boolean))]) {
  try { if (!fs.existsSync(f)) continue; const v = require("util").parseEnv(fs.readFileSync(f, "utf8")); for (const [k, x] of Object.entries(v)) if (process.env[k] === undefined && x !== "") process.env[k] = x; } catch (e) { console.error("Datoteke " + f + " ni mogoče prebrati: " + e.message); }
}

const VERZIJA = require("./package.json").version;
// prstni odtis gradnje (koda strežnika in portala): pove, ali na vratih že teče drugačna različica
const GRADNJA = (() => { const fs = require("fs"), path = require("path"), h = require("crypto").createHash("sha256"); try { for (const f of ["server.js", "platform.js", "narocnine.js", "posodobitev.js", "shramba.js", "oblak.js", "register.js"]) h.update(fs.readFileSync(path.join(__dirname, f))); const pd = path.join(__dirname, "portal"); for (const f of fs.readdirSync(pd).sort()) h.update(f).update(fs.readFileSync(path.join(pd, f))); } catch {} return h.digest("hex").slice(0, 12); })();
const TESTNO = process.argv.includes("--testno") || process.env.HACCP_TEST === "1"; // testno okolje: ločeni testni podatki, demo račun, napis TESTNA RAZLIČICA
const OMREZJE = process.argv.includes("--omrezje"); // dostop z drugih računalnikov v istem omrežju (samo skupaj z --testno)
if (OMREZJE && !TESTNO) { console.error("Dostop iz omrežja je dovoljen samo v testnem načinu (--testno), ker povezava ni šifrirana."); process.exit(1); }
const PORT = parseInt(process.env.PORT || "3000", 10);
const HOST = OMREZJE ? "0.0.0.0" : (process.env.HOST || "127.0.0.1");
const ROOT = __dirname;
const PACKED = !!process.pkg; // zagnano kot samostojni .exe
// V .exe je baza ob izvedljivi datoteki (da jo lahko urejate); ob prvem zagonu se prekopira privzeta.
const DATA = process.env.HACCP_DATA; // neobvezno: ločena mapa s podatki (testi)
const DB = DATA ? path.join(DATA, "baza") : PACKED ? path.join(path.dirname(process.execPath), "baza") : path.join(ROOT, "baza");
// Privzeta baza (v paketu ali ob programu). Manjkajoče zbirke se dodajo ob zagonu, obstoječe (vaše) se nikoli ne prepišejo.
fs.mkdirSync(DB, { recursive: true });
const DEFAULTS = path.join(ROOT, "baza");
if (DEFAULTS !== DB) {
  for (const f of fs.readdirSync(DEFAULTS).filter(f => f.endsWith(".json"))) {
    if (!fs.existsSync(path.join(DB, f))) fs.writeFileSync(path.join(DB, f), fs.readFileSync(path.join(DEFAULTS, f)));
  }
}
const BACKUP = path.join(DB, "_backup");

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".webmanifest": "application/manifest+json", ".ico": "image/x-icon" };

// zbirke v bazi: ime datoteke brez .json
const collections = () => fs.readdirSync(DB).filter(f => f.endsWith(".json") && !f.startsWith("_")).map(f => f.slice(0, -5));
const valid = name => /^[a-z0-9_]+$/.test(name) && collections().includes(name);
const read = name => JSON.parse(fs.readFileSync(path.join(DB, name + ".json"), "utf8"));

function write(name, data) {
  const file = path.join(DB, name + ".json");
  fs.mkdirSync(BACKUP, { recursive: true });
  fs.copyFileSync(file, path.join(BACKUP, `${name}-${new Date().toISOString().replace(/[:.]/g, "-")}.json`));
  try { const old = fs.readdirSync(BACKUP).filter(f => f.startsWith(name + "-") && /^\d{4}-/.test(f.slice(name.length + 1))).sort(); for (const f of old.slice(0, Math.max(0, old.length - 30))) fs.unlinkSync(path.join(BACKUP, f)); } catch {}
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 1) + "\n");
  fs.renameSync(tmp, file);
}

// Posodobitev baze sestavin: doda nove sestavine in manjkajoče hranilne vrednosti, vaših sprememb ne prepiše.
function mergeSestavine() {
  const defFile = path.join(DEFAULTS, "sestavine.json"), usrFile = path.join(DB, "sestavine.json");
  if (DEFAULTS === DB || !fs.existsSync(defFile) || !fs.existsSync(usrFile)) return;
  let def, usr;
  try { def = JSON.parse(fs.readFileSync(defFile, "utf8")); usr = JSON.parse(fs.readFileSync(usrFile, "utf8")); } catch { return; }
  const REN = { "Tekoči jajčni rumenjak (pasteriziran)": "Jajčni rumenjak, tekoč pasteriziran (v tubi)", "Tekoči jajčni beljak (pasteriziran)": "Jajčni beljak, tekoč pasteriziran (v tubi)", "Jajčni prah": "Celo jajce v prahu", "Moka iz kokosa": "Kokosova moka" };
  let changed = false;
  const has = n => usr.some(x => x.naziv === n);
  for (const x of usr) if (REN[x.naziv] && !has(REN[x.naziv])) { x.naziv = REN[x.naziv]; changed = true; }
  for (const d of def) {
    const u = usr.find(x => x.naziv === d.naziv);
    if (!u) { usr.push(d); changed = true; }
    else if (!u.hranilne && d.hranilne) { u.hranilne = d.hranilne; if (!u.opomba && d.opomba) u.opomba = d.opomba; changed = true; }
  }
  if (changed) write("sestavine", usr);
}
mergeSestavine();

// Nove predloge dejavnosti, merila in besedila dokumentacije iz privzete baze se dodajo obstoječi namestitvi; vaših sprememb ne prepišejo in izbrisanih ne vrnejo
// (podatki/_privzeto-dodano: ključi, ki jih je program že ponudil).
function mergeNovo() {
  if (DEFAULTS === DB) return;
  const sled = path.join(DB, "_privzeto-dodano.json"), PRVIC = { branze: ["vino", "pivo", "zganje", "liker", "sokovi"], rezimi: ["alk_liker", "alk_zganje", "slad_liker", "brix_sok", "ph_kislo", "aw", "metanol_zganje", "metanol_osnova", "so2_vino", "so2_oznaka"], besedila: [] };
  let videno = null; try { videno = JSON.parse(fs.readFileSync(sled, "utf8")); } catch {}
  const prvic = !videno; videno = videno || {}; let sp = false;
  for (const coll of Object.keys(PRVIC)) {
    const key = KEYS[coll], defFile = path.join(DEFAULTS, coll + ".json"), usrFile = path.join(DB, coll + ".json");
    if (!fs.existsSync(defFile) || !fs.existsSync(usrFile)) continue;
    let def, usr; try { def = JSON.parse(fs.readFileSync(defFile, "utf8")); usr = read(coll); } catch { continue; }
    const v = new Set(videno[coll] || (prvic ? def.map(d => d[key]).filter(k => !PRVIC[coll].includes(k)) : []));
    let dod = 0; for (const d of def) { if (v.has(d[key])) continue; v.add(d[key]); sp = true; if (!usr.some(x => x[key] === d[key])) { usr.push(d); dod++; } }
    if (dod) write(coll, usr);
    videno[coll] = [...v];
  }
  if (sp || prvic) { const t = sled + ".tmp"; fs.writeFileSync(t, JSON.stringify(videno)); fs.renameSync(t, sled); }
}

// ---- paketi posodobitev (zakonodaja, sestavine, obrazci …): dodaj / zamenjaj / odstrani ----
const KEYS = { besedila: "id", navodila_predloge: "id", zakonodaja: "predpis", sestavine: "naziv", obrazci: "id", zastavice: "id", rezimi: "id", standardi: "id", branze: "id", alergeni: "naziv", prostori: "naziv", tipi: "koda", mikro: "parameter" };
mergeNovo();
const APPLIED = path.join(DB, "_posodobitve.json");
const appliedList = () => { try { return JSON.parse(fs.readFileSync(APPLIED, "utf8")); } catch { return []; } };
function applyUpdate(u) {
  const sum = {};
  for (const [coll, ops] of Object.entries(u)) {
    if (!KEYS[coll] || !ops || typeof ops !== "object" || Array.isArray(ops)) continue;
    if (!fs.existsSync(path.join(DB, coll + ".json"))) continue;
    const key = KEYS[coll], data = read(coll);
    if (!Array.isArray(data)) continue;
    let dod = 0, zam = 0, odst = 0;
    for (const k of ops.odstrani || []) { const i = data.findIndex(x => x[key] === k); if (i >= 0) { data.splice(i, 1); odst++; } }
    for (const e of ops.dodaj || []) if (e && e[key] !== undefined && !data.some(x => x[key] === e[key])) { data.push(e); dod++; }
    for (const e of ops.zamenjaj || []) { if (!e || e[key] === undefined) continue; const i = data.findIndex(x => x[key] === e[key]); if (i >= 0) { data[i] = e; zam++; } else { data.push(e); dod++; } }
    if (dod || zam || odst) write(coll, data);
    sum[coll] = { dodano: dod, zamenjano: zam, odstranjeno: odst };
  }
  return sum;
}
function applyUpdateObj(u, vir) {
  if (!u || typeof u !== "object" || !u.id) throw new Error("posodobitev nima polja id");
  const ap = appliedList();
  if (ap.some(x => x.id === u.id)) return { ze_uporabljena: true };
  const povzetek = applyUpdate(u);
  ap.push({ id: u.id, datum: u.datum || "", opis: u.opis || "", uporabljeno: new Date().toISOString(), povzetek, vir: vir || "" });
  fs.writeFileSync(APPLIED, JSON.stringify(ap, null, 1));
  return { ok: true, povzetek };
}
(function applyFolders() {
  const dirs = [...new Set([path.join(ROOT, "posodobitve"), path.join(path.dirname(DB), "posodobitve")])];
  for (const d of dirs) {
    if (!fs.existsSync(d)) continue;
    for (const f of fs.readdirSync(d).filter(f => f.endsWith(".json")).sort()) {
      try { const r = applyUpdateObj(JSON.parse(fs.readFileSync(path.join(d, f), "utf8")), f); if (r.ok) console.log("Uporabljena posodobitev: " + f); }
      catch (e) { console.error("Posodobitev " + f + " ni uporabljena: " + e.message); }
    }
  }
})();

const SEC = { "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin", "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'" };
function send(res, code, body, type = "application/json; charset=utf-8") {
  res.writeHead(code, Object.assign({ "Content-Type": type, "Cache-Control": "no-store" }, SEC));
  res.end(typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

function body(req, max, kot) { // kot: "buf" vrne Buffer (binarne datoteke), sicer besedilo UTF-8
  return new Promise((ok, fail) => {
    const parts = []; let n = 0;
    // pri prevelikem telesu ostanek zavržemo (ne prekinemo povezave), da odjemalec dobi odgovor 413
    let prevec = false;
    req.on("data", c => { if (prevec) return; n += c.length; if (n > (max || 20e6)) { prevec = true; parts.length = 0; fail(new Error("prevelik zahtevek")); return; } parts.push(c); });
    req.on("end", () => { if (prevec) return; const b = Buffer.concat(parts); ok(kot === "buf" ? b : b.toString("utf8")); });
    req.on("error", fail);
  });
}

// javna spletna stran: strani HTML z oznakami SEO, blog, sitemap.xml in robots.txt. Predogled (/stran/ na domeni platforme) je za iskalnike zaprt.
function serveStran(req, res, rel, predogled) {
  const host = String(req.headers.host || "localhost"), proto = req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  let base = proto + "://" + host + (predogled ? "/stran/" : "/");
  if (!predogled && process.env.HACCP_SPLETNA_URL) { try { const u = new URL(process.env.HACCP_SPLETNA_URL); if (u.host === host) base = u.origin + "/"; } catch {} } // https tudi za posrednikom
  if (predogled) res.setHeader("X-Robots-Tag", "noindex, nofollow");
  if (rel === "robots.txt") return send(res, 200, platform.robots(base, !predogled), "text/plain; charset=utf-8");
  if (rel === "sitemap.xml") return send(res, 200, platform.sitemap(base), "application/xml; charset=utf-8");
  if (rel.startsWith("blog/")) { let r = rel.slice(5); try { r = decodeURIComponent(r); } catch {} const h = platform.blogHtml(r, base, predogled); return send(res, h.status, h.html, "text/html; charset=utf-8"); }
  if (rel === "" || rel.endsWith(".html")) {
    const file = path.normalize(path.join(STRAN, rel || "index.html"));
    if (!file.startsWith(STRAN + path.sep)) return send(res, 403, { napaka: "Za to dejanje nimate pravic." });
    return fs.readFile(file, "utf8", (err, html) => err ? send(res, 404, { napaka: "Strani ni mogoče najti." }) : send(res, 200, platform.seoStran(rel, html, base, predogled), "text/html; charset=utf-8"));
  }
  return serveStatic(res, STRAN, rel);
}
function serveStatic(res, dir, rel) {
  const file = path.normalize(path.join(dir, rel === "" || rel.endsWith("/") ? rel + "index.html" : rel));
  if (!file.startsWith(dir + path.sep) && file !== dir) return send(res, 403, { napaka: "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja." });
  fs.readFile(file, (err, data) => err ? send(res, 404, { napaka: "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa." }) : send(res, 200, data, MIME[path.extname(file)] || "application/octet-stream"));
}

// Program brez konzole (Windows, .exe): sporočila gredo v zagon.log ob programu (omejeno na ~1 MB)
if (PACKED && !process.stdout.isTTY) {
  try {
    const LOG = path.join(DATA || path.dirname(process.execPath), "zagon.log"); try { if (fs.statSync(LOG).size > 1e6) fs.renameSync(LOG, LOG + ".old"); } catch {}
    const w = (...a) => { try { fs.appendFileSync(LOG, new Date().toISOString() + " " + a.map(x => typeof x === "string" ? x : (x && x.stack) || JSON.stringify(x)).join(" ") + "\n"); } catch {} };
    console.log = w; console.error = w; console.warn = w;
    process.on("uncaughtException", e => { w("NAPAKA:", e); process.exit(1); });
  } catch {}
}
const PODATKI_IME = TESTNO ? "podatki-test" : "podatki"; // testni podatki so vedno ločeni od pravih
const PODATKI = DATA ? path.join(DATA, PODATKI_IME) : PACKED ? path.join(path.dirname(process.execPath), PODATKI_IME) : path.join(ROOT, PODATKI_IME);
fs.mkdirSync(PODATKI, { recursive: true });

// ---- ponastavitev gesla (samo na tem računalniku): node server.js --ponastavi-geslo ----
if (process.argv.includes("--ponastavi-geslo")) {
  (async () => {
    const readline = require("readline"), crypto = require("crypto");
    const shr = require("./shramba.js")(PODATKI); let users = [];
    try { users = shr.preberi("uporabniki"); } catch {}
    if (!users.length) { console.log("Ni uporabnikov (aplikacija še ni nastavljena)."); process.exit(0); }
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); let mute = false;
    const origW = rl._writeToOutput; rl._writeToOutput = function (t) { if (mute) { if (t.includes("\n") || t.includes("\r")) origW.call(rl, t); } else origW.call(rl, t); };
    const lines = []; let waiter = null;
    rl.on("line", l => { if (waiter) { const w = waiter; waiter = null; w(l); } else lines.push(l); });
    rl.on("close", () => { if (waiter) process.exit(1); });
    const ask = (q, m) => new Promise(ok => { process.stdout.write(q); mute = !!m; const done = l => { mute = false; if (m && process.stdin.isTTY) console.log(""); ok(l.trim()); }; if (lines.length) done(lines.shift()); else waiter = done; });
    console.log("ZAUSTAVITE aplikacijo, preden nadaljujete. Uporabniki:");
    users.forEach(u => console.log(" - " + u.email + " (" + u.vloga + (u.aktiven === false ? ", onemogočen" : "") + ")"));
    const def = (users.find(u => hasRole(u, "admin")) || users[0]).email;
    const em = (await ask("E-naslov uporabnika [" + def + "]: ")) || def, u = users.find(x => x.email === em.toLowerCase());
    if (!u) { console.log("Uporabnika ni."); process.exit(1); }
    const p1 = await ask("Novo geslo (vsaj 10 znakov): ", true), p2 = await ask("Ponovite geslo: ", true);
    if (p1 !== p2 || p1.length < 10 || p1.length > 200) { console.log("Gesli se ne ujemata ali je geslo prekratko. Nič ni spremenjeno."); process.exit(1); }
    const salt = crypto.randomBytes(16).toString("hex");
    u.geslo = salt + ":" + crypto.scryptSync(p1, salt, 64).toString("hex"); u.aktiven = true; u.mora_zamenjati = false;
    if (u.totp_vklop) { for (const k of ["totp_vklop", "totp_skrivnost", "totp_zadnji", "totp_rezervne", "totp_cakanje"]) delete u[k]; console.log("Dvostopenjska prijava za " + u.email + " je izklopljena (ponovno jo vklopite v aplikaciji)."); }
    shr.zapisi("uporabniki", users); shr.zapri();
    // vpis v revizijsko sled (veriga zgoščenk)
    const AUD = path.join(PODATKI, "_revizijska-sled.jsonl"); let last = "0";
    try { const t = fs.readFileSync(AUD, "utf8").trim().split("\n"); if (t[0]) last = JSON.parse(t[t.length - 1]).h; } catch {}
    const e = { cas: new Date().toISOString(), uporabnik: null, ime: null, akcija: "ponastavitev-gesla-cli", zbirka: "uporabniki", id: u.id, opis: u.email, ip: "lokalno" };
    e.h = crypto.createHash("sha256").update(last + JSON.stringify(e)).digest("hex"); fs.appendFileSync(AUD, JSON.stringify(e) + "\n");
    console.log("Geslo za " + u.email + " je spremenjeno. Aplikacijo znova zaženite."); process.exit(0);
  })();
}

// ---- pred vrnitvijo na različico brez podatkovne baze (do 2.2.x): node server.js --vrni-json ----
// zapiše zbirke iz haccp.db nazaj v <zbirka>.json in bazo preimenuje; naslednja nova različica jih znova prenese v bazo
if (process.argv.includes("--vrni-json")) {
  if (!fs.existsSync(path.join(PODATKI, "haccp.db"))) { console.log("Podatki niso v podatkovni bazi; nič ni treba narediti."); process.exit(0); }
  const shr = require("./shramba.js")(PODATKI);
  if (shr.nacin !== "sqlite") { console.log("SQLite ni na voljo (HACCP_SHRAMBA=json?)."); process.exit(1); }
  const dat = shr.izvozi(); for (const f of dat) fs.writeFileSync(path.join(PODATKI, path.basename(f.name)), f.data); shr.zapri();
  const cas = new Date().toISOString().replace(/[-:]/g, "").replace("T", "-").slice(0, 15);
  for (const f of fs.readdirSync(PODATKI)) {
    if (/^haccp\.db(-wal|-shm)?$/.test(f)) fs.renameSync(path.join(PODATKI, f), path.join(PODATKI, f + ".vrnjeno-" + cas));
    else if (/\.json\.v-bazi$/.test(f)) fs.rmSync(path.join(PODATKI, f));
  }
  console.log("Zapisanih " + dat.length + " zbirk v datoteke JSON (" + PODATKI + "). Zdaj lahko zaženete prejšnjo različico."); process.exit(0);
}

let AKTIVNA_VRATA = PORT;
const POSODOBITEV = require("./posodobitev.js")({ DIR: PODATKI, VERZIJA, PACKED });
// po namestitvi nove različice: zapri vrata, zaženi novi program (počaka, da se vrata sprostijo) in končaj ta proces
function ponovniZagon(exe) {
  console.log("Posodobitev nameščena, ponovni zagon …");
  if (platform.zapri) platform.zapri();
  server.close();
  const args = process.argv.slice(2).filter(a => a !== "--tiho" && a !== "--po-posodobitvi").concat(["--tiho", "--po-posodobitvi"]);
  // zagnano z zaganjalnikom HiGiFood.vbs: ta po izhodni kodi 75 sam zažene novo različico (najzanesljivejše)
  if (process.argv.includes("--zaganjalnik")) { setTimeout(() => process.exit(75), 500); return; }
  setTimeout(() => {
    // na Windows prek "cmd /c start": novi program ni podproces tega in teče naprej, ko se ta konča
    const win = process.platform === "win32", cp = require("child_process");
    try { const c = win ? cp.spawn(process.env.ComSpec || "cmd.exe", ["/d", "/s", "/c", `start "" "${exe}" ${args.join(" ")}`], { stdio: "ignore", windowsHide: true, windowsVerbatimArguments: true, cwd: path.dirname(exe) }) : cp.spawn(exe, args, { detached: true, stdio: "ignore", cwd: path.dirname(exe) });
      c.on("error", e => console.error("Zagon nove različice ni uspel: " + e.message)); console.log("Nova različica se zaganja."); c.unref(); }
    catch (e) { console.error("Zagon nove različice ni uspel: " + e.message); }
    setTimeout(() => process.exit(0), 8000); // počakaj, da "start" zažene novi program (počasnejši računalniki)
  }, 500);
}
const platform = require("./platform.js")({ DIR: PODATKI, DB, send, body, testno: TESTNO, verzija: VERZIJA, omrezje: () => ({ host: HOST, port: AKTIVNA_VRATA }), posodobitev: POSODOBITEV, ponovniZagon });

const STRAN = path.join(ROOT, "spletna-stran"), STRAN_DOMENE = new Set(String(process.env.HACCP_SPLETNA_STRAN || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean));
const DOSTOPI = process.env.HACCP_DOSTOPNI_DNEVNIK === "1";
const server = http.createServer(async (req, res) => {
  if (DOSTOPI) { const t0 = Date.now(); res.on("finish", () => console.log(`${new Date().toISOString()} ${req.method} ${String(req.url).split("?")[0]} ${res.statusCode} ${Date.now() - t0}ms`)); }
  // HTTPS za posrednikom (Cloudflare Tunnel, Caddy): brskalnik naj ne uporablja več navadnega HTTP (HSTS, 1 leto)
  if (process.env.HACCP_PROXY === "1" && String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim() === "https") res.setHeader("Strict-Transport-Security", "max-age=31536000");
  try {
    const url = new URL(req.url, "http://x");
    let p; try { p = decodeURIComponent(url.pathname); } catch { res.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" }); return res.end("Neveljaven naslov."); }
    // proti zlorabi iz drugih strani: pisanje samo iz iste domene
    if (req.method !== "GET" && req.method !== "HEAD") {
      const og = req.headers.origin, sfs = req.headers["sec-fetch-site"];
      if (og !== undefined) { let h = null; try { h = new URL(og).host; } catch {} if (!h || h !== req.headers.host) return send(res, 403, { napaka: "Zahteva ni prišla iz te aplikacije, zato je zavrnjena. Osvežite stran in poskusite znova." }); }
      else if (sfs && sfs !== "same-origin" && sfs !== "none") return send(res, 403, { napaka: "Zahteva ni prišla iz te aplikacije, zato je zavrnjena. Osvežite stran in poskusite znova." });
      // brez Origin in Sec-Fetch-Site (star brskalnik ali posrednik, ki ju odstrani): vrste vsebine, ki jih lahko pošlje obrazec tuje strani, zavrnemo
      else if (og === undefined && !sfs && /^\s*(application\/x-www-form-urlencoded|multipart\/form-data|text\/plain)/i.test(req.headers["content-type"] || "")) return send(res, 403, { napaka: "zahteva brez izvora ni dovoljena (uporabite Content-Type: application/json)" });
    }

    if (p === "/api/health") return send(res, 200, { ok: true, app: "higifood", verzija: VERZIJA, gradnja: GRADNJA, testno: TESTNO });
    if (await platform.handle(req, res, p, url)) return;
    if (p === "/api/posodobitve" && req.method === "GET") return send(res, 200, appliedList());
    if (p === "/api/posodobitev" && req.method === "POST") {
      let u; try { u = JSON.parse(await body(req)); } catch { return send(res, 400, { napaka: "Podatki niso v pravilni obliki (neveljaven JSON)." }); }
      try { return send(res, 200, applyUpdateObj(u, "uvoz")); } catch (e) { return send(res, 400, { napaka: e.message }); }
    }
    if (p === "/api/baza" && req.method === "GET") return send(res, 200, Object.fromEntries(collections().map(n => [n, read(n)])));

    const m = p.match(/^\/api\/baza\/([a-z0-9_]+)$/);
    if (m) {
      if (!valid(m[1])) return send(res, 404, { napaka: "Ta vrsta podatkov ne obstaja." });
      if (req.method === "GET") return send(res, 200, read(m[1]));
      if (req.method === "PUT") {
        let data;
        try { data = JSON.parse(await body(req)); } catch { return send(res, 400, { napaka: "Podatki niso v pravilni obliki (neveljaven JSON)." }); }
        if (Array.isArray(read(m[1])) !== Array.isArray(data)) return send(res, 400, { napaka: "napačna oblika podatkov" });
        write(m[1], data);
        return send(res, 200, { ok: true });
      }
      return send(res, 405, { napaka: "Ta zahteva ni podprta." });
    }
    if (p.startsWith("/api/")) return send(res, 404, { napaka: "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa." });

    // javna spletna stran: na domenah iz HACCP_SPLETNA_STRAN (npr. higifood.si) je to celotna stran, sicer predogled na /stran/
    if (STRAN_DOMENE.has(String(req.headers.host || "").toLowerCase().replace(/:\d+$/, ""))) {
      // naprave, ki so imele platformo na tej domeni: stari service worker se odstrani (sicer bi namesto strani kazal platformo iz predpomnilnika)
      if (p === "/sw.js") return send(res, 200, 'self.addEventListener("install",()=>self.skipWaiting());self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.map(x=>caches.delete(x)))).then(()=>self.registration.unregister()).then(()=>self.clients.matchAll({type:"window"})).then(c=>c.forEach(w=>w.navigate(w.url)))));', "text/javascript; charset=utf-8");
      if (p === "/blog") { res.writeHead(301, { Location: "/blog/" }); return res.end(); }
      return serveStran(req, res, p.slice(1), false);
    }
    if (p === "/robots.txt") return send(res, 200, platform.robots("", false), "text/plain; charset=utf-8"); // platforma: iskalniki naj je ne indeksirajo
    if (p === "/stran") { res.writeHead(302, { Location: "/stran/" }); return res.end(); }
    if (p === "/stran/blog") { res.writeHead(301, { Location: "/stran/blog/" }); return res.end(); }
    if (p.startsWith("/stran/")) return serveStran(req, res, p.slice(7), true);
    if (p === "/generator") { res.writeHead(302, { Location: "/generator/" }); return res.end(); }
    if (p.startsWith("/generator/")) { // generator je viden samo, če ga administrator ni skril vlogi uporabnika
      const u = platform.userOf(req);
      if (!u) { res.writeHead(302, { Location: "/" }); return res.end(); }
      if (!platform.vidno(u, "generator")) { res.writeHead(302, { Location: "/?nedostop=1" }); return res.end(); }
    }
    if (p.startsWith("/generator/")) return serveStatic(res, path.join(ROOT, "app"), p.slice(11));
    if (p === "/baza") { res.writeHead(302, { Location: "/baza/" }); return res.end(); }
    if (p.startsWith("/baza/")) return serveStatic(res, path.join(ROOT, "baza-admin"), p.slice(6));
    return serveStatic(res, path.join(ROOT, "portal"), p.slice(1));
  } catch (e) {
    send(res, 500, { napaka: String(e.message || e) });
  }
});

function odpriBrskalnik(url) {
  const cmd = process.platform === "win32" ? `start "" "${url}"` : process.platform === "darwin" ? `open "${url}"` : `xdg-open "${url}"`;
  require("child_process").exec(cmd, { windowsHide: true }, () => {}); // brez bliska konzolnega okna
}
function obvestiStaroRazlicico(port) {
  const f = path.join(require("os").tmpdir(), "higifood-stara-razlicica.html");
  fs.writeFileSync(f, `<!doctype html><meta charset="utf-8"><title>HiGiFood – teče starejša različica</title><body style="font:16px/1.5 system-ui,sans-serif;max-width:640px;margin:40px auto;padding:0 16px"><h2>Teče starejša različica programa HiGiFood</h2><p>Nova različica se ni zagnala, ker na tem računalniku še teče prejšnja (skrito, brez okna).</p><ol><li>Odprite <a href="http://127.0.0.1:${port}/#/admin">staro različico → Administracija</a> in kliknite <b>Ustavi program</b> (ali v upravitelju opravil končajte <b>HACCP-sistem.exe</b>).</li><li>Znova zaženite <b>HiGiFood.vbs</b> v mapi nove različice.</li></ol><p>Če ste novo različico razširili v <b>drugo mapo</b>, vanjo prej prekopirajte mapo <b>podatki</b> iz stare mape, sicer novih podatkov ne boste videli. Če imate vklopljen samodejni zagon, ga v novi mapi znova vklopite (samodejni-zagon-vklopi.bat).</p></body>`);
  odpriBrskalnik("file:///" + f.replace(/\\/g, "/"));
}
function listen(port, tries) {
  server.once("error", e => {
    if (e.code === "EADDRINUSE" && process.argv.includes("--po-posodobitvi") && (listen.cakanje = (listen.cakanje || 0) + 1) <= 40) { setTimeout(() => listen(port, tries), 500); return; } // prejšnja različica se še zapira
    if (e.code === "EADDRINUSE") {
      // že teče ta aplikacija? potem samo odpri brskalnik (dveh primerkov nad istimi podatki ne zaganjamo)
      const rq = http.get({ host: HOST === "0.0.0.0" ? "127.0.0.1" : HOST, port, path: "/api/health", timeout: 1500 }, r => {
        let b = ""; r.on("data", c => b += c); r.on("end", () => {
          let ours = false, h = {}; try { h = JSON.parse(b); ours = h.app === "higifood"; } catch {}
          // teče druga (običajno starejša) različica: ne ustavimo je sami, uporabniku pokažemo, kako jo zamenja
          if (ours && h.gradnja !== GRADNJA) { console.log("Na vratih " + port + " teče druga različica programa; najprej jo ustavite."); if (!process.argv.includes("--tiho")) obvestiStaroRazlicico(port); setTimeout(() => process.exit(0), 1500); return; }
          if (ours) { console.log("Aplikacija že teče na vratih " + port + "."); if (!process.argv.includes("--tiho")) odpriBrskalnik(`http://127.0.0.1:${port}/`); setTimeout(() => process.exit(0), 500); }
          else if (tries > 0) listen(port + 1, tries - 1); else { console.error("Strežnika ni mogoče zagnati: vrata so zasedena."); process.exit(1); }
        });
      });
      rq.on("error", () => { if (tries > 0) listen(port + 1, tries - 1); else process.exit(1); }); rq.on("timeout", () => rq.destroy());
      return;
    }
    console.error("Strežnika ni mogoče zagnati: " + e.message);
    process.exit(1);
  });
  server.listen(port, HOST, () => {
    AKTIVNA_VRATA = port;
    const base = `http://${HOST}:${port}`;
    if (TESTNO) console.log("TESTNI NAČIN: podatki v mapi " + PODATKI_IME + " (niso pravi podatki).");
    if (OMREZJE) for (const l of Object.values(require("os").networkInterfaces())) for (const a of l || []) if (a.family === "IPv4" && !a.internal) console.log(`Za druge računalnike v omrežju: http://${a.address}:${port}/`);
    console.log(`Aplikacija:        ${base}/`);
    console.log(`Urejevalnik baze:  ${base}/baza/`);
    console.log(`Baza (JSON):       ${DB}`);
    console.log("Okno pustite odprto. Ustavite s Ctrl+C ali zaprtjem okna.");
    if ((PACKED || process.env.ODPRI) && !process.argv.includes("--tiho")) odpriBrskalnik(`http://127.0.0.1:${port}/`);
  });
}
server.keepAliveTimeout = 65e3; server.headersTimeout = 66e3; // manj prekinjenih ponovno uporabljenih povezav
process.on("unhandledRejection", e => console.error("Neobravnavana napaka:", e && e.stack || e));
for (const sig of ["SIGTERM", "SIGINT"]) process.on(sig, () => { // docker stop: počakaj, da se tekoče zahteve zaključijo
  // najprej ne sprejemamo novih zahtev in počakamo tekoče, šele nato zapremo bazo (sicer zahteva v teku dobi »database is not open«)
  console.log("Zaustavljam (" + sig + ") …"); const konec = () => { if (platform.zapri) platform.zapri(); process.exit(0); };
  server.close(konec); if (server.closeIdleConnections) server.closeIdleConnections(); setTimeout(konec, 8000).unref();
});
// Neobvezno: samodejno preverjanje posodobitev baze z vašega naslova (HACCP_POSODOBITVE_URL vrne JSON posodobitev ali seznam).
if (process.env.HACCP_POSODOBITVE_URL) {
  const preveri = async () => {
    try {
      const r = await fetch(process.env.HACCP_POSODOBITVE_URL, { signal: AbortSignal.timeout(20000), headers: { "User-Agent": "HiGiFood/" + VERZIJA } });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const j = await r.json();
      for (const u of Array.isArray(j) ? j : [j]) { const x = applyUpdateObj(u, "url"); if (x.ok) console.log("Uporabljena posodobitev z URL: " + u.id); }
    } catch (e) { console.error("Posodobitev z URL ni uspela: " + e.message); }
  };
  setTimeout(preveri, 30e3).unref(); setInterval(preveri, 24 * 3600e3).unref();
}
if (!process.argv.includes("--ponastavi-geslo")) listen(PORT, 10);
// samodejno preverjanje nove različice programa (enkrat na dan; rezultat vidi administrator v Vzdrževanju in na nadzorni plošči)
if (!process.argv.includes("--ponastavi-geslo") && !TESTNO) { const p = () => POSODOBITEV.preveri().catch(() => {}); setTimeout(p, 90e3).unref(); setInterval(p, 24 * 3600e3).unref(); }
