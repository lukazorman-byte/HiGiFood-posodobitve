// Specifikacije zbirk: polja obrazcev in stolpci tabel.
const PRAVNE_OBLIKE = ["s.p.", "d.o.o.", "d.d.", "k.d.", "d.n.o.", "so.p.", "zavod", "društvo", "kmetija (dopolnilna dejavnost)", "drugo"];
// s.p. z več vpisanimi odgovornimi osebami (ločene z vejico, podpičjem, poševnico, »in« ali novo vrstico) → seznam oseb, sicer null
const vecOdgovornihSp = o => {
  const sp = o.pravna_oblika ? o.pravna_oblika === "s.p." : /(^|[\s,])s\.\s?p\.?($|[\s,])/i.test(String(o.naziv || ""));
  if (!sp) return null;
  const os = String(o.odgovorna_oseba || "").split(/\s*(?:[,;/&+\n]|\bin\b)\s*/i).map(x => x.trim()).filter(x => x.length > 1);
  return os.length > 1 ? os : null;
};
const DEJAVNOSTI = ["Gostinstvo (restavracija, gostilna)", "Catering / priprava obrokov", "Pekarna / slaščičarna", "Mesnica / predelava mesa", "Mlekarna / sirarna", "Trgovina z živili", "Proizvodnja živil", "Vrtec / šola / zavod", "Turistična kmetija / dopolnilna dejavnost", "Pakiranje / skladišče", "Drugo"];
// dejavnost stranke → predlagane predloge v čarovniku HACCP (id iz baze »branze«)
const DEJ_PREDLOGE = { "Gostinstvo (restavracija, gostilna)": ["jedi"], "Catering / priprava obrokov": ["jedi"], "Pekarna / slaščičarna": ["pekarna", "choc"], "Mesnica / predelava mesa": ["meso"], "Mlekarna / sirarna": ["mleko"], "Trgovina z živili": ["splosno"], "Proizvodnja živil": ["splosno"], "Vrtec / šola / zavod": ["jedi"], "Turistična kmetija / dopolnilna dejavnost": ["jedi", "sadje", "sokovi", "liker", "zganje", "med"], "Pakiranje / skladišče": ["splosno"] };
// slovenska davčna številka: 8 števk, kontrolna števka po modulu 11 (uteži 8 … 2)
function davcnaOk(v) {
  const d = String(v || "").replace(/^SI/i, "").replace(/[\s.-]/g, ""); if (!/^[1-9]\d{7}$/.test(d)) return false;
  const k = 11 - ([...d.slice(0, 7)].reduce((a, c, i) => a + Number(c) * (8 - i), 0) % 11); return k !== 11 && (k === 10 ? 0 : k) === Number(d[7]);
}
// izbirni seznam paketov v obrazcu stranke: naloži pakete; prejšnje prosto besedilo ostane kot izbira, dokler ga ne zamenjate
async function paketiVObrazec(rec) {
  const sel = $("#f_paket"); if (!sel) return;
  try { await paketi(); } catch { return; }
  const cur = rec && rec.paket, pk = (PAK.podatki && PAK.podatki.paketi) || [], po = pk.find(p => p.id === cur || (cur && p.ime.toLowerCase() === String(cur).toLowerCase()));
  sel.innerHTML = '<option value="">brez paketa</option>' + pk.map(p => `<option value="${esc(p.id)}">${esc(p.ime)}</option>`).join("") + (cur && !po ? `<option value="${esc(cur)}">${esc(cur)} (prejšnji vnos – izberite paket)</option>` : "");
  sel.value = po ? po.id : cur || "";
}
const imePaketaStranke = id => { const p = ((typeof PAK !== "undefined" && PAK.podatki && PAK.podatki.paketi) || []).find(x => x.id === id); return p ? p.ime : id || ""; };
const STATUS_SISTEMA = ["v pripravi", "v potrjevanju", "aktivna", "neaktivna"];
const STATUS_DOK = ["osnutek", "v pregledu", "potrjeno", "zastarelo"];
const T = (k, l, o) => Object.assign({ k, l, t: "text" }, o);
const strankaName = (m, id) => (m || {})[id] || "";

// izbirni seznami za obrat (skupina, postavke); lastne postavke dodate z »+ Dodaj«
const PROSTORI_OBRAT = [["Priprava hrane", ["Kuhinja", "Hladna priprava", "Topla priprava", "Slaščičarna", "Priprava zelenjave", "Priprava mesa"]], ["Skladiščenje", ["Prevzemni prostor", "Suho skladišče", "Hladilnica", "Zamrzovalnica", "Skladišče pijač", "Skladišče embalaže"]], ["Postrežba in prodaja", ["Točilni pult", "Jedilnica / gostinski prostor", "Terasa", "Prodajni prostor", "Izdaja hrane"]], ["Higiena in drugo", ["Pomivalnica posode", "Prostor za čistila", "Prostor za odpadke", "Garderoba za zaposlene", "Sanitarije za zaposlene", "Sanitarije za goste", "Pisarna"]]];
const NAPRAVE_OBRAT = [["Hlajenje in zamrzovanje", ["Hladilnik", "Zamrzovalnik", "Hladilna vitrina", "Hladilna miza", "Šoker (hitro ohlajanje)", "Ledomat"]], ["Toplotna obdelava", ["Štedilnik", "Konvektomat", "Pečica", "Friteza", "Žar / plošča", "Mikrovalovna pečica", "Vodna kopel / bain-marie", "Grelna vitrina"]], ["Priprava", ["Mesoreznica", "Mešalnik / kuhinjski robot", "Vakuumski aparat", "Stroj za sladoled", "Aparat za kavo", "Rezalnik kruha"]], ["Pribor in merila", ["Barvne deske za rezanje", "Noži (ločeni po namenu)", "Posoda iz nerjavnega jekla", "Termometer / vbodna sonda", "Tehtnica", "Posode za živila s pokrovi"]], ["Higiena", ["Pomivalni stroj", "Korito za umivanje rok", "Dvodelno korito za posodo", "Podajalnik papirnatih brisač", "Koš na pedal"]]];
const SPEC = {
  stranke: {
    ime: "stranka", sort: (a, b) => String(a.naziv || "").localeCompare(String(b.naziv || ""), "sl"), add: () => isStaff(),
    fields: () => [
      T("naziv", "Naziv podjetja (uradni, za dokumente)", { req: 1, wide: 1 }), T("kratko_ime", "Kratko ime (prikaz v aplikaciji)", { h: "Neobvezno. Npr. »Eva Bečan« namesto dolgega uradnega naziva; v dokumentih ostane uradni naziv." }), T("davcna", "Davčna številka", { h: "8 števk, lahko s predpono SI." }), T("maticna", "Matična številka"), { k: "pravna_oblika", l: "Pravna oblika", t: "sel", o: PRAVNE_OBLIKE }, T("skd", "Šifra dejavnosti (SKD 2025)", { h: "Npr. I56.110. Izpolni se iz registra po davčni številki." }),
      T("odgovorna_oseba", "Odgovorna oseba", { h: "Pri s.p. je to nosilec dejavnosti (ena oseba)." }), T("nosilec", "Nosilec dejavnosti (s.p.)", { h: "Ime in priimek nosilca samostojnega podjetnika." }),
      T("naslov", "Naslov sedeža", { wide: 1 }), T("email", "E-naslov", { t: "email" }), T("telefon", "Telefon"),
      { k: "dejavnost", l: "Glavna dejavnost", t: "sel", o: DEJAVNOSTI }, { k: "dodatne_dejavnosti", l: "Dodatne dejavnosti (npr. dopolnilna dejavnost + pekarna)", t: "multi", o: DEJAVNOSTI, wide: 1 }, { k: "status", l: "Stanje HACCP sistema", t: "sel", o: STATUS_SISTEMA, def: "v pripravi" },
      T("opis_dejavnosti", "Opis dejavnosti", { t: "area", h: "Kaj se v podjetju dela, za koga, v kakšnem obsegu." }),
      { k: "paket", l: "Paket storitev (HiGiFood)", t: "sel", o: () => ((typeof PAK !== "undefined" && PAK.podatki && PAK.podatki.paketi) || []).map(p => [p.id, p.ime]), h: "Paketi iz razdelka Naročnine in predračuni." }, T("naslednji_pregled", "Naslednji načrtovani pregled", { t: "date" }),
      T("notranje", "Interne opombe HiGiFood", { t: "area", h: "Vidno samo osebju HiGiFood." }),
      { k: "opomniki_izklop", l: "Izklopi e-poštne opomnike za to stranko", t: "bool", wide: 1, h: "Za vse prejemnike (svetovalec, odgovorna oseba). Posameznik nastavi svoje opomnike v »Moj račun«." }
    ].filter(f => (isStaff() || !["paket", "notranje", "opomniki_izklop"].includes(f.k)) && (f.k !== "paket" || hasRole(ME.u, "admin"))),
    onOpen: (f, ctx, rec) => { if (isStaff()) { podjetjePoDavcni(); paketiVObrazec(rec); } },
    // stranka z isto davčno številko že obstaja: vprašaj (morda gre za dvojnik)
    opozori: async (o, rec) => {
      const m = [], d = String(o.davcna || "").replace(/\D/g, "");
      if (d) { const x = (await D.list("stranke").catch(() => [])).find(s => s.id !== (rec && rec.id) && String(s.davcna || "").replace(/\D/g, "") === d); if (x) m.push(`Stranka z davčno številko ${d} že obstaja: ${sIme(x)}.`); }
      const os = vecOdgovornihSp(o); if (os) m.push(`Pravna oblika je s.p., kot odgovorna oseba pa je vpisanih ${os.length} oseb (${os.join(", ")}). Pri samostojnem podjetniku je odgovorna oseba praviloma nosilec dejavnosti.`);
      return m.length ? m.join("\n\n") + "\n\nVseeno shranim?" : "";
    },
    // preverjanje oblike (enaka pravila preveri tudi strežnik); prazna polja so dovoljena
    check: o => {
      const n = [];
      if (o.davcna && !davcnaOk(o.davcna)) n.push(["davcna", "Davčna številka ni veljavna (8 števk s kontrolno števko, dovoljena predpona SI)."]);
      if (o.maticna && !/^(\d{7}|\d{10})$/.test(o.maticna.replace(/\s/g, ""))) n.push(["maticna", "Matična številka mora imeti 7 ali 10 števk."]);
      if (o.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(o.email)) n.push(["email", "E-naslov ni v pravilni obliki (npr. ime@podjetje.si)."]);
      if (o.telefon && (!/^[0-9 +\/()-]+$/.test(o.telefon) || (o.telefon.match(/\d/g) || []).length < 6)) n.push(["telefon", "Telefon lahko vsebuje samo števke, presledke, +, /, - in oklepaje (vsaj 6 števk)."]);
      return n;
    },
    cols: () => [{ l: "Naziv", f: r => `<a href="#/stranka/${r.id}/podatki"><b>${esc(sIme(r))}</b></a>${r.kratko_ime ? `<br><small class="mut">${esc(r.naziv)}</small>` : ""}` }, { l: "Dejavnost", k: "dejavnost" }, { l: "Odgovorna oseba", k: "odgovorna_oseba" }, { l: "Stanje", f: r => badge(r.status) }, { l: "Rednost vnosov (30 dni)", f: r => rednostBadge(REDNOST[r.id]) }, { l: "Naslednji pregled", f: r => dueBadge(r.naslednji_pregled) }]
  },
  obrati: {
    // prostori in naprave: seznam s kljukicami, pri vsaki izbrani postavki se lahko dopiše opis; prosto besedilo ostane za dodatne opombe
    ime: "obrat / lokacija", sort: (a, b) => String(a.naziv || "").localeCompare(String(b.naziv || ""), "sl"),
    fields: () => [
      T("naziv", "Naziv obrata", { req: 1 }), T("naslov", "Naslov"), T("vrsta", "Vrsta obrata (kuhinja, proizvodnja, trgovina …)"), T("povrsina", "Površina (m²)", { t: "num" }),
      { k: "prostori", l: "Prostori (obkljukajte in opišite)", t: "kljukice", o: PROSTORI_OBRAT, wide: 1 },
      T("opis_prostorov", "Opis prostorov – dodatno", { t: "area", h: "Razporeditev, čiste/nečiste poti, posebnosti." }),
      { k: "naprave", l: "Naprave in pribor (obkljukajte, po potrebi dopišite)", t: "kljukice", o: NAPRAVE_OBRAT, wide: 1 },
      T("oprema_opis", "Oprema in naprave – dodatno", { t: "area" }),
      T("shranjevanje", "Shranjevanje živil", { t: "area", h: "Hladilniki, zamrzovalniki, suho skladišče, režimi." }),
      T("priprava", "Priprava in obdelava", { t: "area" }), T("toplotna", "Toplotna obdelava, hlajenje, ohranjanje toplote", { t: "area" }), T("pakiranje", "Pakiranje, označevanje", { t: "area" }), T("prodaja", "Prodaja / izdaja / dostava", { t: "area" }),
      T("ciscenje", "Čiščenje in razkuževanje", { t: "area" }), T("ddd", "DDD (deratizacija, dezinsekcija, dezinfekcija)", { t: "area" }), T("odpadki", "Ravnanje z odpadki", { t: "area" }), T("voda", "Oskrba z vodo", { t: "area" }),
      { k: "status", l: "Stanje", t: "sel", o: ["aktiven", "neaktiven"], def: "aktiven" }
    ],
    cols: () => [{ l: "Obrat", k: "naziv" }, { l: "Naslov", k: "naslov" }, { l: "Vrsta", k: "vrsta" }, { l: "Površina", f: r => r.povrsina ? esc(r.povrsina) + " m²" : "" }, { l: "Stanje", f: r => badge(r.status) }]
  },
  osebje: {
    ime: "zaposleni", fields: () => [T("ime", "Ime in priimek", { req: 1 }), T("funkcija", "Delovno mesto / vloga"), T("email", "E-naslov", { t: "email" }), T("higienski_do", "Higienski minimum / izobraževanje veljavno do", { t: "date" }), T("zdravniski_do", "Zdravniški pregled veljaven do", { t: "date" }), T("datum_odhoda", "Datum odhoda (za rok hrambe osebnih podatkov)", { t: "date" }), T("opomba", "Opomba", { t: "area" })],
    cols: () => [{ l: "Ime", k: "ime" }, { l: "Vloga", k: "funkcija" }, { l: "Izobraževanje do", f: r => dueBadge(r.higienski_do) }, { l: "Zdravniški do", f: r => dueBadge(r.zdravniski_do) }]
  },
  usposabljanja: {
    ime: "usposabljanje", sort: (a, b) => String(b.datum || "").localeCompare(String(a.datum || "")),
    fields: ctx => [T("tema", "Tema", { req: 1, wide: 1 }), T("datum", "Datum", { t: "date", def: () => today() }), T("veljavno_do", "Veljavno do", { t: "date" }), T("izvajalec", "Izvajalec"), T("udelezenci", "Udeleženci", { t: "area" }), T("opomba", "Opomba / dokazilo", { t: "area" })],
    cols: () => [{ l: "Tema", k: "tema" }, { l: "Datum", f: r => fdate(r.datum) }, { l: "Veljavno do", f: r => dueBadge(r.veljavno_do) }, { l: "Izvajalec", k: "izvajalec" }]
  },
  dobavitelji: {
    ime: "dobavitelj", fields: () => [T("naziv", "Naziv", { req: 1 }), T("kategorija", "Kategorija (meso, zelenjava, embalaža …)"), T("kontakt", "Kontakt"), T("registracija", "Registracija / odobritev (št.)"), { k: "ocena", l: "Ocena dobavitelja", t: "sel", o: ["odobren", "pogojno odobren", "ni ocenjen", "zavrnjen"] }, T("naslednja_ocena", "Naslednja ocena", { t: "date" }), T("prevzem", "Kontrola ob prevzemu (kaj preverjamo)", { t: "area" })],
    cols: () => [{ l: "Dobavitelj", k: "naziv" }, { l: "Kategorija", k: "kategorija" }, { l: "Ocena", f: r => badge(r.ocena) }, { l: "Naslednja ocena", f: r => dueBadge(r.naslednja_ocena) }]
  },
  oprema: {
    ime: "oprema / merilni instrument", fields: ctx => [T("naziv", "Naziv", { req: 1 }), { k: "tip", l: "Vrsta", t: "sel", o: ["hladilnik", "zamrzovalnik", "hladilna vitrina", "termometer / sonda", "tehtnica", "pečica / štedilnik", "pomivalni stroj", "drugo"] }, obratField(ctx), T("lokacija", "Lokacija v obratu"), T("naslednji_servis", "Naslednji servis / umerjanje", { t: "date" }), T("interval_dni", "Interval (dni)", { t: "num" }), T("opomba", "Opomba", { t: "area" })],
    cols: ctx => [{ l: "Naziv", k: "naziv" }, { l: "Vrsta", k: "tip" }, { l: "Obrat", f: r => esc(((ctx && ctx.obrati) || {})[r.obrat_id] || "") }, { l: "Servis / umerjanje", f: r => dueBadge(r.naslednji_servis) }]
  },
  navodila: {
    ime: "navodilo", sort: (a, b) => String(a.naslov || "").localeCompare(String(b.naslov || ""), "sl"), rev: true,
    fields: ctx => [T("naslov", "Naslov", { req: 1, wide: 1 }), { k: "vrsta", l: "Vrsta", t: "sel", o: ["Delovno navodilo", "Predpogojni program", "Obrazec", "Postopek", "Drugo"] }, obratField(ctx), { k: "teme", l: "Teme protokola", t: "teme", req: 1, wide: 1, o: () => typeof TEME_KLJUCI !== "undefined" ? TEME_KLJUCI : [], vrednost: r => typeof temeNavodila === "function" ? temeNavodila(r).filter(t => !/^lastno:/.test(t)) : r.teme, h: "Izberite vse teme, ki jih navodilo pokriva (npr. toplotna obdelava in hlajenje). Navodilo z isto temo nadomesti splošno predlogo v HACCP načrtu. Pri starejših navodilih so teme predlagane iz naslova – preverite in shranite." }, T("verzija_oznaka", "Različica dokumenta", { def: "1.0", h: "Oznaka, ki jo določite sami (npr. 1.0, 2.0). Interna revizija se šteje samodejno ob vsaki shranjeni spremembi." }), { k: "status", l: "Stanje", t: "sel", o: STATUS_DOK, def: "osnutek" }, T("naslednji_pregled", "Naslednji pregled", { t: "date" }), T("vsebina", "Vsebina", { t: "area", wide: 1 })],
    cols: ctx => [{ l: "Naslov", k: "naslov" }, { l: "Vrsta", k: "vrsta" }, { l: "Različica", f: r => `${esc(r.verzija_oznaka || "–")} <small class="mut" title="Interna revizija: šteje vsako shranjeno spremembo">rev. ${r.verzija || 1}</small>` }, { l: "Stanje", f: r => badge(r.status) }, { l: "Pregled", f: r => dueBadge(r.naslednji_pregled) }]
  },
  nacrti: {
    ime: "HACCP načrt", rev: true,
    // potrditev načrta (stanje »potrjeno«): nova različica dokumenta (1.0, nato 1.1 …) z datumom, opisom spremembe in potrjevalcem
    pre: (o, ctx, rec) => {
      if (o.status !== "potrjeno" || (rec && rec.status === "potrjeno")) return;
      const prej = rec && typeof razliciceDokumenta === "function" ? razliciceDokumenta(Object.assign({}, rec, { status: rec.razlicice && rec.razlicice.length ? rec.status : "" })) : [];
      const oz = prej.length ? naslednjaRazlicica(prej[prej.length - 1].oznaka) : (o.verzija_oznaka || "1.0"), rz = document.getElementById("f__razlog");
      o.razlicice = prej.concat([{ oznaka: oz, datum: o.datum_potrditve || today(), opis: (rz && rz.value.trim()) || (prej.length ? "Potrditev spremenjenega načrta" : "Prva izdaja"), potrdil: o.potrdil || "" }]); o.verzija_oznaka = oz;
    }, intro: "Podrobno vsebino načrta urejate v čarovniku (gumb »Čarovnik«).",
    fields: ctx => [T("naziv", "Naziv načrta", { req: 1, wide: 1 }), obratField(ctx), T("verzija_oznaka", "Različica dokumenta", { def: "1.0", h: "Oznaka, ki jo določite sami (npr. 1.0, 2.0). Interna revizija se šteje samodejno ob vsaki shranjeni spremembi." }), { k: "status", l: "Stanje", t: "sel", o: ["osnutek", "v pregledu", "potrjeno", "zastarelo"], def: "osnutek" }, T("potrdil", "Strokovno potrdil (ime)"), T("datum_potrditve", "Datum potrditve", { t: "date" }), T("naslednji_pregled", "Naslednji pregled", { t: "date" })],
    cols: ctx => [{ l: "Načrt", k: "naziv" }, { l: "Obrat", f: r => esc(((ctx && ctx.obrati) || {})[r.obrat_id] || "") }, { l: "Različica", f: r => `${esc(r.verzija_oznaka || "–")} <small class="mut" title="Interna revizija: šteje vsako shranjeno spremembo">rev. ${r.verzija || 1}</small>` }, { l: "Stanje", f: r => badge(r.status) }, { l: "Pregled", f: r => dueBadge(r.naslednji_pregled) }, { l: "", f: r => `<a class="btn sm" href="#/carovnik/${r.id}">Čarovnik</a>` }]
  },
  dogodki: {
    ime: "dogodek v koledarju", sort: (a, b) => String(a.datum || "").localeCompare(String(b.datum || "")),
    fields: ctx => [T("naslov", "Naslov", { req: 1, wide: 1 }), T("datum", "Datum", { t: "date", req: 1, def: () => today() }), T("ura", "Ura", { t: "time" }), { k: "vrsta", l: "Vrsta", t: "sel", o: ["Notranja kontrola", "Obisk HiGiFood", "Pregled dokumentacije", "Usposabljanje", "Servis / umerjanje opreme", "CAPA rok", "Drugo"] }, obratField(ctx), { k: "opomnik_dni", l: "Opomnik (dni prej)", t: "num", def: 3 }, { k: "status", l: "Stanje", t: "sel", o: ["načrtovano", "opravljeno"], def: "načrtovano" }, T("opomba", "Opomba", { t: "area" })],
    cols: () => [{ l: "Datum", f: r => fdate(r.datum) + (r.ura ? " " + esc(r.ura) : "") }, { l: "Naslov", k: "naslov" }, { l: "Vrsta", k: "vrsta" }, { l: "Stanje", f: r => badge(r.status) }]
  },
  storitve: {
    ime: "opravljena storitev", sort: (a, b) => String(b.datum || "").localeCompare(String(a.datum || "")),
    fields: () => [T("datum", "Datum obiska / storitve", { t: "date", req: 1, def: () => today() }), { k: "vrsta", l: "Vrsta", t: "sel", o: ["Obisk na lokaciji", "Svetovanje (na daljavo)", "Izdelava dokumentacije", "Usposabljanje", "Notranja presoja", "Pomoč pri inšpekciji", "Drugo"] }, T("minute", "Trajanje (minute)", { t: "num" }), T("paket", "Paket"), T("opis", "Kaj je bilo opravljeno", { t: "area" }), { k: "stanje_dokumentacije", l: "Stanje dokumentacije po storitvi", t: "sel", o: ["ni začeta", "v pripravi", "pripravljena za potrditev", "potrjena", "potrebna posodobitev"] }, T("manjkajoci_podatki", "Manjkajoči podatki (kaj čakamo od stranke)", { t: "area" }), T("naslednji_pregled", "Priporočen naslednji pregled", { t: "date" }), T("cena", "Cena (EUR), neobvezno", { t: "num" })],
    cols: () => [{ l: "Datum", f: r => fdate(r.datum) }, { l: "Vrsta", k: "vrsta" }, { l: "Minut", k: "minute" }, { l: "Dokumentacija", f: r => esc(r.stanje_dokumentacije || "") }, { l: "Naslednji pregled", f: r => dueBadge(r.naslednji_pregled) }]
  }
};
SPEC.ciscenje_nacrt = {
  ime: "opravilo čiščenja", sort: (a, b) => String(a.podrocje || "").localeCompare(String(b.podrocje || ""), "sl") || String(a.opravilo || "").localeCompare(String(b.opravilo || ""), "sl"),
  intro: "Pogostost in način določi odgovorna oseba po HACCP načrtu. Program pripravi dnevni seznam opravil in opozori na zamude.",
  fields: ctx => [T("podrocje", "Področje / površina / naprava", { wide: 1 }), T("opravilo", "Opravilo", { req: 1, wide: 1, ph: "npr. pranje in razkuževanje delovnih površin" }), obratField(ctx), T("sredstvo", "Čistilo / razkužilo"), T("koncentracija", "Koncentracija (npr. 2 %)"), T("kontaktni_cas", "Kontaktni čas (npr. 5 min)"), T("metoda", "Način izvedbe (kratko)", { t: "area" }), T("pogostost_dni", "Pogostost (na koliko dni)", { t: "num", h: "1 = dnevno, 7 = tedensko, 30 = mesečno. Prazno = po potrebi (brez opomnika)." }), { k: "krat_na_dan", l: "Kolikokrat na dan", t: "sel", o: [["1", "enkrat"], ["2", "dvakrat dnevno"], ["3", "trikrat dnevno"]], h: "Pri pogostosti 1 (dnevno)." }, T("odgovoren", "Odgovoren"), T("zacetek", "Začetek izvajanja", { t: "date", def: () => today() }), T("kontrola", "Kako preverimo (vizualno, ATP, bris …)", { t: "area" }), { k: "aktivno", l: "Aktivno", t: "bool", def: true }],
  cols: ctx => [{ l: "Področje", k: "podrocje" }, { l: "Opravilo", k: "opravilo" }, { l: "Sredstvo", k: "sredstvo" }, { l: "Pogostost", f: r => +r.pogostost_dni === 1 && +r.krat_na_dan > 1 ? esc(r.krat_na_dan) + "× dnevno" : r.pogostost_dni ? "vsakih " + esc(r.pogostost_dni) + " d" : "po potrebi" }, { l: "Odgovoren", k: "odgovoren" }, { l: "Stanje", f: r => r.aktivno === false ? badge("neaktivna") : badge("aktivna") }]
};
SPEC.vabe = {
  ime: "vaba / past (DDD)", sort: (a, b) => String(a.oznaka || "").localeCompare(String(b.oznaka || ""), "sl", { numeric: true }),
  fields: ctx => [T("oznaka", "Oznaka (št. na tlorisu)", { req: 1 }), { k: "vrsta", l: "Vrsta", t: "sel", o: ["vaba za glodavce", "lepilna past", "svetlobna past (UV)", "feromonska past", "drugo"] }, obratField(ctx), T("lokacija", "Lokacija", { wide: 1 }), { k: "status", l: "Stanje", t: "sel", o: ["aktivna", "odstranjena"], def: "aktivna" }, T("opomba", "Opomba", { t: "area" })],
  cols: ctx => [{ l: "Oznaka", k: "oznaka" }, { l: "Vrsta", k: "vrsta" }, { l: "Lokacija", k: "lokacija" }, { l: "Obrat", f: r => esc(((ctx && ctx.obrati) || {})[r.obrat_id] || "") }, { l: "Stanje", f: r => badge(r.status) }]
};
SPEC.kemikalije = {
  ime: "čistilo / razkužilo", sort: (a, b) => String(a.naziv || "").localeCompare(String(b.naziv || ""), "sl"),
  fields: () => [T("naziv", "Naziv", { req: 1, wide: 1 }), T("namen", "Namen (čiščenje, razkuževanje, strojno pranje …)"), T("proizvajalec", "Proizvajalec / dobavitelj"), T("koncentracija", "Delovna koncentracija in čas delovanja", { h: "Po navodilu proizvajalca." }), T("rok_uporabe", "Rok uporabe", { t: "date" }), T("shranjevanje", "Mesto shranjevanja"), T("varnostni_list", "Varnostni list (datoteka ali povezava)", { wide: 1 }), T("opomba", "Opomba", { t: "area" })],
  cols: () => [{ l: "Naziv", k: "naziv" }, { l: "Namen", k: "namen" }, { l: "Koncentracija", k: "koncentracija" }, { l: "Rok uporabe", f: r => dueBadge(r.rok_uporabe) }, { l: "Varnostni list", f: r => r.varnostni_list ? esc(r.varnostni_list) : '<span class="badge warn">manjka</span>' }]
};
function obratField(ctx) { return { k: "obrat_id", l: "Obrat", t: "sel", o: Object.entries((ctx && ctx.obrati) || {}) }; }
