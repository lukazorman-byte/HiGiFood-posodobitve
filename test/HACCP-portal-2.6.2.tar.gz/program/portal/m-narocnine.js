// Plačljivi paketi: pregled naročnin in predračunov (administrator), paket na profilu stranke, zaklenjene funkcije (»na voljo v paketu …«).
const PAK = { podatki: null };
async function paketi() { if (!PAK.podatki) PAK.podatki = await api("GET", "/api/paketi"); return PAK.podatki; }
const eur = n => (Math.round((Number(n) || 0) * 100) / 100).toLocaleString("sl-SI", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " €";
const eurPdf = n => eur(n).replace(" €", " EUR");
const STANJE_NAR = { aktivna: "ok", poteka: "warn", zapadla: "bad", neplacano: "warn" };
const stanjeBadge = st => st ? `<span class="badge ${STANJE_NAR[st.koda] || ""}">${esc(st.besedilo)}</span>` : '<span class="badge">brez omejitev</span>';
const STANJE_PR = { izdan: ["izdan", "warn"], placan: ["plačan", "ok"], storniran: ["storniran", ""] };
const prBadge = s => `<span class="badge ${(STANJE_PR[s] || [])[1] || ""}">${esc((STANJE_PR[s] || [s])[0])}</span>`;
function imeModula(id) {
  const n = NAVITEMS.find(x => x.id === id); if (n) return n.label;
  const t = typeof TABS !== "undefined" && TABS.find(x => "tab:" + x[0] === id); return t ? t[1] : id;
}
const imePaketa = (pk, id) => id ? ((pk.paketi.find(p => p.id === id) || {}).ime || id) : "ni določen (vse funkcije)";

// --- zaklenjena funkcija ---
async function zaklenjenoHtml(modul) {
  const pk = await paketi(), potreben = VIS.zak[modul], moj = VIS.paket;
  let kontakt = '<p class="mut">Za nadgradnjo se obrnite na odgovorno osebo v vašem podjetju.</p>';
  if (hasRole(ME.u, "odgovorna") && ME.u.stranka_id) {
    const n = await api("GET", "/api/narocnina?stranka_id=" + ME.u.stranka_id).catch(() => null), iz = n && n.izdajatelj;
    kontakt = `<p>Za nadgradnjo se obrnite na svojega svetovalca${iz && (iz.email || iz.telefon) ? ": " + [iz.naziv, iz.email, iz.telefon].filter(Boolean).map(esc).join(", ") : ""}.</p>`;
  }
  const p = pk.paketi.find(x => x.id === potreben) || {};
  return `<div class="card"><h2>🔒 ${esc(imeModula(modul))} ni vključeno v vaš paket</h2>
    <p>Vaš paket: <b>${esc(imePaketa(pk, moj))}</b>. Ta funkcija je na voljo v paketu <b>${esc(p.ime || potreben)}</b> in višjih.</p>
    <p class="mut">${esc(p.ime || "")}: ${esc(p.opis || "")}</p>${kontakt}</div>`;
}
async function pageZaklenjeno(v, m) { v.innerHTML = await zaklenjenoHtml(m[1]); }
route(/^\/paket\/([\w:-]+)$/, pageZaklenjeno, "Funkcija ni v paketu", null);

// --- paket na profilu stranke (zavihek Podatki) ---
async function paketStrankeCard(el, s) {
  if (!hasRole(ME.u, "admin", "svetovalec", "odgovorna")) return;
  const [pk, n] = await Promise.all([paketi(), api("GET", "/api/narocnina?stranka_id=" + s.id).catch(() => null)]); if (!n || !el.isConnected) return;
  const nar = n.narocnina, p = pk.paketi.find(x => x.id === n.paket);
  const vkl = p ? p.moduli.map(imeModula) : [];
  el.insertAdjacentHTML("beforeend", `<div class="card" id="paket-card"><h2>Paket in naročnina</h2>
    <table class="t"><tr><th style="width:38%">Paket</th><td><b>${esc(imePaketa(pk, n.paket))}</b>${p ? `<div class="mut">${esc(p.opis)}</div>` : ""}</td></tr>
    ${nar ? `<tr><th>Obračun</th><td>${nar.obdobje === "letno" ? "letno" : "mesečno"}, ${eur(nar.cena_mesec)} na mesec + DDV</td></tr><tr><th>Plačano do</th><td>${nar.placano_do ? fdate(nar.placano_do) : "–"} ${stanjeBadge(nar.stanje)}</td></tr>` : ""}
    ${p ? `<tr><th>Vključeno</th><td>${vkl.map(esc).join(", ")}</td></tr>` : ""}</table>
    ${n.predracuni.length ? `<h3 style="margin-top:14px">Predračuni</h3><div class="tw"><table class="t"><tr><th>Številka</th><th>Obdobje</th><th>Znesek z DDV</th><th>Rok</th><th>Stanje</th><th></th></tr>${n.predracuni.map(r => `<tr><td>${esc(r.stevilka)}</td><td>${fdate(r.od)} – ${fdate(r.do)}</td><td>${eur(r.skupaj)}</td><td>${fdate(r.rok)}</td><td>${prBadge(r.status)}</td><td><button class="btn sm ghost sec" data-prpdf="${r.id}">PDF</button></td></tr>`).join("")}</table></div>` : ""}
    ${hasRole(ME.u, "admin") ? '<p><a href="#/narocnine">Uredi naročnino in predračune</a></p>' : ""}</div>`);
  $$("[data-prpdf]", el).forEach(b => b.onclick = () => predracunPdf(n.predracuni.find(r => r.id === b.dataset.prpdf), n.izdajatelj));
}

// --- predračun (PDF) ---
function predracunPdf(r, iz) {
  iz = iz || {}; const st = r.stranka || {};
  const blob = pdfBuild({ naslov: "Predračun " + r.stevilka, stranka: st.naziv, plain: true, verzija: "1.0", datum: r.datum }, d => {
    if (r.status === "storniran") { // vodni žig čez stran (pod vsebino), da se storniran predračun ne plača po pomoti
      d.cur.s.push(`q 1 0.82 0.82 rg BT /F2 88 Tf 0.766 0.643 -0.643 0.766 ${(d.W / 2 - 205).toFixed(1)} ${(d.H / 2 - 170).toFixed(1)} Tm <${hexOf("STORNIRAN")}> Tj ET Q`); }
    d.text(d.M, d.y, "PREDRAČUN " + r.stevilka + (r.status === "storniran" ? " – STORNIRAN" + (r.storno ? " " + fdate(r.storno) : "") : ""), 16, true, r.status === "storniran" ? "r" : "g"); d.y -= 26;
    d.table(["Izdajatelj", "Kupec"], [[[iz.naziv, iz.naslov, iz.davcna ? "ID za DDV: " + iz.davcna : "", iz.email, iz.telefon].filter(Boolean).join("\n") || "[podatki izdajatelja]", [st.naziv, st.naslov, st.davcna ? "Davčna številka: " + st.davcna : ""].filter(Boolean).join("\n")]], [50, 50]);
    d.gap(6);
    d.table(["Datum izdaje", "Rok plačila", "Obdobje naročnine"], [[fdate(r.datum), fdate(r.rok), fdate(r.od) + " – " + fdate(r.do)]], [30, 30, 40]);
    d.gap(6);
    d.table(["Postavka", "Količina", "Cena", "Znesek"], r.postavke.map(x => [x.opis + "\n" + fdate(x.obdobje.split(" – ")[0]) + " – " + fdate(x.obdobje.split(" – ")[1]), String(x.kolicina) + " mes.", eurPdf(x.cena), eurPdf(x.znesek)]), [52, 14, 17, 17]);
    d.gap(6);
    d.table(["", "Znesek"], [["Skupaj brez DDV", eurPdf(r.neto)], ["DDV " + r.ddv_stopnja + " %", eurPdf(r.ddv)], ["SKUPAJ ZA PLAČILO", eurPdf(r.skupaj)]], [66, 34]);
    d.gap(10);
    d.p("Plačilo: " + (iz.trr ? "TRR " + iz.trr + (iz.banka ? " (" + iz.banka + ")" : "") : "[TRR izdajatelja]") + ", sklic SI00 " + r.stevilka.replace(/^PR-/, "") + ", namen: naročnina HiGiFood HACCP " + r.stevilka + ".", { bold: true });
    d.p("Predračun ni račun. Račun izdamo po prejemu plačila.", { col: "m" });
  });
  dlBlob(blob, "predracun-" + r.stevilka + ".pdf");
}

// --- administrator: naročnine, predračuni, cenik ---
async function pageNarocnine(v) {
  const [d, st] = await Promise.all([api("GET", "/api/narocnine"), D.list("stranke")]);
  const sm = Object.fromEntries(st.map(s => [s.id, s])), pk = d;
  const vrste = st.map(s => ({ s, n: d.stranke[s.id] || null })).sort((a, b) => (a.n ? 0 : 1) - (b.n ? 0 : 1) || String(a.s.naziv).localeCompare(b.s.naziv, "sl"));
  const kod = k => vrste.filter(x => x.n && x.n.stanje.koda === k).length;
  const mrr = vrste.filter(x => x.n && x.n.stanje.koda !== "zapadla").reduce((a, x) => a + (Number(x.n.cena_mesec) || 0), 0);
  const kpi = (n, l, cls) => `<div class="kpi ${cls || ""}"><b>${n}</b><span>${l}</span></div>`;
  const pr = d.predracuni.slice().sort((a, b) => b.datum.localeCompare(a.datum) || b.stevilka.localeCompare(a.stevilka));
  const c = d.cenik, iz = d.izdajatelj;
  v.innerHTML = `<p class="note info">Paket določa, katere funkcije vidijo uporabniki stranke (odgovorna oseba, zaposleni). Stranka brez paketa ima vse funkcije. Plačila urejate sami: izdate predračun, ga pošljete stranki in ga po plačilu označite kot plačanega (podaljša »plačano do«). Računov program ne izdaja.</p>
  <div class="kpis">${kpi(kod("aktivna"), mn(kod("aktivna"), ["aktivna naročnina", "aktivni naročnini", "aktivne naročnine", "aktivnih naročnin"]))}${kpi(kod("poteka"), mn(kod("poteka"), ["poteče", "potečeta", "potečejo", "poteče"]) + " v " + mnx(c.opozorilo_dni, ["dnevu", "dneh", "dneh", "dneh"]))}${kpi(kod("zapadla") + kod("neplacano"), mn(kod("zapadla") + kod("neplacano"), ["zapadla ali neplačana", "zapadli ali neplačani", "zapadle ali neplačane", "zapadlih ali neplačanih"]))}${kpi(eur(mrr), "mesečno (brez DDV)")}</div>
  <div class="card"><h2>Naročnine strank</h2><div class="tw"><table class="t"><tr><th>Stranka</th><th>Paket</th><th>Obračun</th><th>Na mesec</th><th>Plačano do</th><th>Stanje</th><th></th></tr>
  ${vrste.map(({ s, n }) => `<tr><td>${esc(sIme(s))}</td><td>${esc(imePaketa(pk, n && n.paket))}</td><td>${n ? (n.obdobje === "letno" ? "letno" : "mesečno") : ""}</td><td>${n ? eur(n.cena_mesec) : ""}</td><td>${n && n.placano_do ? fdate(n.placano_do) : ""}</td><td>${n ? stanjeBadge(n.stanje) : '<span class="badge">brez omejitev</span>'}</td>
    <td style="white-space:nowrap"><button class="btn sm" data-ur="${s.id}">Uredi</button> ${n ? `<button class="btn sm ghost sec" data-pr="${s.id}">Izdaj predračun</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Ni strank.</td></tr>'}</table></div></div>
  <div class="card"><h2>Predračuni</h2><div class="tw"><table class="t"><tr><th>Številka</th><th>Stranka</th><th>Obdobje</th><th>Z DDV</th><th>Rok</th><th>Stanje</th><th></th></tr>
  ${pr.map(r => `<tr><td>${esc(r.stevilka)}</td><td>${esc((sm[r.stranka_id] || r.stranka || {}).naziv || "")}</td><td>${fdate(r.od)} – ${fdate(r.do)}</td><td>${eur(r.skupaj)}</td><td>${fdate(r.rok)}${r.status === "izdan" && r.rok < today() ? ' <span class="badge bad">zamuda</span>' : ""}</td><td>${prBadge(r.status)}${r.placano_dne ? " " + fdate(r.placano_dne) : ""}</td>
    <td style="white-space:nowrap"><button class="btn sm ghost sec" data-pdf="${r.id}">PDF</button> ${r.status === "izdan" ? `<button class="btn sm" data-pl="${r.id}">Plačano</button> <button class="btn sm ghost sec" data-st="${r.id}">Storniraj</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Ni predračunov.</td></tr>'}</table></div></div>
  <div class="card"><div class="row" style="margin:0 0 8px"><h2 style="margin:0">Paketi</h2><span class="sp"></span><button class="btn" id="pk_nov">Nov paket</button></div><p class="mut">Paket določa funkcije, ki jih vidijo uporabniki stranke, in mesečno ceno za prvi obrat (brez DDV). Cene lahko kadar koli spremenite; obstoječim strankam ostane dogovorjena cena, razen če izberete, da se posodobi.</p><div class="tw"><table class="t"><tr><th>Paket</th><th>Vsebina</th><th>Cena na mesec</th><th>Strank</th><th></th></tr>${pk.paketi.map((p, i) => { const prej = pk.paketi[i - 1], nove = prej ? p.moduli.filter(m => !prej.moduli.includes(m)) : p.moduli, manj = prej ? prej.moduli.filter(m => !p.moduli.includes(m)) : []; return `<tr><td><b>${esc(p.ime)}</b></td><td>${esc(p.opis || "")}<div class="mut">${esc((prej ? (nove.length ? "+ " + nove.map(imeModula).join(", ") : "enake funkcije kot " + prej.ime) + (manj.length ? "; brez: " + manj.map(imeModula).join(", ") : "") : p.moduli.map(imeModula).join(", ")))}</div></td><td>${eur(p.cena)}</td><td>${(d.uporaba || {})[p.id] || 0}</td><td style="white-space:nowrap"><button class="btn sm" data-pku="${p.id}">Uredi</button> <button class="btn sm ghost sec" data-pkx="${p.id}">Izbriši</button></td></tr>`; }).join("") || '<tr><td colspan="5" class="empty">Ni paketov.</td></tr>'}</table></div></div>
  <div class="card"><h2>Cenik in podatki izdajatelja</h2><p class="mut">Cene so brez DDV. Predlog mesečne cene: prvi obrat po ceniku, vsak dodatni obrat s popustom. Pri letnem plačilu se obračuna 12 mesecev manj brezplačnih.</p>
  <div class="fgrid">${[["popust_obrat", "Popust za dodatni obrat (%)"], ["brezplacni_meseci", "Brezplačni meseci pri letnem plačilu"], ["ddv", "DDV (%)"], ["rok_dni", "Rok plačila (dni)"], ["opozorilo_dni", "Opozorilo pred iztekom (dni)"]].map(([k, l]) => `<label class="f"><span>${l}</span><input type="number" min="0" step="0.01" data-c="${k}" value="${esc(c[k])}"></label>`).join("")}</div>
  <div class="fgrid">${[["naziv", "Izdajatelj (naziv)"], ["naslov", "Naslov"], ["davcna", "ID za DDV / davčna št."], ["trr", "TRR (IBAN)"], ["banka", "Banka"], ["email", "E-pošta"], ["telefon", "Telefon"]].map(([k, l]) => `<label class="f"><span>${l}</span><input data-i="${k}" value="${esc(iz[k] || "")}"></label>`).join("")}</div>
  <button class="btn" id="n_sh">Shrani cenik in podatke</button></div>`;
  $("#n_sh").onclick = async () => {
    const cen = {}, izd = {}; $$("[data-c]", v).forEach(i => cen[i.dataset.c] = i.value); $$("[data-i]", v).forEach(i => izd[i.dataset.i] = i.value.trim());
    try { await api("PUT", "/api/narocnine/nastavitve", { cenik: cen, izdajatelj: izd }); PAK.podatki = null; toast("Shranjeno"); render(); } catch (e) { fail(e); }
  };
  $$("[data-ur]", v).forEach(b => b.onclick = () => urediNarocnino(sm[b.dataset.ur], d.stranke[b.dataset.ur], d));
  $("#pk_nov").onclick = () => urediPaket(null, d);
  $$("[data-pku]", v).forEach(b => b.onclick = () => urediPaket(pk.paketi.find(p => p.id === b.dataset.pku), d));
  $$("[data-pkx]", v).forEach(b => b.onclick = () => { const p = pk.paketi.find(x => x.id === b.dataset.pkx); confirmBox("Izbrišem paket »" + p.ime + "«?", async () => { try { await api("DELETE", "/api/narocnine/paketi/" + p.id); PAK.podatki = null; toast("Paket izbrisan"); render(); } catch (e) { fail(e); } }, true); });
  $$("[data-pr]", v).forEach(b => b.onclick = async () => { try { const r = await api("POST", "/api/narocnine/" + b.dataset.pr + "/predracun", {}); toast("Predračun " + r.stevilka + " izdan"); predracunPdf(r, iz); render(); } catch (e) { fail(e); } });
  $$("[data-pdf]", v).forEach(b => b.onclick = () => predracunPdf(pr.find(r => r.id === b.dataset.pdf), iz));
  $$("[data-pl]", v).forEach(b => b.onclick = () => { const r = pr.find(x => x.id === b.dataset.pl); modal("Plačilo predračuna " + r.stevilka, `<p>Znesek: <b>${eur(r.skupaj)}</b>. Naročnina bo podaljšana do ${fdate(r.do)}.</p><label class="f"><span>Datum plačila</span><input type="date" id="pl_d" value="${today()}"></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Označi kot plačano", fn: async () => { await api("POST", "/api/predracun/" + r.id + "/placan", { datum: $("#pl_d").value }); toast("Plačilo zabeleženo"); render(); } }]); });
  $$("[data-st]", v).forEach(b => b.onclick = () => confirmBox("Storniram predračun?", async () => { try { await api("POST", "/api/predracun/" + b.dataset.st + "/storno", {}); toast("Storniran"); render(); } catch (e) { fail(e); } }, true));
}
// ustvarjanje in urejanje paketa: ime, opis, cena, funkcije (moduli)
function urediPaket(p, d) {
  p = p || { id: "", ime: "", opis: "", cena: "", moduli: [] }; const upor = (d.uporaba || {})[p.id] || 0;
  const skupine = {}; for (const m of d.moduli) { const k = m.startsWith("tab:") ? "Zavihki v profilu stranke" : "Meni"; (skupine[k] = skupine[k] || []).push(m); }
  modal(p.id ? "Paket: " + p.ime : "Nov paket", `<div class="fgrid">
    <label class="f"><span>Ime paketa</span><input id="pk_i" value="${esc(p.ime)}" maxlength="60"></label>
    <label class="f"><span>Cena na mesec za prvi obrat (€, brez DDV)</span><input type="number" min="0" step="0.01" id="pk_c" value="${esc(p.cena)}"></label>
    <label class="f wide"><span>Opis (vidi ga tudi stranka)</span><input id="pk_o" value="${esc(p.opis || "")}" maxlength="300"></label></div>
    <div class="row" style="margin:6px 0"><b>Funkcije v paketu</b><span class="sp"></span><button type="button" class="btn sm ghost sec" id="pk_vse">Izberi vse</button><button type="button" class="btn sm ghost sec" id="pk_nic">Počisti</button></div>
    ${Object.entries(skupine).map(([k, ms]) => `<fieldset style="border:1px solid var(--line);border-radius:8px;margin:0 0 8px;padding:6px 10px"><legend class="mut">${k}</legend><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:2px 12px">${ms.map(m => `<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-pkm="${esc(m)}" ${p.moduli.includes(m) ? "checked" : ""}> ${esc(imeModula(m))}</label>`).join("")}</div></fieldset>`).join("")}
    ${upor ? `<label style="display:flex;gap:6px;align-items:center;margin-top:6px"><input type="checkbox" id="pk_pos"> Novo ceno uporabi tudi pri ${upor} obstoječih strankah s tem paketom (sicer jim ostane dogovorjena cena)</label>` : ""}`,
  [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani paket", fn: async () => {
    const moduli = $$("[data-pkm]").filter(c => c.checked).map(c => c.dataset.pkm);
    const r = await api("PUT", "/api/narocnine/paketi/" + p.id, { ime: $("#pk_i").value, opis: $("#pk_o").value, cena: $("#pk_c").value, moduli, posodobi_stranke: !!($("#pk_pos") && $("#pk_pos").checked) });
    PAK.podatki = null; toast("Paket shranjen" + (r.posodobljenih ? ", posodobljenih strank: " + r.posodobljenih : "")); render();
  } }]);
  $("#pk_vse").onclick = () => $$("[data-pkm]").forEach(c => c.checked = true);
  $("#pk_nic").onclick = () => $$("[data-pkm]").forEach(c => c.checked = false);
}
function urediNarocnino(s, n, d) {
  n = n || {}; const pred = d.predlogi[s.id] || {};
  modal("Naročnina: " + s.naziv, `<div class="fgrid">
    <label class="f"><span>Paket</span><select id="nr_p"><option value="">ni določen (vse funkcije, brez obračuna)</option>${d.paketi.map(p => `<option value="${p.id}" ${n.paket === p.id ? "selected" : ""}>${esc(p.ime)}</option>`).join("")}</select></label>
    <label class="f"><span>Obračun</span><select id="nr_o"><option value="mesecno">mesečno</option><option value="letno" ${n.obdobje === "letno" ? "selected" : ""}>letno (${d.cenik.brezplacni_meseci} meseca brezplačno)</option></select></label>
    <label class="f"><span>Cena na mesec (€, brez DDV)</span><input type="number" min="0" step="0.01" id="nr_c" value="${esc(n.cena_mesec !== undefined ? n.cena_mesec : "")}"><small class="mut" id="nr_pc"></small></label>
    <label class="f"><span>Začetek</span><input type="date" id="nr_z" value="${esc(n.zacetek || today())}"></label>
    <label class="f"><span>Plačano do</span><input type="date" id="nr_d" value="${esc(n.placano_do || "")}"></label>
    <label class="f wide"><span>Opomba (vidi samo administrator)</span><input id="nr_op" value="${esc(n.opomba || "")}"></label></div>`,
  [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: async () => {
    const paket = $("#nr_p").value;
    if (!paket) await api("PUT", "/api/narocnine/" + s.id, { paket: null });
    else await api("PUT", "/api/narocnine/" + s.id, { paket, obdobje: $("#nr_o").value, cena_mesec: $("#nr_c").value === "" ? pred[paket] : $("#nr_c").value, zacetek: $("#nr_z").value, placano_do: $("#nr_d").value, opomba: $("#nr_op").value });
    toast("Naročnina shranjena"); render();
  } }]);
  const pc = () => { const p = $("#nr_p").value; $("#nr_pc").innerHTML = p ? `Predlog po ceniku (glede na število obratov): <a href="#" id="nr_up">${eur(pred[p])}</a>` : ""; const a = $("#nr_up"); if (a) a.onclick = e => { e.preventDefault(); $("#nr_c").value = pred[p]; }; };
  $("#nr_p").onchange = pc; pc();
}
route(/^\/narocnine$/, pageNarocnine, "Naročnine in predračuni", "narocnine");
// Spletna stran: povpraševanja in naročniki novic (samo administrator); roki hrambe se izvajajo samodejno na strežniku
// en vnos v meniju »Spletna stran« z zavihki: povpraševanja in novice, blog, SEO
const ssZavihki = akt => !hasRole(ME.u, "admin") ? "" : `<div class="ss-tabs" role="tablist" aria-label="Spletna stran">${[["pov", "#/spletna-stran", "Povpraševanja in novice"], ["blog", "#/blog", "Blog"], ["seo", "#/spletna-stran/seo", "Iskalniki (SEO)"]].map(([k, h, t]) => `<a role="tab" href="${h}" class="${k === akt ? "akt" : ""}" aria-selected="${k === akt}">${t}</a>`).join("")}</div>`;
async function pageSpletnaStran(v) {
  if (!hasRole(ME.u, "admin")) { location.hash = "#/blog"; return; }
  const d = await api("GET", "/api/javno-admin"), stran = d.stran_url || location.origin + "/stran/";
  const pot = d.novice.filter(n => n.stanje === "potrjen"), cak = d.novice.filter(n => n.stanje !== "potrjen"), STANJA = ["novo", "v obdelavi", "zaključeno"];
  v.innerHTML = ssZavihki("pov") + `<div class="card"><h2>Povpraševanja (${d.povprasevanja.length})</h2><p class="mut">Povpraševanja s spletne strani. Samodejno se izbrišejo po 12 mesecih (politika zasebnosti). Ob novem povpraševanju dobite e-pošto na naslov izdajatelja (Naročnine).</p>
    ${d.povprasevanja.length ? `<div class="tw"><table class="t"><tr><th>Prejeto</th><th>Kontakt</th><th>Dejavnost</th><th>Sporočilo</th><th>Stanje</th><th></th></tr>${d.povprasevanja.map(x => `<tr><td>${esc(fdt(x.cas))}</td><td><b>${esc(x.ime)}</b>${x.podjetje ? "<br>" + esc(x.podjetje) : ""}<br><a href="mailto:${esc(x.email)}">${esc(x.email)}</a>${x.telefon ? "<br>" + esc(x.telefon) : ""}</td><td>${esc(x.dejavnost || "")}${x.obratov ? "<br>obratov: " + esc(x.obratov) : ""}</td><td style="white-space:pre-wrap;max-width:360px">${esc(x.sporocilo || "")}</td><td><select data-pst="${esc(x.id)}" aria-label="Stanje povpraševanja">${STANJA.map(s => `<option ${s === x.stanje ? "selected" : ""}>${s}</option>`).join("")}</select></td><td><button class="btn sm ghost sec danger" data-pdel="${esc(x.id)}">Izbriši</button></td></tr>`).join("")}</table></div>` : '<p class="empty">Ni povpraševanj.</p>'}</div>
    <div class="card"><h2>Naročniki novic</h2><p class="mut">Potrjenih: <b>${pot.length}</b>, čaka na potrditev: ${cak.length} (nepotrjene prijave se izbrišejo po 7 dneh). Pri vsakem pošiljanju novic dodajte povezavo za odjavo iz izvoza – odjava izbriše naslov s seznama.</p>
    <div class="row"><button class="btn ghost sec" id="nv_csv" ${pot.length ? "" : "disabled"}>Izvoz potrjenih (CSV)</button></div>
    ${d.novice.length ? `<div class="tw"><table class="t"><tr><th>E-pošta</th><th>Stanje</th><th>Prijava</th><th>Soglasje</th><th></th></tr>${d.novice.map(n => `<tr><td>${esc(n.email)}</td><td>${n.stanje === "potrjen" ? '<span class="badge ok">potrjen</span>' : '<span class="badge warn">čaka na potrditev</span>'}</td><td>${esc(fdt(n.ustvarjeno))}${n.potrjeno ? "<br><small class=\"mut\">potrjeno " + esc(fdt(n.potrjeno)) + "</small>" : ""}</td><td><small>${esc((n.soglasje || {}).vir || "")}</small></td><td><button class="btn sm ghost sec danger" data-ndel="${esc(n.id)}">Izbriši</button></td></tr>`).join("")}</table></div>` : '<p class="empty">Ni naročnikov.</p>'}</div>`;
  $$("[data-pst]", v).forEach(s => s.onchange = async () => { try { await api("PUT", "/api/javno-admin/povprasevanja/" + s.dataset.pst, { stanje: s.value }); toast("Stanje shranjeno"); } catch (e) { fail(e); } });
  $$("[data-pdel]", v).forEach(b => b.onclick = () => confirmBox("Izbrišem povpraševanje? Tega ni mogoče razveljaviti.", async () => { try { await api("DELETE", "/api/javno-admin/povprasevanja/" + b.dataset.pdel); pageSpletnaStran(v); } catch (e) { fail(e); } }, true));
  $$("[data-ndel]", v).forEach(b => b.onclick = () => confirmBox("Izbrišem naročnika s seznama novic?", async () => { try { await api("DELETE", "/api/javno-admin/novice/" + b.dataset.ndel); pageSpletnaStran(v); } catch (e) { fail(e); } }, true));
  $("#nv_csv").onclick = () => { const q = s => '"' + String(s == null ? "" : s).replace(/"/g, '""') + '"'; dlBlob(new Blob(["\ufeff" + [["e-posta", "potrjeno", "povezava_za_odjavo"].join(";"), ...pot.map(n => [q(n.email), q(n.potrjeno || ""), q(stran + "novice.html?odjava=" + n.odjava)].join(";"))].join("\r\n")], { type: "text/csv;charset=utf-8" }), "novice-naročniki-" + today() + ".csv"); };
}
// Blog: administrator piše, ureja, objavi in pošlje naročnikom; svetovalec piše osnutke in jih pošlje v pregled
const BLOG_ST = { osnutek: '<span class="badge">osnutek</span>', "za pregled": '<span class="badge warn">za pregled</span>', objavljen: '<span class="badge ok">objavljen</span>' };
async function pageBlog(v, m) {
  const id = m && m[1];
  if (id) return blogUrednik(v, id);
  const d = await api("GET", "/api/blog-urednik"), adm = hasRole(ME.u, "admin");
  v.innerHTML = ssZavihki("blog") + `<div class="card"><h2>Blog na spletni strani</h2><p class="mut">${adm ? "Članke pišete in objavljate vi. Svetovalci pišejo osnutke in jih pošljejo v pregled; objavi jih administrator." : "Pišete osnutke in jih pošljete v pregled. Članek objavi administrator; po objavi ga ureja samo administrator."} Objavljeni članki so na strani <a href="${esc((d.stran || "/stran/") + "blog/")}" target="_blank" rel="noopener">Blog</a>.</p>
    <div class="row"><button class="btn" id="bl_nov">+ Nov članek</button></div>
    ${d.clanki.length ? `<div class="tw"><table class="t"><tr><th>Naslov</th><th>Stanje</th><th>Avtor</th><th>Spremenjeno</th><th></th></tr>${d.clanki.map(c => `<tr><td><a href="#/blog/${esc(c.id)}"><b>${esc(c.naslov)}</b></a>${c.povzetek ? `<br><small class="mut">${esc(c.povzetek.slice(0, 120))}</small>` : ""}</td><td>${c.stanje === "objavljen" && c.objavljeno > new Date().toISOString() ? `<span class="badge warn">načrtovano ${esc(fdt(c.objavljeno))}</span>` : BLOG_ST[c.stanje] || esc(c.stanje)}${c.poslano_novicam ? '<br><small class="mut">poslano naročnikom</small>' : ""}</td><td>${esc(c.avtor_ime || "")}</td><td>${esc(fdt(c.spremenjeno || c.ustvarjeno))}</td><td><a class="btn sm ghost sec" href="#/blog/${esc(c.id)}">Uredi</a></td></tr>`).join("")}</table></div>` : '<p class="empty">Ni še člankov.</p>'}</div>`;
  $("#bl_nov").onclick = () => modal("Nov članek", '<label class="f"><span>Naslov</span><input id="bl_n" maxlength="160"></label>', [{ t: "Prekliči", cls: "ghost sec" }, { t: "Ustvari", fn: async () => { const n = $("#bl_n").value.trim(); if (!n) { toast("Vpišite naslov.", true); return false; } try { const c = await api("POST", "/api/blog-urednik", { naslov: n }); location.hash = "#/blog/" + c.id; } catch (e) { fail(e); return false; } } }]);
}
async function blogUrednik(v, id) {
  const d = await api("GET", "/api/blog-urednik"), c = d.clanki.find(x => x.id === id); if (!c) throw new Error("Članka ni mogoče najti.");
  const adm = hasRole(ME.u, "admin"), ureja = adm || (c.avtor_id === ME.u.id && c.stanje !== "objavljen"), stran = (d.stran || location.origin + "/stran/") + "blog/" + c.slug;
  let slika; // undefined = brez spremembe, null = odstrani, niz = nova slika (JPEG, base64)
  const nacrt = c.stanje === "objavljen" && c.objavljeno > new Date().toISOString(), lokalno = iso => { const d = new Date(iso || Date.now()); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
  v.innerHTML = `<div class="row"><a class="btn ghost sec sm" href="#/blog">‹ Vsi članki</a> ${nacrt ? `<span class="badge warn">načrtovano ${esc(fdt(c.objavljeno))}</span>` : BLOG_ST[c.stanje] || ""} ${c.stanje === "objavljen" ? `<a class="btn sm ghost sec" href="${esc(stran)}" target="_blank" rel="noopener">Odpri na strani ↗</a>` : ""}</div>
  <div class="bl-preklop" role="tablist" aria-label="Pogled"><button type="button" class="btn sm" data-pog="ed" aria-selected="true">Urejanje</button><button type="button" class="btn sm ghost sec" data-pog="pv" aria-selected="false">Predogled</button></div>
  <div class="grid g2 bl-ured" data-pog="ed"><div class="card bl-ed"><h2>Urejanje članka</h2>${ureja ? "" : `<p class="note">${c.stanje === "objavljen" ? "Objavljen članek ureja administrator." : "To ni vaš članek."}</p>`}
    <label class="f"><span>Naslov</span><input id="bl_naslov" maxlength="160" value="${esc(c.naslov)}"></label>
    <label class="f"><span>Povzetek (prikaže se na seznamu in v iskalnikih, do 300 znakov)</span><textarea id="bl_povzetek" rows="3" maxlength="300">${esc(c.povzetek || "")}</textarea></label>
    <span class="f-lbl">Besedilo</span>
    ${ureja ? `<div class="bl-orodja" role="toolbar" aria-label="Oblikovanje besedila">${[["b", "<b>K</b>", "Krepko (Ctrl+B)"], ["i", "<i>L</i>", "Ležeče (Ctrl+I)"], ["u", "<u>P</u>", "Podčrtano (Ctrl+U)"], ["|"], ["h2", "H2", "Podnaslov"], ["h3", "H3", "Manjši podnaslov"], ["|"], ["ul", "• Seznam", "Alineje"], ["ol", "1. Seznam", "Oštevilčen seznam"], ["q", "❝ Citat", "Citat"], ["|"], ["a", "🔗 Povezava", "Povezava (Ctrl+K)"], ["img", "🖼 Slika", "Vstavi sliko"]].map(([o, t, n]) => o === "|" ? '<span class="bl-loc" aria-hidden="true"></span>' : `<button type="button" class="btn ghost sec sm" data-o="${o}" title="${n}" aria-label="${n}">${t}</button>`).join("")}</div>` : ""}
    <label class="f"><span class="sr-only">Besedilo</span><textarea id="bl_besedilo" rows="18" maxlength="100000" style="font-family:ui-monospace,monospace;font-size:14px">${esc(c.besedilo || "")}</textarea></label>
    ${ureja ? '<div class="row"><button class="btn ghost sec sm" type="button" id="bl_vstavi">🖼 Vstavi sliko v besedilo …</button><input type="file" id="bl_vsl" accept="image/jpeg,image/png,image/webp" multiple hidden><span class="mut" id="bl_vst"></span></div>' : ""}
    <p class="mut">Označite besedilo in kliknite gumb (ali Ctrl+B, Ctrl+I, Ctrl+U, Ctrl+K); ponoven klik oblikovanje odstrani. Prazna vrstica = nov odstavek. Oznake v besedilu: <code>**krepko**</code> · <code>*ležeče*</code> · <code>__podčrtano__</code> · <code>## podnaslov</code> · <code>- alineja</code> · <code>1. točka</code> · <code>&gt; citat</code> · <code>[besedilo](https://naslov)</code>. Sliko vstavite z gumbom, jo prilepite (Ctrl+V) ali povlecite v besedilo; opis v <code>![opis](slika:…)</code> se izpiše pod sliko.</p>
    <label class="f"><span>Naslovna slika (JPEG, PNG ali WebP; pomanjša se na 1600 px)</span><input type="file" id="bl_slika" accept="image/jpeg,image/png,image/webp"></label>
    <details class="bl-seo" ${c.seo_naslov || c.seo_opis || c.kljucne_besede ? "open" : ""}><summary>Iskalniki (SEO): naslov, opis, ključne besede</summary>
      <label class="f"><span>Naslov za Google <small class="mut" id="sn_n"></small></span><input id="bl_seo_naslov" maxlength="70" value="${esc(c.seo_naslov || "")}" placeholder="${esc(c.naslov + " | HiGiFood")}"></label>
      <label class="f"><span>Opis za Google <small class="mut" id="sn_o"></small></span><textarea id="bl_seo_opis" rows="2" maxlength="170" placeholder="Če je prazno, se uporabi povzetek.">${esc(c.seo_opis || "")}</textarea></label>
      <label class="f"><span>Ključne besede (ločene z vejico)</span><input id="bl_kljucne" maxlength="300" value="${esc(c.kljucne_besede || "")}" placeholder="npr. hlajenje hrane, HACCP, kritična kontrolna točka"></label>
      <div class="serp" aria-label="Tako bo videti v Googlu"><div class="serp-u" id="sp_u"></div><div class="serp-n" id="sp_n"></div><div class="serp-o" id="sp_o"></div></div>
      <p class="mut">Naslov naj ima do 60 znakov, opis do 160; ključno besedo uporabite tudi v naslovu, prvem odstavku in podnaslovu. Google ključnih besed v metapodatkih ne upošteva, uporabijo se za oznake članka.</p>
    </details>
    ${adm ? `<label class="f"><span>Čas objave (prihodnji čas = samodejna objava ob tem času)</span><input type="datetime-local" id="bl_objava" value="${esc(lokalno(c.objavljeno))}"></label>` : ""}
    ${c.slika ? '<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="bl_brez" style="width:auto"> Odstrani sedanjo sliko</label>' : ""}
    <div class="row" style="margin-top:10px">${ureja ? '<button class="btn" id="bl_shrani">Shrani</button>' : ""}
      ${ureja && !adm && c.stanje === "osnutek" ? '<button class="btn ghost sec" data-st="za pregled">Shrani in pošlji v pregled</button>' : ""}
      ${ureja && !adm && c.stanje === "za pregled" ? '<button class="btn ghost sec" data-st="osnutek">Vrni v osnutek</button>' : ""}
      ${adm && c.stanje !== "objavljen" ? '<button class="btn" data-st="objavljen">Shrani in objavi</button>' : ""}
      ${adm && c.stanje === "objavljen" ? '<button class="btn ghost sec" data-st="osnutek">Umakni s strani</button>' : ""}
      ${adm && c.stanje === "objavljen" ? `<button class="btn ghost sec" id="bl_novice" ${d.narocnikov && !nacrt ? "" : "disabled"}>${c.poslano_novicam ? "Pošlji naročnikom znova" : "Pošlji naročnikom novic"} (${d.narocnikov})</button>` : ""}
      ${ureja ? '<button class="btn ghost sec danger" id="bl_del">Izbriši</button>' : ""}</div>
    ${c.poslano_novicam ? `<p class="mut">Poslano naročnikom ${esc(fdt(c.poslano_novicam))} (${esc(c.poslano_st || 0)}).</p>` : ""}
  </div><div class="card bl-pv"><h2>Predogled</h2><div id="bl_pred" class="bl-pred"></div></div></div>`;
  $$("[data-pog]", v).forEach(b => { if (b.tagName === "BUTTON") b.onclick = () => { $(".bl-ured", v).dataset.pog = b.dataset.pog; $$(".bl-preklop button", v).forEach(x => { const a = x === b; x.className = "btn sm" + (a ? "" : " ghost sec"); x.setAttribute("aria-selected", a); }); }; });
  // predogled zadetka v Googlu (dolžina naslova in opisa)
  const serp = () => { const n = $("#bl_seo_naslov").value.trim() || $("#bl_naslov").value.trim() + " | HiGiFood", o = $("#bl_seo_opis").value.trim() || $("#bl_povzetek").value.trim() || "(opis iz besedila članka)";
    $("#sp_u").textContent = stran.replace(/^https?:\/\//, "").replace(/\/$/, "").replace(/\//g, " › "); $("#sp_n").textContent = n.length > 60 ? n.slice(0, 59) + "…" : n; $("#sp_o").textContent = o.length > 160 ? o.slice(0, 159) + "…" : o;
    $("#sn_n").textContent = n.length + "/60" + (n.length > 60 ? " – predolg" : ""); $("#sn_o").textContent = o.length + "/160" + (o.length > 160 ? " – predolg" : ""); };
  $$("#bl_seo_naslov,#bl_seo_opis,#bl_naslov,#bl_povzetek", v).forEach(e => e.addEventListener("input", serp)); serp();
  if (!ureja) $$("#bl_naslov,#bl_povzetek,#bl_besedilo,#bl_slika,#bl_seo_naslov,#bl_seo_opis,#bl_kljucne,#bl_objava", v).forEach(e => e.disabled = true);
  let tm; const pred = () => { clearTimeout(tm); tm = setTimeout(async () => { try { const r = await api("POST", "/api/blog-urednik/predogled", { id: c.id, besedilo: $("#bl_besedilo").value }); $("#bl_pred").innerHTML = `<h1 style="margin-top:0">${esc($("#bl_naslov").value)}</h1>${$("#bl_povzetek").value ? `<p class="mut"><b>${esc($("#bl_povzetek").value)}</b></p>` : ""}${r.html}`; } catch {} }, 300); };
  $$("#bl_naslov,#bl_povzetek,#bl_besedilo", v).forEach(e => e.oninput = pred); pred();
  // slika v besedilu: pomanjšana na 1600 px (JPEG), naložena k članku, na mesto kazalca se vstavi ![opis](slika:ID)
  const vJpeg = async f => { const bmp = await createImageBitmap(f), sc = Math.min(1, 1600 / bmp.width), cv = document.createElement("canvas"); cv.width = Math.round(bmp.width * sc); cv.height = Math.round(bmp.height * sc); const g = cv.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, cv.width, cv.height); g.drawImage(bmp, 0, 0, cv.width, cv.height); return cv.toDataURL("image/jpeg", 0.85).split(",")[1]; };
  const vstaviSlike = async files => {
    const ta = $("#bl_besedilo"), st = $("#bl_vst"); files = [...files].filter(f => /^image\/(jpeg|png|webp|gif)$/.test(f.type)); if (!files.length) return;
    for (const f of files) {
      if (st) st.textContent = "Nalagam sliko …";
      try { const r = await api("POST", "/api/blog-urednik/" + c.id + "/slike", { slika: await vJpeg(f) }); const opis = "Opis slike", kos = "\n\n![" + opis + "](" + r.oznaka + ")\n\n", z = ta.selectionStart, k = ta.selectionEnd;
        ta.value = ta.value.slice(0, z).replace(/\s*$/, "") + kos + ta.value.slice(k).replace(/^\s*/, ""); const zac = ta.value.indexOf("![" + opis + "](" + r.oznaka) + 2; ta.focus(); ta.setSelectionRange(zac, zac + opis.length); pred();
        toast("Slika vstavljena – vpišite opis in shranite članek."); } catch (e) { fail(e); }
    }
    if (st) st.textContent = "";
  };
  // orodna vrstica: ovij izbor z oznako (ponoven klik jo odstrani) ali dodaj predpono vrsticam
  const ta0 = $("#bl_besedilo"), poKonc = () => { ta0.focus(); pred(); };
  function ovij(pre, post, ph) {
    const z = ta0.selectionStart, k = ta0.selectionEnd, v = ta0.value, sel = v.slice(z, k);
    // »*« (ležeče) je tudi del »**« (krepko): ležeče je okoli izbora, ko je zvezdic liho število (* ali ***)
    const zn = pre[0], niz = (i, d) => { let n = 0; while (v[d < 0 ? i - 1 - n : i + n] === zn) n++; return n; }, pr = niz(z, -1), po = niz(k, 1);
    const okoli = pre.length === 1 ? pr % 2 === 1 && po % 2 === 1 : pr >= pre.length && po >= pre.length;
    const vIzboru = pre.length === 1 ? /^(\*|\*\*\*)[^*]/.test(sel) && /[^*](\*|\*\*\*)$/.test(sel) : sel.startsWith(pre) && sel.endsWith(post) && sel.length > pre.length + post.length;
    if (vIzboru) { ta0.setRangeText(sel.slice(pre.length, sel.length - post.length), z, k, "select"); return poKonc(); }
    if (okoli) { ta0.setRangeText(sel, z - pre.length, k + post.length, "select"); return poKonc(); }
    const t = sel || ph; ta0.setRangeText(pre + t + post, z, k, "end"); ta0.setSelectionRange(z + pre.length, z + pre.length + t.length); poKonc();
  }
  function vrstice(pref) { // pref: niz ali funkcija (zaporedna številka) → predpona vsake izbrane vrstice
    const v = ta0.value, z = v.lastIndexOf("\n", ta0.selectionStart - 1) + 1, kk = v.indexOf("\n", Math.max(ta0.selectionEnd - (ta0.selectionEnd > ta0.selectionStart && v[ta0.selectionEnd - 1] === "\n" ? 1 : 0), ta0.selectionStart)), k = kk < 0 ? v.length : kk;
    const L = v.slice(z, k).split("\n"), re = typeof pref === "function" ? /^\d+[.)] / : new RegExp("^" + pref.replace(/[#>.*+?^${}()|[\]\\]/g, "\\$&"));
    const nove = L.every(l => re.test(l)) ? L.map(l => l.replace(re, "")) : L.map((l, i) => (typeof pref === "function" ? pref(i) : pref) + l.replace(/^(#{2,3} |[-•] |\d+[.)] |> ?)/, ""));
    ta0.setRangeText(nove.join("\n"), z, k, "select"); poKonc();
  }
  const povezava = () => { const sel = ta0.value.slice(ta0.selectionStart, ta0.selectionEnd), z = ta0.selectionStart, k = ta0.selectionEnd;
    modal("Povezava", `<label class="f"><span>Besedilo povezave</span><input id="lk_t" maxlength="200" value="${esc(sel)}"></label><label class="f"><span>Naslov (https://… ali mailto:…)</span><input id="lk_u" maxlength="500" placeholder="https://"></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Vstavi", fn: () => {
      const t = $("#lk_t").value.trim() || "povezava", u = $("#lk_u").value.trim(); if (!/^(https?:\/\/|mailto:)\S+$/.test(u)) { toast("Naslov mora začeti s https://, http:// ali mailto:", true); return false; }
      ta0.setRangeText("[" + t.replace(/[[\]]/g, "") + "](" + u + ")", z, k, "end"); poKonc(); } }]); setTimeout(() => $(sel ? "#lk_u" : "#lk_t").focus(), 50); };
  const ORODJA = { b: () => ovij("**", "**", "krepko besedilo"), i: () => ovij("*", "*", "ležeče besedilo"), u: () => ovij("__", "__", "podčrtano besedilo"), h2: () => vrstice("## "), h3: () => vrstice("### "), ul: () => vrstice("- "), ol: () => vrstice(i => (i + 1) + ". "), q: () => vrstice("> "), a: povezava, img: () => $("#bl_vsl") && $("#bl_vsl").click() };
  $$("[data-o]", v).forEach(b => { b.onmousedown = e => e.preventDefault(); b.onclick = () => ORODJA[b.dataset.o](); });
  if (ureja) ta0.addEventListener("keydown", e => { if (!(e.ctrlKey || e.metaKey) || e.altKey) return; const k = { b: "b", i: "i", u: "u", k: "a" }[e.key.toLowerCase()]; if (k) { e.preventDefault(); ORODJA[k](); } });
  if ($("#bl_vstavi")) { $("#bl_vstavi").onclick = () => $("#bl_vsl").click(); $("#bl_vsl").onchange = () => { vstaviSlike($("#bl_vsl").files); $("#bl_vsl").value = ""; };
    const ta = $("#bl_besedilo");
    ta.addEventListener("paste", e => { const f = [...(e.clipboardData && e.clipboardData.files || [])]; if (f.length) { e.preventDefault(); vstaviSlike(f); } });
    ta.addEventListener("dragover", e => { if (e.dataTransfer && [...e.dataTransfer.types].includes("Files")) e.preventDefault(); });
    ta.addEventListener("drop", e => { const f = [...(e.dataTransfer && e.dataTransfer.files || [])]; if (f.length) { e.preventDefault(); vstaviSlike(f); } }); }
  $("#bl_slika").onchange = async () => { const f = $("#bl_slika").files[0]; if (!f) return; try { const bmp = await createImageBitmap(f), sc = Math.min(1, 1600 / bmp.width), cv = document.createElement("canvas"); cv.width = Math.round(bmp.width * sc); cv.height = Math.round(bmp.height * sc); const g = cv.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, cv.width, cv.height); g.drawImage(bmp, 0, 0, cv.width, cv.height); slika = cv.toDataURL("image/jpeg", 0.85).split(",")[1]; toast("Slika pripravljena – shranite članek."); } catch { toast("Slike ni mogoče prebrati.", true); } };
  const objava = () => $("#bl_objava") && $("#bl_objava").value ? new Date($("#bl_objava").value).toISOString() : undefined;
  const telo = st => Object.assign({ naslov: $("#bl_naslov").value, povzetek: $("#bl_povzetek").value, besedilo: $("#bl_besedilo").value, seo_naslov: $("#bl_seo_naslov").value, seo_opis: $("#bl_seo_opis").value, kljucne_besede: $("#bl_kljucne").value }, adm && objava() && (st === "objavljen" || c.stanje === "objavljen") ? { objava: objava() } : {}, $("#bl_brez") && $("#bl_brez").checked ? { slika: null } : slika ? { slika } : {}, st ? { stanje: st } : {});
  const shrani = async st => { try { await api("PUT", "/api/blog-urednik/" + c.id, telo(st)); toast(st === "objavljen" ? (objava() && objava() > new Date().toISOString() ? "Objava je načrtovana za " + fdt(objava()) + "." : "Članek je objavljen.") : st === "za pregled" ? "Članek je poslan v pregled administratorju." : st === "osnutek" ? "Članek je osnutek (ni na strani)." : "Shranjeno"); blogUrednik(v, id); } catch (e) { fail(e); } };
  if ($("#bl_shrani")) $("#bl_shrani").onclick = () => shrani();
  $$("[data-st]", v).forEach(b => b.onclick = () => b.dataset.st === "objavljen" ? confirmBox(objava() && objava() > new Date().toISOString() ? "Načrtujem objavo članka za " + fdt(objava()) + "?" : "Objavim članek na javni spletni strani?", () => shrani("objavljen")) : shrani(b.dataset.st));
  if ($("#bl_novice")) $("#bl_novice").onclick = () => confirmBox(`Pošljem članek »${c.naslov}« ${d.narocnikov} potrjenim naročnikom novic? Vsako sporočilo vsebuje povezavo za odjavo.`, async () => { try { const r = await api("POST", "/api/blog-urednik/" + c.id + "/novice"); toast("Poslano: " + r.poslano + (r.napak ? ", napak: " + r.napak : "")); blogUrednik(v, id); } catch (e) { fail(e); } });
  if ($("#bl_del")) $("#bl_del").onclick = () => confirmBox("Izbrišem članek? Tega ni mogoče razveljaviti.", async () => { try { await api("DELETE", "/api/blog-urednik/" + c.id); location.hash = "#/blog"; } catch (e) { fail(e); } }, true);
}
route(/^\/blog(?:\/([\w-]+))?$/, pageBlog, "Spletna stran: blog", "spletna-stran");
route(/^\/spletna-stran$/, pageSpletnaStran, "Spletna stran", "spletna-stran");
navItem("spletna-stran", "Spletna stran", "#/spletna-stran", ["admin", "svetovalec"]);
// iskalniki (SEO): naslov, opis in ključne besede po straneh, sitemap
async function pageSeo(v) {
  if (!hasRole(ME.u, "admin")) { location.hash = "#/blog"; return; }
  const d = await api("GET", "/api/seo-admin"), j = await api("GET", "/api/javno-admin").catch(() => ({})), stran = j.stran_url || location.origin + "/stran/";
  v.innerHTML = ssZavihki("seo") + `<div class="card"><h2>Iskalniki (SEO)</h2><p class="mut">Naslov in opis sta to, kar Google pokaže v zadetkih: naslov do 60 znakov, opis do 160, z glavno ključno besedo na začetku. Kazalo strani za Google: <a href="${esc(stran)}sitemap.xml" target="_blank" rel="noopener">${esc(stran)}sitemap.xml</a> – vpišite ga v Google Search Console (Sitemaps). Članki imajo svoje nastavitve v uredniku bloga.</p></div>
    ${d.strani.map(s => `<div class="card seo-st" data-id="${esc(s.id)}"><h3>${esc(s.privzeto.ime)} ${s.noindex ? '<span class="badge">skrita za iskalnike</span>' : ""}</h3>
      <label class="f"><span>Naslov <small class="mut" data-c="n"></small></span><input data-k="naslov" maxlength="120" value="${esc(s.naslov)}"></label>
      <label class="f"><span>Opis <small class="mut" data-c="o"></small></span><textarea data-k="opis" rows="2" maxlength="320">${esc(s.opis)}</textarea></label>
      <label class="f"><span>Ključne besede (ločene z vejico)</span><input data-k="kljucne" maxlength="400" value="${esc(s.kljucne || "")}"></label>
      <div class="serp"><div class="serp-u">${esc((stran + (s.id === "index.html" ? "" : s.id === "blog" ? "blog/" : s.id)).replace(/^https?:\/\//, ""))}</div><div class="serp-n"></div><div class="serp-o"></div></div></div>`).join("")}
    <div class="row"><button class="btn" id="seo_s">Shrani</button></div>`;
  const os = el => { const n = $("[data-k=naslov]", el).value.trim(), o = $("[data-k=opis]", el).value.trim(); $(".serp-n", el).textContent = n.length > 60 ? n.slice(0, 59) + "…" : n; $(".serp-o", el).textContent = o.length > 160 ? o.slice(0, 159) + "…" : o; $("[data-c=n]", el).textContent = n.length + "/60" + (n.length > 60 ? " – predolg" : ""); $("[data-c=o]", el).textContent = o.length + "/160" + (o.length > 160 ? " – predolg" : ""); };
  $$(".seo-st", v).forEach(el => { $$("input,textarea", el).forEach(i => i.oninput = () => os(el)); os(el); });
  $("#seo_s").onclick = async () => { const strani = {}; $$(".seo-st", v).forEach(el => { strani[el.dataset.id] = { naslov: $("[data-k=naslov]", el).value, opis: $("[data-k=opis]", el).value, kljucne: $("[data-k=kljucne]", el).value }; }); try { await api("PUT", "/api/seo-admin", { strani }); toast("Nastavitve za iskalnike shranjene"); } catch (e) { fail(e); } };
}
route(/^\/spletna-stran\/seo$/, pageSeo, "Spletna stran: iskalniki (SEO)", "spletna-stran");
navItem("narocnine", "Naročnine in predračuni", "#/narocnine", ["admin"]);

// --- nadzorna plošča: opozorila o naročnini ---
async function narocninaOpozorilo() {
  if (ME.real) return "";
  if (hasRole(ME.u, "admin")) {
    const d = await api("GET", "/api/narocnine").catch(() => null); if (!d) return "";
    const vr = Object.entries(d.stranke).filter(([, n]) => n && ["poteka", "zapadla"].includes(n.stanje.koda)); if (!vr.length) return "";
    const st = await D.list("stranke").catch(() => []), sm = Object.fromEntries(st.map(s => [s.id, s.naziv]));
    return `<div class="note" style="border-left:4px solid var(--warnl)"><b>Naročnine:</b><ul style="margin:6px 0 0">${vr.map(([sid, n]) => `<li>${esc(sm[sid] || sid)}: ${esc(n.stanje.besedilo)} (${fdate(n.placano_do)})</li>`).join("")}</ul><a href="#/narocnine">Odpri naročnine</a></div>`;
  }
  if (hasRole(ME.u, "odgovorna") && ME.u.stranka_id) {
    const n = await api("GET", "/api/narocnina?stranka_id=" + ME.u.stranka_id).catch(() => null), nar = n && n.narocnina;
    if (!nar || !["poteka", "zapadla"].includes(nar.stanje.koda)) return "";
    const odprt = n.predracuni.find(r => r.status === "izdan");
    return `<div class="note" style="border-left:4px solid var(--warnl)"><b>Naročnina ${nar.stanje.koda === "zapadla" ? "je zapadla" : "kmalu poteče"}</b> (plačano do ${fdate(nar.placano_do)}).${odprt ? ` Predračun ${esc(odprt.stevilka)} za ${eur(odprt.skupaj)} najdete v <a href="#/stranka/${ME.u.stranka_id}/podatki">podatkih podjetja</a>.` : " Za podaljšanje se obrnite na svojega svetovalca."}</div>`;
  }
  return "";
}
