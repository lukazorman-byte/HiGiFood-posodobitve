// Blog na javni spletni strani: članki z osnutki, pregledom in objavo.
// Pravice: administrator piše, ureja, objavi, umakne, izbriše in pošlje članek naročnikom novic; svetovalec piše in ureja svoje osnutke
// in jih pošlje v pregled (objavi jih administrator). Javno so vidni samo objavljeni članki (/blog/ na domeni strani, predogled /stran/blog/).
// Podatki: _blog.json v podatkovni bazi (shramba.js), slike v mapi blog-slike (JPEG). Besedilo: preprosto oblikovanje (## naslov, - seznam, **krepko**, [povezava](https://…),
// slika v besedilu: vrstica ![opis](slika:ID) – slike naloži urednik, javno so vidne samo pri objavljenem članku).
const fs = require("fs"), path = require("path");

const STANJA = ["osnutek", "za pregled", "objavljen"];
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const cist = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").replace(/\r\n?/g, "\n").trim().slice(0, n);
// naslov → del povezave (šumniki brez kvačic, samo male črke, številke in vezaji)
const slugOf = s => String(s).toLowerCase().replace(/[čć]/g, "c").replace(/š/g, "s").replace(/ž/g, "z").replace(/đ/g, "d").normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "clanek";
const datum = s => { const d = new Date(s); return isNaN(d) ? "" : d.getDate() + ". " + (d.getMonth() + 1) + ". " + d.getFullYear(); };

// preprosto oblikovanje → varen HTML (vse se najprej ubeži; povezave samo http(s) in mailto)
const SLIKA_RE = /^!\[([^\]\n]{0,200})\]\(slika:([\w-]{1,40})\)$/;
// slikaUrl(id) vrne naslov slike ali "" (slika ne pripada članku – se ne prikaže)
function vHtml(t, slikaUrl) {
  const inl = s => esc(s).replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>").replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>").replace(/__([^_\n]+)__/g, "<u>$1</u>")
    .replace(/\[([^\]\n]+)\]\(((?:https?:\/\/|mailto:)[^\s)]+)\)/g, (m, a, u) => `<a href="${u}" rel="noopener">${a}</a>`);
  return String(t || "").split(/\n{2,}/).map(b => b.trim()).filter(Boolean).map(b => {
    const sl = SLIKA_RE.exec(b);
    if (sl) { const u = slikaUrl ? slikaUrl(sl[2]) : ""; return u ? `<figure class="bl-fig"><img src="${esc(u)}" alt="${esc(sl[1])}" loading="lazy">${sl[1] ? `<figcaption>${esc(sl[1])}</figcaption>` : ""}</figure>` : ""; }
    if (/^### /.test(b)) return "<h3>" + inl(b.slice(4)) + "</h3>";
    if (/^## /.test(b)) return "<h2>" + inl(b.slice(3)) + "</h2>";
    const vr = b.split("\n");
    if (vr.every(l => /^[-•] /.test(l))) return "<ul>" + vr.map(l => "<li>" + inl(l.slice(2)) + "</li>").join("") + "</ul>";
    if (vr.every(l => /^> ?/.test(l))) return "<blockquote><p>" + vr.map(l => inl(l.replace(/^> ?/, ""))).join("<br>") + "</p></blockquote>";
    if (vr.every(l => /^\d+[.)] /.test(l))) return "<ol>" + vr.map(l => "<li>" + inl(l.replace(/^\d+[.)] /, "")) + "</li>").join("") + "</ol>";
    return "<p>" + vr.map(inl).join("<br>") + "</p>";
  }).join("\n");
}
const golo = t => String(t || "").replace(/^!\[[^\]]*\]\(slika:[\w-]+\)$/gm, "").replace(/\*\*|__|^#+ |^[-•] |^> ?/gm, "").replace(/(^|[^*])\*([^*\n]+)\*/g, "$1$2").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1");

module.exports = function blog({ DIR, S, send, bad, jbody, audit, now, uid, posljiPosto, narocniki, stranUrl, seo }) {
  const F = path.join(DIR, "_blog.json"), SLIKE = path.join(DIR, "blog-slike");
  let cache = null;
  const preberi = () => { if (!cache) { try { cache = S.beri(F, {}); } catch { cache = {}; } cache = Object.assign({ clanki: [] }, cache); } return cache; };
  const shrani = () => S.pisi(F, cache);
  const objavljeni = () => preberi().clanki.filter(c => c.stanje === "objavljen" && c.objavljeno <= now()).sort((a, b) => b.objavljeno.localeCompare(a.objavljeno));
  const javno = c => ({ id: c.id, slug: c.slug, naslov: c.naslov, povzetek: c.povzetek, avtor: c.avtor_ime, objavljeno: c.objavljeno, slika: !!c.slika });
  const unikaten = (s, id) => { let x = s, i = 2; while (preberi().clanki.some(c => c.slug === x && c.id !== id)) x = s + "-" + i++; return x; };
  const slikaPot = id => path.join(SLIKE, id + ".jpg");
  // slike v besedilu: <članek>-<slika>.jpg; javni naslov samo za objavljen članek, urednik ima svoj naslov (tudi za osnutke)
  const vsebinskaPot = (cid, sid) => path.join(SLIKE, cid + "-" + sid + ".jpg");
  const javnaSlika = c => sid => (c.slike || []).includes(sid) ? "/api/javno/blog/slika/" + c.id + "/" + sid : "";
  const urednikovaSlika = c => sid => (c.slike || []).includes(sid) ? "/api/blog-urednik/" + c.id + "/slike/" + sid : "";
  const jeJpeg = buf => buf.length >= 100 && buf.length <= 3e6 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
  const posljiSliko = (res, f, javno) => { res.writeHead(200, { "Content-Type": "image/jpeg", "Cache-Control": javno ? "public, max-age=3600" : "private, no-store", "X-Content-Type-Options": "nosniff" }); res.end(fs.readFileSync(f)); };
  // slike, ki jih besedilo ne uporablja več, se ob shranjevanju izbrišejo
  function pocistiSlike(c) { const rabi = new Set([...String(c.besedilo || "").matchAll(/^!\[[^\]]*\]\(slika:([\w-]+)\)$/gm)].map(x => x[1])); for (const sid of c.slike || []) if (!rabi.has(sid)) { try { fs.unlinkSync(vsebinskaPot(c.id, sid)); } catch {} } c.slike = (c.slike || []).filter(s => rabi.has(s)); }
  const smeUrejati = (me, c) => me.vloga === "admin" || (me.vloga === "svetovalec" && c.avtor_id === me.id && c.stanje !== "objavljen");

  // ---------- javni del: seznam, članek, slika (samo objavljeni) ----------
  function rJavno(req, res, p) {
    if (req.method !== "GET") return false;
    if (p === "/api/javno/blog") { send(res, 200, objavljeni().slice(0, 50).map(javno)); return true; }
    const mv = /^\/api\/javno\/blog\/slika\/([\w-]+)\/([\w-]+)$/.exec(p);
    if (mv) { const c = objavljeni().find(x => x.id === mv[1]); if (!c || !(c.slike || []).includes(mv[2]) || !fs.existsSync(vsebinskaPot(c.id, mv[2]))) { bad(res, 404, "Slike ni."); return true; } posljiSliko(res, vsebinskaPot(c.id, mv[2]), true); return true; }
    const ms = /^\/api\/javno\/blog\/slika\/([\w-]+)$/.exec(p);
    if (ms) { const c = objavljeni().find(x => x.id === ms[1]); if (!c || !c.slika || !fs.existsSync(slikaPot(c.id))) { bad(res, 404, "Slike ni."); return true; } res.writeHead(200, { "Content-Type": "image/jpeg", "Cache-Control": "public, max-age=3600", "X-Content-Type-Options": "nosniff" }); res.end(fs.readFileSync(slikaPot(c.id))); return true; }
    const m = /^\/api\/javno\/blog\/([a-z0-9-]+)$/.exec(p);
    if (m) { const c = objavljeni().find(x => x.slug === m[1]); if (!c) { bad(res, 404, "Članka ni."); return true; } send(res, 200, Object.assign(javno(c), { html: vHtml(c.besedilo, javnaSlika(c)) })); return true; }
    return false;
  }

  // ---------- strani bloga (HTML iz strežnika, da jih najdejo iskalniki): /blog/ in /blog/<članek> ----------
  const glava = m => `<!doctype html>
<html lang="sl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
${seo().meta(m)}
<link rel="icon" href="../favicon.png"><link rel="stylesheet" href="../stran.css"></head><body>
<header><div class="w"><a href="../" aria-label="HiGiFood – domov"><img class="logo s" src="../logo-svetlo.png" width="600" height="353" alt="HiGiFood – Z znanjem do varne hrane!"><img class="logo t" src="../logo-temno.png" width="600" height="353" alt=""></a>
<nav aria-label="Glavni meni"><a href="../#funkcije">Funkcije</a><a href="../#cenik">Cenik</a><a href="./">Blog</a><a href="../#povprasevanje">Povpraševanje</a><a class="btn" data-prijava href="/">Prijava</a></nav></div></header>`;
  const noga = `<footer><div class="w"><span>© <span id="leto">2026</span> HiGiFood · Z znanjem do varne hrane!</span><span class="nog"><a href="../zasebnost.html">Politika zasebnosti</a><a href="../piskotki.html">Piškotki</a><button type="button" class="pov" data-piskotki>Nastavitve piškotkov</button><a href="../novice.html#odjava">Odjava od novic</a><a data-prijava href="/">Prijava v platformo</a></span></div></footer>
<script src="../stran.js"></script></body></html>`;
  const slikaUrl = c => "/api/javno/blog/slika/" + c.id;
  // pot za stran: "" (seznam) ali "<slug>"; base = absolutni naslov strani (https://higifood.si/ ali …/stran/), predogled = noindex; vrne { status, html }
  function blogHtml(rel, base, predogled) {
    rel = String(rel || "").replace(/\/+$/, ""); base = base || "/";
    const abs = u => { try { return new URL(u, base).href; } catch { return u; } };
    if (!rel) {
      const a = objavljeni(), s = seo().stran("blog");
      const jl = [{ "@context": "https://schema.org", "@type": "Blog", name: "Blog HiGiFood", url: base + "blog/", inLanguage: "sl-SI", description: s.opis, publisher: seo().organizacija(base), blogPost: a.slice(0, 20).map(c => ({ "@type": "BlogPosting", headline: c.naslov, url: base + "blog/" + c.slug, datePublished: c.objavljeno })) }];
      return { status: 200, html: glava({ naslov: s.naslov, opis: s.opis, kljucne: s.kljucne, url: base + "blog/", slika: base + "logo-svetlo.png", noindex: predogled, jsonld: jl }) + `<main><section><div class="w"><p class="kicker">Blog</p><h1 class="bl-h">Nasveti o HACCP in varni hrani</h1><p class="sub">Predpisi, inšpekcija in dobra praksa v živilskih obratih – razloženo preprosto.</p>
<div class="bl-g">${a.map(c => `<article class="k bl-k">${c.slika ? `<a href="${esc(c.slug)}" tabindex="-1" aria-hidden="true"><img src="${slikaUrl(c)}" alt="" loading="lazy"></a>` : ""}<p class="mut">${esc(datum(c.objavljeno))}</p><h2><a href="${esc(c.slug)}">${esc(c.naslov)}</a></h2><p>${esc(c.povzetek)}</p></article>`).join("") || '<p class="sub">Prvi članki bodo kmalu objavljeni. <a href="../novice.html">Prijavite se na novice</a> in obvestili vas bomo.</p>'}</div></div></section></main>` + noga };
    }
    const c = objavljeni().find(x => x.slug === rel);
    if (!c) return { status: 404, html: glava({ naslov: "Članka ni – HiGiFood", opis: "Članka ni mogoče najti.", noindex: true }) + `<main><section><div class="w pravno"><h1>Članka ni mogoče najti</h1><p>Morda je bil umaknjen. <a href="./">Vsi članki</a></p></div></section></main>` + noga };
    const url = base + "blog/" + c.slug, opis = c.seo_opis || c.povzetek || golo(c.besedilo).replace(/\s+/g, " ").slice(0, 160), slika = c.slika ? abs(slikaUrl(c)) : base + "logo-svetlo.png";
    const jl = [{ "@context": "https://schema.org", "@type": "BlogPosting", headline: c.naslov.slice(0, 110), description: opis, url, mainEntityOfPage: url, image: slika, datePublished: c.objavljeno, dateModified: c.spremenjeno && c.spremenjeno > c.objavljeno ? c.spremenjeno : c.objavljeno, inLanguage: "sl-SI", author: { "@type": "Person", name: c.avtor_ime || "HiGiFood" }, publisher: seo().organizacija(base), ...(c.kljucne_besede ? { keywords: c.kljucne_besede } : {}) },
      { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [{ "@type": "ListItem", position: 1, name: "HiGiFood", item: base }, { "@type": "ListItem", position: 2, name: "Blog", item: base + "blog/" }, { "@type": "ListItem", position: 3, name: c.naslov, item: url }] }];
    return { status: 200, html: glava({ naslov: c.seo_naslov || c.naslov + " | HiGiFood", opis, kljucne: c.kljucne_besede || "", url, slika, tip: "article", noindex: predogled, jsonld: jl, objavljeno: c.objavljeno, spremenjeno: c.spremenjeno }) + `<main><section><article class="w pravno bl-c"><p class="kicker"><a href="./">Blog</a></p><h1>${esc(c.naslov)}</h1>
<p class="mut"><time datetime="${esc(c.objavljeno)}">${esc(datum(c.objavljeno))}</time>${c.avtor_ime ? " · " + esc(c.avtor_ime) : ""}</p>${c.slika ? `<img class="bl-slika" src="${slikaUrl(c)}" alt="${esc(c.naslov)}">` : ""}${c.povzetek ? `<p class="lead">${esc(c.povzetek)}</p>` : ""}
${vHtml(c.besedilo, javnaSlika(c))}
<div class="k bl-cta"><h3>Želite urejen HACCP brez papirja?</h3><p>Pokažemo vam, kako HiGiFood deluje v vašem obratu.</p><p style="margin-top:12px"><a class="btn" href="../#povprasevanje">Pošljite povpraševanje</a> <a class="btn o" href="../novice.html">Prijava na novice</a></p></div>
<p><a href="./">← Vsi članki</a></p></article></section></main>` + noga };
  }

  // ---------- urednik (administrator in svetovalec) ----------
  async function rUrednik(req, res, p, url, me, ip) {
    if (!p.startsWith("/api/blog-urednik")) return undefined;
    if (!["admin", "svetovalec"].includes(me.vloga)) { bad(res, 403, "Blog urejata administrator in svetovalec."); return true; }
    const d = preberi();
    if (p === "/api/blog-urednik/predogled" && req.method === "POST") { const b = await jbody(req, res); if (!b) return true; const c = d.clanki.find(x => x.id === b.id && (me.vloga === "admin" || x.avtor_id === me.id || x.stanje === "objavljen")); send(res, 200, { html: vHtml(cist(b.besedilo, 100000), c ? urednikovaSlika(c) : null) }); return true; }
    if (p === "/api/blog-urednik" && req.method === "GET") { send(res, 200, { clanki: d.clanki.filter(c => me.vloga === "admin" || c.avtor_id === me.id || c.stanje === "objavljen").sort((a, b) => (b.spremenjeno || b.ustvarjeno).localeCompare(a.spremenjeno || a.ustvarjeno)), stran: stranUrl(), narocnikov: narocniki().length }); return true; }
    // vsebina iz telesa zahteve (naslov, povzetek, besedilo, slika kot JPEG v base64 ali null za odstranitev)
    const vsebina = (c, b) => {
      if (b.naslov !== undefined) { c.naslov = cist(b.naslov, 160); if (!c.naslov) return "Vpišite naslov članka."; }
      if (b.povzetek !== undefined) c.povzetek = cist(b.povzetek, 300);
      if (b.seo_naslov !== undefined) c.seo_naslov = cist(b.seo_naslov, 70).replace(/\n/g, " ");
      if (b.seo_opis !== undefined) c.seo_opis = cist(b.seo_opis, 170).replace(/\n/g, " ");
      if (b.kljucne_besede !== undefined) c.kljucne_besede = cist(b.kljucne_besede, 300).replace(/\n/g, " ").split(",").map(x => x.trim()).filter(Boolean).slice(0, 15).join(", ");
      if (b.besedilo !== undefined) { c.besedilo = cist(b.besedilo, 100000); pocistiSlike(c); }
      if (b.slika === null) { try { fs.unlinkSync(slikaPot(c.id)); } catch {} c.slika = false; }
      else if (typeof b.slika === "string" && b.slika) { const buf = Buffer.from(b.slika, "base64"); if (buf.length < 100 || buf.length > 3e6 || buf[0] !== 0xff || buf[1] !== 0xd8 || buf[2] !== 0xff) return "Slika mora biti JPEG do 3 MB."; fs.mkdirSync(SLIKE, { recursive: true }); fs.writeFileSync(slikaPot(c.id), buf); c.slika = true; }
      return "";
    };
    if (p === "/api/blog-urednik" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true;
      const c = { id: uid(), naslov: "", povzetek: "", besedilo: "", slika: false, stanje: "osnutek", avtor_id: me.id, avtor_ime: me.ime || me.email, ustvarjeno: now() };
      const e = vsebina(c, Object.assign({ naslov: "" }, b)); if (e) { bad(res, 400, e); return true; }
      c.slug = unikaten(slugOf(c.naslov), c.id); d.clanki.push(c); shrani(); audit(me, "blog-nov", "blog", c.id, c.naslov, ip); send(res, 200, c); return true;
    }
    // slike v besedilu: nalaganje (urednik članka) in ogled (tudi osnutkov)
    const mi = /^\/api\/blog-urednik\/([\w-]+)\/slike(?:\/([\w-]+))?$/.exec(p);
    if (mi) {
      const c = d.clanki.find(x => x.id === mi[1]);
      if (!c || !(me.vloga === "admin" || c.avtor_id === me.id || c.stanje === "objavljen")) { bad(res, 404, "Članka ni mogoče najti."); return true; }
      if (mi[2] && req.method === "GET") { if (!(c.slike || []).includes(mi[2]) || !fs.existsSync(vsebinskaPot(c.id, mi[2]))) { bad(res, 404, "Slike ni."); return true; } posljiSliko(res, vsebinskaPot(c.id, mi[2]), false); return true; }
      if (!mi[2] && req.method === "POST") {
        if (!smeUrejati(me, c)) { bad(res, 403, "Slike dodaja urednik članka."); return true; }
        if ((c.slike || []).length >= 40) { bad(res, 400, "Članek ima že 40 slik."); return true; }
        const b = await jbody(req, res); if (!b) return true; const buf = Buffer.from(String(b.slika || ""), "base64");
        if (!jeJpeg(buf)) { bad(res, 400, "Slika mora biti JPEG do 3 MB."); return true; }
        const sid = uid(); fs.mkdirSync(SLIKE, { recursive: true }); fs.writeFileSync(vsebinskaPot(c.id, sid), buf); c.slike = (c.slike || []).concat(sid); shrani();
        audit(me, "blog-slika", "blog", c.id, sid, ip); send(res, 200, { id: sid, oznaka: "slika:" + sid }); return true;
      }
      return undefined;
    }
    const m = /^\/api\/blog-urednik\/([\w-]+)(\/novice)?$/.exec(p); if (!m) return undefined;
    const c = d.clanki.find(x => x.id === m[1]);
    if (!c || !(me.vloga === "admin" || c.avtor_id === me.id || c.stanje === "objavljen")) { bad(res, 404, "Članka ni mogoče najti."); return true; }
    if (m[2] && req.method === "POST") { // pošlji objavljen članek potrjenim naročnikom novic (vsakemu posebej, s povezavo za odjavo)
      if (me.vloga !== "admin") { bad(res, 403, "Članek naročnikom pošlje administrator."); return true; }
      if (c.stanje !== "objavljen" || c.objavljeno > now()) { bad(res, 400, "Pošljete lahko samo objavljen članek (ne načrtovanega)."); return true; }
      const st = stranUrl(); if (!st) { bad(res, 400, "Nastavite naslov spletne strani (HACCP_SPLETNA_URL), da bodo povezave v e-pošti pravilne."); return true; }
      const L = narocniki(); let ok = 0, nap = 0;
      for (const n of L) { try { await posljiPosto(n.email, c.naslov, `${golo(c.povzetek || "")}\n\n${golo(c.besedilo).slice(0, 1200)}${c.besedilo.length > 1200 ? " …" : ""}\n\nPreberite celoten članek: ${st}blog/${c.slug}\n\n—\nTo sporočilo ste prejeli, ker ste se prijavili na novice HiGiFood. Odjava: ${st}novice.html?odjava=${n.odjava}\n`); ok++; } catch (e) { nap++; if (nap === 1) console.error("Blog: pošiljanje novic: " + e.message); } }
      c.poslano_novicam = now(); c.poslano_st = ok; shrani(); audit(me, "blog-novice", "blog", c.id, ok + " poslanih, " + nap + " napak", ip);
      send(res, 200, { poslano: ok, napak: nap }); return true;
    }
    if (req.method === "PUT") {
      if (!smeUrejati(me, c)) { bad(res, 403, c.stanje === "objavljen" ? "Objavljen članek ureja administrator." : "Urejate lahko samo svoje članke."); return true; }
      const b = await jbody(req, res); if (!b) return true;
      if (b.stanje !== undefined && !STANJA.includes(b.stanje)) { bad(res, 400, "Neveljavno stanje."); return true; }
      if (b.stanje === "objavljen" && me.vloga !== "admin") { bad(res, 403, "Članek objavi administrator. Pošljite ga v pregled."); return true; }
      const e = vsebina(c, b); if (e) { bad(res, 400, e); return true; }
      if (b.naslov !== undefined && c.stanje !== "objavljen") c.slug = unikaten(slugOf(c.naslov), c.id); // povezava objavljenega članka ostane enaka
      const prej = c.stanje;
      const ob = b.objava !== undefined && me.vloga === "admin" && b.objava ? new Date(b.objava) : null;
      if (b.objava !== undefined && b.objava && (!ob || isNaN(ob))) { bad(res, 400, "Neveljaven čas objave."); return true; }
      if (b.stanje !== undefined) { c.stanje = b.stanje; if (b.stanje === "objavljen" && !c.objavljeno) c.objavljeno = ob ? ob.toISOString() : now(); if (b.stanje !== "objavljen") delete c.objavljeno; }
      else if (ob && c.stanje === "objavljen") c.objavljeno = ob.toISOString(); // sprememba časa objave
      c.spremenjeno = now(); c.spremenil_ime = me.ime || me.email; shrani();
      audit(me, prej !== c.stanje ? "blog-" + (c.stanje === "objavljen" ? "objava" : c.stanje === "za pregled" ? "v-pregled" : "umik") : "blog-urejanje", "blog", c.id, c.naslov, ip);
      send(res, 200, c); return true;
    }
    if (req.method === "DELETE") {
      if (!smeUrejati(me, c)) { bad(res, 403, "Članek lahko izbriše administrator ali avtor (dokler ni objavljen)."); return true; }
      try { fs.unlinkSync(slikaPot(c.id)); } catch {}
      for (const sid of c.slike || []) try { fs.unlinkSync(vsebinskaPot(c.id, sid)); } catch {}
      d.clanki.splice(d.clanki.indexOf(c), 1); shrani(); audit(me, "blog-izbris", "blog", c.id, c.naslov, ip); send(res, 200, { ok: true }); return true;
    }
    return undefined;
  }
  return { rJavno, rUrednik, blogHtml, vHtml, slugOf, objavljeni };
};
