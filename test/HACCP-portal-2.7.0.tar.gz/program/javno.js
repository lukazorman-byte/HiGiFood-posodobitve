// Javna spletna stran: povpraševanja in prijava na novice (z dvojno potrditvijo) ter odjava.
// Podatki: _javno.json v podatkovni bazi (shramba.js). Varstvo podatkov (GDPR): samo nujni podatki, zapisano soglasje (besedilo, čas,
// zgoščen IP), novice samo s potrjenim soglasjem, odjava kadar koli (zapis se izbriše), roki hrambe: povpraševanje 12 mesecev, nepotrjena prijava 7 dni.
const path = require("path"), crypto = require("crypto");
const { hasRole } = require("./vloge");

const SOGLASJE_POVPRASEVANJE = "Strinjam se, da HiGiFood obdeluje moje podatke za odgovor na povpraševanje (Politika zasebnosti).";
const SOGLASJE_NOVICE = "Želim prejemati novice HiGiFood po e-pošti (občasno, največ enkrat na mesec). Odjava je mogoča kadar koli.";
const HRAMBA_POVPRASEVANJ_DNI = 365, POTRDITEV_DNI = 7;
const emailOk = e => typeof e === "string" && e.length <= 200 && /^[^@\s<>"']+@[^@\s<>"']+\.[^@\s<>"']{2,}$/.test(e);
const cist = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, "").trim().slice(0, n);

module.exports = function javno({ DIR, S, send, bad, jbody, audit, now, uid, posljiPosto, kontakt, admini, naroceni }) {
  const F = path.join(DIR, "_javno.json"), sh = t => crypto.createHash("sha256").update(String(t)).digest("hex");
  let cache = null;
  const preberi = () => { if (!cache) { try { cache = S.beri(F, {}); } catch { cache = {}; } cache = Object.assign({ povprasevanja: [], novice: [] }, cache); } return cache; };
  const shrani = () => S.pisi(F, cache);
  // roki hrambe: stara povpraševanja in nepotrjene prijave se izbrišejo
  function pocisti() {
    const d = preberi(), t = Date.now(), pred = d.povprasevanja.length + d.novice.length;
    d.povprasevanja = d.povprasevanja.filter(x => t - Date.parse(x.cas) < HRAMBA_POVPRASEVANJ_DNI * 864e5);
    d.novice = d.novice.filter(x => x.stanje === "potrjen" || t - Date.parse(x.ustvarjeno) < POTRDITEV_DNI * 864e5);
    if (d.povprasevanja.length + d.novice.length !== pred) shrani();
  }
  // omejitev zahtevkov na IP (zaščita pred zlorabo obrazca): največ n v eni uri
  const stevci = new Map();
  const prevec = (ip, vrsta, n) => { const k = vrsta + "|" + ip, t = Date.now(), a = (stevci.get(k) || []).filter(x => t - x < 3600e3); a.push(t); stevci.set(k, a); if (stevci.size > 5000) stevci.clear(); return a.length > n; };
  // naslov strani za povezave v e-pošti: mapa strani, s katere je prišla zahteva (higifood.si/ ali …/stran/)
  function osnova(req) {
    if (process.env.HACCP_SPLETNA_URL) return process.env.HACCP_SPLETNA_URL.replace(/\/?$/, "/");
    const host = String(req.headers.host || "localhost"), proto = req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
    let dir = "/"; try { const r = new URL(req.headers.referer || ""); if (r.host === host) dir = r.pathname.replace(/[^/]*$/, ""); } catch {}
    return proto + "://" + host + dir;
  }
  // naslov izdajatelja (sicer administratorji) in uporabniki, ki so v »Moj račun« vklopili obvestila o povpraševanjih
  const prejemniki = () => { const k = kontakt() || {}; return [...new Set((k.email ? [k.email] : admini()).concat(naroceni ? naroceni() : []).map(e => String(e).toLowerCase()))]; };
  const zaIzpis = x => Object.fromEntries(Object.entries(x).filter(([k]) => !["potrdi_h", "potrdi_do"].includes(k)));
  // naslov spletne strani za povezave za odjavo v izvozu (HACCP_SPLETNA_URL ali prva domena iz HACCP_SPLETNA_STRAN)
  const stranUrl = () => process.env.HACCP_SPLETNA_URL ? process.env.HACCP_SPLETNA_URL.replace(/\/?$/, "/") : process.env.HACCP_SPLETNA_STRAN ? "https://" + process.env.HACCP_SPLETNA_STRAN.split(",")[0].trim() + "/" : "";

  async function posljiPotrditev(req, z, t) {
    const pov = osnova(req) + "novice.html?potrdi=" + encodeURIComponent(t);
    await posljiPosto(z.email, "Potrdite prijavo na novice HiGiFood", "Pozdravljeni,\n\nza ta e-naslov je bila oddana prijava na novice HiGiFood. Prijavo potrdite s klikom na povezavo (velja " + POTRDITEV_DNI + " dni):\n\n" + pov + "\n\nČe se niste prijavili vi, to sporočilo prezrite – brez potrditve vam novic ne bomo pošiljali, vaš naslov pa bomo po " + POTRDITEV_DNI + " dneh izbrisali.\n\nHiGiFood – Z znanjem do varne hrane!\n");
  }
  // prijava na novice: nov zapis s soglasjem ali ponovno pošiljanje potrditve; odgovor ne razkrije, ali je naslov že prijavljen
  async function prijavaNovice(req, email, ip, vir) {
    const d = preberi(); let z = d.novice.find(x => x.email.toLowerCase() === email.toLowerCase());
    if (z && z.stanje === "potrjen") return "ze";
    const t = crypto.randomBytes(24).toString("base64url");
    if (!z) { z = { id: uid(), email, stanje: "caka", ustvarjeno: now(), odjava: crypto.randomBytes(24).toString("base64url"), soglasje: { besedilo: SOGLASJE_NOVICE, cas: now(), ip_h: sh(ip).slice(0, 16), vir } }; d.novice.push(z); }
    z.potrdi_h = sh(t); z.potrdi_do = Date.now() + POTRDITEV_DNI * 864e5; shrani();
    await posljiPotrditev(req, z, t); audit(null, "novice-prijava", "", z.id, vir, ip); return "poslano";
  }

  // javne poti (brez prijave): /api/javno/povprasevanje, /api/javno/novice/{prijava,potrdi,odjava}
  async function rJavno(req, res, p, ip) {
    if (req.method !== "POST" || !/^\/api\/javno\/(povprasevanje|novice\/(prijava|potrdi|odjava))$/.test(p)) return false;
    pocisti();
    const b = await jbody(req, res); if (!b) return true;
    if (p === "/api/javno/povprasevanje") {
      if (prevec(ip, "pov", 5)) { bad(res, 429, "Preveč povpraševanj z istega naslova. Poskusite čez eno uro ali nam pišite po e-pošti."); return true; }
      if (cist(b.spletna_stran, 200)) { send(res, 200, { ok: true }); return true; } // past za robote: izpolni jo samo program
      const z = { id: uid(), cas: now(), ime: cist(b.ime, 100), podjetje: cist(b.podjetje, 150), email: cist(b.email, 200), telefon: cist(b.telefon, 40), obratov: cist(b.obratov, 10), dejavnost: cist(b.dejavnost, 100), sporocilo: cist(b.sporocilo, 3000), stanje: "novo" };
      if (!z.ime) { bad(res, 400, "Vpišite ime in priimek."); return true; }
      if (!emailOk(z.email)) { bad(res, 400, "Vpišite veljaven e-naslov."); return true; }
      if (z.telefon && !/^[+\d][\d\s/().-]{5,}$/.test(z.telefon)) { bad(res, 400, "Telefonska številka ni veljavna."); return true; }
      if (b.soglasje !== true) { bad(res, 400, "Za oddajo povpraševanja potrebujemo vaše soglasje z obdelavo podatkov."); return true; }
      z.soglasje = { besedilo: SOGLASJE_POVPRASEVANJE, cas: now(), ip_h: sh(ip).slice(0, 16) };
      preberi().povprasevanja.push(z); shrani(); audit(null, "povprasevanje", "", z.id, z.podjetje || z.ime, ip);
      for (const to of prejemniki()) posljiPosto(to, "Novo povpraševanje: " + (z.podjetje || z.ime), ["Novo povpraševanje s spletne strani HiGiFood:", "", "Ime: " + z.ime, "Podjetje: " + (z.podjetje || "–"), "E-pošta: " + z.email, "Telefon: " + (z.telefon || "–"), "Dejavnost: " + (z.dejavnost || "–"), "Število obratov: " + (z.obratov || "–"), "", z.sporocilo || "(brez sporočila)", "", "Povpraševanje je shranjeno v platformi (Administracija → Spletna stran) in se samodejno izbriše po 12 mesecih."].join("\n")).catch(e => console.error("Povpraševanje: e-pošta ni bila poslana: " + e.message));
      let novice = "";
      if (b.novice === true) { try { novice = await prijavaNovice(req, z.email, ip, "povpraševanje"); } catch { novice = "napaka"; } }
      send(res, 200, { ok: true, novice }); return true;
    }
    if (p === "/api/javno/novice/prijava") {
      if (prevec(ip, "nov", 10)) { bad(res, 429, "Preveč prijav z istega naslova. Poskusite čez eno uro."); return true; }
      if (cist(b.spletna_stran, 200)) { send(res, 200, { ok: true }); return true; }
      const email = cist(b.email, 200); if (!emailOk(email)) { bad(res, 400, "Vpišite veljaven e-naslov."); return true; }
      if (b.soglasje !== true) { bad(res, 400, "Za prijavo na novice potrebujemo vaše soglasje."); return true; }
      try { await prijavaNovice(req, email, ip, "obrazec novice"); } catch (e) { console.error("Novice: potrditev ni bila poslana: " + e.message); bad(res, 503, "Potrditvenega sporočila trenutno ne moremo poslati. Poskusite pozneje."); return true; }
      send(res, 200, { ok: true }); return true; // enak odgovor, če je naslov že prijavljen (brez razkrivanja)
    }
    if (p === "/api/javno/novice/potrdi") {
      const d = preberi(), z = d.novice.find(x => x.potrdi_h && x.potrdi_h === sh(cist(b.t, 100)) && x.potrdi_do > Date.now());
      if (!z) { bad(res, 400, "Povezava za potrditev ni veljavna ali je potekla. Prijavite se znova."); return true; }
      z.stanje = "potrjen"; z.potrjeno = now(); delete z.potrdi_h; delete z.potrdi_do; shrani(); audit(null, "novice-potrjeno", "", z.id, "", ip);
      send(res, 200, { ok: true, odjava: z.odjava }); return true;
    }
    if (p === "/api/javno/novice/odjava") {
      if (prevec(ip, "odj", 20)) { bad(res, 429, "Preveč zahtevkov. Poskusite čez eno uro."); return true; }
      const d = preberi(), t = cist(b.t, 100), email = cist(b.email, 200).toLowerCase();
      const i = d.novice.findIndex(x => (t && x.odjava === t) || (email && x.email.toLowerCase() === email));
      if (t && i < 0) { bad(res, 400, "Povezava za odjavo ni veljavna ali ste že odjavljeni."); return true; }
      if (i >= 0) { const id = d.novice[i].id; d.novice.splice(i, 1); shrani(); audit(null, "novice-odjava", "", id, "", ip); }
      send(res, 200, { ok: true }); return true; // pri odjavi z e-naslovom enak odgovor ne glede na to, ali je bil prijavljen
    }
    return false;
  }

  // skrbniške poti (administrator): pregled in obdelava povpraševanj, seznam naročnikov novic
  async function rAdmin(req, res, p, url, me, ip) {
    if (!p.startsWith("/api/javno-admin")) return undefined;
    if (!hasRole(me, "admin")) { bad(res, 403, "To lahko naredi samo administrator."); return true; }
    pocisti(); const d = preberi();
    if (p === "/api/javno-admin" && req.method === "GET") { send(res, 200, { povprasevanja: d.povprasevanja.slice().sort((a, b) => b.cas.localeCompare(a.cas)), novice: d.novice.map(zaIzpis).sort((a, b) => b.ustvarjeno.localeCompare(a.ustvarjeno)), hramba_dni: HRAMBA_POVPRASEVANJ_DNI, stran_url: stranUrl() }); return true; }
    const m = /^\/api\/javno-admin\/(povprasevanja|novice)\/([\w-]+)$/.exec(p); if (!m) return undefined;
    const arr = d[m[1]], i = arr.findIndex(x => x.id === m[2]);
    if (i < 0) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan."); return true; }
    if (req.method === "PUT" && m[1] === "povprasevanja") { const b = await jbody(req, res); if (!b) return true; if (!["novo", "v obdelavi", "zaključeno"].includes(b.stanje)) { bad(res, 400, "Neveljavno stanje."); return true; } arr[i].stanje = b.stanje; arr[i].opomba = cist(b.opomba, 1000); shrani(); audit(me, "povprasevanje-stanje", "", arr[i].id, b.stanje, ip); send(res, 200, arr[i]); return true; }
    if (req.method === "DELETE") { const id = arr[i].id; arr.splice(i, 1); shrani(); audit(me, m[1] === "novice" ? "novice-izbris" : "povprasevanje-izbris", "", id, "", ip); send(res, 200, { ok: true }); return true; }
    return undefined;
  }
  // potrjeni naročniki novic (za pošiljanje članka iz bloga)
  const potrjeniNarocniki = () => preberi().novice.filter(n => n.stanje === "potrjen").map(n => ({ email: n.email, odjava: n.odjava }));
  return { rJavno, rAdmin, pocisti, potrjeniNarocniki, stranUrl, SOGLASJE_POVPRASEVANJE, SOGLASJE_NOVICE };
};
