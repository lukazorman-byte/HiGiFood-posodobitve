// Manjši popravki po testiranju z agenti (obrazci, seznami, koledar, nadzorna plošča, evidence).
const B = process.env.BASE;
const { chromium } = require("./pw.js");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = [];
  const ctx = await br.newContext({ viewport: { width: 1280, height: 900 }, timezoneId: "Europe/Ljubljana" }), pg = await ctx.newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Ana Admin"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  // koledar brez strank: + Dogodek
  await pg.goto(B + "/#/koledar"); await pg.waitForSelector("#cadd"); await pg.click("#cadd"); await pg.waitForSelector(".toast.show:has-text('Najprej dodajte stranko')"); ok(true, "koledar brez strank: »Najprej dodajte stranko«");
  const ids = await pg.evaluate(async () => {
    const s = await D.add("stranke", { naziv: "Kolesa d.o.o.", dejavnost: "Gostinstvo" }), s2 = await D.add("stranke", { naziv: "Druga d.o.o." }), s3 = await D.add("stranke", { naziv: "Izbrisana d.o.o." });
    await D.add("dogodki", { stranka_id: s3.id, naslov: "Rok izbrisane", datum: today() });
    for (let i = 0; i < 70; i++) await D.add("dogodki", { stranka_id: s.id, naslov: "Dogodek " + i, datum: addDays(today(), i % 25) });
    await D.add("dogodki", { stranka_id: s.id, naslov: "Sestanek z uro", datum: today(), ura: "09:30" });
    for (let i = 0; i < 2; i++) await D.add("dogodki", { stranka_id: s.id, naslov: "Danes " + i, datum: today() }); // danes vedno več kot 4 dogodki (tudi zadnji dan meseca)
    await D.add("ciscenje_nacrt", { stranka_id: s.id, opravilo: "Pomivanje tal", pogostost_dni: 1 }); await D.add("kemikalije", { stranka_id: s.id, naziv: "Razkužilo X" });
    await D.add("oprema", { stranka_id: s.id, naziv: "Hladilnik A", tip: "hladilnik", meja_min: 0, meja_max: 4 }); await D.add("oprema", { stranka_id: s.id, naziv: "Vitrina", tip: "hladilna vitrina" });
    await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", naprava: "Hladilnik A", frekvenca_ur: 24 }); await D.add("urnik", { stranka_id: s.id, vrsta: "temperatura", naprava: "Vitrina", frekvenca_ur: 24 });
    await D.add("evidence", { stranka_id: s.id, vrsta: "ciscenje", izvedeno: true, kontrola_ok: true });
    await api("DELETE", "/api/d/stranke/" + s3.id); return { s: s.id, s2: s2.id };
  });
  // seznam z neznano vrednostjo: dejavnost »Gostinstvo« (ni na seznamu) ostane
  await pg.evaluate(async id => openForm("stranke", (await D.list("stranke")).find(x => x.id === id), null, () => {}), ids.s); await pg.waitForSelector("#f_dejavnost");
  ok(await pg.inputValue("#f_dejavnost") === "Gostinstvo" && /prejšnja vrednost/.test(await pg.textContent("#f_dejavnost")), "izbirni seznam ohrani vrednost, ki je ni med možnostmi");
  await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok(await pg.evaluate(async id => (await D.list("stranke")).find(x => x.id === id).dejavnost, ids.s) === "Gostinstvo", "shranjevanje ne izbriše dejavnosti");
  // koledar: brez rokov izbrisane stranke, vsi roki, +N, ura
  await pg.goto(B + "/#/koledar"); await pg.reload(); await pg.waitForSelector(".cal");
  const kt = await pg.textContent("#view"); ok(!/Rok izbrisane/.test(kt), "koledar ne prikaže rokov izbrisane stranke");
  ok(await pg.locator("table.t tr.click").count() > 60, "tabela rokov ni odrezana pri 60 (" + await pg.locator("table.t tr.click").count() + ")");
  ok(/09:30 Sestanek z uro/.test(kt), "ura dogodka v koledarju");
  const vec = pg.locator(".cal-vec").first(); if (await vec.count()) { const pred = await pg.locator(".cal .d.today .ev:visible").count(); await pg.click(".cal .d.today .cal-vec"); ok(await pg.locator(".cal .d.today .ev:visible").count() > pred, "»+N« v celici prikaže vse dogodke dneva"); } else ok(false, "ni »+N« v celici");
  // nadzorna plošča: aktivnosti in filter
  await pg.goto(B + "/#/nadzorna"); await pg.waitForSelector(".kpi-bloki");
  const ak = (await pg.textContent("details:has-text('Zadnje aktivnosti')")).replace(/\s+/g, " ");
  ok(/Opravilo čiščenja: Pomivanje tal/.test(ak) && /Čistilo: Razkužilo X/.test(ak) && !/undefined/.test(ak), "zadnje aktivnosti: opravilo čiščenja in čistilo (brez »undefined«)");
  await pg.evaluate(async () => { const s = (await D.list("stranke"))[0]; }); await pg.click("details.filtri summary"); await pg.selectOption("#fs", ids.s); await pg.waitForTimeout(800);
  ok(await pg.locator("#fs option").count() === 3, "filter po stranki: v izbirnem seznamu ostanejo vse stranke");
  await pg.evaluate(() => sessionStorage.removeItem("dflt"));
  // naprava: menjava meja, preimenovanje → urnik
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.waitForSelector("#enew"); await pg.click("#enew"); await pg.click("button[data-v=temperatura]"); await pg.waitForSelector("#f_oprema");
  await pg.selectOption("#f_oprema", "Hladilnik A"); ok(await pg.inputValue("#f_max") === "4", "meje iz naprave"); await pg.selectOption("#f_oprema", "Vitrina"); ok(await pg.inputValue("#f_max") === "" && await pg.inputValue("#f_min") === "", "menjava naprave počisti meje prejšnje naprave");
  await pg.selectOption("#f_oprema", "Hladilnik A"); await pg.fill("#f_vrednost", "abc"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => /mora biti število/.test(document.querySelector("#ferr").textContent + ((document.querySelector("#f_vrednost").closest(".f").querySelector(".f-err") || {}).textContent || ""))); ok(true, "nesmiselna vrednost: »mora biti število« (ob polju)");
  await pg.fill("#f_vrednost", "3,5"); await pg.click("#dlg-f .btn:last-child"); await pg.waitForFunction(() => !document.querySelector("dialog[open]"));
  ok(await pg.evaluate(async id => (await D.list("evidence", { stranka_id: id })).some(e => e.vrednost === 3.5), ids.s), "decimalna vejica »3,5« shranjena kot 3.5");
  const op = await pg.evaluate(async id => (await D.list("oprema", { stranka_id: id })).find(x => x.naziv === "Hladilnik A").id, ids.s);
  await pg.evaluate(async o => D.set("oprema", o, { naziv: "Hladilnik A (kuhinja)" }), op);
  ok(await pg.evaluate(async id => (await D.list("urnik", { stranka_id: id }))[0].naprava, ids.s) === "Hladilnik A (kuhinja)", "preimenovanje naprave posodobi urnik");
  // CAPA iz zapisa brez HTML-entitet
  const eid = await pg.evaluate(async id => (await D.add("evidence", { stranka_id: id, vrsta: "prevzem", izdelek: "Sir & šunka <A>", vrednost: 9, max: 4, embalaza_ok: true, dokumenti_ok: true })).id, ids.s);
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.reload(); await pg.waitForSelector(`tr[data-id="${eid}"]`); await pg.click(`tr[data-id="${eid}"] td >> nth=0`); await pg.click("#dlg-f button:has-text('Odpri neskladnost')");
  await pg.waitForSelector("#f_opis"); const opis = await pg.inputValue("#f_opis"); ok(/Sir & šunka <A>/.test(opis) && !/&amp;|&lt;/.test(opis), "samodejna CAPA iz zapisa: opis brez HTML-entitet (" + opis.slice(0, 80) + ")"); await pg.click("#dlg-x");
  // Danes: hiter vnos z vejico, vrstica manjkajočega vnosa izgine
  await pg.goto(B + "/#/danes"); await pg.reload(); await pg.waitForSelector("#ht_0");
  // vitrina še nima zapisa (hladilnik ima zapis pred preimenovanjem, ki se upošteva)
  const iv = await pg.$$eval(".ht-vr label b", l => l.findIndex(x => x.textContent === "Vitrina"));
  const pred = await pg.locator('tr[data-mv="temperatura"]').count(); await pg.fill("#ht_" + iv, "2,5"); await pg.press("#ht_" + iv, "Enter"); await pg.waitForSelector("#htr_" + iv + " .badge");
  ok(pred >= 1 && await pg.locator('tr[data-mv="temperatura"]').count() === 0, "Danes: po hitrem vnosu vrstica »manjka vnos« izgine (z decimalno vejico)");
  // brez povezave: zapis v čakalni vrsti je viden, opozorilo o odstopanju
  await pg.goto(B + "/#/stranka/" + ids.s + "/evidence"); await pg.waitForSelector("#enew"); await ctx.setOffline(true);
  await pg.click("#enew"); await pg.click("button[data-v=temperatura]"); await pg.selectOption("#f_oprema", "Hladilnik A (kuhinja)").catch(() => {}); await pg.fill("#f_vrednost", "9"); await pg.fill("#f_max", "4"); await pg.click("#dlg-f .btn:last-child");
  await pg.waitForSelector(".toast.show:has-text('Brez povezave')"); ok(/odstopanje/i.test(await pg.textContent("#toast")), "brez povezave: obvestilo vključuje ODSTOPANJE");
  await pg.waitForSelector("tr[data-id^='q']"); ok(/čaka na pošiljanje/.test(await pg.textContent("tr[data-id^='q']")), "zapis v čakalni vrsti je viden v seznamu z oznako");
  await ctx.setOffline(false); await pg.evaluate(() => syncOffQueue()); await pg.waitForTimeout(500);
  // svetovalec: brez gumba Izbriši pri stranki; admin: po izbrisu na seznam strank
  await pg.evaluate(async () => api("POST", "/api/uporabniki", { ime: "Sv", email: "sv@t.si", geslo: "dolgogeslo123", vloga: "svetovalec", stranke: [] }));
  await pg.evaluate(async id => { const u = (await api("GET", "/api/uporabniki")).find(x => x.email === "sv@t.si"); await api("PUT", "/api/uporabniki/" + u.id, { stranke: [id] }); }, ids.s2);
  const sv = await (await br.newContext()).newPage(); await sv.goto(B + "/"); await sv.fill("#le", "sv@t.si"); await sv.fill("#lp", "dolgogeslo123"); await sv.click("#lf button"); await sv.waitForSelector("#shell:not([hidden])");
  if (await sv.locator("#p0").count()) { await sv.fill("#p0", "dolgogeslo123"); await sv.fill("#p1", "novogeslo12345"); await sv.click("#dlg-f .btn:last-child"); await sv.waitForFunction(() => !document.querySelector("dialog[open]")); }
  await sv.evaluate(async id => openForm("stranke", (await D.list("stranke")).find(x => x.id === id), null, () => {}), ids.s2); await sv.waitForSelector("#f_naziv");
  ok(await sv.locator("#dlg-f button:has-text('Izbriši')").count() === 0, "svetovalec: v obrazcu stranke ni gumba Izbriši");
  await pg.goto(B + "/#/stranka/" + ids.s2 + "/podatki"); await pg.waitForSelector("#tabbody"); await pg.evaluate(async id => openForm("stranke", (await D.list("stranke")).find(x => x.id === id), null, () => {}), ids.s2); await pg.waitForSelector("#f_naziv");
  pg.once("dialog", d => d.accept()); await pg.click("#dlg-f button:has-text('Izbriši')"); await pg.waitForFunction(() => location.hash === "#/stranke"); ok(true, "po izbrisu stranke preusmeritev na seznam strank");
  // podvojena davčna: vprašanje
  await pg.evaluate(async id => D.set("stranke", id, { davcna: "12345679" }), ids.s);
  await pg.evaluate(() => openForm("stranke", null, null, () => {})); await pg.waitForSelector("#f_naziv"); await pg.fill("#f_naziv", "Dvojnik d.o.o."); await pg.fill("#f_davcna", "SI12345679");
  let vpr = ""; pg.once("dialog", d => { vpr = d.message(); d.dismiss(); }); await pg.click("#dlg-f .btn:last-child"); await pg.waitForTimeout(500);
  ok(/že obstaja: Kolesa d\.o\.o\./.test(vpr) && await pg.locator("dialog[open]").count() === 1, "podvojena davčna: vprašanje, preklic ne shrani");
  // dolg naziv brez presledkov ne razširi strani
  const m = await (await br.newContext({ viewport: { width: 390, height: 800 }, storageState: await ctx.storageState() })).newPage();
  await m.evaluate(() => 0).catch(() => {}); await m.goto(B + "/"); await m.waitForSelector("#shell:not([hidden])");
  const did = await m.evaluate(async () => (await D.add("stranke", { naziv: "Zeloooo".repeat(40) })).id); await m.goto(B + "/#/stranka/" + did + "/podatki"); await m.waitForSelector("#tabbody"); await m.waitForTimeout(300);
  ok(await m.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), "dolg naziv brez presledkov ne razširi profila stranke");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
