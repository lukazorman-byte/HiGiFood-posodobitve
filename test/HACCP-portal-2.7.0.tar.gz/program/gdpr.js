// Izvoz osebnih podatkov posameznika (čl. 15 in 20 GDPR) in izvoz podatkov stranke.
// Strežnik izbere samo podatke, ki se nanašajo na osebo, in jih očisti (gesla, TOTP, seje, ključi API, hash verige, interni naslovi
// infrastrukture nikoli ne zapustijo strežnika). ZIP (PDF, HTML, CSV, JSON, priloge) sestavi brskalnik.
// Obseg (čl. 15(4) GDPR – pravica do kopije ne sme posegati v pravice drugih): račun osebe, revizijska sled njenih dejanj in dejanj na
// njenem računu, zapisi, kjer nastopa (ustvaril/spremenil, ime ali e-naslov v polju, član HACCP skupine, udeleženec usposabljanja …).
// Iz takih zapisov se izvozijo samo opisna poslovna polja; osebna polja le, če je vrednost oseba sama; drugi uporabniki so prikazani z vlogo.
module.exports = function (o) {
  const { fs, path, load, COLL, auditRead, vsebuje, vzorecOsebe, nrmI, vlogeOf, glavnaVloga, mojiPodatki, kontakt, PRIL, ILOGO, gdprNast } = o;
  const DRUG = "drug uporabnik";
  // opisna (poslovna) polja po zbirkah; ostala polja samo, če vsebujejo osebo (takrat z njenim imenom)
  const POLJA = {
    stranke: ["naziv", "dejavnost", "status"], obrati: ["naziv", "naslov", "vrsta", "status"], dobavitelji: ["naziv", "kategorija", "ocena"],
    oprema: ["naziv", "tip", "lokacija", "naslednji_servis"], usposabljanja: ["tema", "datum", "veljavno_do"], navodila: ["naslov", "vrsta", "verzija_oznaka", "status"],
    evidence: ["vrsta", "cas", "status"], capa: ["cas", "proces", "tveganje", "status", "rok"], ciscenje_nacrt: ["podrocje", "opravilo", "pogostost_dni", "krat_na_dan"],
    jedi: ["naziv", "skupina"], dogodki: ["naslov", "datum", "ura", "vrsta", "status"], storitve: ["datum", "vrsta", "minute"], sarze: ["izdelek", "sarza", "datum_prevzema"],
    vabe: ["oznaka", "vrsta", "lokacija", "status"], kemikalije: ["naziv"], tlorisi: ["naziv"], urnik: ["vrsta", "naprava"], priloge: ["ime", "tip", "velikost"], certifikacija: ["standard", "tocka", "ocena"]
  };
  const OSEBJE = ["ime", "funkcija", "email", "higienski_do", "zdravniski_do", "datum_odhoda", "opomba"];
  const SKRITO = /^(geslo|totp_|seja|zeton|token|api_kljuc|oblak_|kopija_geslo|h$|revizije$|vsebina$|razlicice$|slike$|podatki$|_t$)/;
  const SISTEM = new Set(["id", "stranka_id", "obrat_id", "ustvarjeno", "ustvaril", "ustvaril_ime", "spremenjeno", "spremenil", "spremenil_ime", "verzija"]);
  // interni naslovi infrastrukture in poti v opisih dejanj
  const OPIS_FIKSEN = { "kopija-oblak": "Varnostna kopija shranjena v oblak", "kopija-oblak-zdaj": "Varnostna kopija shranjena v oblak", "kopija-mapa": "Mapa za varnostne kopije nastavljena", "posodobitev-naslov": "Naslov za posodobitve programa spremenjen", "nastavitve-obvestil": "Nastavitve e-pošte spremenjene", "nastavitve": "Nastavitve spremenjene", "baza-pisanje": "Baza znanja spremenjena" };
  const cistiOpis = (s, emaili) => String(s || "")
    .replace(/\b[a-z][a-z0-9+.-]*:\/\/[^\s,;)"']+/gi, "[naslov odstranjen]")
    .replace(/\b[\w.-]+\.(?:r2\.cloudflarestorage\.com|amazonaws\.com|backblazeb2\.com|digitaloceanspaces\.com|wasabisys\.com)\b/gi, "[naslov odstranjen]")
    .replace(/(?:[a-zA-Z]:\\|\\\\)[^\s,;]+/g, "[pot odstranjena]")
    .replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, m => emaili.has(m.toLowerCase()) ? m : "[e-naslov]");
  const ime = (m, id) => (id && m[id]) || "";
  function izvozOsebe(q, me, users) {
    const qi = String(q.ime || "").trim(), qe = String(q.email || "").trim().toLowerCase();
    const iskani = [qi, qe].filter(x => nrmI(x).length >= 3).map(vzorecOsebe);
    const racuni = users.filter(x => (qe && x.email === qe) || (qi && nrmI(x.ime) === nrmI(qi)));
    const ids = new Set(racuni.map(u => u.id)), emaili = new Set([qe, ...racuni.map(u => u.email)].filter(Boolean));
    const oseba = qi || (racuni[0] && racuni[0].ime) || qe;
    const je = v => typeof v === "string" && vsebuje(v, iskani);
    const kdo = (uid, nm) => uid && ids.has(uid) || je(nm) ? oseba : uid || nm ? DRUG : "";
    const sm = Object.fromEntries(load("stranke").map(s => [s.id, s.kratko_ime || s.naziv])), om = Object.fromEntries(load("obrati").map(s => [s.id, s.naziv]));
    const zapisi = {}; let izpusceno = 0;
    for (const c of Object.keys(COLL)) {
      const out = [];
      for (const r of load(c)) {
        const revOs = (r.revizije || []).some(v => ids.has(v.uporabnik) || je(v.ime)), omen = vsebuje(r, iskani);
        if (!(ids.has(r.ustvaril) || ids.has(r.spremenil) || revOs || omen)) continue;
        if (c === "osebje" && !(je(r.ime) || (r.email && emaili.has(String(r.email).toLowerCase())))) { izpusceno++; continue; } // zapis o drugi osebi
        const x = { id: r.id };
        if (r.stranka_id) { x.stranka_id = r.stranka_id; x.stranka = ime(sm, r.stranka_id); }
        if (r.obrat_id) { x.obrat_id = r.obrat_id; x.obrat = ime(om, r.obrat_id); }
        const nastopa = [];
        if (ids.has(r.ustvaril) || je(r.ustvaril_ime)) nastopa.push("ustvaril");
        if (ids.has(r.spremenil) || je(r.spremenil_ime)) nastopa.push("spremenil");
        for (const k of c === "osebje" ? OSEBJE : POLJA[c] || ["naziv", "naslov", "ime", "vrsta", "status", "datum"]) if (r[k] !== undefined && r[k] !== "" && r[k] !== null) x[k] = r[k];
        for (const [k, v] of Object.entries(r)) {
          if (SISTEM.has(k) || SKRITO.test(k) || k in x) continue;
          if (vsebuje(v, iskani)) { x[k] = typeof v === "string" && /e-?mail|email/.test(k) ? v : oseba; nastopa.push(k); } // osebno polje: samo oseba, ne drugi navedeni
        }
        if (c === "nacrti") Object.assign(x, povzetekNacrta(r, kdo, je, oseba, nastopa));
        if (revOs && !nastopa.includes("zgodovina sprememb")) nastopa.push("zgodovina sprememb");
        if (c === "osebje" && !nastopa.includes("ime")) nastopa.push("ime");
        x.ustvarjeno = r.ustvarjeno || ""; x.ustvaril = kdo(r.ustvaril, r.ustvaril_ime); x.spremenjeno = r.spremenjeno || ""; x.spremenil = kdo(r.spremenil, r.spremenil_ime);
        x.nastopa = [...new Set(nastopa)];
        out.push(x);
      }
      if (out.length) zapisi[c] = out;
    }
    const lastniOsebje = new Set((zapisi.osebje || []).map(x => x.id));
    // koš: samo opis izbrisanega zapisa (brez vsebine – pri računih bi vseboval hash gesla)
    const kos = load("_kos").filter(it => vsebuje([it.ime, it.zapis], iskani) || ids.has(it.zapis && it.zapis.ustvaril))
      .filter(it => !["osebje", "uporabniki"].includes(it.zbirka) || je(it.ime) || ids.has(it.zapis && it.zapis.id))
      .map(it => ({ zbirka: it.zbirka, naziv: it.zbirka === "uporabniki" || it.zbirka === "osebje" ? oseba : String(it.ime || "").slice(0, 120), stranka: ime(sm, it.stranka_id), izbrisano: it.cas, izbrisal: kdo(null, it.izbrisal) }));
    if (kos.length) zapisi["koš (izbrisano)"] = kos;
    // revizijska sled: dejanja osebe in dejanja drugih na njenem računu ali z njenim imenom; drugi izvajalci le z vlogo, brez IP
    const sled = [];
    for (const e of auditRead(1e6)) {
      const lastno = ids.has(e.uporabnik) || (!e.uporabnik && je(e.ime)) || (ids.size === 0 && je(e.ime));
      const omenjen = (e.zbirka === "uporabniki" && ids.has(e.id)) || je(e.opis);
      if (!lastno && !omenjen) continue;
      let opis = OPIS_FIKSEN[e.akcija] || cistiOpis(e.opis, emaili);
      if (lastno && ["osebje", "uporabniki"].includes(e.zbirka) && !ids.has(e.id) && !lastniOsebje.has(e.id) && !je(e.opis)) opis = "[podatki druge osebe]";
      sled.push({ cas: e.cas, akcija: e.akcija, zbirka: e.zbirka || "", opis, izvedel: lastno ? oseba : e.vloga || DRUG, vloga: e.vloga || "", ip: lastno ? e.ip || "" : "" });
    }
    sled.sort((a, b) => String(a.cas).localeCompare(String(b.cas)));
    // priloge, ki jih je naložila oseba, in logotip / podpis iz »Moji podatki«
    const priloge = load("priloge").filter(p => ids.has(p.ustvaril)).map(p => ({ id: p.id, ime: p.ime, tip: p.tip, velikost: p.velikost, stranka: ime(sm, p.stranka_id), ustvarjeno: p.ustvarjeno }));
    const datoteke = [];
    for (const u of racuni) for (const [suf, naz] of [["", "logotip"], [".podpis", "podpis"]]) {
      const f = path.join(ILOGO, u.id + suf + ".bin"); if (!fs.existsSync(f)) continue;
      let tip = "image/png"; try { tip = JSON.parse(fs.readFileSync(path.join(ILOGO, u.id + suf + ".json"), "utf8")).tip || tip; } catch {}
      datoteke.push({ ime: naz + (racuni.length > 1 ? "-" + u.id : ""), tip, podatki: fs.readFileSync(f).toString("base64") });
    }
    const uporabniski_racuni = racuni.map(u => {
      const st = [...new Set([u.stranka_id, ...(u.stranke || [])].filter(Boolean))], mp = mojiPodatki(u);
      return { id: u.id, ime: u.ime, email: u.email, vloge: vlogeOf(u), stranke: st.map(id => ({ id, naziv: ime(sm, id) || "(izbrisana stranka)" })), aktiven: u.aktiven !== false,
        dvostopenjska_prijava: !!u.totp_vklop, zadnja_prijava: u.zadnja_prijava || null, ustvarjeno: u.ustvarjeno || null,
        moji_podatki: Object.fromEntries(["naziv", "izobrazba", "funkcija", "podjetje", "naslov", "email", "telefon"].map(k => [k, mp[k] || ""]).filter(([, v]) => v)) };
    });
    let k = {}; try { k = kontakt() || {}; } catch {}
    return { izvozeno: new Date().toISOString(), izvozil: { ime: me.ime, vloga: glavnaVloga(vlogeOf(me)) }, zahteval: String(q.zahteval || "").trim().slice(0, 120) || "posameznik sam",
      oseba: { ime: qi, email: qe }, uporabniski_racuni, zapisi, izpusceno_zapisov_drugih_oseb: izpusceno, revizijska_sled: sled, priloge, datoteke,
      upravljavec: { naziv: k.naziv || "", naslov: k.naslov || "", email: k.email || "", telefon: k.telefon || "" }, hramba_osebje_let: gdprNast().hramba_osebje_let };
  }
  // HACCP načrt: samo povzetek (brez vsebine posameznih revizij)
  function povzetekNacrta(r, kdo, je, oseba, nastopa) {
    const W = r.vsebina && typeof r.vsebina === "object" ? r.vsebina : {}, kon = Object.values(W.kontrole || {});
    const clani = ((W.zbiranje || {}).clani || []).filter(c => je(c.ime));
    if (clani.length || je((W.zbiranje || {}).hacc_ekipa)) nastopa.push("haccp_skupina");
    return {
      stevilo: { koraki: (W.koraki || []).length, nevarnosti: (W.nevarnosti || []).length, oprp: kon.filter(c => c.vrsta === "OPRP").length, ccp: kon.filter(c => c.vrsta === "CCP").length },
      haccp_skupina: clani.length ? clani.map(c => c.vloga || "član").join(", ") : je((W.zbiranje || {}).hacc_ekipa) ? "član" : "",
      razlicice: (r.razlicice || []).map(v => ({ oznaka: v.oznaka || "", datum: v.datum || "", opis: v.opis || "", potrdil: v.potrdil ? (je(v.potrdil) ? oseba : "strokovna oseba") : "" })),
      zgodovina: (r.revizije || []).map(v => ({ razlicica: v.n, cas: v.cas, kdo: kdo(v.uporabnik, v.ime), razlog: String(v.razlog || "").slice(0, 200) }))
    };
  }
  // celoten izvoz stranke (poslovni podatki), brez skrivnosti in brez računov drugih
  function izvozStranke(sid) {
    const out = {};
    for (const c of Object.keys(COLL)) {
      const arr = c === "stranke" ? load(c).filter(r => r.id === sid) : load(c).filter(r => r.stranka_id === sid);
      if (arr.length) out[c] = arr.map(r => { const x = {}; for (const [k, v] of Object.entries(r)) if (!/^(geslo|totp_|_t$)/.test(k)) x[k] = v; return x; });
    }
    const priloge = (out.priloge || []).filter(p => fs.existsSync(path.join(PRIL, p.id))).map(p => ({ id: p.id, ime: p.ime, tip: p.tip }));
    return { izvozeno: new Date().toISOString(), stranka_id: sid, zapisi: out, priloge };
  }
  return { izvozOsebe, izvozStranke };
};
