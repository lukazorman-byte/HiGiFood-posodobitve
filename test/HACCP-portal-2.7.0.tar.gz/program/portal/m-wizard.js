// Čarovnik HACCP: 7 korakov. Predlogi so označeni in zahtevajo strokovno potrditev; CCP/OPRP/PRP vedno izbere uporabnik.
const WSTEPS = ["Zbiranje podatkov", "Dejavnost in živila", "Procesni koraki", "Analiza nevarnosti", "Kontrolni ukrepi", "Pregled osnutka", "Izvoz"];
const HTIPI = { B: "Biološka", K: "Kemična", F: "Fizikalna", A: "Alergen", C: "Navzkrižna kontaminacija", T: "Čas / temperatura", D: "Druga" };
const KTIPI = ["tehnološki", "prevzem", "skladiščenje", "priprava", "toplotna obdelava", "hlajenje", "pakiranje", "prodaja / izdaja", "drugo"];
const DEF_METODA = { nizko_do: 4, srednje_do: 11, verjetnost: ["1 – zelo malo verjetno", "2 – malo verjetno", "3 – možno", "4 – verjetno", "5 – zelo verjetno"], teza: ["1 – neznatne posledice", "2 – lažje posledice", "3 – zmerne posledice", "4 – hude posledice", "5 – zelo hude / smrtne posledice"] };
const rizikRazred = (r, m) => r <= m.nizko_do ? "nizko" : r <= m.srednje_do ? "srednje" : "visoko";
const rizik = h => (+h.verjetnost || 0) * (+h.teza || 0);
const CCPPOL = ["kaj", "mejna", "mejna_vir", "spremljanje", "pogostost", "odgovoren", "korektivni", "verifikacija"];
const uidc = () => Math.random().toString(36).slice(2, 9);
// enotno stanje nevarnosti: potrjena je samo s kljukico »pregledal in potrjujem«; urejen predlog in ročni vnos čakata na potrditev,
// sprememba ali izbris koraka zahteva ponovni pregled (starejši ročni vnosi brez oznake veljajo za potrjene)
const HSTAT = { potrjeno: ["ok", "potrjeno"], predlog: ["warn", "predlog"], urejeno: ["warn", "uredil uporabnik – potrdi"], nepotrjeno: ["warn", "nepotrjeno"], preveri: ["bad", "korak spremenjen – preveri"] };
function hazStatus(h) {
  if (h.preveri_korak) return "preveri";
  if (h.potrjeno === true || (h.potrjeno === undefined && !h.predlog && !h.urejeno)) return "potrjeno";
  return h.urejeno ? "urejeno" : h.predlog ? "predlog" : "nepotrjeno";
}
const hazBadge = h => { const [c, t] = HSTAT[hazStatus(h)]; return `<span class="badge ${c}">${t}</span>`; };
// oznake CCP in OPRP (CCP1, OPRP2 …) za tabele, diagram in dokument: številka se ob prvi potrditvi ukrepa zaklene (W.kontrole[id].oznaka)
// in se ob premiku korakov ne spreminja; novi ukrepi dobijo naslednjo prosto številko; »Preštevilči« (korak 5) jih uredi po vrstnem redu korakov
function ccpOznakePoRedu(W) {
  const red = id => { const i = W.koraki.findIndex(k => k.id === id); return i < 0 ? 1e6 : i; }, n = { CCP: 0, OPRP: 0 }, out = {};
  W.nevarnosti.filter(h => ["CCP", "OPRP"].includes((W.kontrole[h.id] || {}).vrsta)).sort((a, b) => red(a.korak_id) - red(b.korak_id))
    .forEach(h => { const v = W.kontrole[h.id].vrsta; out[h.id] = v + (++n[v]); });
  return out;
}
function ccpOznake(W) {
  const red = id => { const i = W.koraki.findIndex(k => k.id === id); return i < 0 ? 1e6 : i; }, max = { CCP: 0, OPRP: 0 }, out = {}, upor = new Set();
  const kand = W.nevarnosti.filter(h => ["CCP", "OPRP"].includes((W.kontrole[h.id] || {}).vrsta));
  for (const h of kand) { const c = W.kontrole[h.id], m = /^(CCP|OPRP)(\d+)$/.exec(c.oznaka || ""); if (m && m[1] === c.vrsta && !upor.has(c.oznaka)) { out[h.id] = c.oznaka; upor.add(c.oznaka); max[m[1]] = Math.max(max[m[1]], +m[2]); } }
  kand.filter(h => !out[h.id]).sort((a, b) => red(a.korak_id) - red(b.korak_id)).forEach(h => { const v = W.kontrole[h.id].vrsta; out[h.id] = v + (++max[v]); });
  return out;
}
// zaklene trenutne oznake (ob potrditvi ukrepa in kot migracija starejših načrtov: ohrani številke, kot so bile prikazane)
function zakleniOznake(W) { const oz = ccpOznake(W); for (const [hid, c] of Object.entries(W.kontrole || {})) { if (oz[hid]) c.oznaka = oz[hid]; else if (c && c.oznaka) delete c.oznaka; } return oz; }
// oznake v prostem besedilu, ki se zamenjajo ob izvozu: {{CCP:<korak_id ali naziv>}}, {{OPRP:<…>}}, {{seznam_CCP}}, {{stevilo_CCP}} (tudi _OPRP)
function zamenjajOznake(t, W, oz) {
  if (!t || !/\{\{/.test(t)) return t;
  oz = oz || ccpOznake(W); const kor = id => W.koraki.find(k => k.id === id) || {};
  const po = v => W.nevarnosti.filter(h => (oz[h.id] || "").startsWith(v) && (W.kontrole[h.id] || {}).vrsta === v).sort((a, b) => oz[a.id].localeCompare(oz[b.id], "sl", { numeric: true }));
  return String(t).replace(/\{\{\s*(CCP|OPRP)\s*:\s*([^}]+?)\s*\}\}/g, (m, v, x) => { const l = po(v).filter(h => h.korak_id === x || String(kor(h.korak_id).naziv || "").trim().toLowerCase() === x.toLowerCase()).map(h => oz[h.id]); return l.length ? l.join(", ") : `[MANJKA: ${v} za »${x}« ne obstaja]`; })
    .replace(/\{\{\s*seznam_(CCP|OPRP)\s*\}\}/g, (m, v) => po(v).map(h => oz[h.id] + " (" + (kor(h.korak_id).naziv || "–") + ")").join(", ") || "ni določenih")
    .replace(/\{\{\s*stevilo_(CCP|OPRP)\s*\}\}/g, (m, v) => String(po(v).length));
}
const ALG_EU_RE = /gluten|žit|pšenic|ječm|(?<!\p{L})rž|oves|rak|jajc|rib|araši|soj|mlek|laktoz|oreš|oreh|lešnik|mandelj|pistacij|zelen|gorčic|sezam|sulfit|žvepl|so2|volčj|mehkuž/iu;
// različice dokumenta (1.0, 1.1 …): ločeno od interne številke zapisa; nova različica ob potrditvi načrta (z datumom in opisom)
function razliciceDokumenta(rec) {
  if (Array.isArray(rec.razlicice) && rec.razlicice.length) return rec.razlicice;
  // starejši načrti: potrjen načrt brez evidence različic – trenutna različica kot prva izdaja
  return rec.status === "potrjeno" ? [{ oznaka: rec.verzija_oznaka || "1.0", datum: rec.datum_potrditve || String(rec.spremenjeno || rec.ustvarjeno || "").slice(0, 10), opis: "Prva izdaja", potrdil: rec.potrdil || "" }] : [];
}
const naslednjaRazlicica = o => { const m = /^(\d+)\.(\d+)$/.exec(String(o || "").trim()); return m ? m[1] + "." + (+m[2] + 1) : "1.0"; };
const ccpNaKoraku = (W, kid) => { const o = ccpOznake(W); return W.nevarnosti.filter(h => h.korak_id === kid && /^CCP/.test(o[h.id] || "")).map(h => o[h.id]); };

// vsebina načrta z vsemi polji (tudi starejši zapisi)
// opis režima iz baze: razpon ali enostranska meja (≥ / ≤), ne »72 do «
const rezimOpis = r => { if (r.enota) return r.predloga || ""; const od = r.od !== undefined && r.od !== null && r.od !== "", dO = r.do !== undefined && r.do !== null && r.do !== ""; return od && dO ? fnum(r.od) + " do " + fnum(r.do) + " °C" : od ? "≥ " + fnum(r.od) + " °C" : dO ? "≤ " + fnum(r.do) + " °C" : ""; };
// kdo in kdaj je potrdil načrt: potrditev načrta (Osnovni podatki) ima prednost pred vnosom v koraku 6 čarovnika
// Potrditev velja kot opravljena samo, če je načrt v stanju »potrjeno«, potrjevalec je vpisan in datum ni v prihodnosti.
// Sicer je to le »predvideni strokovni pregled« (osnutek). Potrjevalec se nikoli ne vzame iz prijavljenega uporabnika.
function potrditevNacrta(rec, W) {
  const pr = (W || (rec.vsebina && typeof rec.vsebina === "object" ? rec.vsebina : {})).pregled || {};
  const potrdil = rec.status === "potrjeno" && rec.potrdil ? rec.potrdil : pr.potrdil || rec.potrdil || "", datum = (rec.status === "potrjeno" && rec.potrdil ? rec.datum_potrditve || pr.datum : pr.datum || rec.datum_potrditve) || "";
  const prihodnost = !!datum && String(datum).slice(0, 10) > today();
  return { potrdil, datum, prihodnost, opravljena: rec.status === "potrjeno" && !!potrdil && !!datum && !prihodnost };
}
// zgodovina načrta za dokument: samo vsebinske spremembe z razlogom in spremembe stanja (brez samodejnih shranjevanj čarovnika)
const SAMODEJNO_SHRANJEVANJE = /^(Posodobitev vsebine v čarovniku|Samodejno shranjevanje.*|Urejanje tlorisa.*|)$/i;
// podpisna polja na naslovnici: izdelovalec in odgovorna oseba (ime in datum le, ko je načrt res potrjen)
function podpisiNacrta(rec, W, stranka) {
  const po = potrditevNacrta(rec, W), iz = izdelovalecNacrta(rec), od = odobrilZa(rec.stranka_id, stranka), opis = z => [z.izobrazba, z.funkcija].filter(Boolean).join(", "), ps = podpisZa(iz);
  const eo = odobritevNacrta(rec);
  if (eo && eo.veljavna) return [{ vloga: "Izdelal (svetovalec)", ime: imeZNazivom(iz), opis: opis(iz), datum: "", podpis_slika: ps }, { vloga: "Odobril (odgovorna oseba)", ime: od.ime ? imeZNazivom(od) : eo.potrdil_ime, opis: opis(od), datum: String(eo.cas).slice(0, 10), podpis_tekst: "Odobreno elektronsko " + fdt(eo.cas) }];
  return [{ vloga: "Izdelal (svetovalec)", ime: imeZNazivom(iz), opis: opis(iz), datum: "", podpis_slika: ps }, { vloga: "Odobril (odgovorna oseba)", ime: po.opravljena && po.potrdil && po.potrdil !== od.ime ? po.potrdil : imeZNazivom(od), opis: po.opravljena && po.potrdil && po.potrdil !== od.ime ? "" : opis(od), datum: po.opravljena ? po.datum : "" }];
}
// letna revizija potrjenega načrta in pregled po spremembi naprav ali prostorov obrata (enako na strežniku za e-poštne opomnike)
function letnaRevizija(n) { if (n.status !== "potrjeno" || !n.datum_potrditve) return ""; const x = new Date(String(n.datum_potrditve).slice(0, 10) + "T00:00:00Z"); if (isNaN(x)) return ""; x.setUTCFullYear(x.getUTCFullYear() + 1); return x.toISOString().slice(0, 10); }
const pregledPoSpremembi = (n, ob) => !!ob && !!ob.sprememba_opreme && ob.sprememba_opreme > String(n.pregled_opreme || n.spremenjeno || n.ustvarjeno || "");
function zgodovinaNacrta(rec) { return (rec.revizije || []).filter(r => !SAMODEJNO_SHRANJEVANJE.test(String(r.razlog || "").trim()) || (r.prej && "status" in r.prej)); }
function vsebinaNacrta(rec) {
  const W = rec.vsebina && typeof rec.vsebina === "object" ? rec.vsebina : {};
  W.zbiranje = W.zbiranje || {}; W.zivila = W.zivila || []; W.kontrole = W.kontrole || {}; W.nevarnosti = W.nevarnosti || []; W.koraki = W.koraki || []; W.koraki = W.koraki || []; W.nevarnosti = W.nevarnosti || []; W.kontrole = W.kontrole || {}; W.metoda = Object.assign({}, DEF_METODA, W.metoda || {}); W.pregled = W.pregled || {}; W.besedila = W.besedila || {}; W.branza = W.branza || "";
  zakleniOznake(W); // migracija: številke CCP/OPRP, kot so bile prikazane, se zaklenejo
  // migracija: besedilo, ki ni alergen EU (»Drugo / opomba«), se iz alergenov prenese v ločeno opombo (nič se ne izgubi)
  for (const z of W.zivila) { if (!z.alergeni || z.alergeni_opomba !== undefined) continue; const pr = /\(preveriti\)/i.test(z.alergeni), deli = alergeniZivila(z), eu = deli.filter(d => ALG_EU_RE.test(d)), dr = deli.filter(d => !ALG_EU_RE.test(d));
    if (dr.length) { z.alergeni_opomba = dr.join(", "); z.alergeni = (eu.length ? eu.join(", ") : /ni alergenov/i.test(z.alergeni) ? "ni alergenov" : "") + (pr ? " (preveriti)" : ""); } }
  return W;
}
async function pageCarovnik(v, m) {
  const id = m[1];
  const plans = await D.list("nacrti"), rec = plans.find(p => p.id === id);
  if (!rec) throw new Error("Načrt ni najden ali nimate dostopa.");
  let stranka = (await D.list("stranke")).find(s => s.id === rec.stranka_id); await loadStrankaLogo(stranka);
  let obrati = await D.list("obrati", { stranka_id: rec.stranka_id });
  // sveži podatki (spremembe v Podatkih, Obratih in Navodilih po odprtju čarovnika) – za korak 7 in izvoz
  const osvezi = async () => {
    const [s, o, n] = await Promise.all([api("GET", "/api/d/stranke/" + rec.stranka_id), api("GET", "/api/d/obrati?stranka_id=" + encodeURIComponent(rec.stranka_id)), api("GET", "/api/d/navodila?stranka_id=" + encodeURIComponent(rec.stranka_id))]);
    stranka = s; obrati = o; await naloziPodpis(izdelovalecNacrta(rec)); return n;
  };
  const tlorisi = await D.list("tlorisi", { stranka_id: rec.stranka_id }).catch(() => []);
  const osebje = await D.list("osebje", { stranka_id: rec.stranka_id }).catch(() => []);
  const db = await baza(); await naloziIzdelovalca(rec.stranka_id);
  const W = vsebinaNacrta(rec);
  const obratNacrta = obrati.find(o => o.id === rec.obrat_id), spremObrat = () => pregledPoSpremembi(rec, obratNacrta);
  const brezSvetovalca = svetovalecManjka(rec.stranka_id); // stranka brez dodeljenega svetovalca načrta ne more urejati (preveri tudi strežnik)
  const editable = canManage() && rec.status !== "potrjeno" && !brezSvetovalca;
  let step = +(sessionStorage.getItem("wstep:" + id) || 0), dirty = false;
  $("#title").textContent = "Čarovnik: " + rec.naziv;
  let urejanj = 0; // števec sprememb: shranjevanje v ozadju ne sme izbrisati oznake za spremembe, narejene med shranjevanjem
  const mark = () => { dirty = true; urejanj++; const b = $("#wsave"); if (b) b.textContent = "Shrani spremembe *"; };
  const verOznaka = () => `${esc(sIme(stranka))} · ${badge(rec.status)} · različica zapisa ${rec.verzija}`;
  const save = async (razlog, samodejno) => {
    const zap = { vsebina: W, _razlog: razlog || "Posodobitev vsebine v čarovniku" };
    if (spremObrat()) {
      // samodejno shranjevanje pregleda po spremembi obrata ne zaključi; ročno shranjevanje vpraša za razlog (zapiše se v zgodovino)
      if (samodejno) zap.pregled_opreme = rec.pregled_opreme || rec.spremenjeno || rec.ustvarjeno || "";
      else {
        const rz = await vprasaj(`Naprave ali prostori obrata »${obratNacrta.naziv}« so bili spremenjeni ${fdt(obratNacrta.sprememba_opreme)}. Na kratko opišite, kaj ste pregledali oziroma spremenili v načrtu.`, { naslov: "Razlog spremembe načrta", vnos: "Razlog (zapiše se v zgodovino)", min: 5 });
        if (rz === null) return;
        zap._razlog = "Pregled po spremembi naprav ali prostorov obrata: " + rz; zap.pregled_opreme = obratNacrta.sprememba_opreme;
      }
    }
    const pri = urejanj, r = await D.set("nacrti", id, zap); Object.assign(rec, r);
    if (!spremObrat()) { const p = $("#wspr"); if (p) p.remove(); }
    if (pri === urejanj) { dirty = false; const b = $("#wsave"); if (b) b.textContent = "Shrani"; }
    const o = $("#wver"); if (o) o.innerHTML = verOznaka();
    toast((samodejno ? "Shranjeno samodejno" : "Shranjeno") + " (različica " + r.verzija + ")");
  };
  // menjava koraka: neshranjene spremembe se shranijo samodejno
  const pojdi = n => {
    const shrani = dirty && editable;
    step = Math.max(0, Math.min(WSTEPS.length - 1, n)); draw(); window.scrollTo(0, 0);
    if (shrani) save("Samodejno shranjevanje ob menjavi koraka", true).catch(fail);
  };
  // stanje koraka za koračnik: "" (prazno), "delno", "polno"
  const stanjeKoraka = i => {
    const Z = W.zbiranje, sig = W.nevarnosti.filter(h => rizik(h) > W.metoda.nizko_do);
    switch (i) {
      case 0: return Z.obseg && Z.hacc_ekipa ? "polno" : Z.zaposleni || Z.obseg || Z.hacc_ekipa || Z.kupci ? "delno" : "";
      case 1: return W.zivila.length ? (W.zivila.every(z => z.naziv) ? "polno" : "delno") : "";
      case 2: return W.koraki.length ? (W.koraki.every(k => k.naziv) ? "polno" : "delno") : "";
      case 3: return !W.nevarnosti.length ? "" : W.nevarnosti.every(h => rizik(h) && hazStatus(h) === "potrjeno" && W.koraki.some(k => k.id === h.korak_id)) ? "polno" : "delno";
      case 4: return !sig.length ? "" : sig.every(h => (W.kontrole[h.id] || {}).vrsta) ? "polno" : Object.keys(W.kontrole).length ? "delno" : "";
      case 5: return W.pregled.potrdil && W.pregled.datum ? "polno" : W.pregled.potrdil || W.besedila.uvod ? "delno" : "";
      default: return "";
    }
  };
  const KRATKO = ["Podatki", "Živila", "Koraki", "Nevarnosti", "Ukrepi", "Pregled", "Izvoz"], STOPIS = { "": "ni izpolnjeno", delno: "delno izpolnjeno", polno: "izpolnjeno" };
  const korakIme = kid => (W.koraki.find(k => k.id === kid) || {}).naziv || "–";
  const num = i => { const k = W.koraki.findIndex(x => x.id === i); return k < 0 ? "" : k + 1; };

  const draw = () => {
    sessionStorage.setItem("wstep:" + id, step);
    v.innerHTML = `${spremObrat() ? `<p class="note" id="wspr">Naprave ali prostori obrata »${esc(obratNacrta.naziv)}« so bili spremenjeni ${esc(fdt(obratNacrta.sprememba_opreme))}. Preglejte korake, nevarnosti in ukrepe ter shranite načrt (z razlogom).</p>` : ""}${!editable ? `<p class="note">${rec.status === "potrjeno" ? "Načrt je potrjen in zaklenjen za urejanje. Za spremembo najprej spremenite stanje načrta (z razlogom) v osnovnih podatkih." : brezSvetovalca ? "HACCP načrt izdela svetovalec. Vaše podjetje nima dodeljenega svetovalca, zato načrta ne morete urejati – obrnite se na administratorja." : "Za urejanje nimate pravic."}</p>` : ""}
    <div class="row"><a href="#/stranka/${rec.stranka_id}/nacrti" class="btn ghost sec sm">‹ Nazaj</a><span class="mut" id="wver">${verOznaka()}</span><span class="sp"></span>${editable ? `<button class="btn" id="wsave">${dirty ? "Shrani spremembe *" : "Shrani"}</button>` : ""}</div>
    <nav class="steps stepper" aria-label="Koraki čarovnika">${WSTEPS.map((s, i) => { const st = stanjeKoraka(i); return `<button data-s="${i}" class="${i === step ? "on" : ""} st-${st || "prazno"}" title="${i + 1}. ${s} – ${STOPIS[st]}" ${i === step ? 'aria-current="step"' : ""}><span class="st-n">${st === "polno" ? "✓" : i + 1}</span><span class="st-t">${KRATKO[i]}</span></button>`; }).join("")}</nav>
    <div id="wbody"></div>
    <div class="row" style="margin-top:14px"><button class="btn ghost sec" id="wprev" ${step === 0 ? "disabled" : ""}>‹ Nazaj</button><span class="sp"></span><button class="btn" id="wnext" ${step === 6 ? "disabled" : ""}>Naprej ›</button></div>`;
    $$(".steps button", v).forEach(b => b.onclick = () => pojdi(+b.dataset.s));
    $("#wprev").onclick = () => pojdi(step - 1); $("#wnext").onclick = () => pojdi(step + 1);
    if ($("#wsave")) $("#wsave").onclick = () => save().catch(fail);
    const body = $("#wbody");
    [s1, s2, s3, s4, s5, s6, s7][step](body);
    if (!editable) $$("#wbody input,#wbody select,#wbody textarea,#wbody .edit").forEach(e => { if (e.tagName === "BUTTON") e.disabled = true; else e.disabled = true; });
  };
  // povezava vnosnega polja na objekt
  const bindAll = (el, obj) => $$("[data-k]", el).forEach(i => { const k = i.dataset.k; if (i.type === "checkbox") i.checked = !!obj[k]; else i.value = obj[k] === undefined ? "" : obj[k]; i.oninput = i.onchange = () => { obj[k] = i.type === "checkbox" ? i.checked : i.value; mark(); }; });
  const inp = (k, l, o) => `<label class="f ${o && o.wide ? "wide" : ""}"><span>${l}</span>${o && o.area ? `<textarea data-k="${k}"></textarea>` : o && o.sel ? `<select data-k="${k}"><option value=""></option>${o.sel.map(x => `<option value="${esc(Array.isArray(x) ? x[0] : x)}">${esc(Array.isArray(x) ? x[1] : x)}</option>`).join("")}</select>` : `<input data-k="${k}" ${o && o.type ? `type="${o.type}"` : ""}>`}</label>`;

  // 1. zbiranje podatkov
  function s1(el) {
    const Z = W.zbiranje, ob = obrati.find(o => o.id === rec.obrat_id);
    const miss = missingData({ obrati, osebje: [{ stranka_id: stranka.id }], nacrti: [rec], dobavitelji: [{ stranka_id: stranka.id }] }, stranka).filter(x => !["seznam zaposlenih", "dobavitelji", "HACCP načrt"].includes(x));
    el.innerHTML = `<div class="card"><h2>1. Zbiranje podatkov</h2>${miss.length ? `<p class="note">V profilu stranke manjka: ${miss.map(esc).join(", ")}. <a href="#/stranka/${stranka.id}/podatki">Dopolni profil</a></p>` : ""}
    <p class="mut">Podatki podjetja in obrata se prevzamejo iz profila stranke. Tu dodajte, kar je pomembno za HACCP načrt.</p>
    <table class="t"><tr><th style="width:30%">Podjetje</th><td>${esc(stranka.naziv)}, ${esc(stranka.naslov || "naslov ni vnesen")}</td></tr><tr><th>Odgovorna oseba</th><td>${esc(stranka.odgovorna_oseba || "ni vnesena")}</td></tr><tr><th>Obrat</th><td>${ob ? esc(ob.naziv + (ob.naslov ? ", " + ob.naslov : "")) : "ni izbran (izberite v osnovnih podatkih načrta)"}</td></tr><tr><th>Prostori</th><td>${esc(ob ? seznamObrata(ob.prostori, ob.opis_prostorov) || "ni vnesen" : "")}</td></tr></table>
    <div class="fgrid" style="margin-top:12px">${inp("zaposleni", "Število zaposlenih", { type: "number" })}${inp("delovni_cas", "Delovni čas / sezonskost")}${inp("kupci", "Kupci in ciljne skupine (npr. splošna populacija, otroci, bolniki)")}${inp("prodaja", "Način prodaje / distribucije")}${inp("obseg", "Obseg HACCP načrta (kaj pokriva)", { wide: 1, area: 1 })}${inp("posebnosti", "Posebnosti (nove tehnologije, sezonske ponudbe, dostava …)", { wide: 1, area: 1 })}${inp("hacc_ekipa", "HACCP skupina (člani in vloge)", { wide: 1, area: 1 })}<div class="wide" style="grid-column:1/-1" id="tl_box"></div></div></div>`;
    const ekipa = () => osebje.map(o => o.ime + (o.funkcija ? " – " + o.funkcija : "")).join("\n");
    $(".fgrid", el).insertAdjacentHTML("beforebegin", osebje.length ? `<p class="note info" id="os_info">Razdelek Zaposleni: ${mnx(osebje.length, ["oseba", "osebi", "osebe", "oseb"])}. Število zaposlenih se prevzame samodejno, če ni vpisano. <button class="btn sm ghost edit" id="os_ek">Prevzemi zaposlene v HACCP skupino</button></p>` : `<p class="note" id="os_info">Razdelek Zaposleni je prazen. <a href="#/stranka/${stranka.id}/osebje">Dodajte zaposlene</a>, da se število zaposlenih in HACCP skupina izpolnita samodejno.</p>`);
    if (editable && !Z.zaposleni && osebje.length) { Z.zaposleni = String(osebje.length); mark(); }
    $(".fgrid", el).insertAdjacentHTML("afterend", `<h3>Registracija in dejavnost</h3><div class="fgrid">${inp("registracija", "Registracija / odobritev obrata (številka, organ)")}${inp("skd", "Šifra dejavnosti po SKD 2025")}${inp("dejavnost_registracija", "Dejavnost po registraciji", { wide: 1 })}</div><p class="mut" id="skd_op"></p>
    <h3>Način prodaje</h3><div class="row" id="np">${[["lokal", "v lokalu"], ["s_seboj", "za s seboj"], ["dostava", "dostava"]].map(([k, l]) => `<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-np="${k}" style="width:auto"> ${l}</label>`).join("")}</div>
    <h3>Kultura varnosti hrane</h3><p class="mut">Uredba (EU) 2021/382: zaveza vodstva, sporočanje težav, usposabljanje in redni pregled.</p><div class="fgrid">${inp("kultura_zaveza", "Zaveza vodstva", { wide: 1, area: 1 })}${inp("kultura_sporocanje", "Kako zaposleni sporočijo težave", { wide: 1, area: 1 })}${inp("kultura_usposabljanje", "Usposabljanje o varnosti hrane", { wide: 1, area: 1 })}${inp("kultura_pregled", "Pregled kulture varnosti hrane (kdaj, kdo)", { wide: 1, area: 1 })}</div>
    <h3>HACCP skupina</h3><div id="clani"></div>`);
    Z.nacin_prodaje = Array.isArray(Z.nacin_prodaje) ? Z.nacin_prodaje : [];
    $$("[data-np]", el).forEach(c => { c.checked = Z.nacin_prodaje.includes(c.dataset.np); c.onchange = () => { Z.nacin_prodaje = $$("[data-np]", el).filter(x => x.checked).map(x => x.dataset.np); mark(); }; });
    // SKD: opozorilo na star šifrant (SKD 2008 velja do konca leta 2024)
    const skdOp = () => { const v = String(Z.skd || "").trim(); $("#skd_op", el).textContent = v ? (Z.skd_2025 ? "" : "Preverite, da je šifra iz šifranta SKD 2025 (velja od 1. 1. 2025) in ne iz starega šifranta SKD 2008.") : ""; };
    const clani = () => { Z.clani = Array.isArray(Z.clani) ? Z.clani : []; const c = $("#clani", el);
      c.innerHTML = `<div class="tw"><table class="t"><tr><th>Ime in priimek</th><th>Vloga v HACCP skupini</th><th></th></tr>${Z.clani.map((x, i) => `<tr data-c="${i}"><td><input data-k="ime" aria-label="Ime člana ${i + 1}"></td><td><input data-k="vloga" aria-label="Vloga člana ${i + 1}" placeholder="npr. vodja HACCP skupine"></td><td><button type="button" class="btn sm ghost sec edit" data-cx="${i}" aria-label="Odstrani člana">✕</button></td></tr>`).join("")}</table></div><div class="row"><button type="button" class="btn sm ghost edit" id="c_add">+ Član</button>${osebje.length ? '<button type="button" class="btn sm ghost edit" id="c_os">Prevzemi zaposlene</button>' : ""}</div>`;
      $$("tr[data-c]", c).forEach(tr => bindAll(tr, Z.clani[+tr.dataset.c]));
      $("#c_add", c).onclick = () => { Z.clani.push({ ime: "", vloga: "" }); mark(); clani(); };
      $$("[data-cx]", c).forEach(b => b.onclick = () => { Z.clani.splice(+b.dataset.cx, 1); mark(); clani(); });
      const co = $("#c_os", c); if (co) co.onclick = () => { for (const o of osebje) if (!Z.clani.some(x => x.ime === o.ime)) Z.clani.push({ ime: o.ime, vloga: o.funkcija || "" }); mark(); clani(); };
    };
    bindAll(el, Z); clani(); skdOp(); $("[data-k=skd]", el).addEventListener("input", skdOp);
    const ek = $("#os_ek"); if (ek) ek.onclick = () => { const go = () => { Z.hacc_ekipa = ekipa(); $("[data-k=hacc_ekipa]", el).value = Z.hacc_ekipa; mark(); }; if (Z.hacc_ekipa && Z.hacc_ekipa.trim()) confirmBox("HACCP skupino zamenjam s seznamom zaposlenih (" + osebje.length + ")?", go); else go(); };
    // tlorisi v načrtu: več narisanih in naloženih (slike), vrstni red in naslov se prenesejo v dokumentacijo
    const tlSeznam = () => {
      const L = tlorisiNacrta(Z), box = $("#tl_box", el), proste = tlorisi.filter(t => !L.some(x => x.vrsta === "narisan" && x.id === t.id));
      const shrani = nov => { Z.tlorisi = nov; delete Z.tloris_id; delete Z.tloris_nacrt_id; mark(); tlSeznam(); };
      box.innerHTML = `<h3 style="margin-top:6px">Tlorisi (vstavijo se v dokumentacijo)</h3>${L.length ? `<div class="tw"><table class="t" id="tl_list"><tr><th>Naslov v dokumentu</th><th>Vir</th><th></th></tr>${L.map((x, i) => {
        const t = x.vrsta === "narisan" ? tlorisi.find(q => q.id === x.id) : null;
        return `<tr data-ti="${i}"><td><input data-tn="${i}" value="${esc(x.naslov || "")}" placeholder="${esc(t ? t.naziv : String(x.ime || "Tloris").replace(/\.[a-z0-9]{2,4}$/i, ""))}" aria-label="Naslov tlorisa ${i + 1}"></td><td>${x.vrsta === "narisan" ? (t ? `narisan: <a href="#/tloris/${esc(x.id)}">${esc(t.naziv)}</a>` : '<span class="badge bad">narisani tloris ne obstaja več</span>') : `slika: <a href="/api/priloga/${esc(x.id)}" target="_blank" rel="noopener">${esc(x.ime || "tloris")}</a>`}</td>
          <td style="white-space:nowrap"><button type="button" class="btn sm ghost sec edit" data-tg="${i}" aria-label="Premakni tloris ${i + 1} gor" ${i ? "" : "disabled"}>↑</button><button type="button" class="btn sm ghost sec edit" data-td="${i}" aria-label="Premakni tloris ${i + 1} dol" ${i < L.length - 1 ? "" : "disabled"}>↓</button><button type="button" class="btn sm ghost sec edit" data-tx="${i}" aria-label="Odstrani tloris ${i + 1}">✕</button></td></tr>`; }).join("")}</table></div>` : '<p class="mut" id="tl_st">Ni dodanih tlorisov.</p>'}
        <div class="row" style="margin-top:6px">${proste.length ? `<select id="tl_sel" aria-label="Narisani tloris"><option value="">narisani tloris …</option>${proste.map(t => `<option value="${esc(t.id)}">${esc(t.naziv)}</option>`).join("")}</select><button type="button" class="btn ghost edit" id="tl_add">Dodaj narisani</button>` : ""}
        <input type="file" id="tl_f" accept="image/*" multiple style="max-width:300px" aria-label="Slike tlorisov (lahko več)"><button type="button" class="btn ghost edit" id="tl_up">Naloži tlorise</button></div>
        <p class="mut" style="margin:4px 0 0">Izberete lahko več slik hkrati. Vrstni red in naslove določite v tabeli.</p>`;
      if (!editable) $$("button, input, select", box).forEach(x => { x.disabled = true; });
      $$("[data-tn]", box).forEach(i => i.oninput = () => { const L2 = tlorisiNacrta(Z); L2[+i.dataset.tn].naslov = i.value; Z.tlorisi = L2; delete Z.tloris_id; delete Z.tloris_nacrt_id; mark(); });
      const zdaj = () => tlorisiNacrta(Z); // trenutno stanje (vključno z vpisanimi naslovi)
      $$("[data-tx]", box).forEach(x => x.onclick = () => shrani(zdaj().filter((_, i) => i !== +x.dataset.tx)));
      const pre = (i, j) => { const n = zdaj(); [n[i], n[j]] = [n[j], n[i]]; shrani(n); };
      $$("[data-tg]", box).forEach(x => x.onclick = () => pre(+x.dataset.tg, +x.dataset.tg - 1)); $$("[data-td]", box).forEach(x => x.onclick = () => pre(+x.dataset.td, +x.dataset.td + 1));
      const ad = $("#tl_add", box); if (ad) ad.onclick = () => { const v = $("#tl_sel", box).value; if (!v) return toast("Izberite narisani tloris.", true); shrani(zdaj().concat([{ vrsta: "narisan", id: v, naslov: "" }])); };
      $("#tl_up", box).onclick = async () => {
        const vse = [...$("#tl_f", box).files], ff = vse.filter(f => /^image\/(png|jpeg|webp|gif)$/.test(f.type)), ne = vse.filter(f => !ff.includes(f));
        // PDF in druge datoteke se v dokument ne morejo vstaviti: jasno sporočilo namesto tihega izpusta
        if (ne.length) toast(`Ni slika (PNG, JPG, WebP): ${ne.map(f => f.name).join(", ")}. Tloris v PDF shranite kot sliko (npr. posnetek zaslona) in ga naložite znova.`, true);
        if (!ff.length) { if (!ne.length) toast("Izberite eno ali več slik.", true); return; }
        const nov = zdaj(), gb = $("#tl_up", box); gb.disabled = true; let n = 0;
        try { for (let i = 0; i < ff.length; i++) { gb.textContent = `Nalagam ${i + 1}/${ff.length} …`; const up = await uploadFile(ff[i], rec.stranka_id, "tloris", rec.obrat_id || null); nov.push({ vrsta: "slika", id: up.id, ime: ff[i].name, naslov: "" }); n++; } }
        catch (e) { fail(e); } finally { if (n) toast(mnx(n, ["tloris naložen", "tlorisa naložena", "tlorisi naloženi", "tlorisov naloženih"]) + " (ne pozabite shraniti)"); shrani(nov); }
      };
    };
    tlSeznam();
  }

  // 2. dejavnost in živila
  function s2(el) {
    el.innerHTML = `<div class="card"><h2>2. Dejavnost in živila</h2><div class="row"><label class="f" style="margin:0;min-width:280px"><span>Predloga dejavnosti (prilagodljiva)</span><select id="wb"><option value=""></option>${db.branze.map(b => `<option value="${esc(b.id)}" ${W.branza === b.id ? "selected" : ""}>${esc(b.naziv)}</option>`).join("")}</select></label><button class="btn ghost edit" id="wload">Naloži predlog korakov in nevarnosti</button></div>
    ${(() => { const dej = [stranka.dejavnost].concat(stranka.dodatne_dejavnosti || []).filter(Boolean), ids = [...new Set(dej.flatMap(d => DEJ_PREDLOGE[d] || []))].filter(i => db.branze.some(b => b.id === i)); return ids.length ? `<p class="mut" id="wpred">Predlagano glede na dejavnosti stranke (${esc(dej.join(", "))}): ${ids.map(i => `<button type="button" class="btn sm ghost edit" data-pb="${i}">${esc(db.branze.find(b => b.id === i).naziv)}</button>`).join(" ")}</p>` : ""; })()}
    <p class="note info">Predlog iz baze znanja je izhodišče: korake in nevarnosti lahko dodajate, brišete in spreminjate. Naložene vrstice so označene kot »predlog« in zahtevajo vašo potrditev.</p>
    <h3>Živila / skupine živil</h3><div class="tw"><table class="t"><tr><th>Naziv</th><th>Skupina</th><th>Alergeni</th><th>RTE</th><th>Ciljna skupina</th><th>Shranjevanje, rok uporabe</th><th>Režim iz baze</th><th></th></tr>${W.zivila.map((z, i) => `<tr data-i="${i}"><td><input data-k="naziv"></td><td><input data-k="skupina"></td><td><button type="button" class="btn sm ghost sec edit al-izb" data-al="${i}" style="white-space:normal;text-align:left;max-width:220px">${esc(z.alergeni || "izberi …")}</button></td><td><input type="checkbox" data-k="rte"></td><td><input data-k="ciljna"></td><td><input data-k="shranjevanje"></td><td class="mut zrez" style="font-size:12px;min-width:150px">${esc(profilOpis(profilZivila(z, db), db))}</td><td><button class="btn sm ghost sec edit" data-del="${i}">✕</button></td></tr>`).join("") || '<tr><td colspan="8" class="empty">Dodajte živila.</td></tr>'}</table></div><div class="row" style="margin-top:8px"><button class="btn edit" id="zadd">+ Dodaj živilo</button>${W.zivila.length ? ' <button class="btn ghost sec edit" id="zrez" title="Temperaturni režim, temperatura ob prevzemu in toplotna obdelava iz baze za odločitveno drevo">Izpolni režime iz baze</button>' : ""}</div></div>`;
    $$("tr[data-i]", el).forEach(tr => bindAll(tr, W.zivila[+tr.dataset.i]));
    // temperaturni režimi iz baze: samodejno ob vpisu naziva (prazna polja), gumb za vsa živila
    $$("tr[data-i] [data-k=naziv],tr[data-i] [data-k=skupina]", el).forEach(inp => inp.addEventListener("change", () => { const tr = inp.closest("tr"), z = W.zivila[+tr.dataset.i], p = izpolniZivilo(z, db); if (!p) return; mark();
      for (const k of ["skupina", "shranjevanje"]) { const x = $(`[data-k=${k}]`, tr); if (x && !x.value) x.value = z[k] || ""; } const r = $("[data-k=rte]", tr); if (r) r.checked = !!z.rte; $(".zrez", tr).textContent = profilOpis(p, db); }));
    const zr = $("#zrez", el); if (zr) zr.onclick = () => { let n = 0; for (const z of W.zivila) if (String(z.naziv || "").trim() && izpolniZivilo(z, db)) n++; mark(); s2(el); toast(n ? "Režimi iz baze izpolnjeni za " + mnx(n, ["živilo", "živili", "živila", "živil"]) + " (prazna polja). Preverite jih." : "Vpišite nazive živil.", !n); };
    // podrobnosti živila (sestava, priprava, pakiranje, rok, stanje alergenov) in prevzem alergenov iz razdelka »Alergeni in jedilnik«
    $$("tr[data-i]", el).forEach(tr => { const i = +tr.dataset.i, z = W.zivila[i]; tr.lastElementChild.insertAdjacentHTML("afterbegin", `<button type="button" class="btn sm ghost sec edit" data-zp="${i}">Podrobnosti${z.alergeni_potrjeni ? "" : " · alergeni nepotrjeni"}</button> `); });
    $$("[data-zp]", el).forEach(b => b.onclick = () => { const z = W.zivila[+b.dataset.zp];
      const d = modal("Živilo: " + (z.naziv || ""), `<div class="fgrid">${[["sestava", "Sestava (glavne sestavine)"], ["priprava", "Priprava"], ["pakiranje", "Pakiranje"], ["shranjevanje", "Shranjevanje"], ["prevzem", "Temperatura ob prevzemu"], ["rok", "Rok uporabe"], ["ciljna", "Ciljna skupina"], ["odprto", "Odprto (kaj še preveriti)"]].map(([k, l]) => `<label class="f wide"><span>${l}</span><input data-k="${k}"></label>`).join("")}<label class="f wide" style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-k="alergeni_potrjeni" style="width:auto"> <b>Alergeni so preverjeni in potrjeni</b> (specifikacije dobaviteljev, recepture)</label></div>`, [{ t: "Zapri", cls: "ghost sec", fn: () => { s2(el); } }]);
      bindAll(d, z); if (!editable) d.querySelectorAll("input").forEach(x => { x.disabled = true; });
      const pk = $("[data-k=alergeni_potrjeni]", d); if (pk) pk.addEventListener("change", () => { if (pk.checked) { z.alergeni_potrdil = ME.u.ime; z.alergeni_potrjeno = today(); } else { delete z.alergeni_potrdil; delete z.alergeni_potrjeno; } mark(); }); });
    if (editable && W.zivila.length && !$("#z_jed")) $("#zadd").insertAdjacentHTML("afterend", ' <button type="button" class="btn ghost sec" id="z_jed">Prevzemi alergene iz jedilnika</button>');
    const zj = $("#z_jed"); if (zj) zj.onclick = async () => { const jedi = await D.list("jedi", { stranka_id: rec.stranka_id }).catch(() => []); let n = 0;
      for (const z of W.zivila) { const j = jedi.find(x => String(x.naziv || "").trim().toLowerCase() === String(z.naziv || "").trim().toLowerCase()); if (!j) continue; const a = algKode(j.alergeni || []); z.alergeni = (j.alergeni || []).length ? (j.alergeni || []).join(", ") : "ni alergenov"; z.alergeni_jedilnik = a.join(", "); n++; }
      mark(); toast(n ? "Alergeni prevzeti iz jedilnika za " + mnx(n, ["živilo", "živili", "živila", "živil"]) + ". Potrdite jih v »Podrobnosti«." : "V jedilniku ni jedi z enakim imenom.", !n); s2(el); };
    $("#wb").onchange = e => { W.branza = e.target.value; mark(); };
    $$("[data-pb]", el).forEach(b => b.onclick = () => { W.branza = b.dataset.pb; $("#wb").value = W.branza; mark(); });
    $("#zadd").onclick = () => { W.zivila.push({ id: uidc() }); mark(); s2(el); };
    $$("[data-del]", el).forEach(b => b.onclick = () => { W.zivila.splice(+b.dataset.del, 1); mark(); s2(el); });
    $$("[data-al]", el).forEach(b => b.onclick = () => alergeniIzbor(W.zivila[+b.dataset.al], () => s2(el)));
    $("#wload").onclick = () => {
      const br = db.branze.find(b => b.id === W.branza); if (!br) return toast("Izberite dejavnost.", true);
      // zamenjaj: predlog nadomesti korake, nevarnosti in ukrepe; dodaj: koraki z enakim imenom se ne podvojijo, nevarnosti se dodajo
      const apply = nacin => {
        const nov = nacin === "zamenjaj"; if (nov) { W.koraki = []; W.nevarnosti = []; W.kontrole = {}; }
        const pred = W.koraki.length, predH = W.nevarnosti.length, idKoraka = {};
        for (const n of br.koraki) { const obst = W.koraki.find(k => (k.naziv || "").trim().toLowerCase() === n.toLowerCase()); if (obst) idKoraka[n] = obst.id; else { const k = { id: uidc(), naziv: n, tip: guessTip(n), predlog: true }; W.koraki.push(k); idKoraka[n] = k.id; } }
        // »Dodaj k obstoječim«: nevarnost, ki na istem koraku že obstaja (po imenu), se ne podvoji
        const ze = h => W.nevarnosti.some(x => x.korak_id === (idKoraka[h.faza] || "") && String(x.nevarnost || "").trim().toLowerCase() === String(h.nevarnost || "").trim().toLowerCase());
        for (const h of br.nevarnosti || []) if (!ze(h)) W.nevarnosti.push({ id: uidc(), korak_id: idKoraka[h.faza] || "", tip: ["B", "K", "F", "A"].includes(h.tip) ? h.tip : "D", nevarnost: h.nevarnost, obstojec: h.ukrep || "", verjetnost: "", teza: "", predlog: true, potrjeno: false });
        mark(); toast(nov ? "Predlog naložen: " + W.koraki.length + " korakov, " + W.nevarnosti.length + " nevarnosti. Verjetnost in težo ocenite sami." : "Dodano: " + (W.koraki.length - pred) + " korakov, " + (W.nevarnosti.length - predH) + " nevarnosti."); pojdi(2);
      };
      if (!W.koraki.length && !W.nevarnosti.length) return apply("zamenjaj");
      modal("Naloži predlog: " + br.naziv, `<p>Načrt že ima ${mnx(W.koraki.length, ["korak", "koraka", "koraki", "korakov"])} in ${mnx(W.nevarnosti.length, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])}${Object.keys(W.kontrole).length ? " ter " + mnx(Object.keys(W.kontrole).length, ["kontrolni ukrep", "kontrolna ukrepa", "kontrolne ukrepe", "kontrolnih ukrepov"]) : ""}.</p><ul><li><b>Zamenjaj</b>: obstoječi koraki, nevarnosti in kontrolni ukrepi se izbrišejo in nadomestijo s predlogom.</li><li><b>Dodaj k obstoječim</b>: obstoječe ostane; dodajo se koraki in nevarnosti, ki jih še ni (po imenu).</li></ul>`,
        [{ t: "Prekliči", cls: "ghost sec" }, { t: "Dodaj k obstoječim", cls: "ghost", fn: () => apply("dodaj") }, { t: "Zamenjaj", cls: "danger", fn: () => apply("zamenjaj") }]);
    };
  }
  // izbor alergenov (14 alergenov EU, »ni alergenov«, opomba »preveriti«); shrani se kot besedilo, kot doslej
  const ALG = (db.alergeni || []).map(a => a.naziv);
  const algUjema = (a, d) => { const A = a.toLowerCase(), x = d.toLowerCase(); return A === x || (x.length >= 4 && A.includes(x.slice(0, Math.min(5, x.length)))) || (/gluten|pšenic|ječmen|rž|oves/.test(x) && /gluten/.test(A)) || (/sulfit|so2|žvepl/.test(x) && /žvepl/.test(A)) || (/oreh|lešnik|mandelj|pistacij/.test(x) && /oreščk/.test(A)); };
  function alergeniIzbor(z, done) {
    const cur = String(z.alergeni || ""), prev = /\(preveriti\)/i.test(cur), deli = cur.replace(/\s*\(preveriti\)\s*/ig, "").split(/[,;]/).map(x => x.trim()).filter(Boolean);
    const izb = new Set(), drugo = [];
    for (const d of deli) { if (/^ni alergenov$/i.test(d)) continue; const a = ALG.find(a => algUjema(a, d)); if (a) izb.add(a); else drugo.push(d); }
    const html = `<p class="mut">Izberite alergene po Prilogi II Uredbe (EU) št. 1169/2011, ki jih živilo vsebuje.</p><div class="al-mreza">${ALG.map(a => `<label><input type="checkbox" data-a="${esc(a)}" ${izb.has(a) ? "checked" : ""}> ${esc(a)}</label>`).join("")}</div>
      <label style="display:flex;gap:6px;align-items:center;margin-top:10px"><input type="checkbox" id="al_ni" ${/ni alergenov/i.test(cur) ? "checked" : ""} style="width:auto"> <b>Ni alergenov</b></label>
      <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="al_pr" ${prev ? "checked" : ""} style="width:auto"> Preveriti (specifikacija dobavitelja ni potrjena, možna navzkrižna kontaminacija)</label>
      <label class="f" style="margin-top:8px"><span>Opomba (neobvezno, ni alergen – izpiše se v stolpcu »Opomba«)</span><input id="al_dr" value="${esc([z.alergeni_opomba, ...drugo].filter(Boolean).join(", "))}"></label>`;
    const d = modal("Alergeni: " + (z.naziv || "živilo"), html, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: () => {
      const sel = $$("[data-a]", d).filter(i => i.checked).map(i => i.dataset.a), ni = $("#al_ni", d).checked, dr = $("#al_dr", d).value.trim();
      if (ni && sel.length) { toast("Izberite alergene ali »Ni alergenov«, ne obojega.", true); return false; }
      const nov = (ni ? ["ni alergenov"] : sel).join(", ") + ($("#al_pr", d).checked ? " (preveriti)" : "");
      if (nov !== z.alergeni) { z.alergeni_potrjeni = false; delete z.alergeni_potrdil; delete z.alergeni_potrjeno; } // sprememba: ponovno potrditi
      z.alergeni = nov; z.alergeni_opomba = dr; mark(); done();
    } }]);
    $("#al_ni", d).onchange = e => { if (e.target.checked) $$("[data-a]", d).forEach(i => { i.checked = false; }); };
    $$("[data-a]", d).forEach(i => i.onchange = () => { if (i.checked) $("#al_ni", d).checked = false; });
    if (!editable) d.querySelectorAll("input").forEach(e => { e.disabled = true; });
  }
  const guessTip = n => { n = n.toLowerCase(); return /prevzem/.test(n) ? "prevzem" : /skladi/.test(n) ? "skladiščenje" : /toplotn|kuhan|peče|pečen|pasteriz/.test(n) ? "toplotna obdelava" : /hlaj/.test(n) ? "hlajenje" : /pakir/.test(n) ? "pakiranje" : /odprema|prodaj|izdaj|serv/.test(n) ? "prodaja / izdaja" : "priprava"; };

  // 3. procesni koraki
  const odprtOpis = new Set();
  // nevarnosti koraka, ki je bil preimenovan ali izbrisan, je treba ponovno pregledati (vezava je na ID koraka, ne na številko)
  const oznaciKorak = (kid, kaj) => { const hs = W.nevarnosti.filter(h => h.korak_id === kid); hs.forEach(h => { h.preveri_korak = kaj; h.potrjeno = false; delete h.urejeno; if (kaj === "izbrisan") h.korak_id = ""; }); return hs.length; };
  const zaPreverjanje = () => W.nevarnosti.filter(h => h.preveri_korak || !W.koraki.some(k => k.id === h.korak_id)).length;
  const nevZaPreverjanje = () => W.nevarnosti.filter(h => h.preveri_korak || !W.koraki.some(k => k.id === h.korak_id));
  // prestavljena nevarnost čaka na potrditev uporabnika (enako pravilo kot pri urejenem predlogu)
  const prestaviNev = (hs, kid) => { hs.forEach(h => { h.korak_id = kid; delete h.preveri_korak; h.potrjeno = false; h.urejeno = true; }); };
  const izbrisiNev = hs => { const ids = new Set(hs.map(h => h.id)); W.nevarnosti = W.nevarnosti.filter(h => !ids.has(h.id)); ids.forEach(id => delete W.kontrole[id]); };
  const korakiSel = (id, brez) => `<select id="${id}" aria-label="Ciljni korak">${W.koraki.filter(k => k.id !== brez).map(k => `<option value="${esc(k.id)}">${W.koraki.indexOf(k) + 1}. ${esc(kratko(k.naziv || "(brez imena)", 40))}</option>`).join("")}</select>`;
  // gumbi pod opozorilom (korak 3 in 4): prestavi vse na izbran korak ali jih izbriši
  const bulkHtml = p => W.koraki.length ? `<span class="row" style="margin-top:6px;gap:6px;align-items:center">Prestavi jih na ${korakiSel(p + "_k")} <button class="btn sm edit" id="${p}_pr">Prestavi</button> <button class="btn sm ghost sec danger edit" id="${p}_iz">Izbriši te nevarnosti</button></span>` : `<span class="row" style="margin-top:6px"><button class="btn sm ghost sec danger edit" id="${p}_iz">Izbriši te nevarnosti</button></span>`;
  const bulkBind = (el, p, po) => {
    const pr = $("#" + p + "_pr", el), iz = $("#" + p + "_iz", el);
    if (pr) pr.onclick = () => { const hs = nevZaPreverjanje(), k = W.koraki.find(x => x.id === $("#" + p + "_k", el).value); prestaviNev(hs, k.id); mark(); toast(mnx(hs.length, ["nevarnost prestavljena", "nevarnosti prestavljeni", "nevarnosti prestavljene", "nevarnosti prestavljenih"]) + " na korak »" + k.naziv + "« – potrdite jih v koraku 4."); po(); };
    if (iz) iz.onclick = () => { const hs = nevZaPreverjanje(); confirmBox(`Izbrišem ${mnx(hs.length, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} in njihove kontrolne ukrepe?`, () => { izbrisiNev(hs); mark(); toast("Izbrisano: " + hs.length); po(); }, true); };
  };
  const risiFlow = () => {
    const f = $("#kflow"); if (!f) return;
    f.innerHTML = W.koraki.map((k, i) => { const c = ccpNaKoraku(W, k.id); return `${i ? '<div class="a">▼</div>' : ""}<div class="n${c.length ? " ccp" : ""}">${i + 1}. ${esc(k.naziv || "(brez imena)")}${c.length ? ` <span class="badge bad">${c.join(", ")}</span>` : ""}</div>`; }).join("") || '<p class="empty">Diagram se izriše iz korakov.</p>';
  };
  function s3(el) {
    const vezane = kid => W.nevarnosti.filter(h => h.korak_id === kid).length;
    el.innerHTML = `<div class="grid g2 kor-lay"><div class="card"><h2>3. Procesni koraki</h2><p class="mut">Vrstni red določa diagram poteka. Korake premikate z vlečenjem (⠿) ali s puščicama. Nevarnosti so vezane na korak, ne na številko: pri premiku ostanejo pri svojem koraku.</p>
    <div id="k_prev"></div>
    <div id="klist">${W.koraki.map((k, i) => `<div class="krow" data-i="${i}"><span class="kdrag" title="Povlecite za premik" aria-hidden="true">⠿</span><b class="kst">${i + 1}.</b><input data-k="naziv" placeholder="Naziv koraka" aria-label="Naziv koraka ${i + 1}"><select data-k="tip" aria-label="Vrsta koraka ${i + 1}">${KTIPI.map(t => `<option>${t}</option>`).join("")}</select>${vezane(k.id) ? `<span class="badge" title="Povezane nevarnosti">${vezane(k.id)} nev.</span>` : ""}${k.predlog ? '<span class="badge warn" title="Predlog iz baze – potrdite ali popravite">predlog</span>' : ""}<span class="kgumbi"><button class="btn sm ghost sec" data-o="${i}" aria-expanded="${odprtOpis.has(k.id) || !!k.opis}" title="Opis koraka">⋯</button><button class="btn sm ghost sec edit" data-up="${i}" aria-label="Premakni gor">↑</button><button class="btn sm ghost sec edit" data-dn="${i}" aria-label="Premakni dol">↓</button><button class="btn sm ghost sec edit" data-x="${i}" aria-label="Izbriši korak">✕</button></span><input class="kopis" data-k="opis" placeholder="Opis koraka (neobvezno)" aria-label="Opis koraka ${i + 1}" ${odprtOpis.has(k.id) || k.opis ? "" : "hidden"}></div>`).join("") || '<p class="empty">Ni korakov. Naložite predlog (korak 2) ali dodajte ročno.</p>'}</div><button class="btn edit" id="kadd">+ Dodaj korak</button> <button class="btn ghost sec edit" id="knap">Predlagaj iz naprav obrata</button></div>
    <div class="card kor-diag"><h2>Diagram poteka</h2><div class="flow" id="kflow"></div><div class="row" style="margin-top:10px"><button class="btn ghost sec" id="dpdf">Diagram v PDF</button></div></div></div>`;
    const pasica = () => { const n = zaPreverjanje(), b = $("#k_prev", el); if (!b) return; b.innerHTML = n ? `<p class="note">${mnx(n, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} ${mn(n, ["je vezana", "sta vezani", "so vezane", "je vezanih"])} na spremenjen ali izbrisan korak – preverite jih. <button class="btn sm ghost" id="k_go4">Pojdi na analizo nevarnosti</button><br>${bulkHtml("kb")}</p>` : ""; const g = $("#k_go4", el); if (g) g.onclick = () => pojdi(3); bulkBind(el, "kb", () => s3(el)); };
    pasica(); risiFlow();
    // veja procesa (npr. kuhinja, hladna priprava, slaščičarna, točilni pult); koraki brez veje so skupni začetek ali konec
    $$(".krow", el).forEach(c => { const t = $("select[data-k=tip]", c); if (t) t.insertAdjacentHTML("afterend", `<input data-k="veja" list="veje_l" placeholder="veja (neobvezno)" aria-label="Veja procesa" style="max-width:150px">`); });
    if (!$("#veje_l")) document.body.insertAdjacentHTML("beforeend", '<datalist id="veje_l"><option>kuhinja</option><option>hladna priprava</option><option>slaščičarna</option><option>točilni pult</option></datalist>');
    $$(".krow", el).forEach(c => {
      const k = W.koraki[+c.dataset.i]; bindAll(c, k);
      const ime = $("input[data-k=naziv]", c); let prej = k.naziv || "";
      ime.addEventListener("input", risiFlow);
      ime.addEventListener("focus", () => { prej = k.naziv || ""; });
      ime.addEventListener("change", () => {
        if ((k.naziv || "").trim() === prej.trim()) return; k.predlog = false;
        // isti korak (ista vezava) z novim imenom: nevarnosti ostanejo potrjene, le obvestilo
        if (prej.trim() && vezane(k.id)) toast("Korak je preimenovan; " + vezane(k.id) + " povezanih nevarnosti ostane potrjenih – po potrebi jih preglejte.");
        prej = k.naziv || "";
      });
      // premik z vlečenjem (samo za ročico, da v poljih deluje izbiranje besedila)
      const roc = $(".kdrag", c);
      roc.onmousedown = roc.ontouchstart = () => { if (editable) c.draggable = true; };
      c.ondragstart = e => { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", c.dataset.i); c.classList.add("vlecem"); };
      c.ondragend = () => { c.draggable = false; c.classList.remove("vlecem"); $$(".krow.cilj", el).forEach(x => x.classList.remove("cilj")); };
      c.ondragover = e => { e.preventDefault(); c.classList.add("cilj"); };
      c.ondragleave = () => c.classList.remove("cilj");
      c.ondrop = e => { e.preventDefault(); const a = +e.dataTransfer.getData("text/plain"), b = +c.dataset.i; if (isNaN(a) || a === b) return; const [m] = W.koraki.splice(a, 1); W.koraki.splice(b, 0, m); mark(); s3(el); };
    });
    $$("[data-o]", el).forEach(b => b.onclick = () => { const k = W.koraki[+b.dataset.o], o = b.closest(".krow").querySelector(".kopis"); if (o.hidden) { odprtOpis.add(k.id); o.hidden = false; o.focus(); } else { odprtOpis.delete(k.id); o.hidden = true; } b.setAttribute("aria-expanded", String(!o.hidden)); });
    $("#knap").onclick = () => { const r = korakiIzNaprav(W, db, obrati.find(o => o.id === rec.obrat_id)); if (!r.nk.length && !r.nh.length) return toast(rec.obrat_id ? "Iz naprav obrata ni novih korakov ali nevarnosti (obkljukajte naprave pri obratu)." : "Načrt ni povezan z obratom.", true); mark(); s3(el); toast("Dodano iz naprav: " + mnx(r.nk.length, ["korak", "koraka", "koraki", "korakov"]) + ", " + mnx(r.nh.length, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"]) + " (predlog – oceni in potrdi v koraku 4)."); };
    $("#kadd").onclick = () => { W.koraki.push({ id: uidc(), naziv: "", tip: "priprava" }); mark(); s3(el); const z = $$(".krow input[data-k=naziv]", el).pop(); if (z) z.focus(); };
    $$("[data-x]", el).forEach(b => b.onclick = () => {
      const i = +b.dataset.x, k = W.koraki[i], n = vezane(k.id);
      const izbrisi = kaj => {
        const hs = W.nevarnosti.filter(h => h.korak_id === k.id), cilj = kaj === "prestavi" ? $("#kx_k").value : "";
        if (kaj === "prestavi" && cilj) prestaviNev(hs, cilj); else if (kaj === "izbrisi") izbrisiNev(hs); else oznaciKorak(k.id, "izbrisan");
        W.koraki.splice(i, 1); mark(); s3(el);
        if (n) toast(kaj === "prestavi" ? n + " nevarnosti prestavljenih na korak »" + (W.koraki.find(x => x.id === cilj) || {}).naziv + "« – potrdite jih v koraku 4." : kaj === "izbrisi" ? n + " nevarnosti izbrisanih." : n + " nevarnosti je ostalo brez koraka – preverite jih v koraku 4.");
      };
      if (!n) return izbrisi();
      modal("Izbris koraka", `<p>Korak »${esc(k.naziv || String(i + 1))}« ima ${mnx(n, ["povezano nevarnost", "povezani nevarnosti", "povezane nevarnosti", "povezanih nevarnosti"])}. Kaj naj se zgodi z ${n === 1 ? "njo" : "njimi"}?</p>
        <label class="kx-o"><input type="radio" name="kx" value="preveri" checked> Pusti jih brez koraka in označi za preverjanje (korak 4)</label>
        ${W.koraki.length > 1 ? `<label class="kx-o"><input type="radio" name="kx" value="prestavi"> Prestavi jih na korak ${korakiSel("kx_k", k.id)}</label>` : ""}
        <label class="kx-o"><input type="radio" name="kx" value="izbrisi"> Izbriši jih skupaj s kontrolnimi ukrepi</label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Izbriši korak", cls: "danger", fn: () => izbrisi(($("input[name=kx]:checked") || {}).value) }]);
      const sel = $("#kx_k"); if (sel) sel.onchange = () => { $("input[name=kx][value=prestavi]").checked = true; };
    });
    $$("[data-up]", el).forEach(b => b.onclick = () => { const i = +b.dataset.up; if (i) { [W.koraki[i - 1], W.koraki[i]] = [W.koraki[i], W.koraki[i - 1]]; mark(); s3(el); } });
    $$("[data-dn]", el).forEach(b => b.onclick = () => { const i = +b.dataset.dn; if (i < W.koraki.length - 1) { [W.koraki[i + 1], W.koraki[i]] = [W.koraki[i], W.koraki[i + 1]]; mark(); s3(el); } });
    $("#dpdf").onclick = () => dlBlob(pdfBuild({ naslov: "Diagram poteka – " + rec.naziv, stranka: stranka.naziv, verzija: rec.verzija_oznaka || "1.0" }, d => { d.h(1, "Diagram poteka"); d.flow(W.koraki.map((k, i) => { const c = ccpNaKoraku(W, k.id); return { n: i + 1, t: k.naziv, ccp: !!c.length, tag: c.join(", ") }; })); }), "diagram-poteka.pdf");
  }

  // 4. analiza nevarnosti
  let samoPreveri = false;
  const kratko = (t, n) => { t = t || "–"; return t.length > n ? t.slice(0, n - 1) + "…" : t; };
  const redKoraka = kid => { const i = W.koraki.findIndex(k => k.id === kid); return i < 0 ? 1e6 : i; };
  function s4(el) {
    const M = W.metoda, npr = zaPreverjanje(), nep = W.nevarnosti.filter(h => hazStatus(h) !== "potrjeno").length;
    const vrste = W.nevarnosti.map((h, i) => [h, i]).sort((a, b) => redKoraka(a[0].korak_id) - redKoraka(b[0].korak_id) || a[1] - b[1]).map(x => x[0])
      .filter(h => !samoPreveri || h.preveri_korak || !W.koraki.some(k => k.id === h.korak_id));
    // matrika tveganja: število nevarnosti po verjetnosti (vrstice, 5 → 1) in teži (stolpci 1 → 5)
    const mat = [5, 4, 3, 2, 1].map(vv => `<tr><th>${vv}</th>${[1, 2, 3, 4, 5].map(tt => { const n = W.nevarnosti.filter(h => +h.verjetnost === vv && +h.teza === tt).length, r = rizikRazred(vv * tt, M); return `<td class="rm-${r}" title="V ${vv} × T ${tt} = ${vv * tt} (${r})">${n || ""}</td>`; }).join("")}</tr>`).join("");
    let prejKorak = null;
    el.innerHTML = `<div class="card"><h2>4. Analiza nevarnosti</h2>
    <details><summary><b>Metodologija ocene tveganja</b> (privzeta, prilagodljiva – potrdi strokovnjak)</summary><p>Tveganje = verjetnost (1–5) × teža posledic (1–5). Razredi: nizko ≤ <input type="number" data-k="nizko_do" style="width:70px;display:inline-block">, srednje ≤ <input type="number" data-k="srednje_do" style="width:70px;display:inline-block">, visoko nad tem. Pomembne nevarnosti (srednje in visoko) obravnavate v koraku 5. Verjetnost: ${M.verjetnost.join("; ")}. Teža: ${M.teza.join("; ")}. Metodologija se izpiše v dokumentaciji.</p></details>
    <div class="nev-vrh"><div><p class="note info">Vrstice z oznako »predlog« so izhodišče iz baze znanja. Ocene verjetnosti in teže niso vnaprej določene – vnesete jih za konkretni obrat. <b>Nevarnost je potrjena samo, ko obkljukate »pregledal in potrjujem«</b> (tudi ročno dodana ali urejena).</p>
    ${npr ? `<p class="note" style="border-left:4px solid var(--bad)">${mnx(npr, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} ${mn(npr, ["je vezana", "sta vezani", "so vezane", "je vezanih"])} na spremenjen ali izbrisan korak – preverite povezavo s korakom. <button class="btn sm ghost" id="h_flt">${samoPreveri ? "Pokaži vse" : "Pokaži samo te"}</button><br>${bulkHtml("hb")}</p>` : ""}
    <div class="row"><button class="btn edit" id="hadd">+ Dodaj nevarnost</button>${nep ? `<button class="btn ghost sec edit" id="hok">Potrdi vse nepotrjene (${nep})</button>` : ""}</div></div>
    <label style="display:flex;gap:6px;align-items:center;margin:6px 0"><input type="checkbox" id="niz_izp" ${W.metoda.nizke_izpuscene ? "checked" : ""} style="width:auto"> Nizka tveganja so namerno izpuščena iz analize (obvladujejo se s PRP)</label>
    <table class="rmat" aria-label="Matrika tveganja"><caption>Matrika tveganja (število nevarnosti)</caption><tr><th>V \\ T</th>${[1, 2, 3, 4, 5].map(t => `<th>${t}</th>`).join("")}</tr>${mat}</table></div>
    <div class="tw"><table class="t nev-t"><thead><tr><th>Korak</th><th>Vrsta</th><th>Nevarnost</th><th>Obstoječi ukrepi</th><th>V</th><th>T</th><th>Tveganje</th><th>Stanje</th></tr></thead><tbody>${vrste.map(h => {
      const r = rizik(h), kor = W.koraki.find(k => k.id === h.korak_id), nova = h.korak_id !== prejKorak; prejKorak = h.korak_id;
      const kc = kor ? `<td class="kgr" title="${esc((redKoraka(h.korak_id) + 1) + ". " + kor.naziv)}"><b>${redKoraka(h.korak_id) + 1}.</b> ${esc(kratko(kor.naziv, 22))}</td>` : '<td class="kgr"><span class="badge bad">brez koraka</span></td>';
      return `<tr class="click${nova ? " grp" : ""}" data-h="${esc(h.id)}">${nova ? kc : '<td class="kgr-n" aria-hidden="true"></td>'}<td>${esc(HTIPI[h.tip] || h.tip)}</td><td>${esc(h.nevarnost)}</td><td>${esc((h.obstojec || "").slice(0, 80))}</td><td>${esc(h.verjetnost || "?")}</td><td>${esc(h.teza || "?")}</td><td>${r ? `<span class="badge ${r <= M.nizko_do ? "ok" : r <= M.srednje_do ? "warn" : "bad"}">${r} ${rizikRazred(r, M)}</span>` : '<span class="badge">neocenjeno</span>'}</td><td>${hazBadge(h)}</td></tr>`; }).join("") || '<tr><td colspan="8" class="empty">Ni nevarnosti.</td></tr>'}</tbody></table></div></div>`;
    bindAll($("details", el), M);
    $("#hadd").onclick = () => hazForm(null, () => s4(el));
    const f = $("#h_flt"); if (f) f.onclick = () => { samoPreveri = !samoPreveri; s4(el); };
    const nz = $("#niz_izp", el); if (nz) nz.onchange = () => { W.metoda.nizke_izpuscene = nz.checked; mark(); };
    bulkBind(el, "hb", () => { samoPreveri = false; s4(el); });
    const ok = $("#hok"); if (ok) ok.onclick = () => {
      const brez = W.nevarnosti.filter(h => hazStatus(h) !== "potrjeno" && !W.koraki.some(k => k.id === h.korak_id)).length;
      confirmBox(`Potrdim ${mnx(nep - brez, ["nepotrjeno nevarnost", "nepotrjeni nevarnosti", "nepotrjene nevarnosti", "nepotrjenih nevarnosti"])}? Potrdite samo, če ste vsako pregledali.${brez ? ` ${mnx(brez, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} brez koraka ${mn(brez, ["ostane nepotrjena", "ostaneta nepotrjeni", "ostanejo nepotrjene", "ostane nepotrjenih"])} – najprej jim določite korak.` : ""}`, () => {
        W.nevarnosti.forEach(h => { if (hazStatus(h) !== "potrjeno" && W.koraki.some(k => k.id === h.korak_id)) { h.potrjeno = true; delete h.urejeno; delete h.preveri_korak; } }); mark(); s4(el);
      });
    };
    $$("tr[data-h]", el).forEach(tr => tr.onclick = () => hazForm(W.nevarnosti.find(h => h.id === tr.dataset.h), () => s4(el)));
  }
  function hazForm(h, done) {
    const isNew = !h; h = h || { id: uidc(), korak_id: "", tip: "B", potrjeno: false };
    const fl = [["korak_id", "Korak", "sel", W.koraki.map((k, i) => [k.id, (i + 1) + ". " + k.naziv])], ["tip", "Vrsta nevarnosti", "sel", Object.entries(HTIPI)], ["nevarnost", "Nevarnost (opis)", "area"], ["vir", "Vir nevarnosti", "area"], ["posledica", "Možna posledica", "area"], ["obstojec", "Obstoječi ukrepi", "area"], ["verjetnost", "Verjetnost (1–5)", "sel", W.metoda.verjetnost.map((x, i) => [i + 1, x])], ["teza", "Teža posledic (1–5)", "sel", W.metoda.teza.map((x, i) => [i + 1, x])], ["dodatni", "Dodatni ukrepi", "area"], ["odgovoren", "Odgovorna oseba"], ["preverjanje", "Preverjanje (verifikacija)"]];
    const opozorilo = h.preveri_korak ? `<p class="note" style="border-left:4px solid var(--bad)">Korak te nevarnosti je bil ${h.preveri_korak === "izbrisan" ? "izbrisan" : "preimenovan"}. Preverite, ali nevarnost še sodi h koraku (po potrebi izberite drugega), in jo znova potrdite.</p>` : "";
    const html = `${opozorilo}<div class="fgrid">${fl.map(([k, l, t, o]) => `<label class="f ${t === "area" ? "wide" : ""} ${k === "korak_id" || k === "nevarnost" ? "req" : ""}"><span>${l}</span>${t === "area" ? `<textarea data-k="${k}"></textarea>` : t === "sel" ? `<select data-k="${k}"><option value=""></option>${o.map(x => `<option value="${esc(x[0])}">${esc(x[1])}</option>`).join("")}</select>` : `<input data-k="${k}">`}</label>`).join("")}</div><div id="rr"></div>
      <label class="f potrdi-h"><input type="checkbox" data-k="potrjeno" style="width:auto"> <b>Nevarnost sem pregledal in potrjujem</b>${h.predlog ? " (predlog iz baze znanja)" : ""}</label>`;
    const copy = Object.assign({}, h, { potrjeno: hazStatus(h) === "potrjeno" });
    const d = modal(isNew ? "Nova nevarnost" : "Nevarnost", html, [{ t: "Prekliči", cls: "ghost sec" }, ...(!isNew && editable ? [{ t: "Izbriši", cls: "danger", fn: async () => { await new Promise(r => setTimeout(r, 0)); if (!(await potrdi("Izbrišem nevarnost" + (W.kontrole[h.id] ? " in njen kontrolni ukrep" : "") + "?", { da: "Izbriši", nevarno: true }))) return false; W.nevarnosti = W.nevarnosti.filter(x => x.id !== h.id); delete W.kontrole[h.id]; mark(); done(); } }] : []), { t: "Shrani", fn: () => {
      if (!copy.nevarnost) { toast("Vnesite opis nevarnosti.", true); return false; }
      if (!copy.korak_id && W.koraki.length) { toast("Izberite korak.", true); return false; }
      const spremenjeno = ["korak_id", "tip", "nevarnost", "vir", "posledica", "obstojec"].some(k => String(copy[k] || "") !== String(h[k] || ""));
      if (copy.potrjeno) delete copy.urejeno; else if (!isNew && h.predlog && spremenjeno) copy.urejeno = true;
      delete copy.preveri_korak; // uporabnik je zapis pregledal
      if (copy.potrjeno && rizik(copy) > W.metoda.nizko_do && !(W.kontrole[h.id] || {}).vrsta) toast("Potrjena nevarnost še nima vrste kontrolnega ukrepa – določite jo v koraku 5.", "opozorilo");
      if (h.potrjeno && !copy.potrjeno && !isNew) toast("Potrditev nevarnosti je odstranjena – nevarnost je spet nepotrjena.", "opozorilo");
      Object.keys(h).forEach(k => { if (!(k in copy)) delete h[k]; }); Object.assign(h, copy); if (isNew) W.nevarnosti.push(h); mark(); done();
    } }]);
    bindAll(d, copy); const live = () => { const r = rizik(copy); $("#rr", d).innerHTML = r ? `Tveganje: <b>${r}</b> (${rizikRazred(r, W.metoda)})` : '<span class="mut">Vnesite verjetnost in težo.</span>'; };
    d.querySelectorAll("[data-k]").forEach(i => i.addEventListener("input", live)); live();
    if (!editable) d.querySelectorAll("input,select,textarea").forEach(e => e.disabled = true);
  }

  // 5. kontrolni ukrepi (PRP / OPRP / CCP)
  const vrstaBadge = (h, oz) => { const c = W.kontrole[h.id] || {}; if (!c.vrsta) return '<span class="badge">ni izbrano</span>'; if (c.vrsta === "nobeno") return '<span class="badge">ni potreben</span>'; return `<span class="badge vu-${esc(String(c.vrsta).toLowerCase())}">${esc(oz[h.id] || c.vrsta)}</span>`; };
  function s5(el) {
    const ocenjene = W.nevarnosti.filter(h => rizik(h)), sig = ocenjene.filter(h => rizik(h) > W.metoda.nizko_do), nizke = ocenjene.filter(h => rizik(h) <= W.metoda.nizko_do);
    const unr = W.nevarnosti.length - ocenjene.length, oz = ccpOznake(W), poKoraku = (a, b) => redKoraka(a.korak_id) - redKoraka(b.korak_id);
    const vrstica = (h, atr) => { const c = W.kontrole[h.id] || {}; return `<tr ${atr}="${esc(h.id)}"><td title="${esc(korakIme(h.korak_id))}">${num(h.korak_id)} ${esc(kratko(korakIme(h.korak_id), 22))}</td><td>${esc(h.nevarnost)}</td><td><span class="badge ${({ visoko: "bad", srednje: "warn", nizko: "ok" })[rizikRazred(rizik(h), W.metoda)]}">${rizikRazred(rizik(h), W.metoda)}</span></td><td>${vrstaBadge(h, oz)}${c.vrsta === "CCP" && (c.mejna_predlog || CCPPOL.some(k => !c[k])) ? ' <span class="badge warn">potrebna strokovna potrditev</span>' : ""}</td><td>${esc((c.ukrep || h.obstojec || "").slice(0, 90))}</td><td><button class="btn sm edit" data-o="${esc(h.id)}">Uredi</button></td></tr>`; };
    const glava = '<thead><tr><th>Korak</th><th>Nevarnost</th><th>Tveganje</th><th>Vrsta ukrepa</th><th>Ukrep / opis</th><th></th></tr></thead>';
    const brezNizkih = nizke.filter(h => !(W.kontrole[h.id] || {}).vrsta).length;
    el.innerHTML = `<div class="card"><h2>5. Kontrolni ukrepi</h2>
    <p class="note info"><span class="badge vu-prp">PRP</span> predpogojni program (splošna higiena), <span class="badge vu-oprp">OPRP</span> operativni predpogojni program (specifičen ukrep z merili), <span class="badge vu-ccp">CCP</span> kritična kontrolna točka (zadnji korak nadzora, mejne vrednosti, spremljanje, korektivni ukrepi). Odločitveno drevo daje samo <b>predlog</b>; vrsto ukrepa vedno izberete vi. Ni vsak temperaturni nadzor CCP.</p>
    ${unr ? `<p class="note">${mnx(unr, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} še ${mn(unr, ["nima", "nimata", "nimajo", "nima"])} ocene tveganja (korak 4).</p>` : ""}
    <div class="row" style="justify-content:space-between;align-items:center"><h3 style="margin:0">Pomembne nevarnosti (srednje in visoko tveganje)</h3>${editable && sig.length ? '<button class="btn sm ghost edit" id="drevo_b" title="Odgovori V1–V4, vrsta ukrepa, mejna vrednost iz režima živila – za nevarnosti brez izbrane vrste ukrepa">Predlagaj razvrstitev iz baze (odločitveno drevo)</button>' : ""}${editable && Object.keys(oz).length ? '<button class="btn sm ghost sec" id="prest" title="Številke CCP/OPRP so zaklenjene ob potrditvi; tu jih uredite po vrstnem redu korakov">Preštevilči …</button>' : ""}</div>
    <div class="tw"><table class="t">${glava}<tbody>${sig.sort(poKoraku).map(h => vrstica(h, "data-h")).join("") || '<tr><td colspan="6" class="empty">Ni pomembnih nevarnosti (ocenite tveganje v koraku 4).</td></tr>'}</tbody></table></div>
    ${nizke.length ? `<details class="nizka" style="margin-top:12px"><summary><b>${mnx(nizke.length, ["nizko tveganje", "nizki tveganji", "nizka tveganja", "nizkih tveganj"])} – PRP</b>${brezNizkih ? ` <span class="mut">(${brezNizkih} brez izbrane vrste ukrepa)</span>` : ""}</summary><p class="mut">Nizka tveganja se praviloma obvladujejo s predpogojnimi programi. Vrsto ukrepa lahko določite posamično ali vsem hkrati.</p>${brezNizkih ? '<div class="row"><button class="btn sm ghost edit" id="nprp">Vsem brez ukrepa dodeli PRP</button></div>' : ""}<div class="tw"><table class="t">${glava}<tbody>${nizke.sort(poKoraku).map(h => vrstica(h, "data-hn")).join("")}</tbody></table></div></details>` : ""}</div>`;
    $$("[data-o]", el).forEach(b => b.onclick = () => ctrlForm(W.nevarnosti.find(h => h.id === b.dataset.o), () => s5(el)));
    const np = $("#nprp"); if (np) np.onclick = () => { nizke.forEach(h => { if (!(W.kontrole[h.id] || {}).vrsta) W.kontrole[h.id] = { hid: h.id, vrsta: "PRP", utemeljitev: "Nizko tveganje – obvladuje se s predpogojnimi programi (dobra higienska praksa)." }; }); mark(); s5(el); $("details.nizka", el).open = true; };
    // predlog razvrstitve iz baze za odločitveno drevo (ne prepiše že izbranih ukrepov)
    const db_ = $("#drevo_b", el); if (db_) db_.onclick = () => {
      const brez = sig.filter(h => !(W.kontrole[h.id] || {}).vrsta); if (!brez.length) return toast("Vse pomembne nevarnosti že imajo izbran ukrep. Predlog za posamezno nevarnost: odprite jo in izberite »Izpolni iz baze«.");
      const st = { CCP: 0, OPRP: 0, PRP: 0 }; for (const h of brez) { const p = predlogDrevo(h, W, db); if (!p) continue; W.kontrole[h.id] = Object.assign({}, W.kontrole[h.id] || {}, p.kontrola); st[p.kontrola.vrsta] = (st[p.kontrola.vrsta] || 0) + 1; }
      zakleniOznake(W); mark(); s5(el); toast(`Predlog iz baze: ${st.CCP} CCP, ${st.OPRP} OPRP, ${st.PRP} PRP. Preverite in potrdite mejne vrednosti.`);
    };
    // ročno preštevilčenje po vrstnem redu korakov (s predogledom sprememb)
    const ps = $("#prest", el); if (ps) ps.onclick = () => {
      const zdaj = ccpOznake(W), novo = ccpOznakePoRedu(W), sp = Object.keys(novo).filter(k => novo[k] !== zdaj[k]);
      if (!sp.length) return toast("Številke CCP in OPRP so že po vrstnem redu korakov.");
      modal("Preštevilči CCP in OPRP", `<p>Številke bodo urejene po vrstnem redu korakov. Spremenijo se:</p><div class="tw"><table class="t" id="prest_t"><tr><th>Faza</th><th>Nevarnost</th><th>Zdaj</th><th>Novo</th></tr>${sp.map(k => { const h = W.nevarnosti.find(x => x.id === k); return `<tr><td>${esc(korakIme(h.korak_id))}</td><td>${esc(kratko(h.nevarnost, 50))}</td><td>${esc(zdaj[k])}</td><td><b>${esc(novo[k])}</b></td></tr>`; }).join("")}</table></div><p class="mut">Če prosto besedilo (opisi, navodila) omenja številke, jih preveri korak 6; namesto številk uporabite oznake {{CCP:faza}}.</p>`,
        [{ t: "Prekliči", cls: "ghost sec" }, { t: "Preštevilči", fn: () => { for (const [hid, o] of Object.entries(novo)) W.kontrole[hid].oznaka = o; mark(); s5(el); toast("Preštevilčeno: " + sp.length); } }]);
    };
  }
  // predlogi meril iz baze režimov: temperaturni (od–do °C) in druga merila (alkohol, sladkor, pH, a_w, metanol, SO2 …)
  // temperaturni režim: obe meji »0 do 4 °C«, samo spodnja »≥ 72 °C«, samo zgornja »≤ -18 °C«
  function ctrlForm(h, done) {
    const c = Object.assign({ hid: h.id }, W.kontrole[h.id] || {}), oz = ccpOznake(W);
    const rez = db.rezimi || [], grp = (l, a) => a.length ? `<optgroup label="${l}">${a.map(r => `<option value="${esc(r.id)}">${esc(r.naziv + " (" + rezimOpis(r) + ")")}</option>`).join("")}</optgroup>` : "";
    const html = `<p><b>${esc(h.nevarnost)}</b><br><span class="mut">Korak: ${esc(korakIme(h.korak_id))} · tveganje ${rizik(h)} (${rizikRazred(rizik(h), W.metoda)})${oz[h.id] ? " · " + oz[h.id] : ""}</span></p>
    <details open class="odl-drevo"><summary><b>Odločitveno drevo (predlog)</b></summary>${editable ? '<div class="row" style="margin:6px 0"><button type="button" class="btn sm ghost" id="dt_baza">Izpolni iz baze (drevo, režim živila)</button><span class="mut" id="dt_baza_r"></span></div>' : ""}<p class="mut" id="dt_ver" style="margin:4px 0">${drevoVer(c) === "2022" ? DREVO_VIR["2022"] : DREVO_VIR["2003"] + " – odgovori po prejšnjem drevesu" + (editable ? ' <button type="button" class="btn sm ghost sec" id="dt_nov">Uporabi drevo Codex 2022 (odgovori se izbrišejo)</button>' : "")}</p><div id="dt">${DREVO_VPR[drevoVer(c)].map((q, i) => `<label class="f odl-v"><span>V${i + 1}: ${q}</span><select data-q="${i}"><option value=""></option><option value="d">Da</option><option value="n">Ne</option></select></label>`).join("")}<div id="dtres" class="note info">Odgovorite na vprašanja.</div></div></details>
    <div class="fgrid"><label class="f req"><span>Vrsta ukrepa (izberete vi)</span><select data-k="vrsta"><option value=""></option><option>PRP</option><option>OPRP</option><option>CCP</option><option value="nobeno">Ni potreben dodaten nadzor</option></select></label>
    <label class="f wide"><span>Utemeljitev izbire</span><textarea data-k="utemeljitev"></textarea></label><label class="f wide"><span>Ukrep za obvladovanje / opis</span><textarea data-k="ukrep"></textarea></label>
    <div id="ccpf" class="wide fgrid" style="grid-column:1/-1"><p class="note wide">Za CCP in OPRP izpolnite spodaj. <b>Mejnih vrednosti ne predpisuje program</b>: vnesite jih sami ali uporabite predlog iz baze in ga strokovno potrdite.</p>
    <label class="f wide"><span>Kaj se nadzoruje</span><input data-k="kaj"></label><label class="f wide"><span>Enolični naziv (npr. Toplotna obdelava mesa)</span><input data-k="naziv"></label><label class="f"><span>Mejna vrednost / merilo</span><input data-k="mejna"></label><label class="f"><span>Vir meje</span><select data-k="mejna_vir_vrsta"><option value=""></option><option>predpis</option><option value="smernica">smernica / strokovno priporočilo</option><option>navodila proizvajalca</option><option>validacija</option><option>lastne meritve</option></select></label><label class="f wide vir-pr"><span>Predpis iz baze zakonodaje</span><select data-k="mejna_vir_predpis"><option value=""></option>${(db.zakonodaja || []).filter(z => z.status !== "razveljavljen" && z.vrsta !== "smernica").map(z => `<option>${esc(z.predpis)}</option>`).join("")}</select></label><label class="f vir-pr"><span>Člen / točka</span><input data-k="mejna_vir_clen" placeholder="npr. Priloga II, pogl. IX"></label><label class="f"><span>Temperatura</span><input data-k="temperatura" placeholder="npr. ≥ 75 °C v jedru"></label><label class="f"><span>Čas</span><input data-k="cas" placeholder="npr. 2 min"></label><label class="f"><span>Temperatura olja (cvrtje)</span><input data-k="temp_olja" placeholder="npr. ≤ 175 °C"></label><label class="f wide"><span>Validacija (zapis, kdo, kdaj)</span><textarea data-k="validacija"></textarea></label><label class="f wide"><span>Naziv evidence (pri »Drugo«)</span><input data-k="evidenca_naziv"></label><label class="f"><span>Predlog iz baze (neobvezno)</span><select id="regsel"><option value=""></option>${grp("Temperatura", rez.filter(r => !r.enota))}${grp("Druga merila (alkohol, sladkor, pH, a_w, metanol, SO2)", rez.filter(r => r.enota))}</select></label><label class="f wide"><span>Utemeljitev mejne vrednosti (vir)</span><textarea data-k="mejna_vir"></textarea></label>
    <label class="f"><span>Način spremljanja</span><input data-k="spremljanje"></label><label class="f"><span>Pogostost</span><input data-k="pogostost"></label><label class="f"><span>Odgovorna oseba</span><input data-k="odgovoren"></label><label class="f"><span>Povezane evidence</span><select data-k="evidenca">${[""].concat(Object.keys(EV)).map(k => `<option value="${k}">${k ? EV[k].ime : ""}</option>`).join("")}</select></label>
    <label class="f wide"><span>Korektivni ukrepi ob preseganju</span><textarea data-k="korektivni"></textarea></label><label class="f wide"><span>Verifikacija</span><textarea data-k="verifikacija"></textarea></label></div></div>`;
    const d = modal("Kontrolni ukrep", html, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: async () => {
      if (!c.vrsta) { toast("Izberite vrsto ukrepa.", true); return false; }
      if (c.evidenca === "drugo" && !String(c.evidenca_naziv || "").trim()) { toast("Pri evidenci »Drugo« vpišite naziv evidence.", true); const e = $("[data-k=evidenca_naziv]", d); if (e) e.focus(); return false; }
      if (c.vrsta === "CCP") { const miss = CCPPOL.filter(k => !c[k]); if (miss.length && !(await potrdi("Pri CCP manjkajo polja (" + miss.length + "). Shranim kot nepopolno? Dokument bo označen »potrebna strokovna potrditev«.", { da: "Shrani kot nepopolno" }))) return false; }
      W.kontrole[h.id] = c; zakleniOznake(W); mark(); done();
    } }]);
    bindAll(d, c);
    // predpis iz baze in člen samo pri viru »predpis«
    { const vv = $("[data-k=mejna_vir_vrsta]", d), pk = () => $$(".vir-pr", d).forEach(e => { e.hidden = vv.value !== "predpis"; }); vv.addEventListener("change", pk); pk(); }
    // polja za mejne vrednosti, spremljanje in korektivne ukrepe samo pri CCP in OPRP
    const ccpPolja = () => { $("#ccpf", d).hidden = !["CCP", "OPRP"].includes(c.vrsta); };
    $("[data-k=vrsta]", d).addEventListener("change", ccpPolja); ccpPolja();
    $("#regsel", d).onchange = e => { const r = rez.find(x => x.id === e.target.value); if (!r) return; $("[data-k=mejna]", d).value = c.mejna = r.naziv + ": " + rezimOpis(r); c.mejna_predlog = true;
      // temperaturni režim tudi pod »Temperatura« in »Čas« (prazna polja)
      { const t = drevoTempRez(r), ca = drevoCasRez(r); if (t && !c.temperatura) $("[data-k=temperatura]", d).value = c.temperatura = t; if (ca && !c.cas) $("[data-k=cas]", d).value = c.cas = ca; } if (!c.mejna_vir) { c.mejna_vir = "Predlog iz baze znanja" + (r.vir ? " (" + r.vir + ")" : " (temperaturni režimi)") + " – potrebna strokovna potrditev."; $("[data-k=mejna_vir]", d).value = c.mejna_vir; } mark(); };
    $$("[data-q]", d).forEach((sel, i) => { sel.value = (c.drevo || [])[i] || ""; });
    const ver0 = drevoVer(c);
    const dt = () => { const a = $$("[data-q]", d).map(s => s.value); c.drevo = a; if (ver0 === "2022" && a.some(Boolean)) c.drevo_ver = "2022"; $("#dtres", d).textContent = drevoBesedilo(a, ver0); };
    $$("[data-q]", d).forEach(s => s.onchange = () => { dt(); mark(); }); if ((c.drevo || []).some(Boolean)) dt();
    const dtn = $("#dt_nov", d); if (dtn) dtn.onclick = () => { c.drevo = []; c.drevo_ver = "2022"; W.kontrole[h.id] = Object.assign({}, W.kontrole[h.id] || {}, { drevo: [], drevo_ver: "2022" }); mark(); d.close(); ctrlForm(h, done); };
    const dtb = $("#dt_baza", d); if (dtb) dtb.onclick = () => { const p = predlogDrevo(h, W, db); if (!p) return toast("Baza za odločitveno drevo ni na voljo.", true);
      Object.assign(c, p.kontrola); for (const [k, v] of Object.entries(p.kontrola)) { const x = $(`[data-k=${k}]`, d); if (x && typeof v !== "object") x.value = v; }
      $$("[data-q]", d).forEach((s, i) => { s.value = c.drevo[i] || ""; }); dt(); ccpPolja(); $("[data-k=mejna_vir_vrsta]", d).dispatchEvent(new Event("change"));
      $("#dt_baza_r", d).textContent = "Pravilo: " + p.pravilo.faza + (p.profil && p.profil.naziv ? " · živilo: " + p.profil.naziv : "") + " – preverite in potrdite."; mark(); };
    if (!editable) d.querySelectorAll("input,select,textarea").forEach(e => e.disabled = true);
  }

  // 6. pregled osnutka
  function warnings() {
    const w = [];
    if (!W.koraki.length) w.push("Ni procesnih korakov.");
    if (!W.nevarnosti.length) w.push("Ni analize nevarnosti.");
    const zp = zaPreverjanje(); if (zp) w.push(zp + " nevarnosti je vezanih na spremenjen ali izbrisan korak – preverite povezavo s korakom.");
    const pr = W.nevarnosti.filter(h => ["predlog", "urejeno", "nepotrjeno"].includes(hazStatus(h))).length; if (pr) w.push(pr + " nevarnosti še ni potrjenih (predlogi, urejeni ali ročno dodani zapisi so nepreverjeni).");
    const un = W.nevarnosti.filter(h => !rizik(h)).length; if (un) w.push(un + " nevarnosti nima ocene tveganja.");
    const sig = W.nevarnosti.filter(h => rizik(h) > W.metoda.nizko_do), nc = sig.filter(h => !(W.kontrole[h.id] || {}).vrsta).length; if (nc) w.push(nc + " pomembnih nevarnosti nima izbrane vrste kontrolnega ukrepa.");
    const ccpNep = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" && CCPPOL.some(k => !c[k])).length; if (ccpNep) w.push(ccpNep + " CCP je nepopolnih (mejne vrednosti, spremljanje, korektivni ukrepi …).");
    const pm = Object.values(W.kontrole).filter(c => c.mejna_predlog).length; if (pm) w.push(pm + " mejnih vrednosti je predlog iz baze in zahteva strokovno potrditev.");
    if (!W.zivila.length) w.push("Niso vnesena živila.");
    if (!rec.obrat_id) w.push("Načrt ni povezan z obratom.");
    return w;
  }
  function s6(el) {
    const P = W.pregled, B = W.besedila;
    el.innerHTML = `<div class="card"><h2>6. Pregled osnutka</h2><div id="pr_list"><p class="mut">Preverjam načrt …</p></div>
    <p class="mut">Osnutek lahko urejate pred izvozom. Tekst spodaj se vključi v dokument.</p>
    <div class="fgrid">${inp("uvod", "Uvodno besedilo dokumenta", { wide: 1, area: 1 })}${inp("opombe", "Dodatne opombe", { wide: 1, area: 1 })}</div>
    <h3>Strokovna potrditev</h3><p class="mut">Končni HACCP načrt mora pregledati in potrditi odgovorna oseba / strokovnjak. Potrditev vpišete tukaj; stanje načrta spremenite v osnovnih podatkih.</p>
    <div class="fgrid">${inp("potrdil", "Strokovno potrdil (ime, funkcija)")}${inp("datum", "Datum potrditve", { type: "date" })}${inp("komentar", "Komentar pregledovalca", { wide: 1, area: 1 })}${inp("interni_rok", "Interni rok naslednjega pregleda načrta", { type: "date" })}${inp("interni_rok_utemeljitev", "Utemeljitev roka", { wide: 1 })}</div>
    <h3>Povzetek</h3><table class="t"><tr><td>Koraki</td><td>${W.koraki.length}</td></tr><tr><td>Nevarnosti</td><td>${W.nevarnosti.length} (pomembnih ${W.nevarnosti.filter(h => rizik(h) > W.metoda.nizko_do).length})</td></tr><tr><td>PRP / OPRP / CCP</td><td>${["PRP", "OPRP", "CCP"].map(t => Object.values(W.kontrole).filter(c => c.vrsta === t).length).join(" / ")}${Object.keys(ccpOznake(W)).length ? " (" + Object.values(ccpOznake(W)).join(", ") + ")" : ""}</td></tr></table></div>`;
    const bs = el.querySelectorAll("[data-k]"); bs.forEach(i => { const k = i.dataset.k, tgt = ["uvod", "opombe"].includes(k) ? B : P; i.value = tgt[k] || ""; i.oninput = () => { tgt[k] = i.value; mark(); }; });
    // »Strokovno potrdil«: predlogi iz uporabnikov z vlogo svetovalec (tudi administratorji), polje ostane prosto
    if (isStaff()) api("GET", "/api/svetovalci").then(L => { const i = $("[data-k=potrdil]", el); if (!i || !el.isConnected) return; el.insertAdjacentHTML("beforeend", `<datalist id="svl_potrdil">${L.map(z => `<option value="${esc([imeZNazivom(z), z.izobrazba || z.funkcija].filter(Boolean).join(", "))}">`).join("")}</datalist>`); i.setAttribute("list", "svl_potrdil"); }).catch(() => {});
    preglejNacrt(el);
  }
  // poročilo preverjanja (isto kot v izvozu) – odprta vprašanja, strokovna opozorila, obravnavana opozorila
  async function preglejNacrt(el) {
    const box = $("#pr_list", el); if (!box) return;
    let navodila = []; try { navodila = await D.list("navodila", { stranka_id: rec.stranka_id }); } catch {}
    const { porocilo } = porociloNacrta(rec, W, stranka, obrati, navodila, db, warnings());
    const odp = porocilo.filter(x => x.tip === "odprto"), opo = porocilo.filter(x => x.tip !== "odprto"), obr = Object.entries(W.obravnavano || {}).filter(([, v]) => v && v.utemeljitev);
    if (!$("#pr_list", el)) return;
    box.innerHTML = (odp.length ? `<div class="note" id="pr_odp"><b>Odprta vprašanja (${odp.length}) – dokument ostane OSNUTEK:</b><ul style="margin:6px 0 0">${odp.map(x => `<li>${esc(x.txt)}</li>`).join("")}</ul></div>` : '<p class="note info" id="pr_ok">Ni odprtih vprašanj. Strokovni pregled je vseeno obvezen.</p>')
      + (opo.length ? `<div class="note info" id="pr_opo"><b>Strokovna opozorila (${opo.length}):</b><ul style="margin:6px 0 0">${opo.map(x => `<li>${esc(x.txt)}${x.kljuc && editable ? ` <button class="btn sm ghost sec" data-obr="${esc(x.kljuc)}">Obravnavano …</button>` : ""}</li>`).join("")}</ul></div>` : "")
      + (obr.length ? `<details class="pr-obr"><summary>Obravnavana opozorila (${obr.length})</summary><ul>${obr.map(([k, v]) => `<li><b>${esc(opozoriloIme(k))}</b>: ${esc(v.utemeljitev)} <small class="mut">(${esc(v.ime || "")}, ${esc(fdate(v.cas))})</small>${editable ? ` <button class="btn sm ghost sec" data-obrx="${esc(k)}">Razveljavi</button>` : ""}</li>`).join("")}</ul></details>` : "");
    $$("[data-obr]", box).forEach(b => b.onclick = () => { const k = b.dataset.obr;
      modal("Opozorilo obravnavano", `<p>${esc(opozoriloIme(k))}</p><label class="f req"><span>Utemeljitev (izpiše se v dokumentu)</span><textarea id="obr_u" rows="3" maxlength="600" placeholder="npr. Uporabljamo samo pasterizirana jajca (dobavitelj …)."></textarea></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: () => {
        const u = $("#obr_u").value.trim(); if (u.length < 10) { toast("Vpišite utemeljitev (vsaj 10 znakov).", true); return false; }
        W.obravnavano = Object.assign({}, W.obravnavano, { [k]: { utemeljitev: u, ime: ME.u.ime, cas: new Date().toISOString() } }); mark(); preglejNacrt(el); } }]); });
    $$("[data-obrx]", box).forEach(b => b.onclick = () => { const o = Object.assign({}, W.obravnavano); delete o[b.dataset.obrx]; W.obravnavano = o; mark(); preglejNacrt(el); });
  }

  // 7. izvoz
  const prilagojeno = id => W.besedila_pogl && W.besedila_pogl[id] !== undefined && W.besedila_pogl[id] !== null;
  const besediloPoglavja = id => { if (prilagojeno(id)) return W.besedila_pogl[id]; const bp = besedilaPodatki(W, stranka, obrati.find(o => o.id === rec.obrat_id), db); return id === "prp" ? [besedilaTekst(db, "prp", bp.oznake, bp.vr), besedilaTekst(db, "alergeni", bp.oznake, bp.vr)].filter(Boolean).join("\n\n") : besedilaTekst(db, id, bp.oznake, bp.vr); };
  function pglEditor(el) {
    const P = W.poglavja, nm = i => (PGL_DEF.find(d => d[0] === P[i].id) || [])[1];
    el.innerHTML = `<h3>Poglavja dokumentacije</h3><p class="mut">Poglavja lahko vključite ali izključite, preimenujete, premaknete in dodate svoja. Številke se v dokumentu prištejejo samodejno.</p><div class="tw"><table class="t"><tr><th>Vključi</th><th>Naslov</th><th>Besedilo (lastna poglavja)</th><th></th></tr>${P.map((c, i) => `<tr data-i="${i}"><td><input type="checkbox" data-k="on"></td><td><input data-k="naslov"></td><td>${c.custom ? '<textarea data-k="besedilo" style="min-height:60px"></textarea>' : c.id === "priloga" ? '<span class="mut">samodejno iz baze zakonodaje</span>' : `<details class="pgl-b"><summary>${prilagojeno(c.id) ? '<span class="badge warn">besedilo prilagojeno</span>' : (besediloPoglavja(c.id) ? '<span class="mut">besedilo iz baze besedil</span>' : '<span class="mut">brez uvodnega besedila – po želji ga dodajte</span>')}</summary><textarea data-pb="${esc(c.id)}" style="min-height:160px" aria-label="Besedilo poglavja ${esc(c.naslov)}"></textarea><div class="row" style="margin:4px 0 0"><button class="btn sm ghost sec edit" data-pbr="${esc(c.id)}" ${prilagojeno(c.id) ? "" : "hidden"}>Ponastavi na besedilo iz baze</button><small class="mut">»## « začne podnaslov, »- « alinejo. Tabele se dodajo samodejno iz podatkov načrta.</small></div></details>`}</td><td style="white-space:nowrap"><button class="btn sm ghost sec edit" data-up="${i}">↑</button> <button class="btn sm ghost sec edit" data-dn="${i}">↓</button> ${c.custom ? `<button class="btn sm ghost sec edit" data-x="${i}">✕</button>` : ""}</td></tr>`).join("")}</table></div><div class="row" style="margin-top:8px"><button class="btn ghost edit" id="padd">+ Dodaj lastno poglavje</button><button class="btn ghost sec edit" id="preset">Ponastavi poglavja</button></div>`;
    $$("tr[data-i]", el).forEach(tr => bindAll(tr, P[+tr.dataset.i]));
    // besedilo vgrajenega poglavja: privzeto iz baze besedil (s podatki načrta); sprememba se shrani v načrt
    $$("[data-pb]", el).forEach(ta => { const id = ta.dataset.pb; ta.value = besediloPoglavja(id); ta.oninput = () => { W.besedila_pogl = W.besedila_pogl || {}; W.besedila_pogl[id] = ta.value; mark(); const r = $(`[data-pbr="${id}"]`, el); if (r) r.hidden = false; }; });
    $$("[data-pbr]", el).forEach(b => b.onclick = () => { delete W.besedila_pogl[b.dataset.pbr]; mark(); pglEditor(el); });
    $("#padd").onclick = () => { P.splice(Math.max(0, P.length - 1), 0, { id: "x" + uidc(), custom: true, on: true, naslov: "Novo poglavje", besedilo: "" }); mark(); pglEditor(el); };
    $("#preset").onclick = () => confirmBox("Ponastavim poglavja na privzeta (lastna poglavja bodo odstranjena)?", () => { W.poglavja = poglavjaCfg({}); mark(); pglEditor(el); }, true);
    $$("[data-up]", el).forEach(b => b.onclick = () => { const i = +b.dataset.up; if (i) { [P[i - 1], P[i]] = [P[i], P[i - 1]]; mark(); pglEditor(el); } });
    $$("[data-dn]", el).forEach(b => b.onclick = () => { const i = +b.dataset.dn; if (i < P.length - 1) { [P[i + 1], P[i]] = [P[i], P[i + 1]]; mark(); pglEditor(el); } });
    $$("[data-x]", el).forEach(b => b.onclick = () => { P.splice(+b.dataset.x, 1); mark(); pglEditor(el); });
    if (!editable) $$("input,textarea,button", el).forEach(e => e.disabled = true);
  }
  // korak 7 se izriše šele po svežih podatkih; če je uporabnik medtem odšel (drug korak ali stran), se ne izriše
  let s7stevec = 0;
  function s7(el) { const moj = ++s7stevec; el.innerHTML = '<p class="mut">Nalagam sveže podatke stranke, obrata in navodil …</p>'; const izris = () => { if (moj === s7stevec && el.isConnected && step === 6) s7r(el); }; osvezi().then(izris).catch(e => { fail(e); izris(); }); }
  function s7r(el) {
    W.poglavja = poglavjaCfg(W);
    el.innerHTML = `<div id="pgl" class="card"></div><div class="card"><h2>7. Izvoz dokumentacije</h2>${rec.status !== "potrjeno" ? '<p class="note">Načrt še ni potrjen – dokument bo označen kot OSNUTEK.</p>' : ""}${warnings().length ? '<p class="note">Odprte vrzeli iz koraka 6 bodo navedene v dokumentu.</p>' : ""}
    <div class="row"><button class="btn" id="xpdf">PDF dokumentacija (HiGiFood)</button><button class="btn" id="xdoc">Word (.docx, urejljivo)</button><button class="btn ghost sec" id="xxl">Excel (nevarnosti in ukrepi)</button><button class="btn ghost sec" id="xnav">PDF / Word posameznega navodila …</button></div>
    <p class="mut">Dokument vsebuje naslovnico, kazalo, številke strani, različico in datum. Ne pomeni uradne odobritve in ne zagotavlja samodejne skladnosti z zakonodajo.</p></div>
    <div class="card" id="izd_c"><h2>Naslovnica: izdelal in odobril</h2>${(() => { const iz = izdelovalecNacrta(rec), od = odobrilZa(rec.stranka_id, stranka); return `<table class="t"><tr><th style="width:30%">Izdelal (svetovalec)</th><td>${izdelovalecVrstice(iz).map(esc).join("<br>") || '<span class="mut">ni podatkov</span>'}</td></tr><tr><th>Odobril (odgovorna oseba)</th><td>${[imeZNazivom(od), od.izobrazba, od.funkcija].filter(Boolean).map(esc).join(", ") || '<span class="mut">ni vnesena – vpišite jo v profil stranke ali naj jo vnese odgovorna oseba v Moji podatki</span>'}</td></tr></table>${iz.izobrazba ? "" : '<p class="note">Pri izdelovalcu manjka izobrazba.</p>'}`; })()}
    <p class="mut">Podatki se vpišejo v <a href="#/moji-podatki">Moji podatki</a> (svetovalec in odgovorna oseba vsak svoje) in veljajo za vse dokumente.</p>
    ${(() => { const eo = odobritevNacrta(rec); return eo ? (eo.veljavna ? `<p class="note info" id="eo_st">Odobreno elektronsko: <b>${esc(eo.potrdil_ime)}</b>, ${esc(fdt(eo.cas))}. Na naslovnici je namesto ročnega podpisa navedena elektronska odobritev.</p>` : `<p class="note" id="eo_st">Elektronska odobritev (${esc(eo.potrdil_ime)}, ${esc(fdt(eo.cas))}) ni več veljavna, ker je bil načrt po odobritvi spremenjen. Načrt je treba odobriti znova.</p>`) : ""; })()}
    ${hasRole(ME.u, "odgovorna", "admin") ? '<div class="row"><button class="btn" id="eo_b">Odobri načrt elektronsko …</button></div>' : '<p class="mut">Elektronsko odobritev opravi odgovorna oseba stranke v tem koraku (z geslom).</p>'}</div>`;
    { const eb = $("#eo_b", el); if (eb) eb.onclick = () => { if (dirty) return toast("Najprej shranite spremembe načrta, nato ga odobrite.", true);
      modal("Elektronska odobritev HACCP načrta", `<p>Z odobritvijo potrjujete, da ste HACCP načrt »${esc(rec.naziv)}« (različica ${esc(rec.verzija_oznaka || "1.0")}) pregledali in ga uvajate v podjetju. Odobritev se zapiše v revizijsko sled in velja, dokler se načrt ne spremeni.</p><label class="f"><span>Vaše geslo</span><input type="password" id="eo_g" autocomplete="current-password"></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Odobri", fn: async () => {
        try { await api("POST", "/api/potrdi", { zbirka: "nacrti", id: rec.id, odobritev: true, geslo: $("#eo_g").value }); await naloziIzdelovalca(rec.stranka_id); toast("Načrt je elektronsko odobren."); s7(el); } catch (e) { fail(e); return false; } } }]); }; }
    pglEditor($("#pgl", el));
    $("#xpdf").onclick = async () => { try { const navodila = await osvezi(); const ex = { tlorisi: await tlorisiForPlan(W) }; dlBlob(buildHaccpPdf(rec, W, stranka, obrati, navodila, db, warnings(), undefined, ex), "HACCP-" + stranka.naziv + ".pdf"); const dl = dolzinaDokumenta(pdfBuild.zadnji, 50); if (dl) toast(dl, "opozorilo"); } catch (e) { fail(e); } };
    $("#xdoc").onclick = async () => { try { const navodila = await osvezi(); const ex = { tlorisi: await tlorisiForPlan(W) }; dlBlob(buildHaccpPdf(rec, W, stranka, obrati, navodila, db, warnings(), "docx", ex), "HACCP-" + stranka.naziv + ".docx"); } catch (e) { fail(e); } };
    $("#xxl").onclick = () => downloadXlsx("HACCP-analiza-" + stranka.naziv + ".xlsx", [
      { ime: "Koraki", glava: ["Št.", "Korak", "Vrsta", "Opis"], vrste: W.koraki.map((k, i) => [i + 1, k.naziv, k.tip, k.opis || ""]) },
      { ime: "Analiza nevarnosti", glava: ["Korak", "Vrsta", "Nevarnost", "Vir", "Posledica", "Obstoječi ukrepi", "Verjetnost", "Teža", "Tveganje", "Razred", "Dodatni ukrepi", "Odgovoren", "Preverjanje", "Stanje"], vrste: W.nevarnosti.map(h => [korakIme(h.korak_id), HTIPI[h.tip] || h.tip, h.nevarnost, h.vir || "", h.posledica || "", h.obstojec || "", +h.verjetnost || "", +h.teza || "", rizik(h) || "", rizik(h) ? rizikRazred(rizik(h), W.metoda) : "", h.dodatni || "", h.odgovoren || "", h.preverjanje || "", HSTAT[hazStatus(h)][1]]) },
      { ime: "Kontrolni ukrepi", glava: ["Nevarnost", "Vrsta", "Ukrep / opis", "Utemeljitev izbire", "Kaj se nadzoruje", "Mejna vrednost", "Vir meje", "Spremljanje", "Pogostost", "Odgovoren", "Korektivni ukrepi", "Verifikacija"], vrste: Object.values(W.kontrole).map(c => { const h = W.nevarnosti.find(x => x.id === c.hid) || {}; return [h.nevarnost || "", ccpOznake(W)[c.hid] || (c.vrsta === "nobeno" ? "ni potreben" : c.vrsta), c.ukrep || "", c.utemeljitev || "", c.kaj || "", c.mejna || "", c.mejna_vir || "", c.spremljanje || "", c.pogostost || "", c.odgovoren || "", c.korektivni || "", c.verifikacija || ""]; }) }]);
    $("#xnav").onclick = async () => { const nav = await D.list("navodila", { stranka_id: rec.stranka_id }); if (!nav.length) return toast("Ni navodil.", true); modal("Izberi navodilo", `<select id="nsel" size="8" style="min-height:180px">${nav.map(n => `<option value="${esc(n.id)}">${esc(n.naslov)}</option>`).join("")}</select>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Word", cls: "ghost", fn: () => { const n = nav.find(x => x.id === $("#nsel").value); if (!n) return false; dlBlob(navodiloPdf(n, stranka, db, "docx"), "navodilo-" + n.naslov + ".docx"); } }, { t: "PDF", fn: () => { const n = nav.find(x => x.id === $("#nsel").value); if (!n) return false; dlBlob(navodiloPdf(n, stranka, db), "navodilo-" + n.naslov + ".pdf"); } }]); };
  }
  draw();
  // opozorilo ob zaprtju zavihka z neshranjenimi spremembami; ob odhodu na drugo stran aplikacije se shrani samodejno
  window.onbeforeunload = e => { if (dirty && editable) { e.preventDefault(); e.returnValue = ""; return ""; } };
  const odhod = () => {
    if (location.hash.startsWith("#/carovnik/" + id)) return;
    window.removeEventListener("hashchange", odhod); window.onbeforeunload = null;
    if (dirty && editable) save("Samodejno shranjevanje ob odhodu iz čarovnika", true).catch(fail);
  };
  window.addEventListener("hashchange", odhod);
}
function navodiloPravno(d, n, db) {
  const p = (db.navodila_predloge || []).find(x => x.id === n.predloga); if (!p) return;
  const zv = zakoniVrstice(p, db); if (!zv.length) return;
  d.h(2, "Pravna podlaga (stanje baze znanja na dan izpisa)");
  d.bullets(zv.map(x => x.txt));
  const w = navodiloOpozorila(n, db); if (w.length) d.box("Opozorilo: " + w.join("; ") + ".", "r");
}
function navodiloPdf(n, stranka, db, fmt) {
  return (fmt === "docx" ? docxBuild : pdfBuild)({ naslov: n.naslov, stranka: stranka.naziv, verzija: n.verzija_oznaka || "1.0", stanje: n.status }, d => { d.h(1, n.naslov); // zaporedne vrstice »- …« so alineje (prej so se izpustile)
    let al = []; const izpisi = () => { if (al.length) { d.bullets(al); al = []; } };
    String(n.vsebina || "").split("\n").forEach(l => { if (/^8\. PRAVNA/.test(l)) return; if (/^\s*[-•] /.test(l)) { al.push(l.replace(/^\s*[-•] /, "")); return; } izpisi(); if (/^\d+\. [A-ZČŠŽĆĐ ]+$/.test(l)) d.h(2, l); else if (l.trim()) d.p(l); else d.gap(4); }); izpisi(); navodiloPravno(d, n, db); });
}

// ---------- besedila poglavij iz baze znanja (zbirka »besedila«; enako v generatorju dokumentacije) ----------
// besedilo poglavja: izbrana besedila (po oznakah dejavnosti) z vstavljenimi podatki; oblika: »## naslov«, odstavki, »- « alineje
function besedilaTekst(db, pogl, oznake, vr) {
  return (db.besedila || []).filter(b => b.poglavje === pogl && (b.oznake && b.oznake.length ? b.oznake : ["*"]).some(o => oznake.has(o))).sort((a, b) => (a.vrstni_red || 0) - (b.vrstni_red || 0))
    .map(b => (b.naslov ? "## " + b.naslov + "\n\n" : "") + String(b.besedilo || "").replace(/\{(\w+)\}/g, (m, k) => vr[k] ? vr[k] : "____")).join("\n\n");
}
function besedilaBloki(t) {
  const out = [];
  for (const del of String(t || "").split(/\n\s*\n/)) {
    const v = del.trim(); if (!v) continue;
    if (v.startsWith("## ")) { out.push({ h: v.slice(3).trim() }); continue; }
    const uvod = [], al = [];
    for (const l of v.split("\n")) { if (/^\s*-\s+/.test(l)) al.push(l.replace(/^\s*-\s+/, "").trim()); else if (al.length) al[al.length - 1] += " " + l.trim(); else uvod.push(l.trim()); }
    if (uvod.length) out.push({ p: uvod.join(" ") }); if (al.length) out.push({ ul: al });
  }
  return out;
}
// podatki načrta za vstavljanje v besedila in oznake dejavnosti za izbor besedil
function besedilaPodatki(W, stranka, ob, db) {
  const br = (db.branze || []).find(b => b.id === W.branza), dej = [stranka.dejavnost].concat(stranka.dodatne_dejavnosti || []).filter(Boolean);
  const oznake = new Set(["*", ...((br && br.oznake) || []), ...dej.flatMap(d => (typeof DEJ_PREDLOGE !== "undefined" && DEJ_PREDLOGE[d] || []).flatMap(id => ((db.branze || []).find(b => b.id === id) || {}).oznake || []))]);
  if (W.zivila.some(z => z.rte)) oznake.add("rte");
  const oz = ccpOznake(W), ccp = W.nevarnosti.filter(h => /^CCP/.test(oz[h.id] || "")).sort((a, b) => oz[a.id].localeCompare(oz[b.id], "sl", { numeric: true }));
  const alg = [...new Set(W.zivila.flatMap(z => String(z.alergeni || "").replace(/\s*\(preveriti\)/ig, "").split(/[,;]/).map(x => x.trim()).filter(x => x && !/^ni alergenov$/i.test(x))))];
  const kor = W.koraki.map(k => k.naziv).filter(Boolean), cl = (W.zbiranje.clani || []).filter(x => x.ime), ekipa = cl.length ? cl.map(x => x.ime + (x.vloga ? " – " + x.vloga : "")) : String(W.zbiranje.hacc_ekipa || "").split("\n").map(x => x.trim()).filter(Boolean);
  return { oznake, vr: {
    podjetje: stranka.naziv, obrat: ob ? ob.naziv + (ob.naslov ? ", " + ob.naslov : "") : "", odgovorna_oseba: stranka.odgovorna_oseba || "",
    dejavnost: (ob && ob.vrsta) || [...new Set(dej.map(x => String(x).trim()).filter(Boolean))].join(", ") || (br ? br.naziv : ""), izdelki: W.zivila.map(z => z.naziv).filter(Boolean).join(", "), alergeni: alg.length ? alg.join(", ") : "alergeni niso navedeni",
    kupci: W.zbiranje.kupci || "splošna populacija", koraki_stevilo: String(kor.length), koraki_seznam: kor.join(" → "),
    ccp_stevilo: String(ccp.length), ccp_seznam: ccp.length ? ccp.map(h => oz[h.id] + " (" + ((W.koraki.find(k => k.id === h.korak_id) || {}).naziv || "–") + ")").join(", ") : "kritične kontrolne točke niso določene",
    skupina: ekipa.length ? ekipa.map(x => "- " + x).join("\n") : "- ____"
  } };
}

// PDF celotne dokumentacije (12 poglavij)
const PGL_DEF = [["uvod", "Namen in obseg sistema HACCP"], ["podjetje", "Podatki o podjetju in obratu"], ["skupina", "HACCP skupina in odgovornosti"], ["dejavnost", "Dejavnost in obseg"], ["zivila", "Opis živil"], ["diagram", "Diagram poteka"], ["metodologija", "Metodologija ocene tveganja"], ["nevarnosti", "Analiza nevarnosti"], ["ukrepi", "Kontrolni ukrepi (PRP, OPRP, CCP)"], ["ccp", "Kritične kontrolne točke – nadzorni list"], ["prp", "Predpogojni programi"], ["navodila", "Delovna navodila"], ["evidence", "Evidence in obrazci"], ["verifikacija", "Verifikacija in validacija"], ["potrditev", "Potrditev in zgodovina različic"], ["priloga", "Priloga: pravna podlaga"]];
// vrstni red, vključenost in lastna poglavja (shranjeno v načrtu: W.poglavja)
function poglavjaCfg(W) {
  const sv = Array.isArray(W.poglavja) ? W.poglavja : [], out = sv.filter(c => c.custom || PGL_DEF.some(d => d[0] === c.id)).map(c => Object.assign({ on: true }, c));
  // manjkajoče privzeto poglavje (npr. novo v novejši različici) se vstavi za predhodno poglavje iz privzetega vrstnega reda
  PGL_DEF.forEach(([id, naslov], i) => { if (out.some(c => c.id === id)) return; const pred = i ? out.findIndex(c => c.id === PGL_DEF[i - 1][0]) : -1; out.splice(pred + 1, 0, { id, naslov, on: true }); });
  return out;
}
// preverjanje načrta pred izpisom: ista funkcija za korak 6 (Pregled) in izvoz (poročilo v dokumentu)
function porociloNacrta(rec, W, stranka, obrati, navodila, db, warn, ex) {
  const ob = obrati.find(o => o.id === rec.obrat_id), oz = ccpOznake(W);
  const BP = besedilaPodatki(W, stranka, ob, db);
  // izbira navodil (vsaka tema enkrat), številke poglavij za sklice, predpisi za prilogo, preverjanje pred izpisom
  const NV = izberiNavodila(navodila), NAV = NV.izbrana.slice().sort((a, b) => String(a.naslov || "").localeCompare(String(b.naslov || ""), "sl"));
  const cfg0 = poglavjaCfg(W).filter(c => c.on), PN = {}; { let n = 0; for (const c of cfg0) if (c.id !== "priloga") PN[c.id] = ((ex && ex.predpona) || "") + (++n); }
  const tekst = id => { const pr = (W.besedila_pogl || {})[id]; return pr !== undefined && pr !== null ? pr : besedilaTekst(db, id, BP.oznake, BP.vr); };
  const vseBesedilo = [W.koraki.map(k => k.naziv).join(" "), W.zivila.map(z => [z.naziv, z.priprava, z.sestava].join(" ")).join(" "), NAV.map(n => n.naslov + " " + n.vsebina).join(" "), Object.values(W.kontrole).map(c => [c.kaj, c.mejna, c.ukrep].join(" ")).join(" ")].join(" ");
  const cvre = /cvr|friter|ocvr/i.test(vseBesedilo);
  const tags = new Set(["*", W.branza, ...BP.oznake]); if (cvre) tags.add("acryl");
  const zakVsi = (db.zakonodaja || []).filter(z => z.status !== "razveljavljen");
  const izNavodil = new Set(NAV.flatMap(n => (((db.navodila_predloge || []).find(p => p.id === n.predloga) || {}).zakoni || []).map(q => q.predpis)));
  const predpisi = zakVsi.filter(z => !(z.samo_za || []).length || z.samo_za.some(o => tags.has(o))).filter(z => (z.oznake || []).some(o => tags.has(o)) || izNavodil.has(z.predpis) || (cvre && /2017\/2158/.test(z.predpis)));
  const PR = typeof preveriNacrt === "function" ? preveriNacrt({ rec, W, stranka, ob, navodila: NAV, db, oz, besedila: Object.fromEntries(cfg0.filter(c => !c.custom && c.id !== "priloga").map(c => [c.id, tekst(c.id)])), poglavja: PN, predpisi }) : [];
  const porocilo = [...(warn || []).map(t => ({ tip: "odprto", txt: t })), ...PR, ...NV.porocilo.filter(x => x.tip !== "info")];
  const odprto = porocilo.some(x => x.tip === "odprto");
  return { ob, oz, BP, NV, NAV, cfg0, PN, tekst, cvre, predpisi, PR, porocilo, odprto };
}
function buildHaccpPdf(rec, W, stranka, obrati, navodila, db, warn, fmt, ex) {
  const ob = obrati.find(o => o.id === rec.obrat_id), M = W.metoda, korak = id => (W.koraki.find(k => k.id === id) || {}).naziv || "–", oz = ccpOznake(W);
  const kRed = id => { const i = W.koraki.findIndex(k => k.id === id); return i < 0 ? 1e6 : i; };
  const { BP, NV, NAV, PN, tekst, predpisi, porocilo, odprto } = porociloNacrta(rec, W, stranka, obrati, navodila, db, warn, ex);
  // besedilo poglavja: prilagojeno v čarovniku (korak 7) ali iz baze besedil
  const Z = t => zamenjajOznake(t, W, oz), brezStevilaCCP = t => String(t || "").replace(/(?:^|\s)Število (?:kritičnih kontrolnih točk(?: \(CCP\))?|CCP)[^.\n]*\.(?=\s|$)/g, "").trim();
  // stavek o številu CCP se vedno generira (ne iz prilagojenega besedila)
  const stavekCCP = () => { const l = Object.entries(oz).filter(([, o]) => /^CCP/.test(o)).sort((a, b) => a[1].localeCompare(b[1], "sl", { numeric: true })); return `Število CCP: ${l.length}` + (l.length ? " – " + l.map(([hid, o]) => o + " (" + korak((W.nevarnosti.find(h => h.id === hid) || {}).korak_id) + ")").join(", ") : " – kritične kontrolne točke niso določene") + "."; };
  const T = (d, id) => { const pr = (W.besedila_pogl || {})[id]; let t = Z(pr !== undefined && pr !== null ? pr : besedilaTekst(db, id, BP.oznake, BP.vr)); if (id === "ccp" || id === "diagram") { t = brezStevilaCCP(t); d.p(stavekCCP()); } for (const b of besedilaBloki(t)) { if (b.h) d.h(2, b.h); else if (b.ul) d.bullets(b.ul); else d.p(b.p); } };
  const stat = potrditevNacrta(rec, W).opravljena && !odprto ? "potrjeno" : "OSNUTEK – potrebna strokovna potrditev";
  const POPIS = { ok: "da", ne: "ne" }, V = a => a === "d" ? "Da" : a === "n" ? "Ne" : "–";

  const CHS = {
    uvod: (d, H) => { d.h(1, H); T(d, "uvod"); },
    skupina: (d, H) => {
      d.h(1, H); T(d, "skupina");
      const Z = W.zbiranje, ku = [["Zaveza vodstva", Z.kultura_zaveza], ["Sporočanje težav", Z.kultura_sporocanje], ["Usposabljanje", Z.kultura_usposabljanje], ["Pregled", Z.kultura_pregled]].filter(r => r[1]);
      d.h(2, "Kultura varnosti hrane"); if (ku.length) d.table(["Področje", "Opis"], ku, [28, 72]); else d.p("[MANJKA – kultura varnosti hrane (Uredba (EU) 2021/382)]");
    },
    // predpogojni programi: iz vsakega programa 1–2 stavka in sklic na navodilo (protokol je izpisan samo v poglavju navodil)
    prp: (d, H) => {
      d.h(1, H); T(d, "prp");
      if (NAV.length) d.bullets(NAV.map(n => n.naslov + ": " + (namenNavodila(n, db) || "") + (PN.navodila ? ` Postopek: poglavje ${PN.navodila}.` : "")));
      if (!(W.besedila_pogl && W.besedila_pogl.prp != null)) { if (alergeniPotrjeni(W)) T(d, "alergeni"); else d.box("Matrika alergenov še ni popolna: alergeni niso potrjeni pri vseh živilih.", "w"); }
    },
    podjetje: (d, H) => {
      d.h(1, H); T(d, "podjetje");
      d.table(["Podatek", "Vrednost"], [["Naziv", stranka.naziv], ["Naslov", stranka.naslov || ""], ["Matična / davčna št.", [stranka.maticna, stranka.davcna].filter(Boolean).join(" / ")], ["Odgovorna oseba", stranka.odgovorna_oseba || ""], ["Obrat", ob ? ob.naziv + (ob.naslov ? ", " + ob.naslov : "") : ""], ["Registracija obrata", W.zbiranje.registracija || ""], ["Šifra dejavnosti (SKD 2025)", W.zbiranje.skd || ""], ["Površina", ob && ob.povrsina ? fnum(ob.povrsina) + " m²" : ""], ["Število zaposlenih", W.zbiranje.zaposleni || ""]].filter(r => r[1] !== ""), [30, 70]);
      const tl = (ex && (ex.tlorisi || (ex.tloris ? [{ img: ex.tloris, naslov: "Tloris obrata" }] : []))) || [];
      tl.forEach((t, i) => { d.p(tl.length > 1 ? `Tloris ${i + 1}: ${t.naslov}` : t.naslov || "Tloris obrata", { bold: true }); d.img(t.img, 470, 330, t.naslov || "Tloris obrata"); });
    },
    // dejavnost: samo opis dejavnosti, časovna organizacija, prostori, oprema, kupci in način prodaje (brez obsega, faz in protokolov)
    dejavnost: (d, H) => {
      d.h(1, H); T(d, "dejavnost");
      const rows = [["Dejavnost", BP.vr.dejavnost], ["Opis dejavnosti", Z(stranka.opis_dejavnosti || "")], ["Časovna organizacija", W.zbiranje.delovni_cas || ""], ["Prostori", Z(seznamObrata(ob && ob.prostori, ob && ob.opis_prostorov))], ["Naprave in pribor", Z(seznamObrata(ob && ob.naprave, ob && ob.oprema_opis))], ["Kupci in ciljne skupine", W.zbiranje.kupci || ""], ["Način prodaje", [(W.zbiranje.nacin_prodaje || []).join(", "), W.zbiranje.prodaja].filter(Boolean).join(" – ")]].filter(r => r[1]);
      if (rows.length) d.table(["Podatek", "Opis"], rows, [28, 72]);
    },
    // opis živil: ločen stolpec »Odprto« (opombe niso alergeni), sestava, priprava, pakiranje, rok, stanje potrditve
    zivila: (d, H) => {
      d.h(1, H); T(d, "zivila");
      // alergeni: samo alergeni EU s stanjem (predlog / potrjeno, kdo in kdaj); »Drugo« in odprta vprašanja v ločenem stolpcu »Opomba«
      const alg = z => { const a = alergeniZivila(z).join(", ") || (/ni alergenov/i.test(z.alergeni || "") ? "ni alergenov" : "–"); return a + (z.alergeni_potrjeni === true && !/preveriti|\?/i.test(z.alergeni || "") ? (z.alergeni_potrdil ? ` (potrjeno: ${z.alergeni_potrdil}${z.alergeni_potrjeno ? ", " + fdate(z.alergeni_potrjeno) : ""})` : " (potrjeno)") : " (predlog)"); };
      const opo = z => [z.alergeni_opomba, /preveriti/i.test(z.alergeni || "") ? "preveriti specifikacijo" : "", z.odprto].filter(Boolean).join("; ");
      d.table(["Živilo", "Sestava", "Priprava / pakiranje", "Shranjevanje / rok", "RTE", "Ciljna skupina", "Alergeni", "Opomba"], W.zivila.map(z => [z.naziv, z.sestava || z.skupina || "", [z.priprava, z.pakiranje].filter(Boolean).join("; "), [z.shranjevanje, z.rok].filter(Boolean).join("; "), z.rte ? "da" : "ne", z.ciljna || "", alg(z), opo(z)]), [14, 16, 15, 14, 5, 11, 14, 11]);
      const ao = alergeniObrata(W); d.p("Alergeni v obratu (izračunano iz živil): " + (ao.length ? ao.join(", ") : "ni navedenih alergenov") + ".");
    },
    diagram: (d, H) => {
      d.h(1, H);
      // stavek o preverjanju diagrama na kraju samem samo ob vpisanem datumu preverjanja
      d.p(stavekCCP());
      const t = brezStevilaCCP(Z(tekst("diagram"))), brez = W.zbiranje.diagram_preverjen ? t : String(t || "").split(/\n/).filter(l => !/na kraju samem|preverjen\w* na lokaciji/i.test(l)).join("\n");
      for (const bl of besedilaBloki(brez)) { if (bl.h) d.h(2, bl.h); else if (bl.ul) d.bullets(bl.ul); else d.p(bl.p); }
      if (W.zbiranje.diagram_preverjen) d.p("Diagram poteka je bil preverjen na kraju samem dne " + fdate(W.zbiranje.diagram_preverjen) + ".");
      const el = (k, i) => { const c = ccpNaKoraku(W, k.id); return { n: i + 1, t: k.naziv, ccp: !!c.length, tag: c.join(", ") }; }, Ks = W.koraki.map((k, i) => [k, i]);
      if (!Ks.some(([k]) => k.veja)) d.flow(Ks.map(([k, i]) => el(k, i)));
      else {
        const prvi = Ks.findIndex(([k]) => k.veja), zadnji = Ks.length - 1 - [...Ks].reverse().findIndex(([k]) => k.veja), veje = [...new Set(Ks.filter(([k]) => k.veja).map(([k]) => k.veja))];
        if (prvi > 0) { d.p("Skupni začetek", { bold: true }); d.flow(Ks.slice(0, prvi).map(([k, i]) => el(k, i))); }
        for (const v of veje) { d.p("Linija: " + v, { bold: true }); d.flow(Ks.filter(([k]) => k.veja === v).map(([k, i]) => el(k, i))); }
        const kon = Ks.slice(zadnji + 1).filter(([k]) => !k.veja); if (kon.length) { d.p("Skupni konec", { bold: true }); d.flow(kon.map(([k, i]) => el(k, i))); }
      }
    },
    metodologija: (d, H) => {
      d.h(1, H); T(d, "metodologija");
      d.p(`Tveganje = verjetnost × teža posledic (obe na lestvici 1–5). Razredi: nizko (≤ ${M.nizko_do}), srednje (≤ ${M.srednje_do}), visoko (nad ${M.srednje_do}). Pomembne nevarnosti so v razredu srednje in visoko.`); d.p("Verjetnost: " + M.verjetnost.join("; ")); d.p("Teža posledic: " + M.teza.join("; "));
      d.p("Razvrstitev kontrolnih ukrepov (PRP, OPRP, CCP) je izvedla odgovorna oseba z uporabo odločitvenega drevesa Codex Alimentarius (CXC 1-1969, rev. 2022, Priloga IV) kot pripomočka. Mejne vrednosti so navedene z virom; vrednosti brez vira so navedene v poročilu pred izpisom.");
    },
    // analiza nevarnosti: ločena stolpca »Dodatni ukrepi« in »Odgovoren«
    nevarnosti: (d, H) => {
      d.h(1, H); T(d, "nevarnosti");
      // nizka tveganja v strnjeni tabeli pod glavno tabelo (obvladujejo se s PRP)
      const vse = W.nevarnosti.map((h, i) => [h, i]).sort((a, b) => kRed(a[0].korak_id) - kRed(b[0].korak_id) || a[1] - b[1]).map(x => x[0]), niz = vse.filter(h => rizik(h) && rizik(h) <= M.nizko_do), ur = vse.filter(h => !niz.includes(h));
      d.table(["Korak", "Vrsta", "Nevarnost / vir", "Obstoječi ukrepi", "V×T", "Razred", "Dodatni ukrepi", "Odgovoren"], ur.map(h => [korak(h.korak_id), HTIPI[h.tip] || h.tip, h.nevarnost + (h.vir ? " (vir: " + h.vir + ")" : ""), h.obstojec || "", rizik(h) ? (h.verjetnost + "×" + h.teza + "=" + rizik(h)) : "?", rizik(h) ? rizikRazred(rizik(h), M) : "neocenjeno", (h.dodatni || "") + (hazStatus(h) !== "potrjeno" ? " (" + HSTAT[hazStatus(h)][1] + ")" : ""), h.odgovoren || ""]), [12, 8, 22, 15, 7, 8, 18, 10]);
      if (niz.length) { d.h(2, "Nizka tveganja (obvladujejo se s predpogojnimi programi)"); d.table(["Korak", "Nevarnost", "V×T", "Ukrep"], niz.map(h => [korak(h.korak_id), h.nevarnost, h.verjetnost + "×" + h.teza + "=" + rizik(h), (W.kontrole[h.id] || {}).vrsta || "PRP"]), [22, 50, 12, 16]); }
      const oc = W.nevarnosti.filter(h => rizik(h)); if (oc.length && !niz.length) { if (W.metoda.nizke_izpuscene) d.p("Nizka tveganja v analizi niso navedena; obvladujejo se s predpogojnimi programi (PRP)."); else d.box("Opozorilo: nobena nevarnost ni ocenjena kot nizka – preverite oceno tveganja.", "w"); }
      const obr = Object.entries(W.obravnavano || {}).filter(([, v]) => v && v.utemeljitev);
      if (obr.length) { d.h(2, "Obravnavana strokovna opozorila"); d.bullets(obr.map(([k, v]) => opozoriloIme(k) + " – " + v.utemeljitev)); }
    },
    // razvrstitev ukrepov: faza, nevarnost, odgovori V1–V4, razvrstitev, utemeljitev (brez krajšanja besedila)
    ukrepi: (d, H) => {
      d.h(1, H); T(d, "ukrepi");
      const vr = W.nevarnosti.filter(h => W.kontrole[h.id]).sort((a, b) => kRed(a.korak_id) - kRed(b.korak_id));
      const verz = [...new Set(vr.filter(h => (W.kontrole[h.id].drevo || []).some(Boolean)).map(h => drevoVer(W.kontrole[h.id])))].sort().reverse();
      for (const v of verz) d.p("Odločitveno drevo – " + DREVO_VIR[v] + (verz.length > 1 ? " (vrstice z oznako " + v + ")" : "") + ": " + DREVO_VPR[v].map((q, i) => "V" + (i + 1) + " " + q).join(" "));
      d.table(["Faza", "Nevarnost", "V1", "V2", "V3", "V4", "Razvrstitev", "Utemeljitev"], vr.map(h => { const c = W.kontrole[h.id], a = c.drevo || []; return [korak(h.korak_id), h.nevarnost || "", V(a[0]), V(a[1]), V(a[2]), V(a[3]), (c.vrsta === "nobeno" ? "ni potreben" : oz[h.id] || c.vrsta) + (verz.length > 1 && a.some(Boolean) ? " (" + drevoVer(c) + ")" : ""), Z([c.utemeljitev, c.ukrep].filter(Boolean).join(" – "))]; }), [14, 22, 5, 5, 5, 5, 10, 34]);
    },
    // CCP in OPRP: naslov iz enoličnega naziva (OPRP6), vir meje, ločeno temperatura in čas
    ccp: (d, H) => {
      d.h(1, H); T(d, "ccp"); // T izpiše generiran stavek »Število CCP: n – …«
      const ccps = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" || c.vrsta === "OPRP");
      if (!ccps.length) d.p("Kritične kontrolne točke ali OPRP niso določene.");
      ccps.sort((a, b) => String(oz[a.hid] || "").localeCompare(String(oz[b.hid] || ""), "sl", { numeric: true })).forEach(c => {
        const h = W.nevarnosti.find(x => x.id === c.hid) || {};
        d.h(2, (oz[c.hid] || c.vrsta) + (c.naziv ? " – " + c.naziv : ""));
        d.table(["Postavka", "Vsebina"], [["Faza", korak(h.korak_id)], ["Nevarnost", h.nevarnost], ["Kaj se nadzoruje", c.kaj], ["Mejna vrednost / merilo", c.mejna || "[MANJKA – mejna vrednost]"], ["Temperatura", c.temperatura], ["Čas", c.cas], ["Temperatura olja", c.temp_olja], ["Vir meje", virMeje(c) || "[MANJKA – vir meje]"], ["Spremljanje", c.spremljanje], ["Pogostost", c.pogostost], ["Odgovorna oseba", c.odgovoren], ["Korektivni ukrepi", c.korektivni], ["Evidenca", c.evidenca ? ((EV[c.evidenca] || {}).ime || c.evidenca) + (c.evidenca_naziv ? ": " + c.evidenca_naziv : "") : "[MANJKA – evidenca]"]].filter(r => r[1]), [28, 72]);
      });
    },
    // navodila: naslov poglavja enkrat, podjetje in različica enkrat v uvodu, vsak protokol (tema) enkrat, brez OPOMBE in pravne podlage
    navodila: (d, H) => {
      d.h(1, H); T(d, "navodila");
      if (!NAV.length) { d.p("Navodila še niso dodana."); return; }
      d.p(`Navodila veljajo za ${stranka.naziv}${ob ? ", " + ob.naziv : ""}. Pravna podlaga navodil je v prilogi.`);
      const vers = new Set(NAV.map(n => (n.verzija_oznaka || "") + "|" + (n.status || "")));
      if (vers.size > 1) d.table(["Navodilo", "Različica", "Stanje"], NAV.map(n => [n.naslov, n.verzija_oznaka || "", n.status || ""]), [60, 15, 25]);
      else d.p(`Vsa navodila: različica ${[...vers][0].split("|")[0] || "1.0"}, stanje ${[...vers][0].split("|")[1] || "osnutek"}.`, { size: 9 });
      NAV.forEach(n => {
        d.h(2, n.naslov); let al = []; const izpisi = () => { if (al.length) { d.bullets(al); al = []; } };
        for (const l of cistiNavodilo(n).vrstice.map(Z)) { if (/^\s*[-•] /.test(l)) { al.push(l.replace(/^\s*[-•] /, "")); continue; } izpisi(); if (/^\d+\.\s+[A-ZČŠŽĆĐ ]{3,}$/.test(l.trim())) d.p(l.trim(), { bold: true, size: 9.5 }); else if (l.trim()) d.p(l, { size: 9, gap: 1 }); }
        izpisi();
      });
    },
    // evidence: vsak CCP in OPRP ima evidenco; »Drugo« z nazivom
    evidence: (d, H) => {
      d.h(1, H); T(d, "evidence");
      const k = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" || c.vrsta === "OPRP").sort((a, b) => String(oz[a.hid] || "").localeCompare(String(oz[b.hid] || ""), "sl", { numeric: true }));
      if (k.length) d.table(["CCP / OPRP", "Faza", "Evidenca"], k.map(c => [oz[c.hid] || c.vrsta, korak((W.nevarnosti.find(x => x.id === c.hid) || {}).korak_id), c.evidenca ? (c.evidenca === "drugo" ? (c.evidenca_naziv || "[MANJKA – naziv evidence]") : (EV[c.evidenca] || {}).ime || c.evidenca) : "[MANJKA – evidenca]"]), [20, 30, 50]);
    },
    // verifikacija in validacija za vsak CCP in OPRP
    verifikacija: (d, H) => {
      d.h(1, H); T(d, "verifikacija");
      const k = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" || c.vrsta === "OPRP").sort((a, b) => String(oz[a.hid] || "").localeCompare(String(oz[b.hid] || ""), "sl", { numeric: true }));
      if (k.length) d.table(["CCP / OPRP", "Plan verifikacije", "Validacija (zapis)"], k.map(c => [oz[c.hid] || c.vrsta, c.verifikacija || "[MANJKA – plan verifikacije]", c.validacija || "[MANJKA – zapis validacije]"]), [16, 42, 42]);
      if (W.pregled.interni_rok) d.p(`Interni rok naslednjega pregleda načrta: ${fdate(W.pregled.interni_rok)}${W.pregled.interni_rok_utemeljitev ? " – " + W.pregled.interni_rok_utemeljitev : ""}.`);
      if (W.pregled.komentar) d.p(W.pregled.komentar); if (W.besedila.opombe) d.p(W.besedila.opombe);
    },
    potrditev: (d, H) => {
      d.h(1, H); T(d, "potrditev");
      const po = potrditevNacrta(rec, W);
      // osnutek ne prikaže potrditve kot opravljene: le »Predvideni strokovni pregled«
      d.table(["Podatek", "Vrednost"], (po.opravljena ? [["Stanje načrta", stat], ["Strokovno potrdil", po.potrdil], ["Datum potrditve", fdate(po.datum)]]
        : [["Stanje načrta", stat], ["Predvideni strokovni pregled", [po.potrdil, po.datum ? "predviden datum " + fdate(po.datum) : ""].filter(Boolean).join(", ") || "ni določen"]]).concat([["Različica dokumenta", rec.verzija_oznaka || "1.0"]]), [30, 70]);
      const zg = zgodovinaNacrta(rec);
      if (zg.length) { if (pre) { d.h(2, "Zgodovina sprememb"); d.table(["Rev.", "Kdaj", "Kdo", "Sprememba"], zg.slice(-15).map(r => [r.n, fdt(r.cas), r.ime, r.razlog || (r.prej && "status" in r.prej ? "sprememba stanja: " + (r.prej.status || "") + " → " : "")]), [8, 22, 22, 48]); } else d.p("Zgodovina sprememb je v evidenci različic na začetku dokumenta.", { col: "m" }); }
    },
    // priloga: predpisi po tipu obrata in navodilih, datum zadnjega preverjanja; Uredba (EU) 2017/2158, kadar obrat cvre
    priloga: (d, H) => {
      d.h(1, H);
      d.p("Seznam predpisov iz baze znanja z datumom zadnjega preverjanja (izbor po dejavnosti obrata in navodilih). Pred uporabo preverite aktualno veljavnost v uradnih virih (EUR-Lex, PISRS).", { size: 9 });
      const skrajsaj = t => { t = String(t || ""); if (t.length <= 160) return t; const k = t.slice(0, 160); return k.slice(0, Math.max(k.lastIndexOf(" "), 120)) + " …"; };
      d.table(["Predpis", "Vsebina", "Preverjeno"], predpisi.slice(0, 80).map(z => [z.predpis + (z.vrsta === "smernica" ? " (smernica, ni predpis)" : ""), skrajsaj(z.vsebina), z.preverjeno ? fdate(z.preverjeno) : "ni preverjeno"]), [38, 50, 12]);
      if (predpisi.length > 80) d.p(`Navedenih je 80 od ${predpisi.length} predpisov; celoten seznam je v bazi znanja (Zakonodaja).`, { col: "m" });
    },
  };
  const cfg = poglavjaCfg(W).filter(c => c.on), pre = (ex && ex.predpona) || ""; // predpona številk poglavij, ko je načrt priloga drugega dokumenta
  const fill = d => {
    // evidenca različic na začetku dokumenta (nadzorovan dokument); ni v kazalu
    if (!pre) { const rz = razliciceDokumenta(rec).slice(-15); d.h(2, "Evidenca različic dokumenta");
      d.table(["Različica", "Datum potrditve", "Opis spremembe", "Potrdil"], rz.length ? rz.map(r => [r.oznaka, r.datum ? fdate(r.datum) : "", r.opis || "", r.potrdil || ""]) : [[rec.verzija_oznaka || "1.0", "", "Prva izdaja (osnutek, še ni potrjena)", ""]], [14, 18, 44, 24]);
      d.p("Veljavna je različica " + (rec.verzija_oznaka || "1.0") + (rec.status === "potrjeno" ? "." : " (osnutek).") + " Starejše različice so v arhivu sistema.", { size: 9, col: "m" }); }
    if (W.besedila.uvod) d.p(W.besedila.uvod);
    if (porocilo.length) { d.box(odprto ? `Preverjanje pred izpisom: dokument ostane OSNUTEK, dokler so odprta vprašanja (${porocilo.filter(x => x.tip === "odprto").length}).` : "Preverjanje pred izpisom: ni odprtih vprašanj; spodaj so strokovna opozorila.", odprto ? "r" : "w"); d.bullets(porocilo.map(x => (x.tip === "odprto" ? "Odprto: " : "Opozorilo: ") + x.txt)); }
    let n = 0;
    for (const c of cfg) {
      const pr = c.id === "priloga"; if (!pr) n++;
      const H = (pr ? (pre ? pre + " " : "") : pre + n + ". ") + c.naslov;
      if (c.custom) { d.h(1, H); String(Z(c.besedilo || "")).split("\n").forEach(l => { if (l.trim()) d.p(l); else d.gap(4); }); }
      else CHS[c.id](d, H);
    }
  };
  if (fmt === "fill") return fill; // samo vsebina (npr. priloga paketa za inšpekcijo)
  return (fmt === "docx" ? docxBuild : pdfBuild)({ naslov: "HACCP načrt: " + rec.naziv, podnaslov: ob ? ob.naziv : "", stranka: stranka.naziv, verzija: rec.verzija_oznaka || "1.0", avtor: ME.u.ime, izdelal: izdelovalecVrstice(izdelovalecNacrta(rec)), izdelalNoga: izdelovalecNoga(izdelovalecNacrta(rec)), izdelalLogo: izdelovalecLogoZa(rec.stranka_id), podpisi: podpisiNacrta(rec, W, stranka), stanje: stat, tocNivo: 1 }, fill);
}
route(/^\/carovnik\/([\w-]+)$/, pageCarovnik, "Čarovnik HACCP", "stranke");
