// Urejevalnik tlorisa (SVG): sobe, stene, vrata, naprave, vabe (DDD), poti (čista/nečista, hladna/topla veriga), besedilo.
const TL = { S: 50, snap: 0.25 };
const TL_TIPI = { "čisto območje": "#e3f1e8", "nečisto območje": "#fbe4e1", "skladišče": "#e8edf7", "hladno skladišče": "#d9e8fa", "kuhinja / priprava": "#fff1d1", "sanitarije / garderoba": "#efe6f5", "drugo": "#f1f1ef" };
const TL_POTI = { "čista pot": ["#1e7a46", ""], "nečista pot": ["#b3261e", ""], "hladna veriga": ["#1f5f99", "8 5"], "topla veriga": ["#d9822b", "8 5"], "odpadki": ["#6b4f2a", "3 4"], "osebje": ["#7a3fa0", "2 5"] };
const TL_OPR = { hladilnik: [0.7, 0.7, "#cfe3f7"], zamrzovalnik: [0.7, 0.7, "#b9d4f2"], "štedilnik / pečica": [0.8, 0.7, "#f5d9b0"], umivalnik: [0.6, 0.5, "#dff0f0"], "umivalnik za roke": [0.45, 0.4, "#bfe6e6"], "delovna miza": [1.6, 0.7, "#f4f4f4"], polica: [1.2, 0.4, "#ece6da"], "koš za odpadke": [0.4, 0.4, "#d8d2c4"], "pomivalni stroj": [0.8, 0.7, "#e0e6ea"], drugo: [0.8, 0.6, "#f4f4f4"] };
const tuid = () => Math.random().toString(36).slice(2, 9);
const r2 = v => Math.round(v * 100) / 100;
const snapv = v => Math.round(v / TL.snap) * TL.snap;

function tlorisSvg(t, o) {
  o = o || {}; const S = TL.S, W = t.sirina_m * S, H = t.visina_m * S, leg = o.legend ? 54 : 0, E = t.elementi || [];
  const used = new Set(E.filter(e => e.t === "pot").map(e => e.vrsta)), usedS = new Set(E.filter(e => e.t === "soba").map(e => e.tip));
  const sel = id => o.sel === id ? ' data-sel="1"' : "";
  const out = [`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H + leg}" width="${W}" height="${H + leg}" font-family="system-ui,Arial,sans-serif">`,
    `<defs>${Object.entries(TL_POTI).map(([k, [c]], i) => `<marker id="ar${i}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${c}"/></marker>`).join("")}${o.edit ? `<pattern id="gr" width="${S / 2}" height="${S / 2}" patternUnits="userSpaceOnUse"><path d="M ${S / 2} 0 L 0 0 0 ${S / 2}" fill="none" stroke="#dfe5e0" stroke-width="1"/></pattern>` : ""}</defs>`,
    `<rect width="${W}" height="${H + leg}" fill="#fff"/>`, o.edit ? `<rect width="${W}" height="${H}" fill="url(#gr)"/>` : "", `<rect x="0.5" y="0.5" width="${W - 1}" height="${H - 1}" fill="none" stroke="#cfd6d1"/>`];
  const order = { soba: 0, stena: 1, vrata: 2, oprema: 3, pot: 4, vaba: 5, besedilo: 6 };
  for (const e of [...E].sort((a, b) => order[a.t] - order[b.t])) {
    const id = `data-id="${xe(e.id)}"`;
    if (e.t === "soba") out.push(`<g ${id}><rect x="${e.x * S}" y="${e.y * S}" width="${e.w * S}" height="${e.h * S}" fill="${TL_TIPI[e.tip] || "#f1f1ef"}" stroke="#2f6f4f" stroke-width="2.5"/></g>`);
    else if (e.t === "stena") out.push(`<line ${id} x1="${e.x1 * S}" y1="${e.y1 * S}" x2="${e.x2 * S}" y2="${e.y2 * S}" stroke="#2b2f2d" stroke-width="6" stroke-linecap="square"/>`);
    else if (e.t === "vrata") { const w = 0.9 * S, h = 0.16 * S, vert = e.rot === 90; out.push(`<rect ${id} x="${e.x * S - (vert ? h / 2 : w / 2)}" y="${e.y * S - (vert ? w / 2 : h / 2)}" width="${vert ? h : w}" height="${vert ? w : h}" fill="#fff" stroke="#d9822b" stroke-width="2.5"/>`); }
    else if (e.t === "oprema") out.push(`<g ${id}><rect x="${e.x * S}" y="${e.y * S}" width="${e.w * S}" height="${e.h * S}" rx="3" fill="${(TL_OPR[e.ikona] || TL_OPR.drugo)[2]}" stroke="#4a5550" stroke-width="1.5"/></g>`);
    else if (e.t === "pot") { const c = TL_POTI[e.vrsta] || TL_POTI["čista pot"], i = Object.keys(TL_POTI).indexOf(e.vrsta); out.push(`<polyline ${id} points="${e.pts.map(p => p[0] * S + "," + p[1] * S).join(" ")}" fill="none" stroke="${c[0]}" stroke-width="3.5" ${c[1] ? `stroke-dasharray="${c[1]}"` : ""} marker-end="url(#ar${Math.max(0, i)})" stroke-linejoin="round"/>`); }
    else if (e.t === "vaba") { const uv = /svetlob|UV/i.test(e.vrsta || ""), cx = e.x * S, cy = e.y * S; out.push(`<g ${id}>${uv ? `<rect x="${cx - 11}" y="${cy - 11}" width="22" height="22" fill="#6b3fa0" stroke="#fff" stroke-width="1.5"/>` : `<circle cx="${cx}" cy="${cy}" r="11" fill="#b3261e" stroke="#fff" stroke-width="1.5"/>`}<text x="${cx}" y="${cy + 4}" text-anchor="middle" font-size="11" font-weight="700" fill="#fff">${xe(e.oznaka || "")}</text></g>`); }
  }
  // napisi na koncu (nad vsemi oblikami), razporejeni brez prekrivanja
  const N = tlNapisi(E, S, W, H); out.push(N.svg);
  if (o.sel) { const e = E.find(x => x.id === o.sel); if (e) { const b = e.t === "besedilo" && N.pos[e.id] ? N.pos[e.id] : tlBox(e); if (b) out.push(`<rect x="${b.x * S - 3}" y="${b.y * S - 3}" width="${b.w * S + 6}" height="${b.h * S + 6}" fill="none" stroke="#1f5f99" stroke-width="1.5" stroke-dasharray="4 3" pointer-events="none"/>`, (e.t === "soba" || e.t === "oprema") ? `<rect data-h="1" x="${(b.x + b.w) * S - 6}" y="${(b.y + b.h) * S - 6}" width="12" height="12" fill="#1f5f99" style="cursor:nwse-resize"/>` : ""); } }
  if (o.legend) {
    let x = 8; const y = H + 16; out.push(`<line x1="0" y1="${H}" x2="${W}" y2="${H}" stroke="#cfd6d1"/>`);
    for (const k of used) { const c = TL_POTI[k]; out.push(`<line x1="${x}" y1="${y}" x2="${x + 26}" y2="${y}" stroke="${c[0]}" stroke-width="3.5" ${c[1] ? `stroke-dasharray="${c[1]}"` : ""}/><text x="${x + 31}" y="${y + 4}" font-size="11" fill="#1d2420">${xe(k)}</text>`); x += 40 + k.length * 6.2; }
    x = 8; for (const k of usedS) if (k) { out.push(`<rect x="${x}" y="${y + 18}" width="14" height="12" fill="${TL_TIPI[k] || "#f1f1ef"}" stroke="#2f6f4f"/><text x="${x + 19}" y="${y + 28}" font-size="11" fill="#1d2420">${xe(k)}</text>`); x += 36 + k.length * 6.2; }
    out.push(`<circle cx="${W - 150}" cy="${y}" r="8" fill="#b3261e"/><text x="${W - 136}" y="${y + 4}" font-size="11">vaba / past (DDD)</text><text x="${W - 8}" y="${y + 28}" text-anchor="end" font-size="10" fill="#5f6b64">merilo: mreža = 0,5 m; ${t.sirina_m} × ${t.visina_m} m</text>`);
  }
  out.push("</svg>"); return out.join("");
}
// ---------- napisi brez prekrivanja ----------
// Vrstni red: napis naprave (v njenem pravokotniku, po potrebi manjša pisava, dve vrstici ali »…«), ime prostora (znotraj prostora,
// čim bliže središču), prosto besedilo (čim bliže mestu, kamor ga je postavil uporabnik). Napis se umakne napravam, vabam, vratom,
// stenam, potem in že postavljenim napisom; podatki (položaj v tlorisu) se ne spremenijo.
// širina besedila v px: izmeri brskalnik (enaka pisava kot v SVG), sicer ocena po znakih
let tlCtx; const tlMeri = (s, f, b) => { try { tlCtx = tlCtx || document.createElement("canvas").getContext("2d"); tlCtx.font = (b ? "600 " : "") + f + "px system-ui,Arial,sans-serif"; return tlCtx.measureText(String(s || "")).width; } catch { return null; } };
const tlSir = (s, f, b) => { const m = typeof document !== "undefined" ? tlMeri(s, f, b) : null; return m !== null ? m : tlOceni(s, f, b); };
const tlOceni = (s, f, b) => [...String(s || "")].reduce((a, ch) => a + (/[il.,:;'|!()\[\]]/.test(ch) ? 0.3 : /[mwMWŠŽ@]/.test(ch) ? 0.86 : /[A-ZČĆĐ0-9]/.test(ch) ? 0.66 : ch === " " ? 0.29 : 0.56), 0) * f * (b ? 1.07 : 1);
const tlPres = (a, b) => Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
// ali daljica seka pravokotnik (Liang–Barsky)
function tlDaljica(x1, y1, x2, y2, r) {
  let t0 = 0, t1 = 1; const dx = x2 - x1, dy = y2 - y1;
  for (const [p, q] of [[-dx, x1 - r.x], [dx, r.x + r.w - x1], [-dy, y1 - r.y], [dy, r.y + r.h - y1]]) {
    if (p === 0) { if (q < 0) return false; continue; }
    const t = q / p; if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
  }
  return true;
}
// prelom besedila na širino (po besedah; predolga beseda se razdeli)
function tlLomi(s, f, maxW, b, celeBesede) {
  const out = []; let vr = "";
  for (let bes of String(s || "").split(/\s+/).filter(Boolean)) {
    if (celeBesede && tlSir(bes, f, b) > maxW) return null; // beseda ne gre v vrstico: najprej poskusi manjšo pisavo
    while (tlSir(bes, f, b) > maxW && bes.length > 1) { // predolga beseda: razdeli z vezajem
      if (vr) { out.push(vr); vr = ""; }
      let n = bes.length - 1; while (n > 1 && tlSir(bes.slice(0, n) + "-", f, b) > maxW) n--;
      out.push(bes.slice(0, n) + "-"); bes = bes.slice(n);
    }
    const t = vr ? vr + " " + bes : bes;
    if (vr && tlSir(t, f, b) > maxW) { out.push(vr); vr = bes; } else vr = t;
  }
  if (vr) out.push(vr);
  return out;
}
// največja pisava (od maxF do minF), pri kateri prelomljeno besedilo pade v okvir bw × bh; sicer zadnja vrstica s »…« in celotno besedilo v namigu
function tlPrilagodi(s, maxF, minF, bw, bh, b) {
  for (const cele of [true, false]) for (let f = maxF; f >= minF; f -= 0.5) { const vrst = tlLomi(s, f, bw, b, cele); if (vrst && vrst.length * f * 1.22 <= bh) return { f, vrst, title: "" }; }
  const f = minF, n = Math.max(1, Math.floor(bh / (f * 1.22))), vrst = tlLomi(s, f, bw, b);
  if (vrst.length <= n) return { f, vrst, title: "" };
  const v = vrst.slice(0, n); let z = v[n - 1].replace(/-$/, ""); while (z.length > 1 && tlSir(z + "…", f, b) > bw) z = z.slice(0, -1); v[n - 1] = z.trimEnd() + "…";
  return { f, vrst: v, title: s };
}
function tlNapisi(E, S, W, H) {
  const ovire = [], crte = [], postavljeni = [], pos = {}, out = [];
  const HALO = 'paint-order="stroke" stroke="#fff" stroke-width="3" stroke-linejoin="round"';
  for (const e of E) {
    if (e.t === "oprema") ovire.push({ x: e.x * S, y: e.y * S, w: e.w * S, h: e.h * S });
    else if (e.t === "vaba") ovire.push({ x: e.x * S - 13, y: e.y * S - 13, w: 26, h: 26 });
    else if (e.t === "vrata") { const b = tlBox(e); ovire.push({ x: b.x * S, y: b.y * S, w: b.w * S, h: b.h * S }); }
    else if (e.t === "stena") crte.push([e.x1 * S, e.y1 * S, e.x2 * S, e.y2 * S, 4]);
    else if (e.t === "pot" && e.pts) for (let i = 1; i < e.pts.length; i++) crte.push([e.pts[i - 1][0] * S, e.pts[i - 1][1] * S, e.pts[i][0] * S, e.pts[i][1] * S, 3]);
  }
  // cena položaja: prekrivanje z ovirami in napisi (površina) + presečene stene in poti
  const cena = (r0, brez) => {
    const m = 4, r = { x: r0.x - m, y: r0.y - m, w: r0.w + 2 * m, h: r0.h + 2 * m }; let c = 0; // odmik od naprav in drugih napisov
    for (const o of ovire) if (o !== brez) c += tlPres(r, o);
    const rl = { x: r.x - 8, y: r.y - 6, w: r.w + 16, h: r.h + 12 }; for (const p of postavljeni) c += 3 * tlPres(rl, p); // med napisi večji odmik (ne bereta se kot eno)
    for (const [x1, y1, x2, y2, d] of crte) if (tlDaljica(x1, y1, x2, y2, { x: r.x - d, y: r.y - d, w: r.w + 2 * d, h: r.h + 2 * d })) c += 60;
    return c;
  };
  // najboljši položaj iz kandidatov (urejenih po oddaljenosti od želenega mesta)
  const najboljsi = kand => { let naj = null; for (const k of kand) { const c = cena(k.r, k.brez); if (c === 0) return k; if (!naj || c < naj.c - 1e-6) naj = Object.assign({ c }, k); } return naj; };
  const mreza = (cx, cy, w, h, meje, korak, polmer) => {
    const k = [], st = Math.max(4, korak);
    for (let dy = -polmer; dy <= polmer; dy += st) for (let dx = -polmer; dx <= polmer; dx += st) {
      const x = cx + dx - w / 2, y = cy + dy - h / 2;
      if (x < meje.x || y < meje.y || x + w > meje.x + meje.w || y + h > meje.y + meje.h) continue;
      k.push({ r: { x, y, w, h }, d: dx * dx + dy * dy });
    }
    return k.sort((a, b) => a.d - b.d);
  };
  const tekst = (id, x, y, f, b, col, s, title, anchor) => `<text data-nid="${xe(id)}" x="${r2(x)}" y="${r2(y)}" text-anchor="${anchor || "middle"}" font-size="${r2(f)}"${b ? ' font-weight="600"' : ""} fill="${col}" ${HALO}>${title ? `<title>${xe(title)}</title>` : ""}${xe(s)}</text>`;
  // izpis vrstic: (x, y) je zgornji rob bloka; sredinsko ali levo poravnano
  const vrstice = (id, x, y, bl, anchor) => { for (const [vr, f, b, col, title] of bl) for (const l of vr) { y += f * 0.95; out.push(tekst(id, x, y, f, b, col, l, title, anchor)); y += f * 0.27; } };
  const visina = bl => bl.reduce((a, [vr, f]) => a + vr.length * f * 1.22, 0), sirina = bl => Math.max(1, ...bl.map(([vr, f, b]) => Math.max(0, ...vr.map(l => tlSir(l, f, b)))));
  // 1) naprave: napis se prelomi in ostane v pravokotniku naprave
  for (const e of E.filter(z => z.t === "oprema")) {
    const s = String(e.ime || e.ikona || ""); if (!s) continue;
    const bw = e.w * S - 8, bh = e.h * S - 4, cx = (e.x + e.w / 2) * S, cy = (e.y + e.h / 2) * S;
    const t = tlPrilagodi(s, 11, 6, bw, bh), bl = [[t.vrst, t.f, false, "#1d2420", t.title]], h = visina(bl), w = sirina(bl);
    vrstice(e.id, cx, cy - h / 2, bl); postavljeni.push({ x: cx - w / 2, y: cy - h / 2, w, h });
  }
  // 2) prostori: ime in vrsta prostora se prelomita in ostaneta v prostoru, čim bliže središču, stran od naprav in drugih napisov
  for (const e of E.filter(z => z.t === "soba")) {
    const ime = String(e.ime || ""), tip = e.tip && e.tip !== "drugo" ? e.tip : ""; if (!ime && !tip) continue;
    const rw = Math.max(10, e.w * S - 8), rh = Math.max(10, e.h * S - 8); let bl = null;
    iskanje: for (const cele of [true, false]) for (let f1 = 13; f1 >= 7; f1 -= 0.5) {
      const f2 = Math.max(6.5, Math.min(10, f1 * 0.78)), a = ime ? tlLomi(ime, f1, rw, true, cele) : [], b2 = tip ? tlLomi(tip, f2, rw, false, cele) : [];
      if (!a || !b2) continue;
      bl = [[a, f1, true, "#1d2420", ""], [b2, f2, false, "#5f6b64", ""]].filter(x => x[0].length);
      if (visina(bl) <= rh) break iskanje;
    }
    if (visina(bl) > rh) { // tudi z najmanjšo pisavo previsoko: samo ime, skrajšano na razpoložljive vrstice
      const f = 7, n = Math.max(1, Math.floor(rh / (f * 1.22))), t = tlPrilagodi(ime || tip, f, f, rw, n * f * 1.22); bl = [[t.vrst, t.f, !!ime, "#1d2420", t.title || [ime, tip].filter(Boolean).join(" – ")]];
    }
    const w = Math.min(rw, sirina(bl)), h = Math.min(rh, visina(bl)), meje = { x: e.x * S + 4, y: e.y * S + 4, w: rw, h: rh }, cx = (e.x + e.w / 2) * S, cy = (e.y + e.h / 2) * S;
    const kand = mreza(cx, cy, w, h, meje, Math.min(rw, rh) / 40, Math.max(rw, rh) / 2 + 2);
    const r = najboljsi(kand.length ? kand : [{ r: { x: cx - w / 2, y: cy - h / 2, w, h } }]).r;
    vrstice(e.id, r.x + r.w / 2, r.y, bl); postavljeni.push(r); pos[e.id] = { x: r.x / S, y: r.y / S, w: r.w / S, h: r.h / S };
  }
  // 3) prosto besedilo: ostane v prostoru, kamor je postavljeno (sicer v tlorisu), se po potrebi prelomi
  //    in se umakne na najbližje prosto mesto; če prostega mesta ni, ostane na svojem mestu
  for (const e of E.filter(z => z.t === "besedilo")) {
    const s = String(e.text || ""); if (!s.trim()) continue;
    const soba = E.filter(z => z.t === "soba" && e.x >= z.x && e.x <= z.x + z.w && e.y >= z.y && e.y <= z.y + z.h).sort((a, b) => a.w * a.h - b.w * b.h)[0];
    const meje = soba ? { x: soba.x * S + 4, y: soba.y * S + 4, w: Math.max(10, soba.w * S - 8), h: Math.max(10, soba.h * S - 8) } : { x: 2, y: 2, w: W - 4, h: H - 4 };
    const t = tlPrilagodi(s, +e.vel || 14, Math.min(8, +e.vel || 14), meje.w, meje.h), bl = [[t.vrst, t.f, false, "#1d2420", t.title]], w = Math.min(meje.w, sirina(bl)), h = Math.min(meje.h, visina(bl));
    const x0 = Math.min(Math.max(e.x * S, meje.x), meje.x + meje.w - w), y0 = Math.min(Math.max(e.y * S - t.f * 0.95, meje.y), meje.y + meje.h - h);
    const kand = mreza(x0 + w / 2, y0 + h / 2, w, h, meje, 6, 150), r = najboljsi([{ r: { x: x0, y: y0, w, h } }].concat(kand)).r;
    out.push(`<g data-id="${xe(e.id)}">`); vrstice(e.id, r.x, r.y, bl, "start"); out.push("</g>"); postavljeni.push(r); // besedilo je samostojen element (izbira, premik) pos[e.id] = { x: r.x / S, y: r.y / S, w: r.w / S, h: r.h / S };
  }
  return { svg: out.join(""), pos };
}
function tlBox(e) {
  if (e.t === "soba" || e.t === "oprema") return { x: e.x, y: e.y, w: e.w, h: e.h };
  if (e.t === "stena") return { x: Math.min(e.x1, e.x2), y: Math.min(e.y1, e.y2), w: Math.abs(e.x2 - e.x1), h: Math.abs(e.y2 - e.y1) };
  if (e.t === "pot") { const xs = e.pts.map(p => p[0]), ys = e.pts.map(p => p[1]); return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) }; }
  if (e.t === "vaba") return { x: e.x - 0.25, y: e.y - 0.25, w: 0.5, h: 0.5 };
  if (e.t === "vrata") return e.rot === 90 ? { x: e.x - 0.1, y: e.y - 0.45, w: 0.2, h: 0.9 } : { x: e.x - 0.45, y: e.y - 0.1, w: 0.9, h: 0.2 };
  if (e.t === "besedilo") return { x: e.x, y: e.y - 0.3, w: Math.max(0.6, (e.text || "").length * 0.17), h: 0.4 };
  return null;
}
// SVG → JPEG (za PDF/Word)
function svgToImg(svg, w, h, scale) {
  return new Promise(ok => {
    const img = new Image(), url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }));
    img.onload = () => { const k = scale || 1.5, c = document.createElement("canvas"); c.width = Math.round(w * k); c.height = Math.round(h * k); const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); c.toBlob(async b => ok({ u8: new Uint8Array(await b.arrayBuffer()), w: c.width, h: c.height }), "image/jpeg", 0.9); };
    img.onerror = () => { URL.revokeObjectURL(url); ok(null); }; img.src = url;
  });
}
async function tlorisToImg(t) { const leg = 54; return svgToImg(tlorisSvg(t, { legend: true }), t.sirina_m * TL.S, t.visina_m * TL.S + leg, 1.6); }
// tlorisi HACCP načrta: seznam { vrsta: "narisan" | "slika", id, ime, naslov }; prej sta bila največ en narisan (tloris_nacrt_id) in ena slika (tloris_id)
function tlorisiNacrta(z) {
  z = z || {}; if (Array.isArray(z.tlorisi)) return z.tlorisi.map(x => Object.assign({}, x));
  return [z.tloris_nacrt_id ? { vrsta: "narisan", id: z.tloris_nacrt_id, naslov: "" } : null, z.tloris_id ? { vrsta: "slika", id: z.tloris_id, ime: "", naslov: "" } : null].filter(Boolean);
}
// slike vseh tlorisov za dokument: [{ img, naslov }] v vrstnem redu iz čarovnika (manjkajoči se izpustijo)
async function tlorisiForPlan(W) {
  const L = tlorisiNacrta(W.zbiranje), out = []; let nar = null;
  for (const x of L) {
    try {
      if (x.vrsta === "narisan") { nar = nar || await D.list("tlorisi"); const t = nar.find(q => q.id === x.id); if (t) { const img = await tlorisToImg(t); if (img) out.push({ img, naslov: x.naslov || t.naziv || "Tloris obrata" }); } }
      else { const img = await loadImg("/api/priloga/" + x.id, 1400); if (img) out.push({ img, naslov: x.naslov || String(x.ime || "").replace(/\.[a-z0-9]{2,4}$/i, "") || "Tloris obrata" }); }
    } catch {}
  }
  return out;
}
async function tlorisForPlan(W) { const t = await tlorisiForPlan(W); return t.length ? t[0].img : null; } // združljivost: prvi tloris

// ---------- seznam v profilu stranke ----------
async function tabTloris(el, ctx) {
  SPEC.tlorisi = SPEC.tlorisi || { ime: "tloris", cols: c => [{ l: "Naziv", k: "naziv" }, { l: "Obrat", f: r => esc((c.obrati || {})[r.obrat_id] || "") }, { l: "Velikost", f: r => esc(r.sirina_m) + " × " + esc(r.visina_m) + " m" }, { l: "Elementov", f: r => (r.elementi || []).length }, { l: "Spremenjeno", f: r => fdt(r.spremenjeno || r.ustvarjeno) }], fields: c => [] };
  await listView(el, "tlorisi", ctx, {
    create: () => modal("Nov tloris", `<p class="err" id="ferr"></p><div class="fgrid"><label class="f req wide"><span>Naziv</span><input id="tn" value="Tloris obrata"></label>${fieldHtml(obratField(ctx), "", ctx)}<label class="f"><span>Širina (m)</span><input type="text" inputmode="decimal" id="tw" value="12"></label><label class="f"><span>Višina (m)</span><input type="text" inputmode="decimal" id="th" value="8"></label></div>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Ustvari", fn: async () => { try { const r = await D.add("tlorisi", { stranka_id: ctx.stranka_id, naziv: $("#tn").value.trim(), obrat_id: $("#f_obrat_id").value || null, sirina_m: Math.min(80, Math.max(2, +decBeri($("#tw").value) || 12)), visina_m: Math.min(60, Math.max(2, +decBeri($("#th").value) || 8)), elementi: [] }); location.hash = "#/tloris/" + r.id; } catch (e) { $("#ferr").textContent = e.message; return false; } } }]),
    open: r => location.hash = "#/tloris/" + r.id
  });
}

// ---------- urejevalnik ----------
async function pageTloris(v, m) {
  const id = m[1], rec = (await D.list("tlorisi")).find(x => x.id === id); if (!rec) throw new Error("Tloris ni najden ali nimate dostopa.");
  const stranka = (await D.list("stranke")).find(s => s.id === rec.stranka_id);
  const [opr, vabe] = await Promise.all([D.list("oprema", { stranka_id: rec.stranka_id }), D.list("vabe", { stranka_id: rec.stranka_id }).catch(() => [])]);
  const T = { naziv: rec.naziv, sirina_m: rec.sirina_m, visina_m: rec.visina_m, elementi: JSON.parse(JSON.stringify(rec.elementi || [])) };
  const edit = canManage();
  let tool = "izberi", sel = null, drag = null, draft = null, dirty = false; const hist = [];
  $("#title").textContent = "Tloris: " + rec.naziv;
  const push = () => { hist.push(JSON.stringify(T.elementi)); if (hist.length > 60) hist.shift(); dirty = true; $("#ts").textContent = "Shrani *"; };
  v.innerHTML = `<div class="row"><a href="#/stranka/${rec.stranka_id}/tloris" class="btn ghost sec sm">‹ Nazaj</a><span class="mut">${esc(sIme(stranka))}</span><span class="sp"></span>${edit ? '<button class="btn ghost sec sm" id="tu">↶ Razveljavi</button><button class="btn" id="ts">Shrani</button>' : ""}<button class="btn ghost sec sm" id="te">Prenesi PNG/SVG</button></div>
  ${edit ? `<div class="row" id="tb">${[["izberi", "☝ Izberi / premakni"], ["soba", "▭ Soba"], ["stena", "╱ Stena"], ["vrata", "⎍ Vrata"], ["oprema", "▣ Naprava"], ["vaba", "● Vaba (DDD)"], ["pot", "➜ Pot"], ["besedilo", "T Besedilo"]].map(([k, l]) => `<button class="btn sm ghost ${k === "izberi" ? "" : "sec"}" data-tool="${k}">${l}</button>`).join("")}<select id="tvp" style="max-width:150px" title="Vrsta poti">${Object.keys(TL_POTI).map(k => `<option>${k}</option>`).join("")}</select><select id="tvo" style="max-width:170px" title="Vrsta naprave">${Object.keys(TL_OPR).map(k => `<option>${k}</option>`).join("")}</select><button class="btn sm ghost sec" id="tend" hidden>Končaj pot</button></div><p class="mut" id="thint">Izberite orodje. Mreža 0,25 m. Del = izbriši izbrani element; puščice premikajo izbrani element (Shift = 1 m).</p>` : ""}
  <div class="grid" style="grid-template-columns:minmax(0,1fr) 260px;align-items:start"><div class="tw" style="padding:6px;overflow:auto"><div id="tc" style="touch-action:none"></div></div>
  <div class="card" id="tp"><b>Lastnosti</b><div id="tpb" class="mut" style="margin-top:6px">Izberite element.</div><hr style="border:0;border-top:1px solid var(--line)"><div class="fgrid" style="grid-template-columns:1fr 1fr"><label class="f"><span>Širina (m)</span><input type="text" inputmode="decimal" id="tsw" value="${esc(decVnos(T.sirina_m))}" ${edit ? "" : "disabled"}></label><label class="f"><span>Višina (m)</span><input type="text" inputmode="decimal" id="tsh" value="${esc(decVnos(T.visina_m))}" ${edit ? "" : "disabled"}></label></div><div id="tdd" class="mut"></div></div></div>`;
  const cont = $("#tc"), S = TL.S;
  const paint = () => { const view = draft && draft.t === "pot" ? Object.assign({}, T, { elementi: [...T.elementi, Object.assign({}, draft, { pts: draft.pts.length === 1 ? [draft.pts[0], draft.pts[0]] : draft.pts })] }) : T; cont.innerHTML = tlorisSvg(view, { edit: true, sel }); const svg = cont.firstChild; svg.style.width = "100%"; svg.style.maxWidth = "1100px"; svg.style.height = "auto"; svg.style.cursor = tool === "izberi" ? "default" : "crosshair"; };
  const draw = () => { paint(); props(); ddd(); };
  const pt = e => { const svg = cont.firstChild, r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal; return [(e.clientX - r.left) / r.width * vb.width / S, (e.clientY - r.top) / r.height * vb.height / S]; };
  const get = id => T.elementi.find(e => e.id === id);
  const move = (e, dx, dy) => { if ("x" in e) { e.x = r2(e.x + dx); e.y = r2(e.y + dy); } if (e.t === "stena") { e.x1 = r2(e.x1 + dx); e.x2 = r2(e.x2 + dx); e.y1 = r2(e.y1 + dy); e.y2 = r2(e.y2 + dy); } if (e.t === "pot") e.pts = e.pts.map(p => [r2(p[0] + dx), r2(p[1] + dy)]); };
  const hint = t => { if ($("#thint")) $("#thint").textContent = t; };
  const endPot = () => { if (draft && draft.t === "pot") { if (draft.pts.length >= 2 && draft.pts.some(q => q[0] !== draft.pts[0][0] || q[1] !== draft.pts[0][1])) { push(); T.elementi.push(draft); sel = draft.id; } draft = null; if ($("#tend")) $("#tend").hidden = true; setTool("izberi"); draw(); } };
  const setTool = k => { tool = k; $$("[data-tool]").forEach(b => b.classList.toggle("sec", b.dataset.tool !== k)); hint({ izberi: "Kliknite element za izbiro; povlecite za premik; modri kvadrat spodaj desno spremeni velikost.", soba: "Povlecite pravokotnik sobe.", stena: "Povlecite črto stene.", vrata: "Kliknite mesto vrat (zasukate v lastnostih).", oprema: "Izberite vrsto naprave in kliknite mesto.", vaba: "Kliknite mesto vabe/pasti.", pot: "Klikajte točke poti; Končaj pot ali dvoklik zaključi.", besedilo: "Kliknite mesto besedila." }[k] || ""); if (k !== "pot") { draft = null; if ($("#tend")) $("#tend").hidden = true; } else $("#tend").hidden = false; draw(); };
  if (edit) $$("[data-tool]").forEach(b => b.onclick = () => setTool(b.dataset.tool));
  cont.addEventListener("pointerdown", e => {
    if (!edit) return; const [x, y] = pt(e), sx = snapv(x), sy = snapv(y), tg = e.target.closest("[data-id]") || (n => n ? { dataset: { id: n.dataset.nid } } : null)(e.target.closest("[data-nid]")), hd = e.target.closest("[data-h]");
    if (tool === "izberi") {
      if (hd && sel) { drag = { k: "resize", id: sel, moved: false }; hist.push(JSON.stringify(T.elementi)); cont.setPointerCapture(e.pointerId); return; }
      sel = tg ? tg.dataset.id : null; if (tg) { drag = { k: "move", id: sel, x: x, y: y, moved: false }; hist.push(JSON.stringify(T.elementi)); cont.setPointerCapture(e.pointerId); } draw(); return;
    }
    if (tool === "soba") { draft = { id: tuid(), t: "soba", x: sx, y: sy, w: 0, h: 0, ime: "Prostor", tip: "drugo" }; T.elementi.push(draft); drag = { k: "new" }; cont.setPointerCapture(e.pointerId); }
    else if (tool === "stena") { draft = { id: tuid(), t: "stena", x1: sx, y1: sy, x2: sx, y2: sy }; T.elementi.push(draft); drag = { k: "new" }; cont.setPointerCapture(e.pointerId); }
    else if (tool === "vrata") { push(); const el2 = { id: tuid(), t: "vrata", x: sx, y: sy, rot: 0 }; T.elementi.push(el2); sel = el2.id; setTool("izberi"); }
    else if (tool === "oprema") { push(); const k = $("#tvo").value, d = TL_OPR[k]; const el2 = { id: tuid(), t: "oprema", x: sx, y: sy, w: d[0], h: d[1], ikona: k, ime: k === "drugo" ? "" : k.split(" ")[0] }; T.elementi.push(el2); sel = el2.id; setTool("izberi"); }
    else if (tool === "vaba") { push(); const used = new Set(T.elementi.filter(z => z.t === "vaba").map(z => z.oznaka)), free = vabe.find(b => !used.has(b.oznaka)); const el2 = { id: tuid(), t: "vaba", x: sx, y: sy, oznaka: free ? free.oznaka : String(T.elementi.filter(z => z.t === "vaba").length + 1), vrsta: free ? free.vrsta : "vaba za glodavce" }; T.elementi.push(el2); sel = el2.id; setTool("izberi"); }
    else if (tool === "besedilo") { push(); const el2 = { id: tuid(), t: "besedilo", x: sx, y: sy, text: "Besedilo", vel: 14 }; T.elementi.push(el2); sel = el2.id; setTool("izberi"); }
    else if (tool === "pot") { if (!draft) draft = { id: tuid(), t: "pot", vrsta: $("#tvp").value, pts: [] }; const lp = draft.pts[draft.pts.length - 1], now = Date.now(); if (lp && lp[0] === sx && lp[1] === sy && now - (draft.t0 || 0) < 600) { endPot(); return; } draft.pts.push([sx, sy]); draft.t0 = now; }
    draw();
  });
  cont.addEventListener("pointermove", e => {
    if (!drag) return; const [x, y] = pt(e), sx = snapv(x), sy = snapv(y);
    if (drag.k === "new") { if (draft.t === "soba") { draft.w = Math.max(0, r2(sx - draft.x)); draft.h = Math.max(0, r2(sy - draft.y)); } else { draft.x2 = sx; draft.y2 = sy; } }
    else if (drag.k === "move") { const dx = snapv(x - drag.x), dy = snapv(y - drag.y); if (dx || dy) { move(get(drag.id), dx, dy); drag.x += dx; drag.y += dy; drag.moved = true; } }
    else if (drag.k === "resize") { const el2 = get(drag.id); el2.w = Math.max(0.25, r2(sx - el2.x)); el2.h = Math.max(0.25, r2(sy - el2.y)); drag.moved = true; }
    draw();
  });
  cont.addEventListener("pointerup", () => {
    if (!drag) return;
    if (drag.k === "new") { const ok = draft.t === "soba" ? draft.w >= 0.5 && draft.h >= 0.5 : Math.hypot(draft.x2 - draft.x1, draft.y2 - draft.y1) >= 0.25; if (ok) { const d2 = draft; T.elementi = T.elementi.filter(z => z !== d2); hist.push(JSON.stringify(T.elementi)); T.elementi.push(d2); dirty = true; $("#ts").textContent = "Shrani *"; sel = draft.id; } else T.elementi = T.elementi.filter(z => z !== draft); draft = null; drag = null; setTool("izberi"); return; }
    if ((drag.k === "move" || drag.k === "resize") && drag.moved) { dirty = true; $("#ts").textContent = "Shrani *"; } else if (drag.k !== "new") hist.pop();
    drag = null; draw();
  });
  if (edit) { $("#tend").onclick = endPot; $("#tu").onclick = () => { if (!hist.length) return; T.elementi = JSON.parse(hist.pop()); sel = null; draw(); }; }
  document.onkeydown = e => { if (!edit || !document.getElementById("tc")) return; if ((e.key === "Delete" || e.key === "Backspace") && sel && !/INPUT|SELECT|TEXTAREA/.test((e.target || {}).tagName)) { push(); T.elementi = T.elementi.filter(z => z.id !== sel); sel = null; draw(); } if (e.key === "Enter" && draft) endPot(); if (e.key === "Escape") { draft = null; setTool("izberi"); }
    if (sel && /^Arrow/.test(e.key) && !/INPUT|SELECT|TEXTAREA/.test((e.target || {}).tagName || "")) { e.preventDefault(); push(); const el2 = get(sel), s2 = e.shiftKey ? 1 : TL.snap; move(el2, e.key === "ArrowLeft" ? -s2 : e.key === "ArrowRight" ? s2 : 0, e.key === "ArrowUp" ? -s2 : e.key === "ArrowDown" ? s2 : 0); draw(); } if ((e.ctrlKey || e.metaKey) && e.key === "z") { e.preventDefault(); $("#tu").click(); } };
  // lastnosti izbranega elementa
  function props() {
    const b = $("#tpb"); if (!b) return; const e = sel && get(sel);
    if (!e) { b.innerHTML = "Izberite element."; return; }
    const inp = (k, l, o) => `<label class="f"><span>${l}</span>${o && o.sel ? `<select data-p="${k}">${o.sel.map(x => `<option ${String(e[k]) === String(Array.isArray(x) ? x[0] : x) ? "selected" : ""} value="${esc(Array.isArray(x) ? x[0] : x)}">${esc(Array.isArray(x) ? x[1] : x)}</option>`).join("")}</select>` : `<input data-p="${k}" ${o && o.num ? 'inputmode="decimal" autocomplete="off"' : ""} value="${esc(e[k] === undefined ? "" : o && o.num ? decVnos(e[k]) : e[k])}">`}</label>`;
    let h = "";
    if (e.t === "soba") h = inp("ime", "Ime prostora") + inp("tip", "Vrsta", { sel: Object.keys(TL_TIPI) }) + `<div class="fgrid" style="grid-template-columns:1fr 1fr">${inp("w", "Širina m", { num: 1 })}${inp("h", "Višina m", { num: 1 })}</div>`;
    else if (e.t === "oprema") h = inp("ikona", "Vrsta", { sel: Object.keys(TL_OPR) }) + `<label class="f"><span>Naprava iz seznama opreme</span><select data-p="ime"><option value=""></option>${opr.map(o => `<option ${e.ime === o.naziv ? "selected" : ""}>${esc(o.naziv)}</option>`).join("")}</select></label>` + inp("ime", "Oznaka na tlorisu") + `<div class="fgrid" style="grid-template-columns:1fr 1fr">${inp("w", "Širina m", { num: 1 })}${inp("h", "Višina m", { num: 1 })}</div>`;
    else if (e.t === "vaba") h = `<label class="f"><span>Vaba iz registra DDD</span><select data-p="__vaba"><option value=""></option>${vabe.map(o => `<option value="${esc(o.oznaka)}" ${e.oznaka === o.oznaka ? "selected" : ""}>${esc(o.oznaka + " – " + (o.vrsta || ""))}</option>`).join("")}</select></label>` + inp("oznaka", "Oznaka") + inp("vrsta", "Vrsta", { sel: ["vaba za glodavce", "lepilna past", "svetlobna past (UV)", "feromonska past", "drugo"] });
    else if (e.t === "pot") h = inp("vrsta", "Vrsta poti", { sel: Object.keys(TL_POTI) });
    else if (e.t === "vrata") h = inp("rot", "Usmerjenost", { sel: [[0, "vodoravno"], [90, "navpično"]] });
    else if (e.t === "besedilo") h = inp("text", "Besedilo") + inp("vel", "Velikost (pisava)", { num: 1 });
    b.innerHTML = `${h}<div class="row" style="margin-top:8px">${edit ? '<button class="btn sm ghost sec" id="tdup">Podvoji</button><button class="btn sm danger" id="tdel">Izbriši</button>' : ""}</div>`;
    $$("[data-p]", b).forEach(i => { i.disabled = !edit; i.onchange = i.oninput = () => { const k = i.dataset.p, key = sel + "|" + k; if (!props.last || props.last.key !== key || Date.now() - props.last.t > 1500) push(); props.last = { key, t: Date.now() }; let val = i.value; if (k === "__vaba") { const o = vabe.find(z => z.oznaka === val); if (o) { e.oznaka = o.oznaka; e.vrsta = o.vrsta || e.vrsta; } } else { if (["w", "h", "vel"].includes(k)) val = Math.max(0.1, +decBeri(val) || 0.5); if (k === "rot") val = +decBeri(val); e[k] = val; } paint(); if (i.tagName === "SELECT") props(); }; });
    if (edit) { $("#tdel").onclick = () => { push(); T.elementi = T.elementi.filter(z => z.id !== sel); sel = null; draw(); }; $("#tdup").onclick = () => { push(); const c = JSON.parse(JSON.stringify(e)); c.id = tuid(); move(c, 0.5, 0.5); T.elementi.push(c); sel = c.id; draw(); }; }
  }
  function ddd() { const el2 = $("#tdd"); if (!el2) return; const placed = new Set(T.elementi.filter(z => z.t === "vaba").map(z => z.oznaka)), miss = vabe.filter(b => b.status !== "odstranjena" && !placed.has(b.oznaka)); el2.innerHTML = vabe.length ? (miss.length ? `<span class="badge warn">Vabe, ki še niso na tlorisu: ${miss.map(b => esc(b.oznaka)).join(", ")}</span>` : '<span class="badge ok">Vse vabe iz registra so na tlorisu</span>') : "Register vab je prazen (Higiena → DDD)."; }
  const size = () => { T.sirina_m = Math.min(80, Math.max(2, +decBeri($("#tsw").value) || T.sirina_m)); T.visina_m = Math.min(60, Math.max(2, +decBeri($("#tsh").value) || T.visina_m)); push(); draw(); };
  if (edit) { $("#tsw").onchange = $("#tsh").onchange = size; $("#ts").onclick = async () => { try { const r = await D.set("tlorisi", id, { naziv: T.naziv, sirina_m: T.sirina_m, visina_m: T.visina_m, elementi: T.elementi, _razlog: "Urejanje tlorisa" }); Object.assign(rec, r); dirty = false; $("#ts").textContent = "Shrani"; toast("Tloris shranjen (različica " + r.verzija + ")"); } catch (e) { fail(e); } }; }
  $("#te").onclick = () => modal("Prenos tlorisa", "<p>Izberite obliko. Izvoz vsebuje legendo.</p>", [{ t: "Zapri", cls: "ghost sec" }, { t: "SVG", cls: "ghost", fn: () => { dlBlob(new Blob([tlorisSvg(T, { legend: true })], { type: "image/svg+xml" }), "tloris-" + T.naziv + ".svg"); } }, { t: "PNG", fn: async () => { const leg = 54, svg = tlorisSvg(T, { legend: true }), w = T.sirina_m * TL.S, h = T.visina_m * TL.S + leg; const img = new Image(); const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" })); await new Promise(ok => { img.onload = ok; img.src = url; }); const c = document.createElement("canvas"); c.width = w * 2; c.height = h * 2; const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); c.toBlob(b => dlBlob(b, "tloris-" + T.naziv + ".png")); } }]);
  draw(); if (edit) setTool("izberi");
}
route(/^\/tloris\/([\w-]+)$/, pageTloris, "Tloris", "stranke");
