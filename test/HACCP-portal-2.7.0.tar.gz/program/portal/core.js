// Jedro portala: API, pomočniki, obrazci, tabele, usmerjevalnik. Dostop vedno preverja strežnik; tu se skrivajo samo gumbi.
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ME = { u: null };
const ROLE = { admin: "Administrator HiGiFood", svetovalec: "HACCP-svetovalec", odgovorna: "Odgovorna oseba stranke", zaposleni: "Zaposleni stranke" };
// vloge uporabnika (enako kot vloge.js na strežniku): u.vloge = ["admin", "svetovalec"] …; starejši zapisi imajo samo u.vloga
const vlogeOf = u => !u ? [] : Array.isArray(u.vloge) && u.vloge.length ? u.vloge : u.vloga ? [u.vloga] : [];
const hasRole = (u, ...r) => { const v = vlogeOf(u); return r.some(x => v.includes(x)); };
const vlogeIme = u => vlogeOf(u).map(v => (typeof ROLE !== "undefined" && ROLE[v]) || v).join(" in ");
const isStaff = () => ME.u && (hasRole(ME.u, "admin") || hasRole(ME.u, "svetovalec"));
const STATE = {}; // stanje strežnika: testno okolje, različica
const VIS = { moje: null, zak: {}, paket: null }; // zak: moduli, ki jih paket stranke ne vsebuje → potreben paket
function effPrev() { try { return JSON.parse(sessionStorage.getItem("haccp_prev") || "null"); } catch { return null; } }
const vis = id => !VIS.moje || VIS.moje[id] !== false;
async function loadVidnost() {
  const pv = effPrev();
  try { const r = await api("GET", "/api/vidnost" + (pv && ME.real ? "?kot=" + pv.kot + (pv.sid ? "&stranka_id=" + pv.sid : "") : "")); VIS.moje = r.moje; VIS.zak = r.zaklenjeno || {}; VIS.paket = r.paket || null; } catch (e) { VIS.moje = null; VIS.zak = {}; VIS.paket = null; }
}
const modulZaPot = h => /^\/carovnik\//.test(h) ? "tab:nacrti" : /^\/tloris\//.test(h) ? "tab:tloris" : /^\/qr\//.test(h) ? "tab:oprema" : /^\/(vnos|prevzem)\//.test(h) ? "tab:evidence" : null;
const PRINT = { moje: null };
async function loadTisk() { try { const r = await api("GET", "/api/tisk"); PRINT.moje = r.moje; try { localStorage.setItem("haccp_tisk", JSON.stringify(r.moje)); } catch {} } catch (e) { try { PRINT.moje = JSON.parse(localStorage.getItem("haccp_tisk") || "null"); } catch {} } }
function printKey(name) { const n = String(name || "").toLowerCase(); return n.startsWith("haccp") ? "haccp" : n.startsWith("navodilo") ? "navodila" : n.startsWith("evidence") ? "evidence" : n.startsWith("capa") ? "capa" : n.startsWith("inspekcija") ? "inspekcija" : n.startsWith("obrazec") ? "obrazci" : n.startsWith("qr") ? "qr" : "ostalo"; }
// prazna predloga za uvoz ni izpis dokumentacije, zato je onemogočen tisk ne blokira
function canPrint(name) { if (!ME.u || hasRole(ME.u, "admin") || !PRINT.moje || /^predloga-/i.test(String(name || ""))) return true; if (PRINT.moje[printKey(name)]) return true; toast("Izpis te dokumentacije vam je onemogočil administrator.", true); return false; }
const canManage = () => ME.u && !hasRole(ME.u, "zaposleni");

// razumljiv opis, kadar strežnik ne vrne svojega sporočila
const opisNapake = st => st === 413 ? "Podatki ali datoteka so preveliki za pošiljanje." : st === 404 ? "Zahtevanega podatka ni mogoče najti." : st === 403 ? "Za to dejanje nimate pravic." : st === 429 ? "Preveč zahtev v kratkem času. Počakajte minuto in poskusite znova."
  : st >= 502 && st <= 504 ? "Strežnik trenutno ni dosegljiv (morda se posodablja). Poskusite znova čez minuto." : st >= 500 ? "Na strežniku je prišlo do napake. Poskusite znova; če se ponavlja, obvestite administratorja." : "Zahteva ni uspela (koda " + st + ").";
async function api(method, url, body) {
  const pisanje = method !== "GET"; if (pisanje && typeof DCACHE !== "undefined") DCACHE.clear();
  try { return await api0(method, url, body); } finally { if (pisanje && typeof DCACHE !== "undefined") DCACHE.clear(); } // tudi branje, ki se je začelo med pisanjem, ne ostane v predpomnilniku
}
async function api0(method, url, body) {
  let r;
  try { r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) }); }
  catch (e) { const er = new Error("Ni povezave s strežnikom. Preverite internetno povezavo in poskusite znova."); er.offline = true; throw er; }
  let j = null; try { j = await r.json(); } catch {}
  if (r.status === 401 && !url.includes("/auth/prijava") && !url.includes("/auth/jaz")) { ME.u = null; showLogin(); throw new Error("Seja je potekla. Prijavite se znova."); }
  if (!r.ok) { const er = new Error((j && j.napaka) || opisNapake(r.status)); er.data = j; er.status = r.status; if (r.status === 503 && j && j.napaka === "Brez povezave") { er.offline = true; er.message = "Ni povezave s strežnikom."; } throw er; }
  return j;
}
// čakalna vrsta zapisov evidenc, ustvarjenih brez povezave (localStorage); pošlje se ob vrnitvi povezave
const OFFQ = "haccp_offq";
const offq = () => { try { return JSON.parse(localStorage.getItem(OFFQ) || "[]"); } catch { return []; } };
const offqSave = a => { try { localStorage.setItem(OFFQ, JSON.stringify(a)); } catch {} drawOffBadge(); };
function drawOffBadge() {
  const el = document.getElementById("offbadge"); if (!el) return; const n = offq().length, off = navigator.onLine === false;
  el.hidden = !n && !off; el.className = "badge " + (n ? "warn" : "info"); el.textContent = (off ? "Brez povezave" : "") + (n ? (off ? " · " : "") + "čaka na pošiljanje: " + n : "");
  el.title = n ? "Kliknite za pošiljanje" : "";
}
let syncing = false;
async function syncOffQueue(manual) {
  if (syncing || !ME.u) return; let q = offq(); if (!q.length) { drawOffBadge(); return; } syncing = true; let sent = 0, dropped = 0;
  try {
    for (const it of q.slice()) {
      try { await api("POST", "/api/d/" + it.c, it.body); sent++; q = q.filter(x => x !== it && x.t !== it.t); offqSave(q); }
      catch (e) { if (e.offline || /seja je potekla/i.test(e.message)) break; dropped++; q = q.filter(x => x.t !== it.t); offqSave(q); toast("Zapis iz čakalne vrste je bil zavrnjen: " + e.message, true); }
    }
    if (sent) { toast("Poslano zapisov, ustvarjenih brez povezave: " + sent); if (typeof render === "function") render(); }
    else if (manual && q.length) toast("Strežnik ni dosegljiv.", true);
  } finally { syncing = false; drawOffBadge(); }
}
window.addEventListener("online", () => { drawOffBadge(); syncOffQueue(); });
window.addEventListener("offline", drawOffBadge);
setInterval(() => { if (offq().length) syncOffQueue(); }, 30000);
// predpomnilnik branj zbirk (30 s): zavihki stranke in nadzorna plošča ne nalagajo istih zbirk ob vsakem odprtju;
// vsako pisanje (POST/PUT/DELETE prek api) ga izprazni, zato so po shranjevanju podatki vedno sveži; vsak klic dobi svojo kopijo
const DCACHE = new Map(), DCACHE_MS = 30000;
const D = {
  list: (c, q) => {
    const k = c + "?" + (q ? new URLSearchParams(q) : ""), h = DCACHE.get(k);
    if (h && Date.now() - h.t < DCACHE_MS) return h.p.then(x => structuredClone(x));
    const p = api("GET", "/api/d/" + k.replace(/\?$/, "")); DCACHE.set(k, { t: Date.now(), p }); p.catch(() => DCACHE.delete(k));
    return p.then(x => structuredClone(x));
  },
  add: async (c, o) => {
    try { return await api("POST", "/api/d/" + c, o); }
    catch (e) {
      if (e.offline && c === "evidence") { const body = Object.assign({ cas: new Date().toISOString() }, o), t = Date.now() + Math.random(); offqSave([...offq(), { t, c, body }]); toast("Brez povezave: zapis je shranjen v napravi in se pošlje, ko bo povezava."); return Object.assign({ id: "q" + t, ustvaril_ime: ME.u ? ME.u.ime : "", status: "čaka", verzija: 1, revizije: [] }, body); }
      throw e;
    }
  },
  set: (c, id, o) => api("PUT", "/api/d/" + c + "/" + id, o),
  del: (c, id) => api("DELETE", "/api/d/" + c + "/" + id)
};
let _baza = null;
const baza = async () => _baza || (_baza = await api("GET", "/api/baza"));

// obvestilo; napaka je jasno označena (»Napaka«), ostane dlje (do 10 s, med premikom miške nad njo ne izgine), ima gumb za zapiranje in se prebere kot opozorilo
function toast(m, err) {
  const t = $("#toast"); clearTimeout(toast.t);
  // odprto okno (dialog) je v zgornji plasti: obvestilo mora biti v njem, sicer je skrito pod oknom
  const dl = document.querySelector("dialog[open]"), kam = dl || document.body; if (t.parentElement !== kam) kam.appendChild(t);
  // err === "opozorilo": shranjeno, a z odstopanjem (rumeno) – ni napaka
  const opoz = err === "opozorilo";
  if (err) {
    t.innerHTML = `<span class="toast-ik" aria-hidden="true">⚠</span><span class="toast-b"><b>${opoz ? "Opozorilo" : "Napaka"}</b> ${esc(m)}</span><button type="button" class="toast-x" aria-label="Zapri obvestilo">×</button>`;
    t.setAttribute("role", "alert"); t.setAttribute("aria-live", "assertive"); $(".toast-x", t).onclick = () => { t.className = "toast"; };
  } else { t.textContent = m; t.setAttribute("role", "status"); t.setAttribute("aria-live", "polite"); }
  t.className = "toast show" + (err ? " err" : "") + (opoz ? " warn" : "");
  const skrij = () => { toast.t = setTimeout(() => { if (!t.matches(":hover")) t.className = "toast"; else skrij(); }, err ? Math.min(10000, 5000 + m.length * 40) : 2500); };
  skrij();
}
// napaka v kodi aplikacije (ne sporočilo strežnika): uporabnik dobi jasno navodilo, tehnični opis ostane v konzoli
const fail = e => { if (e && (e instanceof TypeError || e instanceof ReferenceError || e instanceof SyntaxError) && !e.status) { console.error(e); return toast("V aplikaciji je prišlo do nepričakovane napake. Osvežite stran in poskusite znova; če se ponavlja, jo prijavite (" + e.message + ").", true); } toast((e && e.message) || String(e), true); };

// datumi
const pad = n => String(n).padStart(2, "0");
const today = () => { const d = new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
// neveljaven datum se izpiše ubežan (vrednost lahko pride iz uvoza ali starejših podatkov)
const fdate = s => { if (!s) return ""; const m = String(s).match(/^(\d{4})-(\d\d)-(\d\d)/); return m ? `${+m[3]}. ${+m[2]}. ${m[1]}` : esc(s); };
const fdt = s => { if (!s) return ""; const d = new Date(s); return isNaN(d) || (typeof s === "string" && !/^\d{4}-\d\d-\d\d/.test(s)) ? esc(s) : `${d.getDate()}. ${d.getMonth() + 1}. ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const daysTo = s => s ? Math.round((new Date(String(s).slice(0, 10) + "T00:00:00") - new Date(today() + "T00:00:00")) / 864e5) : null; // round: dan s premikom ure ima 23 ali 25 ur
// lokalni dan (YYYY-MM-DD) časovnega žiga: zapis ob 00:30 po lokalnem času je današnji, čeprav je v UTC še prejšnji dan
const lokDan = s => { if (!s) return ""; s = String(s); if (s.length <= 10) return s; const d = new Date(s); return isNaN(d) ? s.slice(0, 10) : d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
const addDays = (s, n) => { const d = new Date(s + "T00:00:00"); d.setDate(d.getDate() + n); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
// rednost vnosov: delež obdobij v zadnjih `dni` dneh, v katerih je bil opravljen vnos po urniku pogostosti in načrtu čiščenja.
// Obdobja tečejo nazaj od zdaj, dolga toliko kot največji dovoljeni razmik; štejejo samo cela obdobja od nastanka urnika naprej,
// tekoče obdobje pa samo, če je vnos že opravljen (da se nedokončan dan ne šteje kot zamuda). null = ni urnika.
function rednostVnosov(urnik, nacrt, evid, dni = 30) {
  const zdaj = Date.now(), od0 = zdaj - dni * 864e5, post = [];
  for (const u of urnik || []) if (+u.frekvenca_ur > 0) post.push({ f: +u.frekvenca_ur, zac: u.ustvarjeno, m: r => r.vrsta === u.vrsta && (!u.naprava || r.oprema === u.naprava || r.izdelek === u.naprava) && (!u.obrat_id || r.obrat_id === u.obrat_id) });
  let ok = 0, vse = 0, imaUrnik = post.length > 0;
  // načrt čiščenja: obdobja po koledarskih dneh (lokalno), enako kot na strani Danes – čiščenje ob 7:00 in naslednji dan ob 20:00 je redno
  for (const n of nacrt || []) {
    if (n.aktivno === false || !(+n.pogostost_dni > 0)) continue;
    imaUrnik = true;
    const p = +n.pogostost_dni, dnes = today(), zac = [lokDan(n.zacetek || n.ustvarjeno), lokDan(new Date(od0).toISOString())].sort().pop() || dnes;
    const dnevi = new Set((evid || []).filter(r => r.vrsta === "ciscenje" && r.nacrt_id === n.id && r.izvedeno).map(r => lokDan(r.cas)));
    const st = 1 - daysTo(zac); // dni od začetka do danes (vključno)
    for (let i = 0; i * p < st; i++) { // obdobje i: p dni, ki se končajo i·p dni pred danes
      const je = Array.from({ length: p }, (_, k) => addDays(dnes, -(i * p + k))).some(d => d >= zac && dnevi.has(d));
      if (i === 0 && !je) continue; // tekoče obdobje brez vnosa se ne šteje
      if ((i + 1) * p > st && i > 0) break; // nepopolno obdobje pred začetkom
      vse++; if (je) ok++;
    }
  }
  for (const p of post) {
    const zac = Math.max(od0, Date.parse(p.zac) || od0), f = p.f * 36e5, casi = (evid || []).filter(p.m).map(r => Date.parse(r.cas)).filter(t => t > zac && t <= zdaj);
    for (let i = 0, n = Math.floor((zdaj - zac) / f); i < n; i++) { const d = zdaj - i * f, je = casi.some(t => t > d - f && t <= d); if (i === 0 && !je) continue; vse++; if (je) ok++; }
  }
  return imaUrnik ? { pct: vse ? Math.round(ok / vse * 100) : null, ok, vse } : null; // pct null: urnik je prenov za celo obdobje
}
// rednost po strankah (id → rezultat) iz seznamov vseh strank
function rednostStrank(stranke, urnik, nacrt, evid) {
  const po = (a, id) => (a || []).filter(x => x.stranka_id === id), od = new Date(Date.now() - 31 * 864e5).toISOString(), ev = (evid || []).filter(r => (r.cas || "") >= od);
  return Object.fromEntries(stranke.map(s => [s.id, rednostVnosov(po(urnik, s.id), po(nacrt, s.id), po(ev, s.id))]));
}
const rednostBadge = r => !r ? '<span class="mut" title="Pogostost vnosov (urnik) ali načrt čiščenja ni določen">ni urnika</span>' : r.pct === null ? '<span class="mut" title="Urnik je nov – rednost bo prikazana po prvem celem obdobju">premalo podatkov</span>' : `<span class="badge ${r.pct >= 90 ? "ok" : r.pct >= 70 ? "warn" : "bad"}" title="${r.ok} od ${r.vse} obdobij z opravljenim vnosom (zadnjih 30 dni)">${r.pct} %</span>`;
let REDNOST = {}; // za stolpec na seznamu strank
// sličice fotografij zapisa (klik odpre fotografijo v polni velikosti)
function slikeHtml(ids, n) {
  ids = ids || []; if (!ids.length) return ""; n = n || 3;
  return `<span class="thumbs">${ids.slice(0, n).map((i, k) => `<a href="/api/priloga/${encodeURIComponent(i)}" target="_blank" rel="noopener" data-brez-odpiranja title="Fotografija ${k + 1}"><img class="thumb" src="/api/priloga/${encodeURIComponent(i)}" loading="lazy" alt="Fotografija ${k + 1}" onerror="this.replaceWith(document.createTextNode('priloga'))"></a>`).join("")}${ids.length > n ? `<small class="mut">+${ids.length - n}</small>` : ""}</span>`;
}
// besedilo iz HTML (npr. povzetek zapisa za vnosno polje): brez oznak in HTML-entitet
const izHtml = h => { const t = document.createElement("textarea"); t.innerHTML = String(h == null ? "" : h).replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim(); return t.value; };
function dueBadge(s) {
  const n = daysTo(s); if (n === null) return '<span class="mut">–</span>';
  if (n < 0) return `<span class="badge bad">${fdate(s)} (zamuda ${-n} d)</span>`;
  if (n <= 30) return `<span class="badge warn">${fdate(s)} (${n === 0 ? "danes" : "čez " + n + " d"})</span>`;
  return `<span class="badge ok">${fdate(s)}</span>`;
}
const STAT = { "pretečeno": "bad", "čaka na pošiljanje": "warn", aktivna: "ok", potrjeno: "ok", opravljeno: "ok", zaprto: "ok", skladno: "ok", "v pripravi": "warn", osnutek: "warn", "v pregledu": "info", "v potrjevanju": "info", vneseno: "info", odprto: "bad", neskladno: "bad", zamuda: "bad", zastarelo: "bad", načrtovano: "info", neaktivna: "" };
// slovenske oblike števila: mn(n, ["stranka", "stranki", "stranke", "strank"]) – 1, 2, 3–4, 5+ (101 kot 1, 102 kot 2 …)
// število z besedo v pravilni obliki, npr. mnx(2, [...]) → »2 stranki«
const mnx = (n, o) => n + " " + mn(n, o);
const mn = (n, o) => { const m = Math.abs(Math.trunc(Number(n) || 0)) % 100; return o[m === 1 ? 0 : m === 2 ? 1 : m === 3 || m === 4 ? 2 : 3]; };
const badge = s => s ? `<span class="badge ${STAT[s] || ""}">${esc(s)}</span>` : "";

// ---------- modalno okno ----------
function modal(title, html, buttons) {
  const d = $("#dlg"); $("#dlg-t").textContent = title; $("#dlg-b").innerHTML = html;
  const f = $("#dlg-f"); f.innerHTML = "";
  for (const b of buttons || [{ t: "Zapri", cls: "ghost sec" }]) {
    const el = document.createElement("button"); el.className = "btn " + (b.cls || ""); el.textContent = b.t;
    el.onclick = async () => { if (!b.fn) return d.close(); el.disabled = true; try { const r = await b.fn(); if (r !== false) d.close(); } catch (e) { fail(e); } el.disabled = false; };
    f.appendChild(el);
  }
  if (!d.open) { modal.prev = document.activeElement; d.showModal(); }
  $$("label.f.req input,label.f.req select,label.f.req textarea", d).forEach(e => e.setAttribute("aria-required", "true"));
  const first = $("#dlg-b input:not([type=hidden]):not([disabled]),#dlg-b select,#dlg-b textarea", d); if (first && !/^(checkbox|file)$/.test(first.type)) setTimeout(() => { const ae = document.activeElement; if (!(ae && $("#dlg-b").contains(ae) && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName))) first.focus(); }, 30); // ne prestavi kurzorja, če uporabnik že piše v polje
  return d;
}
$("#dlg-x").onclick = () => $("#dlg").close();
// ob zaprtju okna obvestilo ostane vidno na strani (npr. »Shranjeno« po shranjevanju obrazca)
for (const d of document.querySelectorAll("dialog")) d.addEventListener("close", () => { const t = $("#toast"); if (t && d.contains(t)) document.body.appendChild(t); });
$("#dlg").addEventListener("close", () => { const p = modal.prev; modal.prev = null; if (p && document.contains(p) && p.focus) try { p.focus(); } catch {} });
// lastno okno za potrditev, obvestilo ali vnos (namesto window.confirm/alert/prompt): ločen <dialog>, ki se odpre nad morebitnim odprtim oknom.
// Vrne obljubo: potrditev → true/false, obvestilo → true, vnos → besedilo ali null (preklic). o: { naslov, da, ne, nevarno, vnos (oznaka polja), min, vrednost }
function dlgVprasanje(msg, o) {
  o = o || {};
  return new Promise(res => {
    const d = document.createElement("dialog"), tip = o.vnos ? "prompt" : o.samoOk ? "alert" : "confirm", nid = "cdlg-t" + (dlgVprasanje.n = (dlgVprasanje.n || 0) + 1);
    d.className = "cdlg"; d.dataset.tip = tip; d.setAttribute("aria-labelledby", nid); d.setAttribute("role", tip === "alert" ? "alertdialog" : "dialog");
    d.innerHTML = `<div class="dlg-h"><h3 id="${nid}">${esc(o.naslov || (tip === "alert" ? "Obvestilo" : tip === "prompt" ? "Vnos" : "Potrditev"))}</h3></div><div class="dlg-b"><p class="cdlg-m" style="white-space:pre-line;margin-top:0">${esc(msg)}</p>${tip === "prompt" ? `<label class="f req"><span>${esc(o.vnos)}</span><textarea class="cdlg-i" rows="3" maxlength="500">${esc(o.vrednost || "")}</textarea></label><p class="err cdlg-e" hidden></p>` : ""}</div><div class="dlg-f">${tip === "alert" ? "" : `<button type="button" class="btn ghost sec cdlg-no">${esc(o.ne || "Prekliči")}</button>`}<button type="button" class="btn ${o.nevarno ? "danger" : ""} cdlg-ok">${esc(o.da || (tip === "alert" ? "V redu" : "Potrdi"))}</button></div>`;
    let r = tip === "prompt" ? null : tip === "alert";
    const konec = v => { r = v; d.close(); }, inp = $(".cdlg-i", d);
    d.addEventListener("close", () => { const t = $("#toast"); if (t && d.contains(t)) document.body.appendChild(t); d.remove(); res(r); });
    $(".cdlg-ok", d).onclick = () => {
      if (!inp) return konec(true);
      const v = inp.value.trim(), e = $(".cdlg-e", d);
      if (v.length < (o.min || 1)) { e.hidden = false; e.textContent = o.min > 1 ? `Vpišite vsaj ${o.min} znakov.` : "Polje je obvezno."; inp.focus(); return; }
      konec(v);
    };
    const no = $(".cdlg-no", d); if (no) no.onclick = () => konec(tip === "prompt" ? null : false);
    document.body.appendChild(d); d.showModal(); (inp || $(".cdlg-ok", d)).focus();
  });
}
const potrdi = (msg, o) => dlgVprasanje(msg, o);
const obvesti = (msg, o) => dlgVprasanje(msg, Object.assign({ samoOk: true }, o));
const vprasaj = (msg, o) => dlgVprasanje(msg, Object.assign({ vnos: "Odgovor", da: "Shrani" }, o));
const confirmBox = (msg, fn, danger) => modal("Potrditev", `<p>${esc(msg)}</p>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Potrdi", cls: danger ? "danger" : "", fn }]);

// ---------- obrazec iz specifikacije ----------
// polje: {k, l, t: text|area|num|date|datetime|email|sel|bool|tags|ref, o: [možnosti], req, wide, ph, ref: zbirka}
// decimalna vejica: vrednost za vnosno polje (3.5 → »3,5«) in branje vnosa (»3,5« → "3.5")
const decVnos = v => v === undefined || v === null ? "" : typeof v === "number" ? String(v).replace(".", ",") : String(v);
const decBeri = s => String(s == null ? "" : s).trim().replace(/\s/g, "").replace(",", ".").replace("−", "-");
function fieldHtml(f, v, ctx) {
  const id = "f_" + f.k, val = v === undefined || v === null ? "" : f.t === "num" ? decVnos(v) : v;
  let inp;
  const opts = typeof f.o === "function" ? f.o(ctx) : f.o;
  if (f.t === "area") inp = `<textarea id="${id}" ${f.ph ? `placeholder="${esc(f.ph)}"` : ""}>${esc(val)}</textarea>`;
  else if (f.t === "sel") { // vrednost, ki je ni med možnostmi (uvoz, preimenovana naprava, starejši zapis), ostane izbrana – shranjevanje je ne izbriše
    const ima = val !== undefined && val !== null && val !== "" && !(opts || []).some(o => String(Array.isArray(o) ? o[0] : o) === String(val));
    inp = `<select id="${id}"><option value=""></option>${(opts || []).map(o => { const [ov, ol] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(ov)}" ${String(ov) === String(val) ? "selected" : ""}>${esc(ol)}</option>`; }).join("")}${ima ? `<option value="${esc(val)}" selected>${esc(val)} (prejšnja vrednost)</option>` : ""}</select>`;
  }
  else if (f.t === "teme") inp = `<div id="${id}" class="multi" role="group" aria-label="${esc(f.l)}" style="display:flex;flex-wrap:wrap;gap:4px 14px">${(opts || []).map(([k, l]) => `<label style="display:flex;gap:5px;align-items:center;font-weight:400"><input type="checkbox" value="${esc(k)}" ${[].concat(val || []).includes(k) ? "checked" : ""}> ${esc(l)}</label>`).join("")}</div>`;
  else if (f.t === "multi") inp = `<div id="${id}" class="multi" role="group" aria-label="${esc(f.l)}" style="display:flex;flex-wrap:wrap;gap:4px 14px">${(opts || []).map((o, i) => `<label style="display:flex;gap:5px;align-items:center;font-weight:400"><input type="checkbox" value="${esc(o)}" ${[].concat(val || []).includes(o) ? "checked" : ""}> ${i + 1}. ${esc(o)}</label>`).join("")}</div>`;
  else if (f.t === "bool") inp = `<input type="checkbox" id="${id}" ${val ? "checked" : ""}>`;
  else if (f.t === "tags") inp = `<input id="${id}" value="${esc([].concat(val || []).join(", "))}" placeholder="vrednosti, ločene z vejico">`;
  // seznam s kljukicami: shrani se kot [{ ime, opis }]; pri izbrani postavki se pokaže polje za opis; lastne postavke z »+ Dodaj«
  else if (f.t === "kljukice") {
    const izb = new Map((Array.isArray(val) ? val : []).filter(x => x && x.ime).map(x => [x.ime, x.opis || ""])), znane = new Set(), vrsta = (ime, opis, on) => `<div class="kl-row${on ? " on" : ""}"><label><input type="checkbox" value="${esc(ime)}" ${on ? "checked" : ""}> ${esc(ime)}</label><input class="kl-opis" value="${esc(opis || "")}" placeholder="opis (neobvezno)" aria-label="Opis: ${esc(ime)}"></div>`;
    const sk = (opts || []).map(g => Array.isArray(g) && Array.isArray(g[1]) ? g : ["", [g]]);
    inp = `<div id="${id}" class="kljukice" role="group" aria-label="${esc(f.l)}">${sk.map(([g, l]) => `${g ? `<div class="kl-sk">${esc(g)}</div>` : ""}${l.map(x => { znane.add(x); return vrsta(x, izb.get(x), izb.has(x)); }).join("")}`).join("")}<div class="kl-lastne">${[...izb].filter(([k]) => !znane.has(k)).map(([k, o]) => vrsta(k, o, true)).join("")}</div><div class="row" style="margin-top:6px"><input class="kl-nov" placeholder="drugo (vpišite)" aria-label="Dodaj postavko: ${esc(f.l)}" style="max-width:260px"><button type="button" class="btn sm ghost" data-kl-dodaj>+ Dodaj</button></div></div>`;
  }
  else if (f.t === "datetime") inp = `<input type="datetime-local" id="${id}" value="${esc(val ? toLocal(val) : "")}">`;
  // števila: besedilno polje s številsko tipkovnico – decimalna vejica deluje v vseh brskalnikih (»-17,5«), napačen vnos se označi pri polju
  else inp = `<input id="${id}" type="${{ date: "date", email: "email", time: "time" }[f.t] || "text"}" ${f.t === "num" ? 'inputmode="decimal" autocomplete="off"' : ""} value="${esc(val)}" ${f.ph ? `placeholder="${esc(f.ph)}"` : ""}>`;
  return `<label class="f ${f.req ? "req" : ""} ${f.wide || f.t === "area" ? "wide" : ""}"><span>${esc(f.l)}</span>${inp}${f.h ? `<small class="mut">${esc(f.h)}</small>` : ""}</label>`;
}
// seznam s kljukicami: ob izbiri se pokaže polje za opis; »+ Dodaj« doda lastno postavko (izbrano)
document.addEventListener("change", e => { const r = e.target.closest && e.target.closest(".kl-row"); if (r && e.target.type === "checkbox") { r.classList.toggle("on", e.target.checked); if (e.target.checked) { const o = $(".kl-opis", r); if (o) o.focus(); } } });
document.addEventListener("click", e => { const b = e.target.closest && e.target.closest("[data-kl-dodaj]"); if (!b) return; const k = b.closest(".kljukice"), n = $(".kl-nov", k), ime = n.value.trim(); if (!ime) { n.focus(); return; }
  const obst = $$(".kl-row input[type=checkbox]", k).find(c => c.value.toLowerCase() === ime.toLowerCase()); if (obst) { obst.checked = true; obst.closest(".kl-row").classList.add("on"); n.value = ""; return; }
  $(".kl-lastne", k).insertAdjacentHTML("beforeend", `<div class="kl-row on"><label><input type="checkbox" value="${esc(ime)}" checked> ${esc(ime)}</label><input class="kl-opis" placeholder="opis (neobvezno)" aria-label="Opis: ${esc(ime)}"></div>`); n.value = ""; n.focus(); });
function toLocal(s) { const d = new Date(s); return isNaN(d) ? "" : `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function readFields(fields) {
  const o = {};
  for (const f of fields) {
    const el = $("#f_" + f.k); if (!el) continue;
    let v;
    if (f.t === "multi" || f.t === "teme") v = $$("input:checked", el).map(i => i.value);
    else if (f.t === "kljukice") v = $$(".kl-row", el).filter(r => $("input[type=checkbox]", r).checked).map(r => ({ ime: $("input[type=checkbox]", r).value, opis: $(".kl-opis", r).value.trim() }));
    else if (f.t === "bool") v = el.checked;
    else if (f.t === "num") { const t = el.value.trim().replace(/\s/g, "").replace(",", ".").replace("−", "-"); v = t === "" ? "" : /^[-+]?\d*\.?\d+$/.test(t) ? Number(t) : el.value.trim(); }
    else if (f.t === "tags") v = el.value.split(",").map(x => x.trim()).filter(Boolean);
    else if (f.t === "datetime") v = el.value ? new Date(el.value).toISOString() : "";
    else v = el.value.trim();
    o[f.k] = v;
  }
  return o;
}
function fieldsFor(spec, ctx) { return typeof spec.fields === "function" ? spec.fields(ctx) : spec.fields; }

// kdo sme brisati (enako kot COLL.del na strežniku): A admin, S svetovalec, O odgovorna oseba, Z zaposleni
const BRISANJE = { stranke: "A", obrati: "AS", osebje: "ASO", dobavitelji: "ASO", oprema: "ASO", usposabljanja: "ASO", nacrti: "AS", navodila: "AS", evidence: "", capa: "", ciscenje_nacrt: "ASO", vabe: "ASO", kemikalije: "ASO", tlorisi: "ASO", urnik: "ASO", dogodki: "ASO", storitve: "A", priloge: "AS", sarze: "ASO", jedi: "ASO", certifikacija: "ASO" };
const smeBrisati = coll => !(coll in BRISANJE) || vlogeOf(ME.u).some(v => BRISANJE[coll].includes({ admin: "A", svetovalec: "S", odgovorna: "O", zaposleni: "Z" }[v] || "-"));
// odpre obrazec za dodajanje/urejanje zapisa zbirke
// napaka ob polju: rdeč okvir, sporočilo pod poljem, povezano z aria-describedby; ob popravku polja izgine
function oznaciPolje(el, m) {
  const l = el.closest(".f"); if (!l) return; const id = "err_" + (el.id || Math.random().toString(36).slice(2));
  l.classList.add("bad"); el.setAttribute("aria-invalid", "true"); el.setAttribute("aria-describedby", id);
  l.insertAdjacentHTML("beforeend", `<small class="f-err" role="alert" id="${esc(id)}">${esc(m)}</small>`);
  const pocisti = () => { l.classList.remove("bad"); el.removeAttribute("aria-invalid"); el.removeAttribute("aria-describedby"); const s = $(".f-err", l); if (s) s.remove(); };
  el.addEventListener("input", pocisti, { once: true }); el.addEventListener("change", pocisti, { once: true });
}
// zapis evidence in neskladnost (CAPA): sprememba obstoječega zapisa zahteva razlog (strežnik zahteva enako, vsaj 3 znake)
const RAZLOG_OBVEZEN = new Set(["evidence", "capa"]), RAZLOG_MIN = 3;
const spremenjeno = (rec, o, fields) => fields.some(f => o[f.k] !== undefined && JSON.stringify(o[f.k] ?? "") !== JSON.stringify(rec[f.k] ?? "") && String(o[f.k] ?? "") !== String(rec[f.k] ?? ""));
function razlogNapaka(coll, rec, o, fields, foto) {
  if (!rec || !RAZLOG_OBVEZEN.has(coll)) return "";
  const rz = $("#f__razlog"), t = rz ? rz.value.trim() : "";
  if (!spremenjeno(rec, o, fields) && !foto && !(o.obrat_id !== undefined && (o.obrat_id || "") !== (rec.obrat_id || ""))) return "";
  return t.length < RAZLOG_MIN ? `Vnesite razlog popravka (vsaj ${RAZLOG_MIN} znake).` : "";
}
// števila za prikaz v slovenski obliki (9,5 °C; 1.250,5); shranjena vrednost ostane številka
const fnum = (v, max = 2, min = 0) => { const n = typeof v === "number" ? v : v === "" || v == null ? NaN : Number(String(v).replace(",", ".")); return isFinite(n) ? n.toLocaleString("sl-SI", { minimumFractionDigits: min, maximumFractionDigits: max }) : (v == null ? "" : String(v)); };
// sporočilo za neštevilsko vrednost: temperature in meje imajo lahko minus, intervali in trajanja ne
const stevMsg = f => `»${f.l}« mora biti število (npr. ${/^(min|max|meja_|vrednost|temp)/.test(f.k) ? "4 ali -17,5" : "30"}).`;
function openForm(coll, rec, ctx, done) {
  const spec = SPEC[coll], fields = fieldsFor(spec, ctx);
  const edit = !!rec, locked = edit && rec.status === "potrjeno" && spec.rec;
  const html = `<p class="err" id="ferr"></p>${spec.intro ? `<p class="note info">${esc(spec.intro)}</p>` : ""}<div class="fgrid">${fields.map(f => fieldHtml(f, edit ? (f.vrednost ? f.vrednost(rec) : rec[f.k]) : (f.def !== undefined ? (typeof f.def === "function" ? f.def(ctx) : f.def) : ""), ctx)).join("")}${spec.foto ? `<label class="f wide"><span>Fotografija (neobvezno)</span><input type="file" id="f__foto" accept="image/*" capture="environment"></label>${edit && rec.slike && rec.slike.length ? `<div class="wide"><span class="mut">Fotografije:</span> ${slikeHtml(rec.slike, 12)}</div>` : ""}` : ""}${locked || (spec.rev && edit) ? `<label class="f wide ${locked || RAZLOG_OBVEZEN.has(coll) ? "req" : ""}"><span>Razlog spremembe${locked ? " (obvezno, zapis je potrjen)" : RAZLOG_OBVEZEN.has(coll) ? " (obvezno pri spremembi)" : ""}</span><input id="f__razlog"></label>` : ""}</div>${edit && rec.revizije && rec.revizije.length ? `<h3>Zgodovina sprememb</h3>${revHtml(rec)}` : ""}`;
  modal((edit ? "Uredi: " : "Dodaj: ") + spec.ime, html, [
    { t: "Prekliči", cls: "ghost sec" },
    ...(edit && spec.del !== false && !spec.rec && smeBrisati(coll) ? [{ t: "Izbriši", cls: "danger", fn: async () => { await new Promise(r => setTimeout(r, 0)); if (!(await potrdi("Res izbrišem zapis?", { da: "Izbriši", nevarno: true }))) return false; await D.del(coll, rec.id); toast("Izbrisano (v Košu 30 dni)"); if (coll === "stranke") { location.hash = "#/stranke"; return; } done && done(); } }] : []),
    { t: "Shrani", fn: async () => {
      const o = readFields(fields), err = $("#ferr");
      // napake pri posameznem polju: rdeč okvir, sporočilo pod poljem, fokus na prvo napačno polje
      $$(".f.bad", $("#dlg-b")).forEach(l => { l.classList.remove("bad"); const s = $(".f-err", l); if (s) s.remove(); }); err.textContent = "";
      let nap = fields.filter(f => f.req && (o[f.k] === "" || o[f.k] === undefined || (Array.isArray(o[f.k]) && !o[f.k].length))).map(f => [f.k, `Izpolnite polje »${f.l}«.`]);
      nap = nap.concat(fields.filter(f => f.t === "num" && typeof o[f.k] === "string" && o[f.k] !== "").map(f => [f.k, stevMsg(f)]));
      // oblika (davčna, e-naslov …) se preveri tudi, ko obvezna polja še niso izpolnjena – vse napake naenkrat
      if (spec.check) { const m = spec.check(o, ctx), ze = new Set(nap.map(x => x[0])); nap = nap.concat((Array.isArray(m) ? m : m ? [[null, m]] : []).filter(x => !x[0] || !ze.has(x[0]))); }
      { const ze = new Set(nap.map(x => x[0])); nap = nap.concat(PRAVILA.preveri(coll, Object.assign({}, rec || {}, o)).filter(x => !ze.has(x[0]))); } // razponi, meje, ura, e-naslov (enako preveri strežnik)
      { const m = razlogNapaka(coll, rec, o, fields, !!($("#f__foto") && $("#f__foto").files[0])); if (m) nap.push(["_razlog", m]); }
      if (nap.length) {
        for (const [k, m] of nap) { const el = k && $("#f_" + k), l = el && el.closest(".f"); if (!l) { err.textContent = m; continue; } oznaciPolje(el, m); }
        const prvo = nap[0][0] && $("#f_" + nap[0][0]); if (prvo) prvo.focus();
        if (nap.length > 1 || !err.textContent) err.textContent = nap.length > 1 ? `Popravite ${nap.length} ${mn(nap.length, ["polje", "polji", "polja", "polj"])} (označeno rdeče).` : "";
        return false;
      }
      if (spec.opozori) { const m = await spec.opozori(o, rec); if (m && !(await potrdi(m, { naslov: "Opozorilo", da: "Vseeno shrani" }))) return false; } // opozorilo, ki ga uporabnik lahko potrdi (npr. podvojena davčna)
      if (ctx && ctx.stranka_id && coll !== "stranke") o.stranka_id = ctx.stranka_id;
      if (ctx && ctx.obrat_id && !o.obrat_id) o.obrat_id = ctx.obrat_id;
      if (spec.pre) spec.pre(o, ctx, rec);
      const fo = $("#f__foto"); if (fo && fo.files[0]) { const up = await uploadFile(await zmanjsajSliko(fo.files[0]), ctx.stranka_id, coll, o.obrat_id || null); o.slike = [...((rec && rec.slike) || []), up.id]; }
      const rz = $("#f__razlog"); if (rz && rz.value.trim()) o._razlog = rz.value.trim();
      let nov = null; if (edit) await D.set(coll, rec.id, Object.assign({ _ver: rec.spremenjeno || rec.ustvarjeno }, o)); else nov = await D.add(coll, o); // _ver: zaznava hkratnega urejanja (409)
      toast("Shranjeno"); done && done(nov);
    } }
  ]);
  if (spec.onOpen) spec.onOpen(fields, ctx, rec);
}
function revHtml(rec) {
  return `<div class="tw"><table class="t"><tr><th>Ver.</th><th>Kdaj</th><th>Kdo</th><th>Razlog</th><th>Prejšnje vrednosti</th></tr>${rec.revizije.slice().reverse().map(r => `<tr><td>${r.n}</td><td>${fdt(r.cas)}</td><td>${esc(r.ime)}</td><td>${esc(r.razlog || "")}</td><td><small>${Object.entries(r.prej).map(([k, v]) => `${esc(k)}: ${esc(typeof v === "object" ? JSON.stringify(v) : v)}`).join("<br>")}</small></td></tr>`).join("")}</table></div>`;
}

// seznam zbirke z iskanjem in obrazcem
async function listView(el, coll, ctx, opt) {
  opt = opt || {};
  const spec = SPEC[coll];
  const q = Object.assign({}, ctx && ctx.stranka_id ? { stranka_id: ctx.stranka_id } : {}, opt.q || {});
  let rows;
  try { rows = await D.list(coll, q); } catch (e) { el.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  if (spec.sort) rows.sort(spec.sort);
  const cols = spec.cols(ctx || {});
  const mayAdd = opt.add !== false && (spec.add ? spec.add() : canManage());
  el.innerHTML = `<div class="row"><input type="search" id="lq" placeholder="Iskanje …" style="max-width:260px"><span class="sp"></span>${(opt.extra || "")}${mayAdd ? `<button class="btn" id="ladd">+ Dodaj</button>` : ""}</div>${spec.intro_list ? `<p class="note info">${esc(spec.intro_list)}</p>` : ""}<div class="tw"><table class="t"><thead><tr>${cols.map(c => `<th>${esc(c.l)}</th>`).join("")}</tr></thead><tbody id="lb"></tbody></table></div>`;
  const draw = () => {
    const f = $("#lq", el).value.toLowerCase();
    const sh = rows.filter(r => !f || JSON.stringify(r).toLowerCase().includes(f));
    $("#lb", el).innerHTML = sh.length ? sh.map(r => `<tr class="click" data-id="${r.id}">${cols.map(c => `<td>${c.f ? c.f(r) : esc(r[c.k] == null ? "" : r[c.k])}</td>`).join("")}</tr>`).join("") : `<tr><td colspan="${cols.length}" class="empty">${f ? "Ni zadetkov." : mayAdd ? `Ni še nobenega zapisa. <button class="btn sm" data-prvi data-brez-odpiranja>+ Dodaj prvi zapis: ${esc(spec.ime || "zapis")}</button>` : "Ni zapisov."}</td></tr>`;
    const pv = $("[data-prvi]", el); if (pv) pv.onclick = () => $("#ladd", el).click();
  };
  draw(); $("#lq", el).oninput = draw;
  const reload = () => listView(el, coll, ctx, opt);
  $("#lb", el).onclick = e => { if (e.target.closest("a[href],[data-brez-odpiranja]")) return; const tr = e.target.closest("tr[data-id]"); if (!tr) return; const r = rows.find(x => x.id === tr.dataset.id); (opt.open || ((r) => openForm(coll, r, ctx, reload)))(r, reload); };
  const add = $("#ladd", el); if (add) add.onclick = () => (opt.create || (() => openForm(coll, null, ctx, reload)))(reload);
  if (opt.bind) opt.bind(el, rows);
  if (opt.onRows) opt.onRows(rows); // npr. števci nad seznamom – po vsakem shranjevanju z novimi podatki
}

// ---------- usmerjevalnik in ogrodje ----------
const ROUTES = [];
const route = (re, fn, title, nav) => ROUTES.push({ re, fn, title, nav });
const NAVITEMS = [];
function navItem(id, label, hash, who) { NAVITEMS.push({ id, label, hash, who }); }
// skupine glavnega menija (vrstni red); vse so zložljive, administracija je privzeto zaprta
const NAV_SKUPINE = [["Vsakodnevno delo", ["nadzorna", "danes", "pregled-zapisov", "koledar", "umiki"]], ["Stranke", ["stranke", "moja", "storitve", "narocnine"]], ["Orodja", ["spletna-stran", "obrazci", "generator", "uvoz", "kos"]], ["Administracija", ["uporabniki", "admin", "vzdrzevanje", "vidnost", "gdpr", "strokovni-pregled"], true]];
function drawNav() {
  const items = NAVITEMS.filter(n => n.id !== "-" && (!n.who || hasRole(ME.u, ...n.who)) && (vis(n.id) || VIS.zak[n.id]));
  const link = n => VIS.zak[n.id] && !vis(n.id) ? `<a href="#/paket/${n.id}" data-id="${n.id}" class="zaklep" title="Ni vključeno v vaš paket">${n.label} <span aria-label="ni v paketu">🔒</span></a>` : `<a href="${n.hash}" data-id="${n.id}">${n.label}</a>`;
  const vSk = new Set(NAV_SKUPINE.flatMap(g => g[1])), sk = NAV_SKUPINE.concat([["Drugo", items.map(n => n.id).filter(id => !vSk.has(id))]]);
  // vsaka skupina je zložljiva; stanje se zapomni v brskalniku (privzeto odprte, razen administracije)
  let st = {}; try { st = JSON.parse(localStorage.getItem("nav_skupine") || "{}") || {}; if (localStorage.getItem("nav_zlozeno") === "odprto") st.Administracija = true; } catch {}
  $("#menu").innerHTML = sk.map(([ime, ids, zaprto]) => {
    const its = ids.map(id => items.find(n => n.id === id)).filter(Boolean); if (!its.length) return "";
    const odpri = st[ime] !== undefined ? st[ime] : !zaprto;
    return `<details class="nav-sk" data-sk="${esc(ime)}"${odpri ? " open" : ""}><summary class="sep">${ime}</summary>${its.map(link).join("")}</details>`;
  }).join("");
  $$("#menu details.nav-sk").forEach(z => { z.ontoggle = () => { try { const o = JSON.parse(localStorage.getItem("nav_skupine") || "{}") || {}; o[z.dataset.sk] = z.open; localStorage.setItem("nav_skupine", JSON.stringify(o)); } catch {} }; });
  drawPreviewBar(); if (typeof drawTestBar === "function") drawTestBar();
  $("#whoami").innerHTML = `<b>${esc(ME.u.ime)}</b><small>${esc(vlogeIme(ME.u))}</small>`;
  $("#whoami").setAttribute("role", "button"); $("#whoami").tabIndex = 0; $("#whoami").title = "Moj račun"; $("#whoami").style.cursor = "pointer";
  $("#whoami").onclick = mojRacun; $("#whoami").onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); mojRacun(); } };
}
async function render() {
  render.n = render.n || 0;
  if (!ME.u || /^#\/geslo\//.test(location.hash)) return; // povezava za geslo: glej showNastaviGeslo
  const h = location.hash.slice(1) || "/nadzorna";
  meni(false);
  for (const r of ROUTES) {
    const m = h.match(r.re);
    if (m) {
      const need = modulZaPot(h) || r.nav;
      // strani, ki jih meni za vlogo ne prikaže (npr. #/vidnost za zaposlenega), niso dosegljive niti z neposrednim naslovom
      const ni = r.nav !== "stranke" && NAVITEMS.find(x => x.id === r.nav && x.who); if (ni && !hasRole(ME.u, ...ni.who)) { toast(`Razdelek »${ni.label}« ni na voljo za vašo vlogo (${vlogeIme(ME.u)}). Odprta je nadzorna plošča.`, true); location.hash = "#/nadzorna"; return; }
      if (need && !vis(need)) { if (VIS.zak[need]) { location.hash = "#/paket/" + need; return; } const nm = (NAVITEMS.find(x => x.id === need) || {}).label; toast(`${nm ? "Razdelek »" + nm + "«" : "Ta razdelek"} vam je skril administrator (nastavitve vidnosti). Če ga potrebujete, se obrnite nanj. Odprta je nadzorna plošča.`, true); location.hash = "#/nadzorna"; return; }
      $("#title").textContent = typeof r.title === "function" ? r.title(m) : r.title; document.title = ($("#title").textContent ? $("#title").textContent + " – " : "") + "HiGiFood HACCP";
      $("#topact").innerHTML = "";
      $$("#menu a").forEach(a => { const on = a.dataset.id === r.nav; a.classList.toggle("on", on); if (on) { a.setAttribute("aria-current", "page"); const z = a.closest("details"); if (z && !z.open) z.open = true; } else a.removeAttribute("aria-current"); });
      // vsak prikaz dobi svoj vsebnik: počasnejši prejšnji prikaz (npr. po hitrem kliku) ne more prepisati novejšega
      const tok = render.tok = (render.tok || 0) + 1, v = document.createElement("div");
      if (!render.tiho) v.innerHTML = '<p class="mut">Nalaganje …</p>';
      $("#view").replaceChildren(v);
      try { await r.fn(v, m); } catch (e) { if (tok === render.tok) v.innerHTML = `<p class="err">${esc(e.message)}</p>`; }
      if (tok !== render.tok) return;
      render.cas = Date.now();
      if (render.tiho) return;
      window.scrollTo(0, 0); if (render.n++ > 0 && !/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || "") && !$("#dlg").open) $("#title").focus({ preventScroll: true });
      return;
    }
  }
  location.hash = "#/nadzorna";
}
window.addEventListener("hashchange", () => render());
// Osvežitev odprtega zaslona, da se vidijo spremembe drugih uporabnikov: ob vrnitvi na zavihek (po 1 min) in vsakih 5 min.
// Ne osveži med urejanjem (odprto okno, kurzor v polju) ali v urejevalnikih z neshranjenim stanjem.
async function osveziTiho(starost) {
  if (!ME.u || document.visibilityState !== "visible" || $("#dlg").open || Date.now() - (render.cas || 0) < starost) return;
  const a = document.activeElement; if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return;
  if (/^#\/(carovnik|tloris|uvoz|vidnost|admin)/.test(location.hash)) return;
  const y = window.scrollY; render.tiho = true; try { await render(); } finally { render.tiho = false; } window.scrollTo(0, y);
}
document.addEventListener("visibilitychange", () => osveziTiho(60e3));
setInterval(() => osveziTiho(5 * 60e3), 60e3);
// mobilni meni: zaprt meni je »inert« (tipkovnica in bralnik zaslona ga ne dosežeta), odprt prejme fokus
const MOB = matchMedia("(max-width:860px)");
function meni(odpri, nazaj) {
  const n = $("#nav"), b = $("#burger"); n.classList.toggle("open", !!odpri); b.setAttribute("aria-expanded", String(!!odpri)); n.inert = MOB.matches && !odpri;
  if (odpri) { const a = $$("a[href],button", n).find(x => x.getClientRects().length); if (a) a.focus(); } else if (nazaj) b.focus();
}
MOB.addEventListener("change", () => meni(false)); meni(false);
$("#burger").onclick = e => { e.stopPropagation(); meni(!$("#nav").classList.contains("open")); };
// mobilni meni: klik izven menija ali Esc ga zapre
document.addEventListener("click", e => { const n = $("#nav"); if (n.classList.contains("open") && !n.contains(e.target)) meni(false); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && $("#nav").classList.contains("open")) meni(false, true); });

function showLogin(setup) {
  $("#shell").hidden = true; const L = $("#login"); L.hidden = false;
  L.innerHTML = `<div class="card"><picture><source srcset="/logo-temno.png" media="(prefers-color-scheme: dark)"><img class="login-logo" src="/logo-svetlo.png" alt="HiGiFood – Z znanjem do varne hrane!"></picture><h1 class="login-h">${setup ? "Prva nastavitev: ustvarite administratorja" : "Prijava v HACCP platformo"}</h1><p class="err" id="lerr"></p><form id="lf"><label class="f"><span>E-naslov</span><input type="email" id="le" autocomplete="username" required></label>${setup ? '<label class="f"><span>Ime in priimek</span><input id="ln" required></label>' : ""}<label class="f"><span>Geslo${setup ? " (vsaj 10 znakov)" : ""}</span><input type="password" id="lp" autocomplete="${setup ? "new-password" : "current-password"}" required></label><button class="btn" style="width:100%">${setup ? "Ustvari in vstopi" : "Prijava"}</button></form>${setup ? "" : '<p style="margin:12px 0 0;text-align:center"><a href="#" id="l_poz">Pozabljeno geslo?</a></p>'}</div>`;
  if ($("#l_poz")) $("#l_poz").onclick = e => { e.preventDefault(); modal("Pozabljeno geslo", `<p>Vpišite e-naslov računa. Poslali vam bomo povezavo za nastavitev novega gesla.</p><p class="err" id="pz_e"></p><label class="f"><span>E-naslov</span><input type="email" id="pz_m" value="${esc($("#le").value)}" autocomplete="username"></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Pošlji povezavo", fn: async () => { try { const r = await api("POST", "/api/auth/pozabljeno", { email: $("#pz_m").value }); modal("Pozabljeno geslo", `<p>${esc(r.sporocilo)}</p><p class="mut">Če sporočila ni, preverite mapo z neželeno pošto ali se obrnite na administratorja.</p>`); return false; } catch (x) { $("#pz_e").textContent = x.message; return false; } } }]); };
  if (typeof testLoginHint === "function") testLoginHint();
  $("#lf").onsubmit = async e => {
    e.preventDefault();
    try {
      const kd = $("#lk") ? $("#lk").value : undefined;
      const u = await api("POST", setup ? "/api/auth/nastavi" : "/api/auth/prijava", { email: $("#le").value, geslo: $("#lp").value, ime: setup ? $("#ln").value : undefined, koda: kd || undefined, zapomni: $("#lz") ? $("#lz").checked : undefined });
      ME.u = u; await loadTisk(); await loadVidnost(); naloziIzdelovalca(); start();
    } catch (x) {
      $("#lerr").textContent = x.message;
      if (x.data && x.data.potrebna_koda && !$("#lk")) { $("#lp").closest("label").insertAdjacentHTML("afterend", '<label class="f"><span>Koda iz aplikacije za preverjanje (ali rezervna koda)</span><input id="lk" inputmode="numeric" autocomplete="one-time-code" maxlength="12"></label><label style="display:flex;gap:6px;align-items:center;margin:4px 0 8px"><input type="checkbox" id="lz" checked style="width:auto"> Na tej napravi kodo zahtevaj spet čez 30 dni (izklopite na skupnem računalniku)</label>'); $("#lk").focus(); }
    }
  };
}
// nastavitev gesla s povezavo iz e-pošte (pozabljeno geslo ali povabilo): #/geslo/<žeton>
async function showNastaviGeslo(t) {
  { const d = $("#dlg"); if (d && d.open) d.close(); }
  $("#shell").hidden = true; const L = $("#login"); L.hidden = false;
  const glava = '<picture><source srcset="/logo-temno.png" media="(prefers-color-scheme: dark)"><img class="login-logo" src="/logo-svetlo.png" alt="HiGiFood – Z znanjem do varne hrane!"></picture>';
  const nazaj = () => { history.replaceState(null, "", "/"); fetch("/api/auth/stanje").then(r => r.json()).then(s => { Object.assign(STATE, s); showLogin(!s.nastavljeno); }); };
  let z; try { z = await api("GET", "/api/auth/zeton?t=" + encodeURIComponent(t)); } catch (x) {
    L.innerHTML = `<div class="card">${glava}<h1 class="login-h">Povezava ni veljavna</h1><p>${esc(x.message)}</p><button class="btn" id="gz_n" style="width:100%">Na prijavo</button></div>`; $("#gz_n").onclick = nazaj; return;
  }
  L.innerHTML = `<div class="card">${glava}<h1 class="login-h">${z.namen === "povabilo" ? "Dobrodošli! Nastavite geslo" : "Nastavite novo geslo"}</h1><p class="mut">Račun: <b>${esc(z.email)}</b></p><p class="err" id="gz_e"></p>
    <form id="gz_f"><label class="f"><span>Novo geslo (vsaj 10 znakov)</span><input type="password" id="gz_1" autocomplete="new-password" required></label><label class="f"><span>Ponovite geslo</span><input type="password" id="gz_2" autocomplete="new-password" required></label><button class="btn" style="width:100%">Shrani geslo</button></form></div>`;
  $("#gz_f").onsubmit = async e => {
    e.preventDefault(); if ($("#gz_1").value !== $("#gz_2").value) { $("#gz_e").textContent = "Gesli se ne ujemata."; return; }
    try { await api("POST", "/api/auth/nastavi-geslo", { zeton: t, geslo: $("#gz_1").value }); nazaj(); setTimeout(() => { if ($("#le")) $("#le").value = z.email; if ($("#lerr")) { $("#lerr").textContent = ""; $("#lf").insertAdjacentHTML("beforebegin", '<p class="note info" id="gz_ok">Geslo je nastavljeno. Prijavite se.</p>'); } }, 300); }
    catch (x) { $("#gz_e").textContent = x.message; }
  };
}
function start() {
  $("#login").hidden = true; $("#shell").hidden = false;
  drawNav(); drawOffBadge(); if (typeof loadLogo === "function") loadLogo(); if (typeof navStrankaLogo === "function") navStrankaLogo(); try { const prev = JSON.parse(localStorage.getItem("haccp_me") || "null"); if (prev && prev.id !== ME.u.id && navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage("clear-api"); localStorage.setItem("haccp_me", JSON.stringify(ME.u)); } catch {}
  if (ME.u.geslo_ponastavljeno) { changePw(true, true); return; } // po ponastavitvi s strani administratorja je menjava obvezna
  if (ME.u.mora_zamenjati) { changePw(true); }
  if (ME.u.mora_2fa) { obvezna2fa(); return; }
  render();
}
// obvezna dvostopenjska prijava: dokler je ne nastavi, uporabnik vidi samo ta zaslon
function obvezna2fa() {
  $("#title").textContent = "Varnost računa";
  $("#view").innerHTML = `<div class="card" style="max-width:640px"><h2>Nastavite dvostopenjsko prijavo</h2><p>Za vašo vlogo je dvostopenjska prijava obvezna. Potrebujete telefon z aplikacijo za preverjanje (npr. Google Authenticator ali Microsoft Authenticator). Nastavitev traja minuto.</p>
    <div class="row"><button class="btn" id="o2_n">Nastavi zdaj</button><button class="btn ghost sec" id="o2_o">Odjava</button></div></div>`;
  $("#o2_n").onclick = () => vklop2fa(() => { ME.u.mora_2fa = false; render(); drawNav(); });
  $("#o2_o").onclick = () => $("#logout").click();
}
function mojRacun() {
  modal("Moj račun", `<p><b>${esc(ME.u.ime)}</b><br><span class="mut">${esc(ME.u.email)} · ${esc(vlogeIme(ME.u))}</span></p>
    <p>Dvostopenjska prijava: ${ME.u.totp ? '<span class="badge ok">vklopljena</span>' : '<span class="badge warn">izklopljena</span>'}</p>
    <p class="mut">Ob prijavi poleg gesla vnesete 6-mestno kodo iz aplikacije na telefonu (npr. Google ali Microsoft Authenticator). Priporočeno za administratorje in svetovalce.</p>
    ${!hasRole(ME.u, "admin", "svetovalec", "odgovorna") ? "" : (o => `<h3>E-poštna obvestila</h3>
    <fieldset class="obv-sk"><legend>Povzetek</legend><div class="row" style="align-items:center;margin:0"><label class="f" style="margin:0;min-width:200px"><span>Pogostost</span><select id="op_p">${[["dnevno", "vsak dan"], ["tedensko", "tedensko (ob ponedeljkih)"], ["izklop", "izklopljeno"]].map(([k, l]) => `<option value="${k}" ${o.pogostost === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
    <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="op_r" ${o.roki !== false ? "checked" : ""}> roki in zamude</label><label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="op_v" ${o.vnosi !== false ? "checked" : ""}> manjkajoči vnosi evidenc</label></div></fieldset>
    <fieldset class="obv-sk"><legend>Takoj, ko se zgodi</legend>
    <label style="display:flex;gap:6px;align-items:flex-start"><input type="checkbox" id="op_o" ${o.odstopanja !== false ? "checked" : ""} style="margin-top:4px"> <span>odstopanje v evidenci – odprta neskladnost s korektivnim ukrepom <small class="mut">(za stranke, ki so vam dodeljene)</small></span></label>
    ${hasRole(ME.u, "admin", "svetovalec") ? `<label style="display:flex;gap:6px;align-items:flex-start;margin-top:4px"><input type="checkbox" id="op_q" ${o.povprasevanja === true ? "checked" : ""} style="margin-top:4px"> <span>novo povpraševanje s spletne strani</span></label>` : ""}</fieldset>
    <div class="row" style="margin:8px 0 0"><button class="btn sm" id="op_s">Shrani obvestila</button></div><p class="mut" style="margin-top:4px">Obvestila pridejo na ${esc(ME.u.email)}, ko ima administrator nastavljeno pošiljanje e-pošte. Če ima stranka izklopljene opomnike, za njo ne pride nobeno obvestilo.</p>`)(ME.u.opomniki || {})}`,
    [{ t: "Zapri", cls: "ghost sec" }, { t: "Moji podatki (za dokumente)", cls: "ghost", fn: () => { location.hash = "#/moji-podatki"; } }, { t: "Spremeni geslo", cls: "ghost", fn: () => { setTimeout(() => changePw(false), 0); } }, ...(ME.u.totp && ME.u.totp_naprave ? [{ t: "Pozabi zaupanja vredne naprave (" + ME.u.totp_naprave + ")", cls: "ghost", fn: async () => { try { await api("POST", "/api/auth/2fa/pozabi-naprave"); ME.u.totp_naprave = 0; toast("Na vseh napravah bo ob naslednji prijavi zahtevana koda."); } catch (e) { fail(e); } } }] : []), ME.u.totp ? { t: "Izklopi dvostopenjsko prijavo", cls: "danger", fn: () => { setTimeout(izklop2fa, 0); } } : { t: "Vklopi dvostopenjsko prijavo", fn: () => { setTimeout(vklop2fa, 0); } }]);
  const sh = $("#op_s"); if (sh) sh.onclick = async () => { try { const q = $("#op_q"), u = await api("POST", "/api/auth/opomniki", { pogostost: $("#op_p").value, roki: $("#op_r").checked, vnosi: $("#op_v").checked, odstopanja: $("#op_o").checked, povprasevanja: !!(q && q.checked) }); ME.u.opomniki = u.opomniki; toast("Nastavitve obvestil shranjene"); } catch (e) { fail(e); } };
}
async function vklop2fa(koncano) {
  const r = await api("POST", "/api/auth/2fa/zacni"); let qr = "";
  try { qr = typeof QR !== "undefined" ? QR.svg(r.uri, { px: 190 }) : ""; } catch {}
  modal("Vklop dvostopenjske prijave", `<ol><li>Na telefonu odprite aplikacijo za preverjanje (Google Authenticator, Microsoft Authenticator …) in skenirajte kodo QR.</li><li>Če skeniranje ne deluje, vnesite ključ ročno: <code id="f2k">${esc(r.skrivnost)}</code></li><li>Vpišite 6-mestno kodo, ki jo prikaže aplikacija.</li></ol><div style="text-align:center">${qr}</div><p class="err" id="f2e"></p><label class="f"><span>Koda iz aplikacije</span><input id="f2c" inputmode="numeric" autocomplete="one-time-code" maxlength="6"></label>`,
    [{ t: "Prekliči", cls: "ghost sec" }, { t: "Potrdi", fn: async () => {
      try { const x = await api("POST", "/api/auth/2fa/potrdi", { koda: $("#f2c").value }); ME.u.totp = true; setTimeout(() => modal("Rezervne kode", `<p class="note">Dvostopenjska prijava je vklopljena. Shranite te rezervne kode na varno (natisnite ali zapišite). Vsaka deluje <b>enkrat</b>, če nimate telefona.</p><pre id="f2r" style="font-size:16px;line-height:1.7">${x.rezervne.map(esc).join("\n")}</pre>`, [{ t: "Shranil sem kode", fn: () => { if (koncano) setTimeout(koncano, 0); } }]), 0); }
      catch (e) { $("#f2e").textContent = e.message; return false; }
    } }]);
}
function izklop2fa() {
  modal("Izklop dvostopenjske prijave", `<p class="err" id="f2e"></p><label class="f"><span>Geslo</span><input type="password" id="f2p" autocomplete="current-password"></label><label class="f"><span>Koda iz aplikacije ali rezervna koda</span><input id="f2c" autocomplete="one-time-code"></label>`,
    [{ t: "Prekliči", cls: "ghost sec" }, { t: "Izklopi", cls: "danger", fn: async () => { try { await api("POST", "/api/auth/2fa/izklopi", { geslo: $("#f2p").value, koda: $("#f2c").value }); ME.u.totp = false; toast("Dvostopenjska prijava je izklopljena"); } catch (e) { $("#f2e").textContent = e.message; return false; } } }]);
}
function changePw(forced, obvezno) {
  modal("Sprememba gesla", `<p class="err" id="perr"></p>${forced ? '<p class="note">Administrator je nastavil začasno geslo. Prosimo, zamenjajte ga.</p>' : ""}<label class="f"><span>Trenutno geslo</span><input type="password" id="p0" autocomplete="current-password"></label><label class="f"><span>Novo geslo (vsaj 10 znakov)</span><input type="password" id="p1" autocomplete="new-password"></label>`, [obvezno ? { t: "Odjava", cls: "ghost sec", fn: () => { $("#logout").click(); } } : { t: "Kasneje", cls: "ghost sec" }, { t: "Spremeni", fn: async () => { try { await api("POST", "/api/auth/geslo", { staro: $("#p0").value, novo: $("#p1").value }); ME.u.mora_zamenjati = false; toast("Geslo spremenjeno"); if (ME.u.geslo_ponastavljeno) { ME.u.geslo_ponastavljeno = false; render(); } } catch (e) { $("#perr").textContent = e.message; return false; } } }]);
  if (obvezno) $("#dlg").addEventListener("cancel", e => e.preventDefault(), { once: true }); // Esc ne zapre obvezne menjave
}
// odjava: neposlani zapisi (vneseni brez povezave) bi se izgubili – najprej jih poskusi poslati, nato vprašaj
$("#logout").onclick = async () => {
  if (offq().length && navigator.onLine !== false) { try { await syncOffQueue(); } catch {} }
  const ost = offq().length;
  if (ost && !(await potrdi(`${mnx(ost, ["zapis", "zapisa", "zapisi", "zapisov"])} še ni poslanih na strežnik (vneseni brez povezave). Če se zdaj odjavite, se izgubijo.\n\nPriporočilo: Prekliči, počakajte na povezavo in se odjavite pozneje.\n\nSe vseeno odjavim in izgubim te zapise?`, { naslov: "Neposlani zapisi", da: "Odjavi in izgubi zapise", nevarno: true }))) return;
  try { await api("POST", "/api/auth/odjava"); } catch {} ME.u = null; try { localStorage.removeItem("haccp_me"); localStorage.removeItem(OFFQ); } catch {} if (navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage("clear-api"); showLogin(); };

// dostopnost: vrstice s klikom so dosegljive s tipkovnico (Enter/preslednica), gumbi brez besedila dobijo ime
(function a11y() {
  const names = { "✕": "Odstrani", "↑": "Premakni gor", "↓": "Premakni dol", "‹": "Nazaj", "›": "Naprej", "×": "Zapri" };
  const fix = root => {
    root.querySelectorAll("tr.click:not([tabindex])").forEach(t => { t.tabIndex = 0; });
    root.querySelectorAll("button:not([aria-label]),a.btn:not([aria-label])").forEach(b => { const t = b.textContent.trim(); if (names[t]) b.setAttribute("aria-label", names[t] + (b.closest("tr,.card") && b.closest("tr,.card").querySelector("input[data-k=naziv],b") ? "" : "")); });
    root.querySelectorAll("input:not([type=hidden]):not([aria-label]),select:not([aria-label]),textarea:not([aria-label])").forEach(e => { if ((e.labels && e.labels.length) || e.getAttribute("aria-labelledby") || e.title) return; const nm = e.placeholder || (e.type === "file" ? "Izberi datoteko" : e.type === "search" ? "Iskanje" : e.tagName === "SELECT" ? ((e.options[0] && e.options[0].textContent.trim()) || "Izbira") : ""); if (nm) e.setAttribute("aria-label", nm); });
    root.querySelectorAll(".err:not([role])").forEach(e => e.setAttribute("role", "alert"));
    root.querySelectorAll(".steps button").forEach(b => b.classList.contains("on") ? b.setAttribute("aria-current", "step") : b.removeAttribute("aria-current"));
    root.querySelectorAll(".tabs a").forEach(a => a.classList.contains("on") ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current"));
  };
  new MutationObserver(ms => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) fix(n.parentNode || document); }).observe(document.body, { childList: true, subtree: true });
  document.addEventListener("keydown", e => { if ((e.key === "Enter" || e.key === " ") && e.target && e.target.matches && e.target.matches("tr.click")) { e.preventDefault(); e.target.click(); } });
  document.addEventListener("DOMContentLoaded", () => fix(document));
})();
// Prikaz gesla: vsako polje za geslo dobi gumb z očesom (pokaži/skrij), tudi polja v kasneje odprtih oknih.
const OKO = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const OKO_X = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.4 10.4 0 0 1 12 19C5 19 1 12 1 12a18.5 18.5 0 0 1 5.1-5.9M9.9 4.2A9.6 9.6 0 0 1 12 4c7 0 11 7 11 7a18.6 18.6 0 0 1-2.2 3.2M14.1 14.1a3 3 0 1 1-4.2-4.2"/><path d="M1 1l22 22"/></svg>';
function okoGesla(root) {
  for (const i of (root || document).querySelectorAll('input[type="password"]:not([data-oko])')) {
    i.dataset.oko = "1";
    const ovoj = document.createElement("span"); ovoj.className = "geslo-ovoj"; i.parentNode.insertBefore(ovoj, i); ovoj.appendChild(i);
    // span z vlogo gumba (ne <button>), da ne postane prvi gumb obrazca in ne vpliva na oddajo z Enter
    const b = document.createElement("span"); b.setAttribute("role", "button"); b.tabIndex = 0; b.className = "oko"; b.innerHTML = OKO; b.setAttribute("aria-label", "Pokaži geslo"); b.setAttribute("aria-pressed", "false"); b.title = "Pokaži geslo";
    b.onclick = e => { e.preventDefault(); const vidno = i.type === "password"; i.type = vidno ? "text" : "password"; b.innerHTML = vidno ? OKO_X : OKO; const t = vidno ? "Skrij geslo" : "Pokaži geslo"; b.setAttribute("aria-label", t); b.title = t; b.setAttribute("aria-pressed", String(vidno)); i.focus(); };
    b.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); b.onclick(e); } };
    ovoj.appendChild(b);
  }
}
new MutationObserver(() => okoGesla()).observe(document.documentElement, { childList: true, subtree: true });
okoGesla();
// povezava za nastavitev gesla odprta v že odprtem zavihku (sprememba dela naslova za #)
window.addEventListener("hashchange", () => { const m = location.hash.match(/^#\/geslo\/([\w-]+)$/); if (m) showNastaviGeslo(m[1]); });
