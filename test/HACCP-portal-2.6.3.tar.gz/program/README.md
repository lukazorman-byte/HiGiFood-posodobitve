# HiGiFood HACCP platforma

Večstrankarska platforma za pripravo in vodenje HACCP dokumentacije. Vse prejšnje funkcije (generator dokumentacije, baza znanja, urejevalnik baze, posodobitve zakonodaje, Word izvoz) ostanejo; dodani so prijava, vloge, stranke, čarovnik, evidence, CAPA, koledar in storitve.

## Zagon in prva prijava
Potrebujete Node.js 18+. Windows: dvoklik `zagon.bat`; Mac/Linux: `./zagon.sh`; ali `node server.js`.
Ob prvem zagonu odprite http://127.0.0.1:3000/ in ustvarite **administratorja** (e-naslov + geslo, vsaj 10 znakov). Brez prijave ni dostopa do podatkov. Samostojna datoteka `dist/haccp-aplikacija.html` (samo generator) deluje brez strežnika in prijave.

## Zagon brez črnega okna in dostop od koderkoli
- **Windows (.exe):** dvoklik na `HiGiFood.vbs` zažene program skrito in odpre brskalnik (`HACCP-sistem.exe` neposredno odpre okno terminala). Ustavitev: Administracija → »Ustavi program«. Dvojen zagon ni mogoč: drugi zagon samo odpre brskalnik.
- **Samodejni zagon ob prijavi v Windows:** `samodejni-zagon-vklopi.bat` (izklop: `samodejni-zagon-izklopi.bat`); program se zažene skrit, brskalnika ne odpre.
- **Dostop od drugod:** program teče samo na računalniku, kjer je zagnan. Za dostop s telefona ali od drugod mora računalnik teči in biti dosegljiv: zasebno prek Tailscale, v domačem omrežju (`HOST=0.0.0.0`) ali na najetem strežniku. Podrobnosti in komplet za strežnik (Docker, Caddy, systemd) so v mapi `streznik/`, navodila pa v `../NAVODILA-ZA-STREZNIK.md`.

## Pozabljeno geslo
Aplikacijo ustavite in zaženite `ponastavi-geslo.bat` (Mac/Linux: `./ponastavi-geslo.sh`; pri `.exe`: `HACCP-sistem.exe --ponastavi-geslo`). Izberete uporabnika in vnesete novo geslo. Ponastavitev deluje samo na računalniku, kjer so podatki, in se zapiše v revizijsko sled.

## Vloge (dostop preverja strežnik)
| Vloga | Kaj lahko |
|---|---|
| Administrator HiGiFood | vse: stranke, uporabniki, baza znanja, kopije/obnova, revizijska sled, nastavitve obvestil |
| HACCP-svetovalec | samo dodeljene stranke: podatki, načrti, evidence, CAPA, storitve |
| Odgovorna oseba stranke | samo lastna stranka: podatki, zaposleni (dodaja uporabnike), načrti, potrjevanje evidenc |
| Zaposleni stranke | lastna stranka: vnos evidenc in neskladnosti, branje; ne more potrditi ali spreminjati potrjenih zapisov |
Interne opombe in cene so za stranko skrite že v odgovoru strežnika.

## Moduli
- **Nadzorna plošča**: število strank, aktivni sistemi, načrti po stanju, roki in zamude, zapisi za pregled, odstopanja, odprti CAPA, dokumenti za posodobitev, poteki izobraževanj/opreme, zadnje aktivnosti, opozorila o manjkajočih podatkih; filtri po stranki, stanju in datumu.
- **Stranke**: profil (podjetje, odgovorna oseba, dejavnost), več obratov (opis prostorov, procesov, čiščenje, DDD, odpadki, voda), zaposleni in usposabljanja, dobavitelji, oprema/instrumenti z mejami, HACCP načrti, navodila, evidence, CAPA, koledar, priloge, storitve, uporabniki.
- **Čarovnik HACCP (7 korakov)**: zbiranje podatkov → dejavnost in živila (predloga dejavnosti iz baze, prilagodljiva) → procesni koraki (dodaj/uredi/premakni, diagram poteka, izvoz v PDF) → analiza nevarnosti (B/K/F/alergen/navzkrižna/čas-temperatura; ocena verjetnost × teža z zapisano metodologijo) → kontrolni ukrepi PRP/OPRP/CCP (odločitveno drevo daje samo predlog; CCP se nikoli ne določi samodejno) → pregled osnutka z opozorili → izvoz PDF/Excel. Predlogi iz baze so označeni »predlog« in zahtevajo potrditev. Mejnih vrednosti program ne izmišlja: vnese jih uporabnik ali jih vstavi kot predlog iz baze (označeno »potrebna strokovna potrditev«).
- **Navodila**: 19 predlog (higiena, čiščenje, prevzem, skladiščenje, temperature, navzkrižna kontaminacija, alergeni, odpadki, DDD, voda, vzdrževanje, merilni instrumenti, sledljivost, odpoklic, reklamacije, usposabljanje, notranja kontrola, pregled dokumentacije, hlajenje); dodajo se kot osnutek in se prilagodijo; vsaka ima različico, datum in pravno podlago. Zbirka `navodila_predloge` v bazi znanja.
- **Evidence**: prevzem, temperature, toplotna obdelava, hlajenje, čiščenje, higienski pregled, kontrola opreme, sledljivost/odpoklic, prilagojeno. Čas in uporabnik se zapišeta samodejno; obvezna polja; fotografija; skladnost se oceni samo, če so mejne vrednosti določene (sicer »brez ocene«); nastavljiva pogostost z opozorili za manjkajoče vnose; izvoz v PDF in Excel. Zapisov ni mogoče brisati; vsak popravek je nova različica z razlogom, potrjene zapise lahko popravi samo odgovorna oseba/svetovalec z razlogom.
- **Neskladnosti / CAPA**: vsa polja (čas, obrat/proces, opis, tveganje, nujnost, takojšnji ukrep, odločitev o živilu, vzrok, dolgoročni ukrep, odgovoren, rok, dokaz, učinkovitost, zapiranje); zaprtje zahteva izpolnjena polja; odprti ukrepi na nadzorni plošči in v opomnikih.
- **Inšpekcija** (zavihek pri stranki; izpis vsebuje tudi tlorise obrata): kontrolni seznam stanja (potrjen načrt, navodila, izobraževanja in zdravniški pregledi, oprema, dobavitelji, evidence v obdobju, odprti CAPA) in izpis dokazil za izbrano obdobje v PDF, Word in Excel. Prikazuje samo vneseno stanje in ne ocenjuje skladnosti.
- **QR kode naprav**: Stranka → Oprema → »QR kode naprav« natisne nalepke. Skeniranje odpre vnos zapisa (temperatura za hladilnike in zamrzovalnike, sicer kontrola opreme) z že izbrano napravo in mejami. Telefon potrebuje dostop do strežnika (npr. `HOST=0.0.0.0` v lokalnem omrežju, naslov v kodi lahko spremenite) in prijavo.
- **Tloris** (zavihek pri stranki): risanje tlorisa v aplikaciji (SVG): sobe z vrsto (čisto/nečisto območje, skladišče, hladno skladišče …), stene, vrata, naprave (povezava s seznamom opreme), vabe/pasti DDD (povezava z registrom vab; opozorilo, katere vabe še niso na tlorisu), poti (čista, nečista, hladna in topla veriga, odpadki, osebje), besedilo. Mreža 0,25 m, premikanje, spreminjanje velikosti, podvoji, razveljavi (Ctrl+Z), Del. Shrani z revizijami; izvoz PNG/SVG z legendo; v čarovniku HACCP (korak 1) izberete tloris, ki se vstavi v dokumentacijo (PDF/Word).
- **Higiena** (zavihek pri stranki): *Danes za opraviti* (opravila iz načrta čiščenja, ki so na vrsti ali v zamudi; »Opravljeno« ustvari zapis), *Načrt čiščenja* (področje, opravilo, sredstvo, pogostost, odgovoren), *Brisi in hitri testi* (mikrobiološki brisi/odtisi z rezultati po parametrih ter hitri testi: ATP, beljakovine, alergen, koncentracija razkužila; mejne vrednosti vnesete sami, graf gibanja ATP s pragom, odstopanja in delež), *DDD* (register vab in pasti, obiski izvajalca, opažanja škodljivcev), *Zdravje zaposlenih* (zdravstvene izjave), *Čistila in razkužila* (register z roki in varnostnimi listi). Zamude čiščenja so na nadzorni plošči, v koledarju in v dnevnih e-poštnih opomnikih (če je SMTP nastavljen; opomnik čistil 14 dni pred potekom); higienske vrstice so tudi v inšpekciji. Dodani sta predlogi navodil »Preverjanje čiščenja: brisi in hitri testi« in »Ravnanje s čistili in razkužili«. Program ne predpisuje mejnih vrednosti: brez vnesenih mej ocena ni mogoča.
- **Koledar**: roki iz celotne baze (pregledi, usposabljanja, oprema, CAPA, dobavitelji) in lastni dogodki; izvoz .ics.
- **Storitve**: opravljene storitve po stranki (datum, trajanje, paket, stanje dokumentacije, manjkajoči podatki, naslednji pregled), povzetek dela za stranko, izvoz v Excel. Cena je neobvezno polje (cenika program nima).
- **Slike v dokumentih**: v Administraciji naložite logotip (PNG/JPEG/WebP, do 1,5 MB), ki se prikaže na naslovnici PDF in Word. Fotografije, priložene evidencam, se pri izvozu evidenc v PDF/Word vstavijo v razdelek »Fotografije« s podnapisom (čas, vrsta, podatek). Fotografije pri neskladnostih (CAPA) se vstavijo v izvoz CAPA (Word/PDF). Tloris obrata naložite v koraku 1 čarovnika; vstavi se v poglavje »Podatki o podjetju in obratu«.
- **Poglavja**: v koraku 7 čarovnika poglavja dokumentacije poljubno vključite/izključite, preimenujete, premaknete in dodate lastna (z besedilom); številke so samodejne, nastavitev se shrani z načrtom.
- **Word (.docx)**: isti dokument (12 poglavij) in posamezna navodila se izvozijo tudi v Word (tudi evidence in seznam CAPA); besedilo, tabele in diagram poteka (polja in puščice) urejate v Wordu. Ob odprtju Word vpraša, ali naj osveži polja (kazalo, številke strani) – potrdite. Urejanje poteka samo v Wordu; spremembe se ne vračajo nazaj v aplikacijo (vsebino, ki naj ostane v sistemu, popravite v čarovniku).
- **PDF dokumentacija**: naslovnica, kazalo, številke strani, različica/datum, 12 poglavij + priloga s pravno podlago in datumom preverjanja. Dokument je označen kot OSNUTEK, dokler načrta ne potrdi strokovnjak; ne pomeni uradne odobritve in ne zagotavlja samodejne skladnosti.
- **Obvestila po e-pošti**: Administracija → SMTP (neobvezno). Brez SMTP-ja ostanejo opozorila v aplikaciji. Pošiljanje preizkusite z gumbom »Pošlji test« (pošiljanje s STARTTLS/SSL je odvisno od vašega ponudnika; samodejno preverjeno je bilo samo nešifrirano omrežje).

## Podatki, varnost in kopije
- Podatki strank so v podatkovni bazi SQL (SQLite, `podatki/haccp.db`): vse zbirke ter nastavitve, seje, naročnine in obvestila o umikih. Baza uporablja transakcije in način WAL, zato več uporabnikov in strank hkrati varno vnaša podatke. Priloge so v `podatki/priloge/`, baza znanja v `baza/`. Mapi ne objavljajte javno; vsebujeta osebne podatke.
- Ob prvem zagonu nove različice se obstoječe datoteke JSON samodejno prenesejo v bazo. Nastavitve se zapisujejo tudi v zrcalne datoteke `_*.json`, da vrnitev na prejšnjo različico ne izgubi nastavitev.
- Gesla: scrypt; seja: HttpOnly, SameSite=Strict piškotek (Secure za HTTPS za posredniškim strežnikom); omejitev poskusov prijave; Origin preverjanje za spreminjanje podatkov; varnostne glave (CSP, X-Frame-Options).
- **Revizijska sled** (`podatki/_revizijska-sled.jsonl`): prijave, ustvarjanje, spremembe, brisanja, pisanje baze; veriga zgoščenk razkrije naknadno spreminjanje; pregled v Administraciji.
- **Kopije**: samodejno vsak dan (zadnjih 30 v `podatki/_kopije`), ročni prenos in obnova (zip) v Administraciji; pred obnovo se naredi kopija stanja. **Kopija na drugo mesto**: v Administraciji določite mapo (USB, zunanji disk, sinhronizirana mapa), kamor se dnevna kopija prepiše še enkrat (zadnjih 30); prikazano je stanje zadnje kopije. Nadrejena mapa mora obstajati.
- Strežnik privzeto posluša samo na 127.0.0.1. Za uporabo v omrežju/internetu ga postavite za HTTPS posredniški strežnik (npr. Caddy, nginx) in nastavite `HOST` ter `x-forwarded-proto`.
- Gesla za SMTP so šifrirana v podatkovni bazi na strežniku (`podatki/haccp.db`, zrcalno v `podatki/_nastavitve.json`), nikoli v kodi odjemalca.
- Skladnost zapisov (»skladno/odstopanje«) izračuna odjemalec ob vnosu; sprememba je sledljiva (revizije, revizijska sled), ni pa kriptografsko zaščitena pred zaposlenim, ki ima pravico vnosa.

## Preostali del dokumentacije (prej)

Ločeni deli, povezani prek API-ja:

| Del | Mapa | Naloga |
|---|---|---|
| Baza | `baza/*.json` | Podatki: branže, zakonodaja, temperaturni režimi, standardi, alergeni … |
| Strežnik | `server.js` | Ponuja API (`/api/baza`) in postreže obema aplikacijama. Brez odvisnosti. |
| Glavna aplikacija | `app/` | Generator HACCP dokumentacije. Vse podatke bere iz baze. |
| Urejevalnik baze | `baza-admin/` | Urejanje baze v brskalniku. Pred vsakim zapisom naredi varnostno kopijo v `baza/_backup/`. |

## Posodobitev (različica z nabori sestavin)
Pri izdelku zdaj izbirate sestavine iz baze (195 sestavin): alergeni se obkljukajo sami, v dokumentaciji so receptura, osnutek seznama sestavin za etiketo, nevarnosti iz sestavin in specifikacije surovin, zakonodaja pa se dopolni glede na sestavine.
Ob posodobitvi nadomestite samo program (.exe ali mapo `app`, `baza-admin`, `server.js`). Vaša mapa `baza` ostane, manjkajoča zbirka `sestavine` pa se doda sama ob prvem zagonu.

## Redne posodobitve zakonodaje
Zakonodaja v bazi (EU in Slovenija, standardi) ima pri vsakem predpisu polji `status` (veljaven ali razveljavljen) in `preverjeno` (datum). Razveljavljeni predpisi se v dokumentaciji ne prikažejo. Baza se posodablja s paketi posodobitev (`posodobitev-LLLL-MM.json`), ki lahko dodajo, zamenjajo ali odstranijo predpise (in zapise v drugih zbirkah):
- v urejevalniku baze kliknite **Uvozi posodobitev** in izberite datoteko, ali
- datoteko prekopirajte v mapo `posodobitve` (ob programu ali v mapi `haccp-sistem`) in znova zaženite program.
Vsaka posodobitev se uporabi samo enkrat (evidenca v `baza/_posodobitve.json`, pregled v urejevalniku baze). Pred spremembo se naredi varnostna kopija v `baza/_backup/`. Mesečno pripravo paketa opravlja načrtovana naloga (1. v mesecu); paket se pošlje v pogovor.

## Nadgradnje (zadnji sklop)
- **Testi**: `npm test` (mapa `testi/`, glej `testi/README.md`). UI-testi potrebujejo Playwright + Chromium; brez njih se preskočijo.
- **Skladnost vnosa** ocenjuje strežnik (brskalnik jo le prikaže), zato je ni mogoče ponarediti z odjemalcem.
- **Delo brez povezave (PWA)**: namestljiva aplikacija; vnosi evidenc se brez povezave shranijo v čakalno vrsto in se ob vrnitvi povezave samodejno pošljejo. Deluje na `localhost` ali prek HTTPS. Fotografije brez povezave niso na voljo.
- **Koš**: izbrisani zapisi ostanejo 30 dni in jih je mogoče obnoviti; trajno brisanje samo administrator.
- **Uvoz iz Excela/CSV** z naložljivimi predlogami (osebje, dobavitelji, oprema ...).
- **Tiskani prazni obrazci** za vnos na papir.
- **Globalno iskanje**: polje zgoraj ali tipka `/`.
- **Šifrirane kopije** (AES-256-GCM, `.hfbk`). Geslo za zunanje kopije je shranjeno na strežniku; izgubljeno geslo pomeni, da kopije ni mogoče obnoviti.
- **Dostopnost**: povezava za preskok, oznake, upravljanje fokusa v oknih.
- **Word diagram poteka**: urejljivi liki in puščice (do 9 korakov na risbo). V pravem Wordu ni preverjeno.

- **Tiskanje po vlogah**: Administracija → "Tiskanje dokumentacije". Administrator za vsako skupino dokumentov (HACCP načrt, navodila, evidence, CAPA, inšpekcijska mapa, prazni obrazci, QR, ostalo) določi, ali jo smejo izpisati svetovalec, odgovorna oseba in zaposleni. Omejitev velja za izpisovanje v aplikaciji (podatke še vedno vidijo glede na vlogo).
- **Kartoteke zaposlenih**: zavihek "Zaposleni in usposabljanja" → PDF z listom na osebo (podatki, veljavnosti, usposabljanja, podpis).

- **Potrditve in različice** (zavihek v profilu stranke): odgovorna oseba potrdi trenutno različico HACCP načrta ali navodila (kdo, kdaj, katera različica). Vsaka sprememba potrditev razveljavi. Pri vsakem dokumentu je pregled različic z razlikami in vrnitev na prejšnjo različico (zapiše se kot nova).
- **Danes (opravila)**: v meniju; prikaže manjkajoče redne vnose (po pogostosti vnosov), čiščenje za danes in ukrepe z rokom v tednu. Vnos se opravi z enim klikom.
- **Obvestila o manjkajočih vnosih**: e-poštni opomnik odgovorni osebi in svetovalcu, če vnos po pogostosti (urnik) zamuja.
- **Sledljivost in odpoklic**: evidenca šarž (dobavitelj, rok, kje uporabljeno), iskanje po šarži/izdelku, PDF poročilo in samodejna neskladnost (CAPA) ter oznaka "umaknjeno".
- **Alergeni in jedilnik**: matrika jedi × 14 alergenov, predlog alergenov iz sestavin (vedno ga pregleda odgovorna oseba), jedilnik z oznakami v PDF in Excel.
- **Pripravljenost na certifikacijo**: seznam zahtev za izbrani standard z samodejnim preverjanjem iz podatkov in ročno oceno; izvoz v Excel/PDF. Ni nadomestilo za presojo.
- **Arhiv evidenc** (Administracija): evidence starejše od izbranih let se stisnejo v `podatki/_arhiv` in odstranijo iz žive baze; arhiv je mogoče prenesti in vrniti. Upoštevajte zakonske roke hrambe.

- **Umiki in odpoklici živil**: stran "Umiki in odpoklici". Administrator vpiše naslove virov RSS/Atom (program jih bere vsakih 6 ur), svetovalec in administrator pa lahko obvestilo dodata ročno. Program obvestila samodejno primerja z izdelki in šaržami (Sledljivost), dobavitelji in sestavinami jedi vsake stranke; ujemanja se prikažejo na strani Danes in pridejo po e-pošti. Ujemanje je opozorilo, ki ga potrdi človek. Uradni objavi umikov sta na gov.si; ali ponujata RSS vir, ni preverjeno, zato so vnos virov in ročno dodajanje obe možnosti.

- **RASFF**: v Umiki in odpoklici (administrator) je vklop uvoza iz EU sistema RASFF. Uporablja neuradni, nedokumentirani endpoint RASFF Window (lahko se spremeni; z živim strežnikom ni preizkušeno, ker razvojno okolje nima dostopa). Uvoz je enkrat na dan, 15 s timeout, 3 poskusi, `User-Agent: MojaPlatforma/1.0`, stran 1 (50 zapisov). Šifri filtra (privzeto klasifikacija 306, izvor 5075) sta nastavljivi. Imena polj v odgovoru so uganjena (tolerantno branje), zato po prvem uvozu preverite, ali so obvestila smiselna. Zapisi pridejo v isti seznam in se samodejno primerjajo s šaržami (tudi po EAN), dobavitelji in sestavinami.

- **Nastavitve vidnosti** (Administracija → Nastavitve vidnosti): za vsak razdelek menija, zavihek v profilu stranke in generator administrator s stikali določi, ali ga vidi Stranka (zaposleni stranke) in/ali Odgovorna oseba stranke. Nastavitve veljajo privzeto za vse stranke, za posamezno stranko jih je mogoče prepisati; "Ponastavi na privzeto" prepise odstrani. Skrit razdelek ni v meniju, neposreden naslov preusmeri na nadzorno ploščo z obvestilom "Nimate dostopa", podatkovne zbirke tega razdelka pa zavrne tudi strežnik (403), generator pa strežnik preusmeri. Zbirka podatkov je dostopna, če je viden vsaj en razdelek, ki jo uporablja (npr. oprema je potrebna tudi v evidencah). Administrator in svetovalec vidita vse. Gumba "Predogled kot Stranka" / "Predogled kot Odgovorna oseba" prikažeta platformo z izbrano vidnostjo (samo vmesnik; podatki ostanejo administratorjevi).
- **Generator**: gumb "← Nazaj na platformo" v glavi; če so v obrazcu neshranjene spremembe (po zadnjem prenosu ali tisku), vpraša za potrditev.

- **Brez terminala (Windows)**: `HACCP-sistem.exe` je okenski program brez konzole, zato se dvoklik nanj ali na `HiGiFood.vbs` ne odpre noben črn zaslon. Sporočila in napake se zapišejo v `zagon.log` ob programu. `HACCP-sistem-konzola.exe` je enak program s konzolo; uporablja ga samo `ponastavi-geslo.bat` (vpis gesla v oknu). Konzolni exe se pripravi z `pkg`, okenski pa z `node scripts/pe-gui.js`. Pri zagonu iz izvorne kode (`zagon.bat`, Node.js) se terminal odpre, ker teče Node; takrat uporabite `HiGiFood.vbs`.

- **Testno okolje za druge testerje**: zagon `HiGiFood-test.vbs` (ali `node server.js --testno`) uporabi ločeno mapo `podatki-test`, ustvari testne račune (admin@, svetovalec@, odgovorna@, zaposleni@ `test.si`, geslo `Testiram-123`) in demo podatke, prikaže napis TESTNA RAZLIČICA, gumb za prijavo napake (prenese besedilno datoteko) in gumb za ponastavitev testnih podatkov (admin). E-poštna obvestila so v testnem načinu izklopljena. `HiGiFood-test-omrezje.vbs` (`--testno --omrezje`) je dosegljiv tudi drugim računalnikom v istem omrežju; dovoljeno samo v testnem načinu, ker povezava ni šifrirana. Požarni zid: `odpri-pozarni-zid.bat` / `zapri-pozarni-zid.bat` (kot skrbnik), čiščenje: `odstrani-test.bat`. Navodila: `NAVODILA-ZA-TESTIRANJE.html`. V Dockerju: `HACCP_TEST=1`.

- **Več uporabnikov na strežniku**: hkratno urejanje istega zapisa vrne opozorilo (409) namesto tihega prepisa; odprti zasloni se osvežijo ob vrnitvi na zavihek in vsakih 5 minut. `../ZA-UPORABNIKE/HiGiFood-streznik.vbs` na Windows odpre program na strežniku.
- **Varnost in robustnost**: seje preživijo ponovni zagon (`_seje.json`, samo zgoščenke); sprememba gesla odjavi druge naprave in ima omejitev poskusov; prijava z neznanim e-naslovom traja enako dolgo; preverjanje izvora vrne 403 tudi za `Origin: null` in `Sec-Fetch-Site: cross-site`; vsebina naloženih datotek se preveri po prvih bajtih; telo zahteve se dekodira kot celota (šumniki); zapisi z `fsync`; `baza/_backup` hrani zadnjih 30 kopij na zbirko; čista zaustavitev ob SIGTERM; neobravnavane napake v dnevnik; neobvezno `HACCP_DOSTOPNI_DNEVNIK=1` (dnevnik zahtevkov), `HACCP_PROXY=1` (IP iz X-Forwarded-For za posrednikom), `HACCP_POSODOBITVE_URL` (samodejne posodobitve baze znanja). Docker: en nosilec `/data`, uporabnik `node`, preverjanje zdravja, HSTS v Caddyju.

- **Dvostopenjska prijava (TOTP)**: klik na svoje ime spodaj levo, »Moj račun«: vklop s kodo QR (Google/Microsoft Authenticator), 8 rezervnih kod za enkratno uporabo. Administrator jo lahko izklopi uporabniku, ki je izgubil telefon (Uporabniki, uredi). `ponastavi-geslo` jo izklopi tudi lokalno.
- **Gesla v nastavitvah** (SMTP, geslo za šifrirane kopije) so na disku šifrirana s ključem `podatki/_kljuc` (ali okoljsko spremenljivko `HACCP_KLJUC`). Ključ ni del varnostnih kopij: ob selitvi na drug računalnik ta gesla vnesete znova ali prekopirate `_kljuc`.
- **Revizijska sled** se pri ~5 MB arhivira (`_revizijska-sled-<čas>.jsonl`); veriga zgoščenk se nadaljuje čez datoteke in se preverja v celoti (arhivi le enkrat).
- **Preverjanje kode**: `npm run lint` (sintaksa vseh datotek, JSON baze); `npm test` (27 sklopov); `.github/workflows/testi.yml` za samodejno preverjanje na GitHubu.

- **Prvi koraki**: na nadzorni plošči seznam korakov za začetek (napredek se izračuna iz podatkov); zaposleni vidijo kratko pomoč. Za zaposlene so privzeto skriti Certifikacija, Potrditve, Inšpekcija in Generator (vklop v Nastavitvah vidnosti).
- **Vzdrževanje** (Administracija): stanje sistema (disk, velikost podatkov, zadnja kopija, napake), **preizkus obnove** (zadnja kopija se odpre v pomnilniku in preveri), opozorila na nadzorni plošči in po e-pošti administratorjem (malo prostora, stara ali neuspela kopija, nepreizkušena obnova). Dnevna kopija se osveži, kadar se podatki spremenijo.
- **Varstvo podatkov (GDPR)**: izvoz vseh podatkov osebe (JSON), anonimizacija osebe (tudi v zgodovini sprememb; revizijska sled ostane), rok hrambe za nekdanje zaposlene (polje Datum odhoda), predlogi pogodbe o obdelavi in evidence dejavnosti obdelave (Word).
- **Strokovni pregled baze**: izvoz zakonodaje za strokovnjaka (Excel/Word) in oznaka, kdo in kdaj je predpis pregledal.
- **Pilotna uporaba**: `PILOTNI-NACRT.md` (koraki, tedenski pregled, prava vaja obnove, merila za konec).

## Zavihka in segmenti
Aplikacija ima dva zavihka: **Živila (HACCP)** (izdelek, sestavine, alergeni, hranilna vrednost, HACCP) in **Živilski objekt** (prostori, poti, režimi, verige, čiščenje, DDD, predpogojni programi). Vsak ima svoj izpis. Segmenti (poglavja) se dodajo ali odstranijo posamezno s klikom na gumb nad izpisom; »Priporočeni« doda segmente glede na izbrane standarde.

## Codex Alimentarius
HACCP dokumentacija vsebuje oznake Codexovih korakov in načel (CXC 1-1969) pri poglavjih, segment **Skladnost s Codexom** (preslikava 12 korakov v poglavja in obrazce) ter **Odločitveno drevo za CCP** (klasično drevo s štirimi vprašanji in delovni list; uporaba ni obvezna). Pri razlikah velja zavezujoča zakonodaja EU in RS pred Codexom.

## Presoje
Tretji zavihek **Presoje** ima obrazec (vrsta presoje, datum, obseg, vodja, presojevalci, presojana področja) in segmente: podatki o presoji, letni program, načrt z urnikom, kontrolni seznami po standardih (HACCP/Codex, predpogojni programi, ISO 22000, FSSC 22000, IFS Food, BRCGS), presoja dobavitelja, poročilo, korektivni ukrepi, seznam dokazil (iz obrazcev) in priprava na zunanjo presojo. Vprašanja so v zbirki `presoje` (119 vprašanj) in jih urejate v urejevalniku baze. Področja kontrolnih seznamov lahko izberete.

## Obrazci po standardih
V zavihku **Živilski objekt** je 42 obrazcev za izpolnjevanje (prevzem, temperature, CCP/OPRP, čiščenje, DDD, alergeni, sledljivost, odpoklic, presoje, pregled vodstva, food defence, food fraud …), povezanih s klavzulami standardov HACCP/852, ISO 22000 (vključno z ISO/TS 22002-1), FSSC 22000, IFS Food in BRCGS. Izbrani so glede na označene standarde (lahko tudi ročno). Segment »Kazalo obrazcev« prikaže povezavo obrazec × standard. Zbirka `obrazci` je v bazi in jo urejate v urejevalniku baze. Številke klavzul preverite v aktualni izdaji standarda.

## Izvoz v Word
Gumb **Prenesi Word (.docx, urejljivi diagrami)** ustvari pravi dokument Word (ležeča A4). Diagrami (shema čistih in nečistih poti, diagram poteka) niso slike, ampak Wordove oblike (polja, puščice, besedilo), ki jih v Wordu urejate: premikate, spreminjate besedilo, barve in povezave (po potrebi z desnim klikom »Razdruži«). Starejši gumb »Word (.doc, preprosto)« ustvari preprosto datoteko brez urejljivih diagramov.

## Hranilna vrednost
Receptura se vnese v gramih pri izdelku. Program izračuna hranilne vrednosti na 100 g in na porcijo (z upoštevanjem izgube mase pri obdelavi) ter % referenčnega vnosa. Izračun je ocena po povprečnih vrednostih sestavin iz baze.

## Hitri zagon
- **Windows:** dvoklik na `zagon.bat`
- **Mac/Linux:** `./zagon.sh`
- **Brez Node.js:** odprite `dist/haccp-aplikacija.html` (samostojna različica z vgrajeno kopijo baze; baze v tem načinu ne morete urejati). Po urejanju baze jo osvežite z `node build.js`.

## Zagon
Potrebujete Node.js 18 ali novejši.

    node server.js

- Portal (prijava): http://127.0.0.1:3000/
- Generator dokumentacije: http://127.0.0.1:3000/generator/
- Urejevalnik baze (samo administrator): http://127.0.0.1:3000/baza/

Vrata in naslov: `PORT=8080 HOST=0.0.0.0 node server.js`. Z HOST=0.0.0.0 odprete dostop v omrežju; podatki so zaščiteni s prijavo, vendar strežnik ne podpira HTTPS: za omrežje uporabite HTTPS posredniški strežnik.

## API
- (vse zahteva prijavo) `GET /api/baza` vse zbirke
- `GET /api/baza/<zbirka>` ena zbirka
- `PUT /api/baza/<zbirka>` zamenja zbirko (telo: JSON)

## Opombe za urejanje
- ID temperaturnih režimov (`zam, hl0, hl4, hl6, hl8, sob, kuh, hlaj, vro, pon`) uporablja koda aplikacije, zato jih ne preimenujte.
- Oznake v zakonodaji (`oznake`) določajo, kdaj predpis velja: `*` = vedno; branžne oznake (npr. `animal`, `meat`); lastnosti izdelka (`bio`, `add` …); `std_<id standarda>`; `proto`, `rte`.
- Vsebina je izhodišče. Predpise preverite v EUR-Lex in PISRS.

## Čarovnik HACCP (2.4)

- **Koraki in nevarnosti**: nevarnosti so vezane na korak (ID), ne na številko – pri premiku ostanejo pri svojem koraku. Ko korak z nevarnostmi preimenujete ali izbrišete, program opozori, nevarnosti označi »korak spremenjen – preveri« (izbrisanemu koraku »brez koraka«) in jih je treba znova pregledati in potrditi. Korake premikate z vlečenjem (⠿) ali puščicama; opis koraka je zložen pod »⋯«; diagram poteka se osvežuje sproti.
- **Enotno stanje potrditve**: nevarnost je potrjena samo s kljukico »Nevarnost sem pregledal in potrjujem« – tudi ročno dodana. Urejen predlog brez kljukice dobi oznako »uredil uporabnik – potrdi«. Starejši ročni zapisi ostanejo potrjeni.
- **Predloge**: ločene predloge za vino, pivo, žganje, liker/macerat in sokove (poleg splošne »Alkoholne pijače«), z nevarnostmi (metanol, kumarin, japonski zvezdasti janež, SO2 …). Pri nalaganju predloge v načrt z obstoječimi koraki izberete **Zamenjaj** ali **Dodaj k obstoječim**. Obstoječe namestitve nove predloge in merila dobijo ob zagonu (izbrisane se ne vrnejo).
- **Kontrolni ukrepi**: predlogi meril poleg temperature tudi za alkoholno stopnjo, sladkor, °Brix, pH, a_w, metanol in SO2 (z virom predpisa; potrebna strokovna potrditev). Nove evidence: analiza / laboratorijski izvid, meritev serije (% vol., sladkor, pH), pregled embalaže. Odločitveno drevo je odprto na vrhu, polja za mejne vrednosti so vidna le pri CCP in OPRP. CCP in OPRP so oštevilčeni (CCP1, CCP2) v tabelah, diagramu in dokumentu. Nizka tveganja so v koraku 5 zložena (»Vsem brez ukrepa dodeli PRP«).
- **Uporabnost**: koračnik s stanjem (prazno / delno / izpolnjeno), samodejno shranjevanje ob menjavi koraka in ob odhodu iz čarovnika (opozorilo ob zapiranju zavihka), matrika tveganja v koraku 4, vrstice združene po koraku, izbirni seznam 14 alergenov EU (+ »ni alergenov«, »preveriti«), število zaposlenih in HACCP skupina iz zavihka Zaposleni, gumb **Čarovnik** v seznamu načrtov in ponudba »Odpri čarovnik« po dodajanju načrta.

## Besedila dokumentacije (2.4)
- Nova zbirka baze znanja **»Besedila dokumentacije«** (`baza/besedila.json`, urejanje v urejevalniku baze): opisna besedila po poglavjih (namen in obseg, HACCP skupina, opis živil, diagram, nevarnosti, ukrepi, CCP, PRP, alergeni, evidence, verifikacija, potrditev).
- Besedila vsebujejo oznake, ki se nadomestijo s podatki načrta: `{podjetje} {obrat} {dejavnost} {izdelki} {alergeni} {kupci} {koraki_stevilo} {koraki_seznam} {ccp_stevilo} {ccp_seznam} {skupina} {odgovorna_oseba}`. Vnosi z `oznake` (npr. `alcohol`, `meat`, `caterer`) se uporabijo samo za ustrezne dejavnosti.
- Čarovnik (korak 7) besedila vstavi v dokument (PDF/Word); besedilo vsakega poglavja je mogoče za posamezen načrt prilagoditi in ponastaviti na besedilo iz baze. Starejšim načrtom se nova poglavja (Namen in obseg, HACCP skupina, Predpogojni programi) vstavijo samodejno.
- Generator dokumentacije uporablja ista besedila skupaj s podatki obrazca. Ob posodobitvi se nova besedila dodajo, uporabnikove spremembe v bazi ostanejo.

## Opomniki, paket za inšpekcijo, fotografije, nalepke QR (2.4)
- **E-poštni opomniki**: vsak uporabnik v »Moj račun« izbere pogostost (vsak dan / tedensko ob ponedeljkih / izklopljeno) in vrsto (roki in zamude, manjkajoči vnosi evidenc). Svetovalec lahko v obrazcu stranke izklopi opomnike za celotno stranko. Sporočilo je razdeljeno na roke v zamudi, bližnje roke in manjkajoče vnose.
- **Paket za inšpekcijo** (profil stranke → Inšpekcija): en PDF s pregledom stanja, veljavnimi HACCP načrti v celoti (priloge A, B …), vsemi evidencami obdobja po vrstah ter fotografijami odstopanj in ukrepov CAPA.
- **Fotografije**: fotografije, večje od 400 kB, se pred pošiljanjem zmanjšajo na največ 1600 px (JPEG); sličice so v seznamu evidenc, seznamu CAPA in v obrazcih.
- **Nalepke QR** (Oprema → QR kode naprav → Nalepke za tisk): PDF za pole A4 – velike (8), srednje (21) ali majhne (40 na A4), več nalepk na napravo, začetek na poljubni nalepki načete pole, izbira naprav. Tiskajte v 100 % velikosti.

## Rednost vnosov in nova stranka iz predloge (2.4)
- **Rednost vnosov (30 dni)**: delež obdobij, v katerih so bile evidence vnesene po urniku pogostosti (Evidence → Pogostost vnosov) in načrtu čiščenja. Obdobje je dolgo toliko kot največji dovoljeni razmik (npr. 24 h); tekoče obdobje se šteje samo, če je vnos že opravljen. Prikaz: stolpec na seznamu strank in kartica na nadzorni plošči (zeleno ≥ 90 %, rumeno ≥ 70 %, rdeče pod 70 %). »Ni urnika« = pogostost ni določena, »premalo podatkov« = urnik je nov.
- **Stranke → + Iz predloge**: nova stranka prevzame opremo (z mejnimi vrednostmi), načrt čiščenja in urnik evidenc izbrane stranke ter njeno glavno dejavnost. Zapisi, zaposleni, dokumenti, obrati in datumi (servisi, začetek čiščenja) se ne kopirajo.

## Platforma (2.4)

- **Izbris uporabnika** (samo administrator, Uporabniki → Uredi → »Izbriši uporabnika«): dostop se takoj odvzame, uporabnik gre v Koš (obnovljiv 30 dni); zapisi, ki jih je vnesel, ostanejo z njegovim imenom. Začasno onemogočenje ostane kljukica »Aktiven«. Sebe ali zadnjega administratorja ni mogoče izbrisati.
- **Obvezna 2FA**: na strežniku (HACCP_PROXY=1) opozorilo v stanju sistema, dokler dvostopenjska prijava ni obvezna za administratorje in svetovalce; v Administraciji → Varnost prijave gumb »Vklopi priporočeno«.
- **Kratko ime stranke**: prikazano v aplikaciji (seznami, izbirniki, naslovi); uradni naziv ostane v dokumentih. **Dodatne dejavnosti** stranke (več oznak) v čarovniku predlagajo ustrezne predloge.
- **Nadzorna plošča**: ploščice v blokih Stranke in načrti / Roki / Odstopanja; prikazane so samo tiste, ki niso 0.
- **Danes**: hiter vnos temperature za hladilnike in zamrzovalnike (veliko polje, Enter ali »Shrani«; skladnost glede na meje naprave); prazen načrt čiščenja vodi neposredno v Higiena → Načrt čiščenja.
- **Storitve**: klik na število v stolpcu »Manjka« pokaže, kaj manjka. **Prazni seznami** imajo gumb »Dodaj prvi zapis«.
- **Umiki in odpoklici**: privzeta vira – seznam »Nevarni in neskladni izdelki« na gov.si (UVHVVR) in RASFF (vklopljen); vir je lahko RSS ali spletna stran s seznamom.
- **Generator dokumentacije**: izbira stranke izpolni podjetje, vrsto proizvodnje in število zaposlenih.

## Podatki podjetja po davčni številki ali nazivu

V obrazcu stranke (osebje: administrator, svetovalec) vpišete davčno številko in kliknete **Izpolni po davčni številki**, ali začnete tipkati naziv in izberete podjetje s seznama predlogov. Izpolnijo se naziv, naslov, davčna in matična številka ter vrsta dejavnosti (iz šifre SKD). Že vpisani podatki se ne prepišejo brez potrditve.

- **Seznam davčnih zavezancev FURS** (odprti podatki; podjetja, tudi tista, ki niso zavezanci za DDV): program ga prenese enkrat na dan v `podatki/_zavezanci` (ni del varnostnih kopij). Privzeti naslov: `https://www.fu.gov.si/fileadmin/prenosi/DURS_zavezanci_PO_csv.zip`; dodatne datoteke (npr. samostojni podjetniki) dodate v **Administracija → Seznam podjetij (FURS)**, kjer je tudi »Prenesi zdaj« in ročni uvoz datoteke (zip, csv, txt). Bralnik prepozna stolpce po glavi ali po vsebini (ločila `;` `,` tab `|` ali stolpci s presledki, UTF-8 ali Windows-1250). Spremenljivka `HACCP_ZAVEZANCI_URL` (naslovi, ločeni z vejico) nadomesti nastavitev.
- **Register EU VIES** (zavezanci za DDV: naziv, naslov), če podjetja ni v seznamu ali seznam še ni prenesen. Spremenljivka `HACCP_VIES_URL`.
- Program preveri kontrolno števko davčne številke; največ 20 poizvedb na minuto na uporabnika. Povezava **bizi.si** odpre iskanje podjetja za ostale podatke.
- Odgovorne osebe, e-naslova in telefona brezplačni registri ne vsebujejo.

## Plačljivi paketi in naročnine

Administrator v meniju **Naročnine in predračuni** vsaki stranki določi paket, obračun (mesečno ali letno) in ceno. Pakete (privzeto Osnovni, Standard, Pro, S svetovanjem) lahko ureja: **Nov paket** ali **Uredi** (ime, opis, cena na mesec za prvi obrat, funkcije v paketu); ob spremembi cene lahko izbere, da se nova cena uporabi tudi pri obstoječih strankah s tem paketom. Paketa, ki ga uporablja kakšna stranka, ni mogoče izbrisati.

- Paket določa, katere funkcije vidijo uporabniki stranke (odgovorna oseba, zaposleni). Funkcije zunaj paketa so v meniju in zavihkih označene s ključavnico in prikažejo, v katerem paketu so na voljo; strežnik dostop do njih zavrne. Administrator in svetovalec vidita vse.
- Stranka brez paketa ima vse funkcije (tako delujejo obstoječe stranke).
- Predračun (PDF) se izda za naslednje obdobje; ko je plačan, ga označite kot plačanega in naročnina se podaljša. Program računov ne izdaja (račun izdate v svojem računovodskem programu).
- Opozorila: administrator dobi opomnik (nadzorna plošča in e-pošta), ko naročnina poteče v nastavljenem številu dni ali je zapadla; odgovorna oseba vidi opozorilo na nadzorni plošči.
- Cenik, popust za dodatni obrat, brezplačne mesece pri letnem plačilu, DDV, rok plačila in podatke izdajatelja (TRR) nastavite na isti strani. Podatki so v `podatki/_narocnine.json` (del varnostnih kopij).

## Posodobitve programa iz aplikacije

Administrator v **Vzdrževanje → Posodobitve programa** preveri, ali je na voljo nova različica (program to preveri tudi sam enkrat na dan in opozori na nadzorni plošči).

- **Windows program:** gumb **Namesti posodobitev** prenese novo različico, preveri podpis in SHA-256, naredi varnostno kopijo podatkov, zamenja `HACCP-sistem.exe` (prejšnja ostane kot `HACCP-sistem.exe.stara`) in program znova zažene. Podatki ostanejo. Samodejni ponovni zagon opravi zaganjalnik `windows/HiGiFood.vbs` (v paketu za Windows je to `HiGiFood.vbs` ob programu); program morate zagnati z njim. Vrnitev na prejšnjo različico: `HACCP-sistem.exe --vrni-json` (podatke iz baze zapiše v datoteke, ki jih bere tudi različica 2.2), nato `HACCP-sistem.exe.stara` preimenujte v `HACCP-sistem.exe`.
- **Strežnik (Docker):** program pokaže, da je nova različica na voljo. Namestitev: `sudo sh POSODOBI-SAMODEJNO.sh` v mapi namestitve (prenese podpisan arhiv `HACCP-portal-<različica>.tar.gz`, preveri podpis in SHA-256, ohrani `.env`, `Caddyfile` in podatke, shrani prejšnjo različico, znova zažene portal); `... vklopi` to naredi vsako noč ob 3.30.
- Program sprejme samo izdaje, podpisane z zasebnim ključem izdajatelja (Ed25519). Javni ključ je v `posodobitev.js`. Zasebnega ključa nikoli ne objavite in ga ne shranite v git.
- Privzeti naslov izdaj: `https://raw.githubusercontent.com/lukazorman-byte/HiGiFood-posodobitve/main/posodobitev.json` (javni repozitorij samo z izdajami). Naslov lahko spremenite v Vzdrževanju.

**Objava nove različice:** povečajte `version` v `package.json`, zgradite `exe/HACCP-sistem.exe`, nato
`npm run izdaja -- --kljuc <zasebni-kljuc.pem> --url https://raw.githubusercontent.com/lukazorman-byte/HiGiFood-posodobitve/main/ --opis "Kaj je novega"`
in vsebino mape `izdaja/` (exe, arhiv za strežnik, `posodobitev.json`) naložite v repozitorij HiGiFood-posodobitve. Brez exe: `--brez-exe`.

**Postopna objava (obvezno):** nočne posodobitve namestijo izdajo na vse strežnike hkrati, zato slaba izdaja zadene vse naenkrat.
1. Izdajo najprej pripravite z `--url https://raw.githubusercontent.com/lukazorman-byte/HiGiFood-posodobitve/main/test/` in jo naložite v mapo `test/` repozitorija.
2. Testni strežnik ima v `program/streznik/.env` vrstico `HACCP_PROGRAM_URL=…/main/test/posodobitev.json` in se posodobi sam. Nekaj dni preverjajte prijavo, evidence, kopije in e-pošto.
3. Šele nato izdajo pripravite znova z `--url …/main/` (brez `test/`) in jo naložite v koren repozitorija. Šele ta `posodobitev.json` vidijo stranke.

**Zasebni ključ za podpis** je najpomembnejša skrivnost projekta: kdor ga ima, lahko podpiše »posodobitev«, ki se sama namesti na vse strežnike z vklopljenimi nočnimi posodobitvami.
- Hranite ga offline (šifriran USB ali upravljalnik gesel), nikoli v repozitoriju, v mapi programa, v e-pošti ali klepetu.
- Imejte vsaj dve varnostni kopiji na ločenih mestih. Brez ključa nove posodobitve ni mogoče več izdati (programi sprejmejo samo izdaje, podpisane s tem ključem).
- Ključ uporabite samo na svojem računalniku med pripravo izdaje (`--kljuc E:\kljuc\...pem`).
- Če ključ uide: takoj izdajte posodobitev z novim javnim ključem (podpisano s starim, dokler je še vaš) in strežnikom izklopite nočne posodobitve, dokler ni nameščena.

**Windows opozorilo:** `HACCP-sistem.exe` ni podpisan s certifikatom za podpisovanje kode (Authenticode), zato Windows ob prvem zagonu pokaže »Windows protected your PC« / »Windows je zaščitil vaš računalnik«. To je pričakovano: kliknite **Več informacij → Vseeno zaženi**. Program strankam dajte kot povezavo na GitHub (repozitorij HiGiFood-posodobitve), ne po WhatsAppu ali e-pošti. Za odpravo opozorila ga lahko podpišete (Azure Trusted Signing ali certifikat za podpisovanje kode).

## Javna spletna stran (higifood.si)
- Mapa `spletna-stran/`: predstavitev, funkcije, cenik in kontakt. Cenik in kontakt se berejo iz platforme (`/api/javno/cenik`: paketi, cene brez DDV, popusti, kontakt izdajatelja – brez podatkov strank).
- Predogled: `/stran/`. Na domenah iz `HACCP_SPLETNA_STRAN` (npr. `higifood.si,www.higifood.si`) se prikaže stran namesto platforme; gumb »Prijava« vodi na `HACCP_APLIKACIJA_URL`.
- Povpraševanje (obrazec na strani): shrani se v platformo (Administracija → Spletna stran), skrbnik dobi e-pošto na naslov izdajatelja; soglasje, past za robote, največ 5 povpraševanj na uro z istega naslova IP, samodejni izbris po 12 mesecih.
- Novice: prijava z dvojno potrditvijo (povezava v e-pošti, velja 7 dni), odjava s povezavo ali z e-naslovom (`novice.html#odjava`) izbriše naslov; izvoz potrjenih naročnikov s povezavami za odjavo (CSV). Za povezave nastavite `HACCP_SPLETNA_URL` (npr. `https://higifood.si/`), sicer se uporabi domena iz `HACCP_SPLETNA_STRAN`.
- Blog (`/blog/` na domeni strani, predogled `/stran/blog/`, strani iz strežnika za iskalnike): urednik v platformi (Orodja → Blog). Administrator piše, ureja, objavi, umakne in pošlje članek potrjenim naročnikom novic (s povezavo za odjavo); svetovalec piše osnutke in jih pošlje v pregled. Orodna vrstica (krepko, ležeče, podčrtano, H2/H3, seznama, citat, povezava, slika; Ctrl+B/I/U/K), oznake: `**krepko**`, `*ležeče*`, `__podčrtano__`, `## podnaslov`, `- alineja`, `1. točka`, `> citat`, `[besedilo](https://…)`; naslovna slika JPEG; slike v besedilu z gumbom »Vstavi sliko«, prilepi (Ctrl+V) ali povleci – vrstica `![opis](slika:…)`, opis se izpiše pod sliko, neuporabljene slike se ob shranjevanju izbrišejo. Podatki v `_blog.json` in mapi `blog-slike` (v varnostnih kopijah).
- Iskalniki (SEO): Spletna stran → Iskalniki (SEO) – naslov, opis in ključne besede za vsako stran (s predogledom zadetka v Googlu); članki imajo svoje (naslov, opis, ključne besede za Google). Strežnik doda kanonični naslov, Open Graph in Twitter oznake ter strukturirane podatke (JSON-LD: organizacija, spletno mesto, članek, drobtine). `sitemap.xml` (vstopna stran, blog, objavljeni članki z datumom) in `robots.txt` na domeni strani; platforma in predogled `/stran/` sta za iskalnike zaprta (`noindex`). Sitemap vpišite v Google Search Console.
- Načrtovana objava članka: administrator izbere čas objave; članek je javen (in v sitemap) šele od tega časa.
- Piškotki in GDPR: pasica s soglasjem (Samo nujni / Nastavitve / Sprejmi vse, izbira velja 12 mesecev), `piskotki.html`, `zasebnost.html` (podatki upravljavca iz platforme). Besedila naj pred objavo pregleda pravnik.
- Zamenjava stare strani: `streznik/SPLETNA-STRAN.md`; varnostne nastavitve Cloudflare: `streznik/CLOUDFLARE-VARNOST.md`; obvestilo strankam: `objava/OBVESTILO-STRANKAM.md`.

## Novosti v 2.6.3
- Baza za odločitveno drevo (`baza/drevo_profili.json`, `baza/drevo_faze.json`): za vsako živilo se samodejno izpolnijo temperaturni režim shranjevanja, temperatura ob prevzemu in toplotna obdelava; v koraku 5 »Predlagaj razvrstitev iz baze« izpolni odgovore V1–V4, PRP/OPRP/CCP, mejne vrednosti (temperatura in čas), spremljanje in korektivne ukrepe (predlog, ki ga strokovno potrdi svetovalec; ročno izbrani ukrepi se ne prepišejo). Bazo urejate v urejevalniku baze.
- Odločitveno drevo po Codex CXC 1-1969 (rev. 2022, Priloga IV); kontrolni ukrepi z odgovori po prejšnjem drevesu ostanejo nespremenjeni in označeni, prehod na novo drevo je en klik.
- Baze znanja preverjene po uradnih virih: stanje predpisov EU (EUR-Lex), Uredba 853/2004, 2073/2005, 2023/915, Smernice DHP za gostinstvo (tabela NIJZ 2014); popravki temperatur (toplotna obdelava 63/68/74/82 °C, toplo vzdrževanje ≥ 63 °C, ohlajevanje 63 → 20 → 5 °C, pogrevanje ≥ 74 °C), mikrobioloških meril in zakonodaje (BPA 2024/3190). Obstoječe namestitve dobijo popravke s paketom posodobitve.
- Decimalna vejica pri prikazu in vnosu števil.

## Novosti v 2.6.2
- Preverjanje načrta brez lažnih opozoril (nadomestna besedila, [MANJKA], primerjava samo znotraj razdelka navodila); teme navodil kot seznam; »Obravnavano« z utemeljitvijo v dokumentu; korak 6 in izvoz uporabljata isto preverjanje.
- Izvoz s svežimi podatki; oznake {{CCP:…}}, {{seznam_CCP}}, {{stevilo_CCP}}; zaklenjene številke CCP/OPRP z ročnim »Preštevilči«; različice dokumenta (1.0, 1.1) ločeno od interne številke zapisa.
- Vir meje iz baze zakonodaje s členom; alergeni obrata izračunani iz živil (opozorila za sulfite, zeleno); alergen »Drugo« v stolpcu Opomba; nizka tveganja v strnjeni tabeli; »Razdeli navodilo«.
- Razlog ob shranjevanju po spremembi obrata; SKD, pravna oblika in nosilec s.p. iz registra; opozorilo za več odgovornih oseb pri s.p.; lastna potrditvena okna.
- Administrator je lahko tudi svetovalec (»Tudi svetovalec«), profil svetovalca s podpisom, vloga v revizijski sledi, podatki izdelovalca ob potrditvi načrta ostanejo nespremenjeni.

## Novosti v 2.6.1
- Naslovnica dokumentov: izdelal (svetovalec) in odobril (odgovorna oseba) s podpisnimi polji, noga z izdelovalcem, evidenca različic; Moji podatki (naziv, izobrazba, kontakt, logotip izdelovalca).
- HACCP načrt izdela svetovalec (stranka brez svetovalca ga ne more urejati); elektronska odobritev načrta z geslom; letna revizija in pregled po spremembi obrata; poročilo po obisku; mesečni samodejni preizkus obnove.
- Spletna stran: logotip, povpraševanje, novice z dvojno potrditvijo in odjavo, piškotki in politika zasebnosti (GDPR), blog z urednikom (slike, oblikovanje, načrtovana objava), optimizacija za iskalnike (SEO, sitemap).
- Meni: en vnos »Spletna stran« z zavihki; Moji podatki pod »Moj račun«.

## Novosti v 2.6.0
- HACCP dokument: prenovljen izpis vseh poglavij (podjetje, dejavnost, analiza z odprtimi točkami, razvejan diagram poteka, CCP/OPRP, verifikacija, skupina), kazalo, priloga, preverjanje pred izpisom in oznaka OSNUTEK, zgodovina brez samodejnih shranjevanj.
- Čarovnik: nova polja (registracija, SKD, način prodaje, kultura varne hrane, člani skupine), alergeni iz jedilnika, odgovori drevesa odločanja, predlog korakov in nevarnosti iz naprav obrata.
- Obrati: seznam prostorov in naprav za obkljukanje z opisom; baza naprav (temperaturni režimi z virom, protokoli čiščenja) in prostorov; prenos v opremo, urnik meritev in načrt čiščenja brez podvajanja.
- Navodilo »Čiščenje in razkuževanje« iz načrta čiščenja; mesečni list temperatur za vse hladilne naprave (po obratih).
- Dvostopenjska prijava: koda na zaupanja vredni napravi enkrat na 30 dni, »Pozabi zaupanja vredne naprave«.
- Vzdrževanje: preverjanje obstoječih podatkov (zapisi, shranjeni pred uvedbo pravil); opozorilo za predpise, ki niso bili preverjeni 12 mesecev.

## Novosti v 2.5.0
- Podatkovna baza SQL za vse podatke (tudi nastavitve, seje, naročnine, umiki), zrcalne datoteke za vrnitev na prejšnjo različico.
- Obvestila RASFF prevedena v slovenščino (slovar izrazov, neobvezno DeepL z `DEEPL_KLJUC`), angleški izvirnik ostane prikazan.
- Javna spletna stran (`spletna-stran/`), cenik in kontakt iz platforme.
- Več obratov: hiter vnos, manjkajoči vnosi in čiščenje ločeni po obratih.
- Popravki po testiranju 2.3.0: obvezen razlog popravka, preverjanje vnosov na strežniku in v obrazcih, alergeni (skloni in izjeme), enotna ocena Certifikacije in Inšpekcije, šarže (pretečeno, EAN), e-pošta prek HTTPS API (Resend, Brevo), predpomnilnik.
