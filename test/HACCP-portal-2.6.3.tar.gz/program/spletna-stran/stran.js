// Spletna stran HiGiFood: cenik in kontakt iz platforme (/api/javno/cenik), povezava za prijavo,
// soglasje za piškotke, povpraševanje, prijava na novice (z dvojno potrditvijo) in odjava. Enak skript na vseh straneh.
(function () {
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const eur = n => Number(n).toLocaleString("sl-SI", { minimumFractionDigits: Number(n) % 1 ? 2 : 0, maximumFractionDigits: 2 }) + " €";
  const mn = (n, o) => { const k = Math.abs(n) % 100; return o[k === 1 ? 0 : k === 2 ? 1 : k === 3 || k === 4 ? 2 : 3]; };
  const $ = id => document.getElementById(id);
  if ($("leto")) $("leto").textContent = new Date().getFullYear();
  // po zamenjavi strani: zapisi evidenc, ki jih je platforma na tej domeni shranila brez povezave (localStorage), se ne smejo izgubiti
  let q = []; try { q = JSON.parse(localStorage.getItem("haccp_offq") || "[]"); } catch {}
  if (Array.isArray(q) && q.length) {
    const b = document.createElement("div"); b.className = "w"; b.setAttribute("role", "alert");
    b.innerHTML = `<div class="k" style="margin:16px 0;border:2px solid #b3261e"><h3>Na tej napravi so neposlani zapisi evidenc (${q.length})</h3><p>Zapisi so bili vneseni brez internetne povezave in še niso na strežniku.</p><p style="margin-top:12px"><button class="btn" id="poslji-q" type="button">Pošlji zapise zdaj</button> <span id="poslji-r"></span></p></div>`;
    if (document.querySelector("main")) document.querySelector("main").prepend(b);
    document.getElementById("poslji-q").onclick = async () => {
      const r = document.getElementById("poslji-r"); let poslano = 0, napaka = "";
      for (const it of q.slice()) {
        try {
          const x = await fetch("/api/d/" + encodeURIComponent(it.c), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(it.body) });
          if (x.status === 401) { napaka = "Prijava je potekla – prijavite se v platformo in zapise pošljite tam."; break; }
          if (!x.ok) { const j = await x.json().catch(() => ({})); napaka = j.napaka || "Napaka " + x.status; break; }
          poslano++; q = q.filter(y => y !== it); localStorage.setItem("haccp_offq", JSON.stringify(q));
        } catch { napaka = "Ni povezave s strežnikom. Poskusite znova."; break; }
      }
      r.textContent = (poslano ? "Poslano: " + poslano + ". " : "") + (napaka || (q.length ? "" : "Vsi zapisi so poslani."));
      if (!q.length) b.remove();
    };
  }
  fetch("/api/javno/cenik", { headers: { Accept: "application/json" } }).then(r => r.ok ? r.json() : Promise.reject(r.status)).then(c => {
    if (c.aplikacija) document.querySelectorAll("[data-prijava]").forEach(a => { a.href = c.aplikacija; });
    const pk = (c.paketi || []).filter(p => p && p.ime);
    if (pk.length && $("paketi")) $("paketi").innerHTML = pk.map((p, i) => `<div class="k${i === Math.min(1, pk.length - 1) ? " pri" : ""}"><h3>${esc(p.ime)}</h3><div class="cena">${eur(p.cena)} <small>/ mesec</small></div><p>${esc(p.opis)}</p><a class="btn${i === Math.min(1, pk.length - 1) ? "" : " o"}" href="#povprasevanje">Izberi ${esc(p.ime)}</a></div>`).join("");
    const op = ["Cene so brez DDV" + (c.ddv ? " (" + esc(c.ddv) + " %)" : "") + " in veljajo za en obrat."];
    if (+c.popust_obrat > 0) op.push("Vsak dodatni obrat " + esc(c.popust_obrat) + " % ceneje.");
    if (+c.brezplacni_meseci > 0) op.push("Pri letnem plačilu " + esc(c.brezplacni_meseci) + " " + mn(+c.brezplacni_meseci, ["mesec", "meseca", "meseci", "mesecev"]) + " brezplačno.");
    if ($("cenik-opomba")) $("cenik-opomba").textContent = op.join(" ");
    const k = c.kontakt || {}, v = [];
    if (k.email) v.push(`<p>E-pošta: <a href="mailto:${esc(k.email)}?subject=${encodeURIComponent("Predstavitev HiGiFood")}">${esc(k.email)}</a></p>`);
    if (k.telefon) v.push(`<p>Telefon: <a href="tel:${esc(String(k.telefon).replace(/[^\d+]/g, ""))}">${esc(k.telefon)}</a></p>`);
    if (k.naslov) v.push(`<p>${esc(k.naslov)}</p>`);
    // upravljavec osebnih podatkov (politika zasebnosti, piškotki): podatki izdajatelja iz platforme
    document.querySelectorAll("[data-upravljavec]").forEach(el => { el.innerHTML = `<b>${esc(k.naziv || "HiGiFood")}</b>${k.naslov ? "<br>" + esc(k.naslov) : ""}${k.email ? `<br>E-pošta: <a href="mailto:${esc(k.email)}">${esc(k.email)}</a>` : ""}${k.telefon ? "<br>Telefon: " + esc(k.telefon) : ""}`; });
    document.querySelectorAll("[data-kontakt-email]").forEach(el => { if (k.email) el.innerHTML = `<a href="mailto:${esc(k.email)}">${esc(k.email)}</a>`; });
    if (v.length && $("kontakt-podatki")) $("kontakt-podatki").innerHTML = `<h3>${esc(k.naziv || "HiGiFood")}</h3>${v.join("")}${k.email ? `<p style="margin-top:14px"><a class="btn" href="mailto:${esc(k.email)}?subject=${encodeURIComponent("Predstavitev HiGiFood")}">Dogovorimo se za predstavitev</a></p>` : ""}`;
  }).catch(() => {});

  // zadnji članki iz bloga na vstopni strani (razdelek ostane skrit, dokler ni objavljenih člankov)
  if ($("blog-seznam")) fetch("/api/javno/blog").then(r => r.ok ? r.json() : []).then(a => {
    if (!a.length) return;
    $("blog-seznam").innerHTML = a.slice(0, 3).map(c => `<article class="k bl-k">${c.slika ? `<a href="blog/${esc(c.slug)}" tabindex="-1" aria-hidden="true"><img src="/api/javno/blog/slika/${esc(c.id)}" alt="" loading="lazy"></a>` : ""}<p class="mut">${esc(new Date(c.objavljeno).toLocaleDateString("sl-SI"))}</p><h3><a href="blog/${esc(c.slug)}">${esc(c.naslov)}</a></h3><p>${esc(c.povzetek)}</p></article>`).join("");
    $("blog-zadnji").hidden = false;
  }).catch(() => {});

  // ---------- piškotki: soglasje (nujni vedno, analitični samo z dovoljenjem); izbira se hrani v brskalniku ----------
  // Stran trenutno uporablja samo nujno shrambo (izbira piškotkov, neposlani zapisi platforme). Analitika se naloži šele, ko jo obiskovalec dovoli.
  const PK = "hf_piskotki", VER = 1;
  let sog = null; try { sog = JSON.parse(localStorage.getItem(PK) || "null"); } catch {}
  const veljavno = s => s && s.v === VER && s.cas && Date.now() - Date.parse(s.cas) < 365 * 864e5; // soglasje se obnovi po 12 mesecih
  window.hfSoglasje = () => (veljavno(sog) ? sog : null);
  function shraniSoglasje(analitika) {
    sog = { v: VER, nujni: true, analitika: !!analitika, cas: new Date().toISOString() };
    try { localStorage.setItem(PK, JSON.stringify(sog)); } catch {}
    const p = $("piskotki-pasica"); if (p) p.remove();
    document.dispatchEvent(new CustomEvent("hf-soglasje", { detail: sog }));
    const st = $("piskotki-stanje"); if (st) st.textContent = opisSoglasja();
  }
  const opisSoglasja = () => veljavno(sog) ? "Vaša izbira (" + new Date(sog.cas).toLocaleDateString("sl-SI") + "): nujni piškotki" + (sog.analitika ? " in analitični piškotki." : ", analitični zavrnjeni.") : "Izbire še niste shranili.";
  function nastavitve() {
    let d = $("piskotki-nast");
    if (!d) {
      d = document.createElement("dialog"); d.id = "piskotki-nast"; d.className = "pk-dlg"; d.setAttribute("aria-labelledby", "pk-nt");
      d.innerHTML = `<form method="dialog"><h3 id="pk-nt">Nastavitve piškotkov</h3>
        <label class="chk"><input type="checkbox" checked disabled> <span><b>Nujni</b> – potrebni za delovanje strani (zapomnijo si vašo izbiro piškotkov in zaščitijo obrazce). Brez njih stran ne deluje, zato jih ni mogoče izklopiti.</span></label>
        <label class="chk"><input type="checkbox" id="pk-an"> <span><b>Analitični</b> – anonimna statistika obiska, da izboljšamo stran. Trenutno jih ne uporabljamo; če jih uvedemo, se naložijo samo z vašim dovoljenjem.</span></label>
        <p class="mut"><a href="piskotki.html">Več o piškotkih</a> · <a href="zasebnost.html">Politika zasebnosti</a></p>
        <div class="pk-gumbi"><button class="btn o" value="nujni" type="submit">Samo nujni</button><button class="btn o" value="izbira" type="submit">Shrani izbiro</button><button class="btn" value="vsi" type="submit">Sprejmi vse</button></div></form>`;
      document.body.appendChild(d);
      d.addEventListener("close", () => { const v = d.returnValue; if (v === "nujni") shraniSoglasje(false); else if (v === "vsi") shraniSoglasje(true); else if (v === "izbira") shraniSoglasje($("pk-an").checked); });
    }
    $("pk-an").checked = !!(veljavno(sog) && sog.analitika); d.returnValue = ""; d.showModal();
  }
  function pasica() {
    if (veljavno(sog) || $("piskotki-pasica")) return;
    const b = document.createElement("div"); b.id = "piskotki-pasica"; b.className = "pk-pas"; b.setAttribute("role", "region"); b.setAttribute("aria-label", "Piškotki");
    b.innerHTML = `<div class="w"><p><b>Piškotki.</b> Uporabljamo nujne piškotke, brez katerih stran ne deluje. Analitične piškotke uporabimo samo z vašim dovoljenjem. <a href="piskotki.html">Več o piškotkih</a></p>
      <div class="pk-gumbi"><button class="btn o" type="button" data-pk="nujni">Samo nujni</button><button class="btn o" type="button" data-pk="nast">Nastavitve</button><button class="btn" type="button" data-pk="vsi">Sprejmi vse</button></div></div>`;
    document.body.appendChild(b);
    b.addEventListener("click", e => { const a = e.target.closest("[data-pk]"); if (!a) return; if (a.dataset.pk === "nast") nastavitve(); else shraniSoglasje(a.dataset.pk === "vsi"); });
  }
  pasica();
  document.querySelectorAll("[data-piskotki]").forEach(b => b.addEventListener("click", nastavitve));
  if ($("piskotki-stanje")) $("piskotki-stanje").textContent = opisSoglasja();

  // ---------- obrazci: povpraševanje in novice ----------
  const poslji = async (url, telo) => { const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(telo) }); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.napaka || "Pošiljanje ni uspelo (" + r.status + "). Poskusite znova."); return j; };
  const sporocilo = (el, t, napaka) => { el.textContent = t; el.className = "sporocilo" + (napaka ? " nap" : " ok"); };
  function obrazec(id, url, zberi, uspeh) {
    const f = $(id); if (!f) return;
    f.addEventListener("submit", async e => {
      e.preventDefault(); const r = $(id + "_r"), btn = f.querySelector("button[type=submit]");
      const prvi = [...f.querySelectorAll("[required]")].find(x => x.type === "checkbox" ? !x.checked : !x.value.trim() || (x.type === "email" && !x.checkValidity()));
      if (prvi) { sporocilo(r, prvi.type === "checkbox" ? "Za oddajo potrebujemo vaše soglasje (označite polje)." : prvi.type === "email" ? "Vpišite veljaven e-naslov." : "Izpolnite obvezna polja (*).", true); prvi.focus(); return; }
      btn.disabled = true; sporocilo(r, "Pošiljam …");
      try { const j = await poslji(url, zberi(f)); f.reset(); sporocilo(r, uspeh(j)); } catch (er) { sporocilo(r, er.message, true); } finally { btn.disabled = false; }
    });
  }
  const pol = (f, n) => (f.elements[n] ? (f.elements[n].type === "checkbox" ? f.elements[n].checked : f.elements[n].value.trim()) : "");
  obrazec("pv", "/api/javno/povprasevanje", f => ({ ime: pol(f, "ime"), podjetje: pol(f, "podjetje"), email: pol(f, "email"), telefon: pol(f, "telefon"), dejavnost: pol(f, "dejavnost"), obratov: pol(f, "obratov"), sporocilo: pol(f, "sporocilo"), soglasje: pol(f, "soglasje"), novice: pol(f, "novice"), spletna_stran: pol(f, "spletna_stran") }),
    j => "Hvala! Povpraševanje smo prejeli in vam odgovorimo čim prej." + (j.novice === "poslano" ? " Za prijavo na novice potrdite povezavo, ki smo vam jo poslali po e-pošti." : j.novice === "napaka" ? " Prijave na novice trenutno nismo mogli potrditi – poskusite pozneje spodaj." : ""));
  obrazec("nv", "/api/javno/novice/prijava", f => ({ email: pol(f, "email"), soglasje: pol(f, "soglasje"), spletna_stran: pol(f, "spletna_stran") }), () => "Poslali smo vam e-pošto. Prijavo potrdite s klikom na povezavo v sporočilu (velja 7 dni).");
  obrazec("od", "/api/javno/novice/odjava", f => ({ email: pol(f, "email") }), () => "Če je bil e-naslov prijavljen, smo ga odjavili in izbrisali s seznama. Novic vam ne bomo več pošiljali.");
  // stran novice.html: potrditev prijave in odjava s povezavo iz e-pošte
  const qs = new URLSearchParams(location.search), stanje = $("novice-stanje");
  if (stanje && (qs.get("potrdi") || qs.get("odjava"))) {
    const potrdi = qs.get("potrdi"), t = potrdi || qs.get("odjava");
    history.replaceState(null, "", location.pathname + location.hash); // žeton ne ostane v zgodovini brskalnika
    stanje.hidden = false; sporocilo(stanje, potrdi ? "Potrjujem prijavo …" : "Odjavljam …");
    poslji(potrdi ? "/api/javno/novice/potrdi" : "/api/javno/novice/odjava", { t }).then(() => sporocilo(stanje, potrdi ? "Prijava na novice je potrjena. Hvala! Vsaka novica bo vsebovala povezavo za odjavo." : "Odjavljeni ste. Vaš e-naslov smo izbrisali s seznama prejemnikov novic.")).catch(er => sporocilo(stanje, er.message, true));
  }
})();
