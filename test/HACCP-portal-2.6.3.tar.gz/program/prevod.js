// Prevod obvestil RASFF (EU objavlja samo v angleščini) v slovenščino.
// 1) Slovar stalnih izrazov (nevarnosti, alergeni, kategorije izdelkov, tveganje, države): vedno, brez interneta in brez stroškov.
//    Naslov oblike »<nevarnost> in <izdelek> from <država>« se preuredi v »<nevarnost> v izdelku: <izdelek> (izvor: <država>)«,
//    da ni treba sklanjati; neznane besede ostanejo v angleščini.
// 2) DeepL (neobvezno): cel naslov in opis, če je v .env nastavljen DEEPL_KLJUC (brezplačni ključ se konča s »:fx«).
// Izvirnik v angleščini ostane shranjen ob obvestilu (merodajen je izvirnik).

const IZRAZI = {
  // vrste obvestil in tveganje
  "alert notification": "obvestilo o nevarnosti", "information notification for attention": "informativno obvestilo za pozornost",
  "information notification for follow-up": "informativno obvestilo za nadaljnje ukrepanje", "border rejection notification": "obvestilo o zavrnitvi na meji",
  "border rejection": "zavrnitev na meji", "non-compliance notification": "obvestilo o neskladnosti",
  "potentially serious": "potencialno resno", "not serious": "ni resno", "serious": "resno", "potential risk": "možno tveganje", "no risk": "ni tveganja", "undecided": "neodločeno",
  // kategorije izdelkov RASFF
  "cereals and bakery products": "žita in pekovski izdelki", "cocoa and cocoa preparations, coffee and tea": "kakav in kakavovi izdelki, kava in čaj",
  "confectionery": "slaščice", "dietetic foods, food supplements and fortified foods": "dietna živila, prehranska dopolnila in obogatena živila",
  "eggs and egg products": "jajca in jajčni izdelki", "fats and oils": "maščobe in olja", "fish and fish products": "ribe in ribji izdelki",
  "food additives and flavourings": "aditivi za živila in arome", "food contact materials": "materiali v stiku z živili", "fruits and vegetables": "sadje in zelenjava",
  "herbs and spices": "zelišča in začimbe", "honey and royal jelly": "med in matični mleček", "ice cream and desserts": "sladoled in sladice",
  "meat and meat products (other than poultry)": "meso in mesni izdelki (razen perutnine)", "meat and meat products": "meso in mesni izdelki",
  "milk and milk products": "mleko in mlečni izdelki", "non-alcoholic beverages": "brezalkoholne pijače", "alcoholic beverages": "alkoholne pijače",
  "nuts, nut products and seeds": "oreščki, izdelki iz oreščkov in semena", "poultry meat and poultry meat products": "perutninsko meso in izdelki iz perutninskega mesa",
  "prepared dishes and snacks": "pripravljene jedi in prigrizki", "soups, broths, sauces and condiments": "juhe, jušne osnove, omake in začimbne mešanice",
  "crustaceans and products thereof": "raki in izdelki iz rakov", "bivalve molluscs and products thereof": "školjke in izdelki iz školjk",
  "cephalopods and products thereof": "glavonožci in izdelki iz njih", "gastropods": "polži", "feed materials": "posamična krmila", "compound feeds": "krmne mešanice",
  "feed additives": "krmni dodatki", "pet food": "hrana za hišne živali", "natural mineral water": "naravna mineralna voda",
  "water for human consumption (other)": "voda za prehrano ljudi", "foods for infants and young children": "hrana za dojenčke in majhne otroke",
  "other food product / mixed": "drugi živilski izdelki", "plant protection products": "fitofarmacevtska sredstva",
  // nevarnosti
  "pesticide residues": "ostanki pesticidov", "pesticide residue": "ostanek pesticida", "residues of": "ostanki", "residue of": "ostanek",
  "aflatoxins": "aflatoksini", "aflatoxin": "aflatoksin", "ochratoxin a": "okratoksin A", "mycotoxins": "mikotoksini", "deoxynivalenol": "deoksinivalenol",
  "ethylene oxide": "etilen oksid", "2-chloroethanol": "2-kloroetanol", "polycyclic aromatic hydrocarbons": "policiklični aromatski ogljikovodiki",
  "benzo(a)pyrene": "benzo(a)piren", "dioxins": "dioksini", "tropane alkaloids": "tropanski alkaloidi", "pyrrolizidine alkaloids": "pirolizidinski alkaloidi",
  "hydrocyanic acid": "cianovodikova kislina", "sulphur dioxide": "žveplov dioksid", "sulfur dioxide": "žveplov dioksid", "formaldehyde": "formaldehid",
  "primary aromatic amines": "primarni aromatski amini", "melamine": "melamin", "histamine": "histamin", "cannabidiol": "kanabidiol",
  "inorganic arsenic": "anorganski arzen", "arsenic": "arzen", "lead": "svinec", "cadmium": "kadmij", "mercury": "živo srebro", "heavy metals": "težke kovine",
  "hepatitis a virus": "virus hepatitisa A", "shiga toxin-producing escherichia coli": "E. coli, ki tvori šigatoksin (STEC)", "sudan dye": "barvilo Sudan",
  "foreign bodies": "tujki", "foreign body": "tujek", "pieces of glass": "delci stekla", "pieces of metal": "delci kovine", "pieces of plastic": "delci plastike",
  "glass": "steklo", "metal": "kovina", "plastic": "plastika", "insects": "žuželke", "insect": "žuželka", "moulds": "plesni", "mould": "plesen", "molds": "plesni", "mold": "plesen",
  "unauthorised novel food": "nedovoljeno novo živilo", "unauthorized novel food": "nedovoljeno novo živilo", "novel food": "novo živilo",
  "unauthorised substance": "nedovoljena snov", "unauthorized substance": "nedovoljena snov", "unauthorised colour": "nedovoljeno barvilo", "unauthorised colours": "nedovoljena barvila",
  "unauthorised ingredient": "nedovoljena sestavina", "unauthorised": "nedovoljeno", "unauthorized": "nedovoljeno",
  "undeclared": "na oznaki ni navedeno:", "not declared": "na oznaki ni navedeno", "absence of labelling in the national language": "ni označbe v nacionalnem jeziku",
  "too high content of": "previsoka vsebnost", "high content of": "visoka vsebnost", "high level of": "visoka vsebnost", "excessive": "prekomerna vsebnost:",
  "presence of": "prisotnost", "migration of": "migracija", "poor temperature control": "neustrezen nadzor temperature", "temperature abuse": "neustrezna temperatura",
  "improper health certificate": "neustrezno zdravstveno spričevalo", "absence of health certificate": "brez zdravstvenega spričevala", "illegal import": "nezakonit uvoz",
  "spoilage": "kvarjenje", "rotten": "gnilo", "parasitic infestation": "okužba s paraziti", "parasites": "paraziti", "with": "z", "on": "na", "and": "in", "or": "ali", "via": "prek:",
  // alergeni
  "milk": "mleko", "gluten": "gluten", "wheat": "pšenica", "eggs": "jajca", "egg": "jajce", "peanuts": "arašidi", "peanut": "arašidi", "nuts": "oreščki",
  "hazelnuts": "lešniki", "hazelnut": "lešniki", "almonds": "mandlji", "almond": "mandlji", "walnuts": "orehi", "cashew nuts": "indijski oreščki", "cashews": "indijski oreščki",
  "pistachios": "pistacije", "pistachio": "pistacije", "soya": "soja", "soy": "soja", "soybeans": "soja", "mustard": "gorčica", "sesame seeds": "sezamova semena", "sesame": "sezam",
  "celery": "zelena", "sulphites": "sulfiti", "sulfites": "sulfiti", "sulphite": "sulfiti", "lupin": "volčji bob", "crustaceans": "raki", "molluscs": "mehkužci",
  // pogosti izdelki
  "frozen chicken meat": "zamrznjeno piščančje meso", "frozen poultry meat": "zamrznjeno perutninsko meso", "frozen meat": "zamrznjeno meso", "chicken meat": "piščančje meso", "poultry meat": "perutninsko meso", "frozen chicken": "zamrznjen piščanec", "turkey meat": "puranje meso", "turkey": "puran", "chicken": "piščanec", "poultry": "perutnina",
  "minced meat": "mleto meso", "pork": "svinjina", "beef": "govedina", "meat": "meso", "sausages": "klobase", "salami": "salama", "ham": "šunka",
  "cheese": "sir", "yoghurt": "jogurt", "yogurt": "jogurt", "butter": "maslo", "cream": "smetana",
  "frozen fish": "zamrznjene ribe", "fish": "ribe", "tuna": "tuna", "salmon": "losos", "mussels": "klapavice", "oysters": "ostrige", "clams": "školjke",
  "frozen shrimps": "zamrznjene kozice", "shrimps": "kozice", "shrimp": "kozice", "prawns": "kozice", "squid": "lignji", "octopus": "hobotnica",
  "rice": "riž", "flour": "moka", "bread": "kruh", "biscuits": "piškoti", "pasta": "testenine", "noodles": "rezanci", "chocolate": "čokolada", "sweets": "bonboni",
  "spices": "začimbe", "black pepper": "črni poper", "pepper": "poper", "chilli powder": "čili v prahu", "chilli": "čili", "chili": "čili", "cumin": "kumina",
  "turmeric": "kurkuma", "oregano": "origano", "herbs": "zelišča", "tea": "čaj", "coffee": "kava", "cocoa": "kakav", "honey": "med",
  "dried figs": "sušene fige", "figs": "fige", "raisins": "rozine", "dried apricots": "sušene marelice", "apricots": "marelice", "dates": "dateljni", "grapes": "grozdje",
  "oranges": "pomaranče", "lemons": "limone", "mandarins": "mandarine", "apples": "jabolka", "pears": "hruške", "strawberries": "jagode",
  "frozen raspberries": "zamrznjene maline", "raspberries": "maline", "blueberries": "borovnice", "berries": "jagodičje",
  "sweet peppers": "sladke paprike", "peppers": "paprike", "tomatoes": "paradižnik", "cucumbers": "kumare", "lettuce": "solata", "spinach": "špinača",
  "beans": "fižol", "lentils": "leča", "peas": "grah", "chickpeas": "čičerika", "maize": "koruza", "corn": "koruza", "sunflower seeds": "sončnična semena", "seeds": "semena",
  "food supplements": "prehranska dopolnila", "food supplement": "prehransko dopolnilo", "dietary supplement": "prehransko dopolnilo", "baby food": "otroška hrana",
  "infant formula": "začetna formula za dojenčke", "sauce": "omaka", "ice cream": "sladoled", "juice": "sok", "wine": "vino", "beer": "pivo", "water": "voda",
  "olive oil": "oljčno olje", "sunflower oil": "sončnično olje", "oil": "olje", "vegetables": "zelenjava", "fruit": "sadje", "mushrooms": "gobe",
  "dog food": "hrana za pse", "cat food": "hrana za mačke", "feed": "krma",
  // države
  "albania": "Albanija", "argentina": "Argentina", "australia": "Avstralija", "austria": "Avstrija", "azerbaijan": "Azerbajdžan", "armenia": "Armenija",
  "bangladesh": "Bangladeš", "belarus": "Belorusija", "belgium": "Belgija", "bolivia": "Bolivija", "bosnia and herzegovina": "Bosna in Hercegovina", "brazil": "Brazilija",
  "bulgaria": "Bolgarija", "cambodia": "Kambodža", "cameroon": "Kamerun", "canada": "Kanada", "chile": "Čile", "china": "Kitajska", "colombia": "Kolumbija",
  "côte d'ivoire": "Slonokoščena obala", "croatia": "Hrvaška", "cyprus": "Ciper", "czechia": "Češka", "czech republic": "Češka", "denmark": "Danska", "ecuador": "Ekvador",
  "egypt": "Egipt", "estonia": "Estonija", "ethiopia": "Etiopija", "finland": "Finska", "france": "Francija", "georgia": "Gruzija", "germany": "Nemčija", "ghana": "Gana",
  "greece": "Grčija", "hong kong": "Hongkong", "hungary": "Madžarska", "iceland": "Islandija", "india": "Indija", "indonesia": "Indonezija", "iran": "Iran",
  "ireland": "Irska", "israel": "Izrael", "italy": "Italija", "japan": "Japonska", "jordan": "Jordanija", "kazakhstan": "Kazahstan", "kenya": "Kenija", "kosovo": "Kosovo",
  "latvia": "Latvija", "lebanon": "Libanon", "lithuania": "Litva", "luxembourg": "Luksemburg", "madagascar": "Madagaskar", "malaysia": "Malezija", "malta": "Malta",
  "mauritania": "Mavretanija", "mexico": "Mehika", "moldova": "Moldavija", "montenegro": "Črna gora", "morocco": "Maroko", "mozambique": "Mozambik", "myanmar": "Mjanmar",
  "namibia": "Namibija", "nepal": "Nepal", "the netherlands": "Nizozemska", "netherlands": "Nizozemska", "new zealand": "Nova Zelandija", "nigeria": "Nigerija",
  "north macedonia": "Severna Makedonija", "norway": "Norveška", "pakistan": "Pakistan", "paraguay": "Paragvaj", "peru": "Peru", "philippines": "Filipini",
  "poland": "Poljska", "portugal": "Portugalska", "romania": "Romunija", "russia": "Rusija", "saudi arabia": "Savdska Arabija", "senegal": "Senegal", "serbia": "Srbija",
  "slovakia": "Slovaška", "slovenia": "Slovenija", "south africa": "Južna Afrika", "south korea": "Južna Koreja", "spain": "Španija", "sri lanka": "Šrilanka",
  "sudan": "Sudan", "sweden": "Švedska", "switzerland": "Švica", "syria": "Sirija", "taiwan": "Tajvan", "tanzania": "Tanzanija", "thailand": "Tajska", "tunisia": "Tunizija",
  "türkiye": "Turčija", "uganda": "Uganda", "ukraine": "Ukrajina", "united arab emirates": "Združeni arabski emirati", "united kingdom": "Združeno kraljestvo",
  "united states of america": "Združene države Amerike", "united states": "Združene države Amerike", "uruguay": "Urugvaj", "uzbekistan": "Uzbekistan",
  "venezuela": "Venezuela", "vietnam": "Vietnam", "viet nam": "Vietnam", "zimbabwe": "Zimbabve"
};
// en prehod, najdaljši izrazi najprej, cele besede (tudi s šumniki); prevedeno se ne prevaja znova
const ubez = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const RE = new RegExp("(?<![\\p{L}\\p{N}])(" + Object.keys(IZRAZI).sort((a, b) => b.length - a.length).map(ubez).join("|") + ")(?![\\p{L}\\p{N}])", "giu");
const veliko = s => s ? s[0].toUpperCase() + s.slice(1) : s;
function izrazi(t) { return String(t || "").replace(RE, m => IZRAZI[m.toLowerCase()]).replace(/:\s*:/g, ":").replace(/\s+/g, " ").trim(); }

// naslov obvestila RASFF: »X in Y from Z« → »X v izdelku: Y (izvor: Z)«
function slovarNaslov(s) {
  s = String(s || "").trim(); if (!s) return s;
  const m = /^(.+?)\s+in\s+(.+?)(?:\s+from\s+(.+))?$/i.exec(s);
  if (!m) return veliko(izrazi(s));
  return veliko(izrazi(m[1])) + " v izdelku: " + izrazi(m[2]) + (m[3] ? " (izvor: " + izrazi(m[3].replace(/\bturkey\b/gi, "Türkiye")) + ")" : "");
}

// DeepL: največ 50 besedil na zahtevo; vrne prevode v istem vrstnem redu
async function deepl(besedila) {
  const k = String(process.env.DEEPL_KLJUC || "").trim(); if (!k) return null;
  const url = process.env.HACCP_DEEPL_URL || (/:fx$/.test(k) ? "https://api-free.deepl.com/v2/translate" : "https://api.deepl.com/v2/translate"), out = [];
  for (let i = 0; i < besedila.length; i += 50) {
    const r = await fetch(url, { method: "POST", signal: AbortSignal.timeout(20000), headers: { Authorization: "DeepL-Auth-Key " + k, "Content-Type": "application/json" }, body: JSON.stringify({ text: besedila.slice(i, i + 50), source_lang: "EN", target_lang: "SL" }) });
    if (!r.ok) throw new Error("HTTP " + r.status + (r.status === 403 ? " – ključ DEEPL_KLJUC ni veljaven" : r.status === 456 ? " – mesečna količina prevodov je porabljena" : ""));
    const j = await r.json(); if (!j || !Array.isArray(j.translations)) throw new Error("nepričakovan odgovor");
    out.push(...j.translations.map(t => String(t.text || "")));
  }
  return out;
}

const nacin = () => String(process.env.DEEPL_KLJUC || "").trim() ? "deepl" : "slovar";

module.exports = { izrazi, slovarNaslov, deepl, nacin };
