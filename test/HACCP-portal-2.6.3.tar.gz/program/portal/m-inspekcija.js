// Način »inšpekcija«: pregled stanja dokumentacije za izbrano stranko in obdobje + izvoz (PDF, Word, Excel).
async function inspData(ctx, od, doo) {
  const d = await loadAll({ stranka_id: ctx.stranka_id });
  const inP = x => { const t = lokDan(x); return (!od || t >= od) && (!doo || t <= doo); };
  const ev = d.evidence.filter(e => inP(e.cas)), capa = d.capa;
  const exp = (s) => s && daysTo(s) < 0;
  const nav = d.navodila;
  const check = [];
  const add = (p, st, txt) => check.push({ p, st, txt });
  const OC = ocenaPodrocij(d); // ista ocena kot na strani Certifikacija
  add("Potrjen HACCP načrt", OCENA_INSP[OC.haccp.s], OC.haccp.txt);
  const nacrtZam = d.nacrti.filter(n => n.status !== "zastarelo" && exp(n.naslednji_pregled)).length; add("Pregled HACCP načrta", nacrtZam ? "warn" : "ok", nacrtZam ? nacrtZam + " načrt(ov) s pretečenim rokom pregleda" : "Roki pregleda niso pretečeni");
  const navPot = nav.filter(n => n.status === "potrjeno").length, navZam = nav.filter(n => n.status !== "zastarelo" && exp(n.naslednji_pregled)).length;
  add("Delovna navodila", nav.length ? (navPot === nav.length && !navZam ? "ok" : "warn") : "bad", `${navPot} potrjenih od ${nav.length}${navZam ? ", " + navZam + " s pretečenim pregledom" : ""}`);
  add("Zaposleni: izobraževanje, zdravniški pregled, usposabljanja", OCENA_INSP[OC.usposobljenost.s], OC.usposobljenost.txt);
  add("Oprema in merilni instrumenti", OCENA_INSP[OC.oprema.s], OC.oprema.txt);
  add("Dobavitelji", OCENA_INSP[OC.dobavitelji.s], OC.dobavitelji.txt);
  const odst = ev.filter(e => e.skladno === false).length, nepot = ev.filter(e => e.status !== "potrjeno").length, brez = ev.filter(e => e.skladno === null || e.skladno === undefined).length;
  add("Evidence v obdobju", ev.length ? (odst || nepot ? "warn" : "ok") : "bad", `${mnx(ev.length, ["zapis", "zapisa", "zapisi", "zapisov"])}, ${mnx(odst, ["odstopanje", "odstopanji", "odstopanja", "odstopanj"])}, ${nepot} nepotrjenih, ${brez} brez ocene`);
  const cis = ciscenjeStanje(d.ciscenje_nacrt || [], d.evidence), cisZ = cis.filter(x => x.zamuda).length;
  add("Čiščenje po načrtu", (d.ciscenje_nacrt || []).length ? (cisZ ? "warn" : "ok") : "warn", (d.ciscenje_nacrt || []).length ? `${mnx((d.ciscenje_nacrt || []).length, ["opravilo", "opravili", "opravila", "opravil"])} v načrtu${cisZ ? ", " + cisZ + " v zamudi" : ", brez zamud"}` : "Načrt čiščenja ni vnesen");
  const tst = ev.filter(e => e.vrsta === "bris" || e.vrsta === "hitri_test"), tstN = tst.filter(e => e.skladno === false).length, ddd = ev.filter(e => e.vrsta === "ddd_obisk").length;
  add("Brisi in hitri testi v obdobju", tst.length ? (tstN ? "warn" : "ok") : "warn", `${mnx(tst.length, ["rezultat", "rezultata", "rezultati", "rezultatov"])}, ${mnx(tstN, ["odstopanje", "odstopanji", "odstopanja", "odstopanj"])}`);
  add("DDD obiski v obdobju", ddd ? "ok" : "warn", `${mnx(ddd, ["obisk", "obiska", "obiski", "obiskov"])} izvajalca`);
  const capaOdp = capa.filter(c => c.status !== "zaprto"), capaZam = capaOdp.filter(c => exp(c.rok)).length;
  add("Neskladnosti (CAPA)", capaOdp.length ? (capaZam ? "bad" : "warn") : "ok", `${mnx(capaOdp.length, ["odprta", "odprti", "odprte", "odprtih"])}${capaZam ? ", od tega " + capaZam + " v zamudi" : ""}; zaprtih v obdobju: ${capa.filter(c => c.status === "zaprto" && inP(c.datum_zapiranja)).length}`);
  let tlorisi = []; try { tlorisi = await D.list("tlorisi", { stranka_id: ctx.stranka_id }); } catch {}
  return { d, ev, capa, check, od, doo, odst, tlorisi };
}
function inspDoc(doc, ctx, R) {
  const { d, ev, capa, check, od, doo } = R, s = ctx.stranka, obr = d.obrati;
  doc.h(1, "1. Podatki o podjetju in obratih");
  doc.table(["Podatek", "Vrednost"], [["Naziv", s.naziv], ["Naslov", s.naslov || ""], ["Matična / davčna št.", [s.maticna, s.davcna].filter(Boolean).join(" / ")], ["Odgovorna oseba", s.odgovorna_oseba || ""], ["Dejavnost", s.dejavnost || ""], ["Obrati", obr.map(o => o.naziv + (o.naslov ? " (" + o.naslov + ")" : "")).join("; ")], ["Obdobje izpisa", (od ? fdate(od) : "začetek") + " – " + (doo ? fdate(doo) : "danes")]].filter(r => r[1]), [30, 70]);
  doc.h(1, "2. Stanje dokumentacije (po podatkih v sistemu)");
  doc.table(["Področje", "Ocena", "Podrobnosti"], check.map(c => [c.p, c.st === "ok" ? "v redu" : c.st === "warn" ? "preveri" : "manjka / zamuda", c.txt]), [34, 16, 50]);
  doc.p("Izpis prikazuje stanje, kot je vneseno v sistemu. Ne pomeni ocene skladnosti z zakonodajo.", { size: 8.5, col: "m" });
  doc.h(1, "3. HACCP načrti");
  doc.table(["Načrt", "Različica", "Stanje", "Strokovno potrdil", "Datum potrditve", "Naslednji pregled"], d.nacrti.map(n => [n.naziv, n.verzija_oznaka, n.status, potrditevNacrta(n).potrdil, fdate(potrditevNacrta(n).datum), n.naslednji_pregled ? fdate(n.naslednji_pregled) : ""]), [26, 10, 14, 20, 15, 15]);
  doc.h(1, "4. Delovna navodila in predpogojni programi");
  doc.table(["Navodilo", "Vrsta", "Različica", "Stanje", "Naslednji pregled"], d.navodila.map(n => [n.naslov, n.vrsta, n.verzija_oznaka, n.status, n.naslednji_pregled ? fdate(n.naslednji_pregled) : ""]), [40, 20, 10, 14, 16]);
  doc.h(1, "5. Zaposleni in usposabljanja");
  doc.table(["Zaposleni", "Vloga", "Izobraževanje do", "Zdravniški pregled do"], d.osebje.map(o => [o.ime, o.funkcija, o.higienski_do ? fdate(o.higienski_do) : "", o.zdravniski_do ? fdate(o.zdravniski_do) : ""]), [30, 25, 22, 23]);
  doc.table(["Usposabljanje", "Datum", "Veljavno do", "Izvajalec"], d.usposabljanja.map(u => [u.tema, u.datum ? fdate(u.datum) : "", u.veljavno_do ? fdate(u.veljavno_do) : "", u.izvajalec]), [40, 18, 18, 24]);
  doc.h(1, "6. Oprema in merilni instrumenti");
  doc.table(["Naprava", "Vrsta", "Dovoljeni razpon", "Naslednji servis / umerjanje"], d.oprema.map(o => [o.naziv, o.tip, (o.meja_min !== undefined && o.meja_min !== "") || (o.meja_max !== undefined && o.meja_max !== "") ? (o.meja_min ?? "") + " do " + (o.meja_max ?? "") : "ni določen", o.naslednji_servis ? fdate(o.naslednji_servis) : ""]), [30, 20, 22, 28]);
  doc.h(1, "7. Dobavitelji");
  doc.table(["Dobavitelj", "Kategorija", "Ocena", "Naslednja ocena"], d.dobavitelji.map(o => [o.naziv, o.kategorija, o.ocena, o.naslednja_ocena ? fdate(o.naslednja_ocena) : ""]), [34, 22, 22, 22]);
  doc.h(1, "8. Evidence v obdobju");
  const byV = {}; for (const e of ev) { const k = (EV[e.vrsta] || {}).ime || e.vrsta; const r = byV[k] = byV[k] || { n: 0, o: 0, p: 0 }; r.n++; if (e.skladno === false) r.o++; if (e.status === "potrjeno") r.p++; }
  doc.table(["Vrsta evidence", "Zapisov", "Odstopanj", "Potrjenih"], Object.entries(byV).map(([k, r]) => [k, r.n, r.o, r.p]), [46, 18, 18, 18]);
  const od2 = ev.filter(e => e.skladno === false).sort((a, b) => (a.cas || "").localeCompare(b.cas || ""));
  if (od2.length) { doc.h(2, "Zabeležena odstopanja"); doc.table(["Čas", "Vrsta", "Podatek", "Vnesel", "Stanje", "Ver."], od2.map(e => [fdt(e.cas), (EV[e.vrsta] || {}).ime || e.vrsta, evSummary(e).replace(/&[a-z#0-9]+;/g, ""), e.ustvaril_ime || "", e.status, e.verzija || 1]), [18, 22, 26, 16, 12, 6]); }
  doc.h(1, "9. Neskladnosti in korektivni ukrepi (CAPA)");
  doc.table(["Čas", "Opis", "Tveganje", "Odgovoren", "Rok", "Stanje", "Zaprto"], capa.sort((a, b) => (a.cas || "").localeCompare(b.cas || "")).map(c => [fdt(c.cas), c.opis, c.tveganje, c.odgovoren, c.rok ? fdate(c.rok) : "", c.status, c.datum_zapiranja ? fdate(c.datum_zapiranja) : ""]), [14, 30, 9, 14, 11, 11, 11]);
  if (R.tl && R.tl.length) { doc.h(1, "10. Tloris obrata"); R.tl.forEach((im, k) => doc.img(im, 480, 340, R.tlNames[k])); }
}

// paket za inšpekcijo: pregled stanja (poglavja 1–10) in priloge v enem PDF – veljavni HACCP načrti v celoti, vse evidence obdobja po vrstah
// in fotografije odstopanj ter ukrepov CAPA
async function paketInspekcija(ctx, R, meta) {
  const db = await baza(), nacrti = R.d.nacrti.filter(n => n.status !== "zastarelo").sort((a, b) => (a.status === "potrjeno" ? 0 : 1) - (b.status === "potrjeno" ? 0 : 1));
  const obd = (R.od ? fdate(R.od) : "začetek") + " – " + (R.doo ? fdate(R.doo) : "danes");
  // fotografije odstopanj (evidence obdobja) in ukrepov CAPA, največ 40
  const fotke = [];
  for (const [r, opis] of [...R.ev.filter(e => e.skladno === false).map(e => [e, fdt(e.cas) + " – " + ((EV[e.vrsta] || {}).ime || e.vrsta) + ": " + String(evSummary(e)).replace(/<[^>]+>|&[a-z#0-9]+;/g, "")]), ...R.capa.map(c => [c, "CAPA " + fdt(c.cas || c.ustvarjeno) + ": " + String(c.opis || "").slice(0, 80)])])
    for (const id of r.slike || []) { if (fotke.length >= 40) break; const im = await loadImg("/api/priloga/" + id, 1000); if (im) fotke.push({ im, cap: opis }); }
  return pdfBuild(Object.assign(meta, { naslov: "Paket za inšpekcijo: " + ctx.stranka.naziv }), d => {
    d.box(`Vsebina paketa: pregled stanja dokumentacije, ${nacrti.length ? mnx(nacrti.length, ["veljaven HACCP načrt", "veljavna HACCP načrta", "veljavni HACCP načrti", "veljavnih HACCP načrtov"]) + " v celoti" : "HACCP načrta ni"}, ${mnx(R.ev.length, ["zapis", "zapisa", "zapisi", "zapisov"])} evidenc v obdobju ${obd}, usposabljanja ter odstopanja in korektivni ukrepi.`, "i");
    inspDoc(d, ctx, R);
    let L = 0; const crka = () => String.fromCharCode(65 + L++);
    for (const n of nacrti) {
      const c = crka(); d.newPage(); d.h(1, `Priloga ${c}: HACCP načrt – ${n.naziv}`);
      d.p(`Stanje: ${n.status || "osnutek"} · različica ${n.verzija_oznaka || "1.0"}`, { col: "m" });
      buildHaccpPdf(n, vsebinaNacrta(n), ctx.stranka, R.d.obrati, R.d.navodila, db, [], "fill", { predpona: c + "." })(d);
    }
    const c = crka(); d.newPage(); d.h(1, `Priloga ${c}: Evidence v obdobju ${obd}`);
    if (!R.ev.length) d.p("V izbranem obdobju ni zapisov.");
    const po = {}; for (const e of R.ev.slice().sort((a, b) => (a.cas || "").localeCompare(b.cas || ""))) (po[e.vrsta] = po[e.vrsta] || []).push(e);
    for (const [v, a] of Object.entries(po).sort((x, y) => ((EV[x[0]] || {}).ime || x[0]).localeCompare((EV[y[0]] || {}).ime || y[0], "sl"))) {
      d.h(2, `${(EV[v] || {}).ime || v} (${a.length})`);
      d.table(["Čas", "Podatek", "Ocena", "Vnesel", "Stanje", "Opomba"], evRowsForExport(a).map(r => [r[0], r[2], r[3], r[4], r[5], r[7]]), [16, 26, 12, 16, 12, 18]);
    }
    if (fotke.length) { const c2 = crka(); d.newPage(); d.h(1, `Priloga ${c2}: Fotografije odstopanj in korektivnih ukrepov`); fotke.forEach(f => d.img(f.im, 360, 260, f.cap)); }
  });
}
// poročilo po obisku svetovalca: stanje dokumentacije, odstopanja in odprte neskladnosti v obdobju, ugotovitve in priporočila, podpisa
async function porociloObiska(ctx, R, o) {
  await naloziIzdelovalca(ctx.stranka_id);
  const iz = izdelovalecZa(ctx.stranka_id), od = odobrilZa(ctx.stranka_id, ctx.stranka), opis = z => [z.izobrazba, z.funkcija].filter(Boolean).join(", ");
  const odst = R.ev.filter(e => e.skladno === false), odp = R.capa.filter(c => c.status !== "zaprto");
  return pdfBuild({ naslov: "Poročilo o obisku svetovalca", podnaslov: sIme(ctx.stranka) + " – obisk " + fdate(o.datum), stranka: ctx.stranka.naziv, verzija: "1.0", datum: o.datum, stanje: "poročilo svetovalca", izdelal: izdelovalecVrstice(iz), izdelalNoga: izdelovalecNoga(iz), izdelalLogo: izdelovalecLogoZa(ctx.stranka_id),
    podpisi: [{ vloga: "Izdelal (svetovalec)", ime: imeZNazivom(iz), opis: opis(iz), datum: o.datum }, { vloga: "Prejel (odgovorna oseba)", ime: imeZNazivom(od), opis: opis(od), datum: "" }] }, d => {
    d.h(1, "1. Podatki o obisku");
    d.table(["Podatek", "Vrednost"], [["Podjetje", ctx.stranka.naziv], ["Datum obiska", fdate(o.datum)], ["Pregledano obdobje evidenc", fdate(R.od) + " – " + fdate(R.doo)], ["Svetovalec", [imeZNazivom(iz), iz.podjetje].filter(Boolean).join(", ")], ["Prisotni", o.prisotni || "–"]], [35, 65]);
    d.h(1, "2. Stanje dokumentacije");
    d.table(["Področje", "Ocena", "Podrobnosti"], R.check.map(c => [c.p, c.st === "ok" ? "v redu" : c.st === "warn" ? "preveri" : "manjka / zamuda", c.txt]), [34, 16, 50]);
    d.h(1, "3. Odstopanja v obdobju");
    if (odst.length) d.table(["Čas", "Vrsta", "Podatek"], evRowsForExport(odst).slice(0, 40).map(r => [r[0], r[1], r[2]]), [20, 25, 55]); else d.p("V obdobju ni zabeleženih odstopanj.");
    if (odst.length > 40) d.p("Navedenih je 40 od " + odst.length + " odstopanj; vsa so v zavihku Evidence.", { col: "m" });
    d.h(1, "4. Odprte neskladnosti (CAPA)");
    if (odp.length) d.table(["Opis", "Odgovoren", "Rok", "Stanje"], odp.map(c => [c.opis || "", c.odgovoren || "", c.rok ? fdate(c.rok) : "", c.status || ""]), [50, 20, 15, 15]); else d.p("Ni odprtih neskladnosti.");
    d.h(1, "5. Ugotovitve in priporočila");
    const L = String(o.ugotovitve || "").split("\n").map(x => x.replace(/^[-•]\s*/, "").trim()).filter(Boolean); if (L.length) d.bullets(L); else d.p("Brez dodatnih ugotovitev.");
    d.h(1, "6. Naslednji obisk"); d.p(o.naslednji ? "Predvideni naslednji obisk: " + fdate(o.naslednji) + "." : "Naslednji obisk bo dogovorjen naknadno.");
  });
}
async function tabInspekcija(el, ctx) {
  const dnes = today(), od0 = addDays(dnes, -90);
  el.innerHTML = `<p class="note info">Pregled stanja dokumentacije za inšpektorja ali presojevalca: ena stran s kontrolnim seznamom in izpis vseh dokazil za izbrano obdobje. Prikazuje samo podatke, ki so vneseni v sistem.</p>
  <div class="row"><label class="mut">Evidence od <input type="date" id="i_od" value="${od0}" style="width:auto"></label><label class="mut">do <input type="date" id="i_do" value="${dnes}" style="width:auto"></label><span class="sp"></span>${hasRole(ME.u, "admin", "svetovalec") ? '<button class="btn ghost sec" id="i_obisk" disabled title="Poročilo svetovalca po obisku: stanje, odstopanja, ugotovitve in priporočila">Poročilo po obisku …</button>' : ""}<button class="btn" id="i_pak" title="Pregled stanja, HACCP načrti v celoti, vse evidence obdobja, usposabljanja in odstopanja v enem PDF">Paket za inšpekcijo (PDF)</button> <button class="btn ghost sec" id="i_pdf">PDF</button><button class="btn ghost" id="i_doc">Word</button><button class="btn ghost sec" id="i_xl">Excel</button></div><div id="i_body"><p class="mut">Nalaganje …</p></div>`;
  let R;
  const load = async () => {
    R = await inspData(ctx, $("#i_od").value, $("#i_do").value);
    $("#i_body").innerHTML = `<div class="tw"><table class="t"><tr><th>Področje</th><th>Ocena</th><th>Podrobnosti</th></tr>${R.check.map(c => `<tr><td><b>${esc(c.p)}</b></td><td><span class="badge ${c.st === "ok" ? "ok" : c.st === "warn" ? "warn" : "bad"}">${c.st === "ok" ? "v redu" : c.st === "warn" ? "preveri" : "manjka / zamuda"}</span></td><td>${esc(c.txt)}</td></tr>`).join("")}</table></div>`;
  };
  await load(); $("#i_od").onchange = $("#i_do").onchange = load;
  if ($("#i_obisk")) $("#i_obisk").disabled = false; // poročilo potrebuje naložene podatke
  const meta = () => ({ naslov: "Pregled za inšpekcijo: " + ctx.stranka.naziv, podnaslov: "Obdobje evidenc: " + fdate($("#i_od").value) + " – " + fdate($("#i_do").value), stranka: ctx.stranka.naziv, avtor: ME.u.ime, stanje: "izpis iz sistema na dan " + fdate(today()) });
  const withTl = async () => { if (!R.tl) { R.tl = []; R.tlNames = []; for (const t of R.tlorisi) { const im = await tlorisToImg(t); if (im) { R.tl.push(im); R.tlNames.push("Tloris: " + t.naziv); } } } };
  $("#i_pak").onclick = async () => { const b = $("#i_pak"); b.disabled = true; try { await withTl(); dlBlob(await paketInspekcija(ctx, R, meta()), "paket-inspekcija-" + ctx.stranka.naziv + ".pdf"); } catch (e) { fail(e); } b.disabled = false; };
  if ($("#i_obisk")) $("#i_obisk").onclick = () => modal("Poročilo po obisku", `<p class="mut">Poročilo zajame stanje dokumentacije, odstopanja in odprte neskladnosti v izbranem obdobju (${esc(fdate($("#i_od").value))} – ${esc(fdate($("#i_do").value))}).</p>
    <label class="f"><span>Datum obiska</span><input type="date" id="po_d" value="${today()}"></label><label class="f"><span>Prisotni (stranka)</span><input id="po_p" maxlength="200" placeholder="npr. Ana Kos, odgovorna oseba"></label>
    <label class="f"><span>Ugotovitve in priporočila (vsaka v svoji vrstici)</span><textarea id="po_u" rows="6" maxlength="5000"></textarea></label><label class="f"><span>Naslednji obisk (neobvezno)</span><input type="date" id="po_n"></label>
    <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="po_s" checked style="width:auto"> Zabeleži obisk med opravljene storitve (in naslednji obisk v koledar)</label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Ustvari PDF", fn: async () => {
      const o = { datum: $("#po_d").value || today(), prisotni: $("#po_p").value.trim(), ugotovitve: $("#po_u").value, naslednji: $("#po_n").value };
      try { dlBlob(await porociloObiska(ctx, R, o), "porocilo-obisk-" + ctx.stranka.naziv + "-" + o.datum + ".pdf");
        if ($("#po_s").checked) { await D.add("storitve", { stranka_id: ctx.stranka_id, datum: o.datum, vrsta: "Obisk na lokaciji", opis: ["Poročilo po obisku." + (o.prisotni ? " Prisotni: " + o.prisotni + "." : ""), o.ugotovitve.trim()].filter(Boolean).join("\n"), naslednji_pregled: o.naslednji || "" });
          if (o.naslednji) await D.add("dogodki", { stranka_id: ctx.stranka_id, naslov: "Obisk svetovalca", datum: o.naslednji, ura: "09:00" }).catch(() => {}); toast("Poročilo ustvarjeno, obisk zabeležen med storitve."); }
      } catch (e) { fail(e); return false; } } }]);
  $("#i_pdf").onclick = async () => { await withTl(); dlBlob(pdfBuild(meta(), d => inspDoc(d, ctx, R)), "inspekcija-" + ctx.stranka.naziv + ".pdf"); };
  $("#i_doc").onclick = async () => { await withTl(); dlBlob(docxBuild(meta(), d => inspDoc(d, ctx, R)), "inspekcija-" + ctx.stranka.naziv + ".docx"); };
  $("#i_xl").onclick = () => { const { d } = R; downloadXlsx("inspekcija-" + ctx.stranka.naziv + ".xlsx", [
    { ime: "Kontrolni seznam", glava: ["Področje", "Ocena", "Podrobnosti"], vrste: R.check.map(c => [c.p, c.st === "ok" ? "v redu" : c.st === "warn" ? "preveri" : "manjka / zamuda", c.txt]) },
    { ime: "Evidence", glava: ["Čas", "Vrsta", "Podatek", "Ocena", "Vnesel", "Stanje", "Ver."], vrste: evRowsForExport(R.ev).map(r => r.slice(0, 7)) },
    { ime: "CAPA", glava: ["Čas", "Opis", "Tveganje", "Odgovoren", "Rok", "Stanje", "Zaprto"], vrste: R.capa.map(c => [fdt(c.cas), c.opis, c.tveganje, c.odgovoren, c.rok, c.status, c.datum_zapiranja]) },
    { ime: "Načrti in navodila", glava: ["Vrsta", "Naziv", "Različica", "Stanje", "Naslednji pregled"], vrste: [...d.nacrti.map(n => ["HACCP načrt", n.naziv, n.verzija_oznaka, n.status, n.naslednji_pregled]), ...d.navodila.map(n => ["Navodilo", n.naslov, n.verzija_oznaka, n.status, n.naslednji_pregled])] }]); };
}