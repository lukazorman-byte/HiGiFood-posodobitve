// SEO javne strani: naslov, opis, ključne besede po straneh (nastavi administrator), kanonični naslov, Open Graph, JSON-LD,
// sitemap.xml, robots.txt (stran odprta, platforma in predogled zaprta), metapodatki članka, načrtovana objava; poenostavljen meni.
const http = require("http");
const B = process.env.BASE; const { chromium } = require("./pw.js"), port = new URL(B).port;
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
// zahteva na domeno spletne strani (HACCP_SPLETNA_STRAN=higifood.localhost)
const S = p => new Promise((res, rej) => http.get({ host: "127.0.0.1", port, path: p, headers: { Host: "higifood.localhost:" + port } }, r => { let b = ""; r.setEncoding("utf8"); r.on("data", c => b += c); r.on("end", () => res({ s: r.statusCode, t: b, h: r.headers })); }).on("error", rej));
const jl = t => [...t.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)].map(m => JSON.parse(m[1]));
(async () => {
  const req = async (m, p, b, ck) => { const r = await fetch(B + p, { method: m, headers: Object.assign({ "Content-Type": "application/json", Origin: B }, ck ? { Cookie: ck } : {}), body: b ? JSON.stringify(b) : undefined }); const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch {} return { s: r.status, j, t, h: r.headers, ck: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  await req("POST", "/api/auth/nastavi", { email: "a@t.si", ime: "Luka Zorman", geslo: "dolgogeslo123" }); const A = (await req("POST", "/api/auth/prijava", { email: "a@t.si", geslo: "dolgogeslo123" })).ck;
  // vstopna stran na domeni strani
  let r = await S("/"); const H = "http://higifood.localhost:" + port + "/";
  ok(r.s === 200 && /<title>HACCP brez papirja – elektronske evidence in HACCP načrt \| HiGiFood<\/title>/.test(r.t) && (r.t.match(/<title>/g) || []).length === 1 && /<meta name="keywords" content="HACCP, HACCP načrt/.test(r.t), "vstopna stran: naslov in ključne besede (en sam <title>)");
  ok(r.t.includes(`<link rel="canonical" href="${H}">`) && /<meta name="robots" content="index, follow/.test(r.t) && /og:locale" content="sl_SI"/.test(r.t) && /twitter:card/.test(r.t), "kanonični naslov, robots index, Open Graph, Twitter");
  const g = jl(r.t)[0]; ok(g && g["@graph"].some(x => x["@type"] === "Organization" && x.logo === H + "logo-svetlo.png") && g["@graph"].some(x => x["@type"] === "WebSite"), "JSON-LD: organizacija in spletno mesto");
  // nastavitve administratorja
  ok((await req("PUT", "/api/seo-admin", { strani: { "index.html": { naslov: "HACCP program za gostinstvo | HiGiFood", opis: "Nov opis strani.", kljucne: "HACCP, gostinstvo" } } }, A)).s === 200, "administrator shrani SEO strani");
  r = await S("/"); ok(/<title>HACCP program za gostinstvo \| HiGiFood<\/title>/.test(r.t) && /content="Nov opis strani."/.test(r.t) && /content="HACCP, gostinstvo"/.test(r.t), "nastavitve se uporabijo na strani");
  r = await S("/novice.html"); ok(/<meta name="robots" content="noindex, nofollow">/.test(r.t) && !/rel="canonical"/.test(r.t), "stran za odjavo ni za iskalnike");
  // robots.txt in sitemap
  r = await S("/robots.txt"); ok(/Allow: \//.test(r.t) && /Disallow: \/api\//.test(r.t) && r.t.includes("Sitemap: " + H + "sitemap.xml"), "robots.txt spletne strani");
  ok(/Disallow: \/\n/.test((await req("GET", "/robots.txt")).t), "robots.txt platforme: zaprto");
  const pr = await req("GET", "/stran/"); ok(/noindex/.test(pr.h.get("x-robots-tag") || "") && /<meta name="robots" content="noindex, nofollow">/.test(pr.t), "predogled /stran/ zaprt za iskalnike");
  // članek: metapodatki, objava, načrtovana objava
  const c = (await req("POST", "/api/blog-urednik", { naslov: "Hlajenje kuhane hrane", povzetek: "Pravilo 2 + 4 ure.", besedilo: "Besedilo.", seo_naslov: "Hlajenje hrane: pravilo 2 + 4 ure", seo_opis: "Kako hitro ohladiti kuhano hrano in zapisati evidenco.", kljucne_besede: "hlajenje hrane, HACCP,  kritična kontrolna točka,," }, A)).j;
  ok(c.kljucne_besede === "hlajenje hrane, HACCP, kritična kontrolna točka", "ključne besede očiščene");
  const jutri = new Date(Date.now() + 864e5).toISOString();
  await req("PUT", "/api/blog-urednik/" + c.id, { stanje: "objavljen", objava: jutri }, A);
  ok((await S("/blog/" + c.slug)).s === 404 && !(await S("/sitemap.xml")).t.includes(c.slug) && (await req("POST", "/api/blog-urednik/" + c.id + "/novice", null, A)).s === 400, "načrtovan članek še ni javen, ni v sitemap, ne pošlje se");
  await req("PUT", "/api/blog-urednik/" + c.id, { objava: new Date(Date.now() - 6e4).toISOString() }, A);
  r = await S("/blog/" + c.slug);
  ok(r.s === 200 && /<title>Hlajenje hrane: pravilo 2 \+ 4 ure<\/title>/.test(r.t) && /<meta name="description" content="Kako hitro ohladiti kuhano hrano in zapisati evidenco.">/.test(r.t) && /<meta name="keywords" content="hlajenje hrane, HACCP, kritična kontrolna točka">/.test(r.t) && /og:type" content="article"/.test(r.t) && /article:tag" content="HACCP"/.test(r.t) && r.t.includes(`<link rel="canonical" href="${H}blog/${c.slug}">`), "članek: SEO naslov, opis, ključne besede, kanonični naslov");
  const a = jl(r.t); ok(a.some(x => x["@type"] === "BlogPosting" && x.headline === "Hlajenje kuhane hrane" && x.author.name === "Luka Zorman" && x.keywords) && a.some(x => x["@type"] === "BreadcrumbList" && x.itemListElement.length === 3), "članek: JSON-LD BlogPosting in drobtine");
  ok((await S("/sitemap.xml")).t.includes(`<loc>${H}blog/${c.slug}</loc><lastmod>`), "objavljen članek v sitemap z datumom");
  ok(/noindex/.test((await req("GET", "/stran/blog/" + c.slug)).t.match(/<meta name="robots"[^>]*>/)[0]), "predogled članka zaprt za iskalnike");
  // meni in urednik (brskalnik)
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  const meni = await pg.$$eval("nav a[data-id]", a => a.map(x => x.dataset.id));
  ok(meni.includes("spletna-stran") && !meni.includes("blog") && !meni.includes("moji-podatki"), "meni: en vnos »Spletna stran«, brez »Blog« in »Moji podatki« " + meni.join(","));
  await pg.click("#mojracun, [data-akc=mojRacun], .uime, #me").catch(() => {});
  await pg.evaluate(() => mojRacun()); await pg.waitForSelector("dialog[open]"); ok(/Moji podatki/.test(await pg.textContent("dialog[open]")), "Moj račun: gumb Moji podatki"); await pg.evaluate(() => document.querySelector("dialog[open]").close());
  await pg.goto(B + "/#/spletna-stran/seo"); await pg.waitForSelector(".seo-st"); ok((await pg.$$(".seo-st")).length === 5 && (await pg.$$(".ss-tabs a")).length === 3, "SEO: 5 strani in zavihki");
  ok(/HACCP program za gostinstvo/.test(await pg.textContent(".seo-st .serp-n")), "SEO: predogled zadetka v Googlu");
  await pg.goto(B + "/#/blog/" + c.id); await pg.waitForSelector("#bl_seo_naslov"); ok(/33\/60/.test(await pg.textContent("#sn_n")), "urednik: števec znakov naslova za Google");
  await pg.setViewportSize({ width: 390, height: 844 }); await pg.waitForTimeout(200);
  ok(await pg.isVisible(".bl-preklop") && await pg.isVisible(".bl-ed") && !(await pg.isVisible(".bl-pv")), "telefon: urejanje brez predogleda");
  await pg.click("[data-pog=pv]"); ok(await pg.isVisible(".bl-pv") && !(await pg.isVisible(".bl-ed")), "telefon: preklop na predogled");
  ok(!errs.length, "brez napak JavaScript " + errs.join("; "));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
