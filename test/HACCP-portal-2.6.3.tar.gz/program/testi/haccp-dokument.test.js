// HACCP dokument (seznam posodobitev, november 2026): osnutek brez lažne potrditve, vsak protokol enkrat (prilagojen ima prednost),
// besedilo za izpolnjevalca ni končno, preverjanje pred izpisom (dokument ostane OSNUTEK), kazalo samo poglavja, priloga z Uredbo 2017/2158 pri cvrtju.
// Primer je podoben kavarni (kuhinja, slaščičarna, točilni pult, cvrtje, sladoled); drugi primer je mesnica (drug tip obrata).
const B = process.env.BASE, OUT = process.env.OUT; const { chromium } = require("./pw.js"), cp = require("child_process"), fs = require("fs"), path = require("path");
let fails = 0; const ok = (c, m) => { if (!c) { fails++; console.log("NAPAKA:", m); } else console.log("ok:", m); };
(async () => {
  const br = await chromium.launch(), errs = []; const pg = await (await br.newContext()).newPage(); pg.on("pageerror", e => errs.push(String(e.stack || e)));
  await pg.goto(B + "/"); await pg.fill("#le", "a@t.si"); await pg.fill("#ln", "Luka Zorman"); await pg.fill("#lp", "dolgogeslo123"); await pg.click("#lf button"); await pg.waitForSelector("#shell:not([hidden])");
  fs.mkdirSync(OUT, { recursive: true });
  const izdelaj = (ime, nastavi) => pg.evaluate(async ({ ime, nastavi }) => {
    const db = await baza(), sid = (await D.add("stranke", { naziv: ime + " d.o.o.", dejavnost: "Gostinstvo", dodatne_dejavnosti: ["Gostinstvo"] })).id;
    const ob = await D.add("obrati", { stranka_id: sid, naziv: ime, vrsta: nastavi.vrsta, ciscenje: "Po načrtu čiščenja.", voda: "Javni vodovod.", opis_prostorov: "Kuhinja, točilni pult, slaščičarna." });
    const pred = id => db.navodila_predloge.find(p => p.id === id);
    for (const id of ["ciscenje", "voda", "hlajenje", "odpoklic"]) { const p = pred(id); await D.add("navodila", { stranka_id: sid, naslov: p.naslov, vrsta: p.vrsta, verzija_oznaka: "1.0", status: "osnutek", predloga: p.id, tema: p.id, predloga_verzija: p.verzija, vsebina: navodiloBesedilo(p, { naziv: ime + " d.o.o." }, db) }); }
    // prilagojen protokol čiščenja ima prednost pred splošno predlogo
    await D.add("navodila", { stranka_id: sid, naslov: "Čiščenje v " + ime, vrsta: "Delovno navodilo", verzija_oznaka: "1.0", status: "osnutek", tema: "ciscenje", vsebina: "Čiščenje v " + ime + "\n1. NAMEN\nČista oprema in površine v kavarni preprečujejo kontaminacijo živil.\n\n4. POSTOPEK\n- KT2: Pult po vsaki izmeni (KT3).\n- Aparat za kavo dnevno." });
    const k = nastavi.koraki.map((n, i) => ({ id: "k" + i, naziv: n }));
    k.forEach((x, i) => { if (nastavi.veje && nastavi.veje[i]) x.veja = nastavi.veje[i]; });
    const W = { branza: "jedi", zbiranje: Object.assign({ kupci: "odrasli in otroci", delovni_cas: "7–22", obseg: "vsi procesi" }, nastavi.zbiranje || {}), koraki: k, zivila: nastavi.zivila, nevarnosti: nastavi.nevarnosti, kontrole: nastavi.kontrole, metoda: {}, pregled: {}, besedila: {} };
    const n = await D.add("nacrti", { stranka_id: sid, obrat_id: ob.id, naziv: "HACCP " + ime, verzija_oznaka: "1.0", status: "osnutek", potrdil: "Luka Zorman", datum_potrditve: "2026-11-09", vsebina: W });
    for (const r of ["Posodobitev vsebine v čarovniku", "Samodejno shranjevanje ob menjavi koraka", "Dopolnjena analiza nevarnosti"]) await D.set("nacrti", n.id, { opomba: r + Math.random(), _razlog: r });
    const rec = (await D.list("nacrti", { stranka_id: sid })).find(x => x.id === n.id), stranka = (await D.list("stranke")).find(x => x.id === sid);
    const blob = buildHaccpPdf(rec, vsebinaNacrta(rec), stranka, [ob], await D.list("navodila", { stranka_id: sid }), db, [], undefined, {});
    const u = new Uint8Array(await blob.arrayBuffer()); let s = ""; for (const c of u) s += String.fromCharCode(c); return btoa(s);
  }, { ime, nastavi });
  const besedilo = (ime, b64) => { const f = path.join(OUT, ime + ".pdf"); fs.writeFileSync(f, Buffer.from(b64, "base64")); const t = cp.spawnSync("pdftotext", ["-layout", f, "-"], { encoding: "utf8" }); return { t: t.stdout || "", strani: (t.stdout.match(/\f/g) || []).length }; };
  const H = (id, k, n, tip, v, t, extra) => Object.assign({ id, korak_id: k, nevarnost: n, tip, verjetnost: v, teza: t, potrjeno: true }, extra || {});
  const kavarna = {
    vrsta: "Kavarna", zbiranje: { nacin_prodaje: ["lokal", "dostava"], clani: [{ ime: "Ana Kos", vloga: "vodja HACCP skupine" }], kultura_zaveza: "Vodstvo zagotavlja vire." }, veje: ["", "", "kuhinja", "kuhinja", "kuhinja", "slaščičarna", "točilni pult", ""], koraki: ["Prevzem surovin", "Skladiščenje (hladno)", "Priprava v kuhinji", "Cvrtje", "Hlajenje kuhanih jedi", "Priprava sladoleda", "Točilni pult in pijače", "Serviranje"],
    zivila: [{ naziv: "Tiramisu", skupina: "slaščice", alergeni: "jajca, mleko, gluten (preveriti)", rte: true, priprava: "s surovimi jajci" }, { naziv: "Pomfrit", alergeni: "ni alergenov" }],
    nevarnosti: [H("h1", "k0", "Patogeni zaradi prekinjene hladne verige", "B", 2, 4), H("h2", "k3", "Akrilamid pri cvrtju", "K", 3, 3), H("h3", "k4", "Rast sporogenih bakterij pri hlajenju", "B", 3, 4), H("h4", "k6", "Tujki", "F", 1, 2), H("h5", "k2", "Navzkrižna kontaminacija z alergeni v skupnem olju", "K", 2, 3)],
    kontrole: { h2: { hid: "h2", vrsta: "OPRP", kaj: "temperatura olja v friteuzi", mejna: "180 °C", spremljanje: "termometer", pogostost: "vsako cvrtje", odgovoren: "kuhar", korektivni: "znižaj temperaturo", drevo: ["d", "d", "", ""] }, h3: { hid: "h3", vrsta: "CCP", kaj: "čas hlajenja", mejna: "hlajenje 48 do 72 ur", mejna_vir: "lastne meritve", spremljanje: "sonda", pogostost: "vsaka serija", odgovoren: "kuhar", korektivni: "zavrzi", verifikacija: "pregled zapisov tedensko", evidenca: "hlajenje" }, h1: { hid: "h1", vrsta: "PRP", utemeljitev: "Prevzem po navodilu." } }
  };
  const k = besedilo("kavarna", await izdelaj("Kavarna Sonce", kavarna)), t = k.t, tf = t.replace(/\s+/g, " ");
  ok(!/Strokovno potrdil\s+Luka Zorman/.test(t) && !/Datum potrditve\s+9\. ?11\. ?2026/.test(t) && /Predvideni strokovni pregled/.test(t), "1: osnutek ne izpiše potrditve kot opravljene (Predvideni strokovni pregled)");
  ok(/OSNUTEK/.test(t) && !/Stanje\s+potrjeno/.test(t), "1/4: dokument ostane OSNUTEK");
  ok(!/Posodobitev vsebine v čarovniku|Samodejno shranjevanje|Dopolnjena analiza nevarnosti/.test(t) && /Evidenca različic dokumenta/.test(t) && /Prva izdaja \(osnutek/.test(t), "5/12: v dokumentu samo različice dokumenta (brez internih shranjevanj)");
  const telo = t.split("\n").filter(l => !/^\s*• (Odprto|Opozorilo):/.test(l)).join("\n"); // brez poročila pred izpisom
  ok(!/Določite načrt čiščenja: kaj, kako/.test(telo) && /Pult po vsaki izmeni/.test(telo) && (telo.match(/Čiščenje v Kavarna Sonce/g) || []).length >= 1, "2–3: prilagojen protokol čiščenja ima prednost, splošna predloga se ne izpiše");
  ok((t.match(/Pitna voda/g) || []).length >= 1 && !/PRAVNA IN STROKOVNA PODLAGA/.test(t) && !/OPOMBA:/.test(t) && !/Podjetje: Kavarna Sonce d\.o\.o\./.test(t), "12: navodila brez pravne podlage, OPOMBE in ponovljenega podjetja");
  const nav = t.slice(t.indexOf("Navodila veljajo za")); // poglavje navodil (poročilo pred izpisom je na začetku)
  ok(nav.length > 100 && !/Ugotovite vir vode/.test(nav) && !/nastavite v sistemu/.test(nav) && /\[MANJKA/.test(nav), "4: besedilo za izpolnjevalca ni izpisano kot končno ([MANJKA]), le v poročilu");
  ok(/Ugotovite, katere šarže so prizadete/.test(tf), "navodilo za zaposlene (»Ugotovite, katere šarže …«) ostane v protokolu odpoklica");
  const kaz = t.split("\f").slice(0, 3).join(" "); ok(/Kazalo/.test(kaz) && !/Pravna podlaga/.test(kaz), "kazalo brez »Pravna podlaga«");
  ok(/Odprto: .*Nepotrjeni alergeni.*Tiramisu/.test(tf) && /OPRP1 .*nima utemeljitve|OPRP1.*vir meje/.test(tf) && /48 do 72 ur.*ni enolična/.test(tf) && /180 °C presega/.test(tf) && /CCP1.*ni povezane evidence|OPRP1 .*ni povezane evidence/.test(tf) && /prihodnosti/.test(tf), "4: poročilo pred izpisom (alergeni, vir meje, razpon, olje, evidenca, datum v prihodnosti)");
  ok(/Opozorilo: Surova jajca/.test(tf) && /skupnem olju/.test(tf), "strokovna opozorila brez samodejnih zaključkov");
  ok(/Uredba \(EU\) 2017\/2158/.test(t), "priloga: Uredba (EU) 2017/2158, ker obrat cvre");
  ok(/Matrika alergenov še ni popolna/.test(tf), "trditev o popolni matriki alergenov se pri nepotrjenih alergenih ne izpiše");
  ok(!/\bKT\s?\d/.test(t), "oznake KT niso izpisane");
  ok(/OPRP1/.test(t) && /CCP1/.test(t) && /V1\s+V2\s+V3\s+V4/.test(t), "poglavji 9 in 10: enolični nazivi in stolpci V1–V4");
  ok(!/Glej poglavje 8/.test(t), "poglavje 9 brez »Glej poglavje 8«");
  ok(/Skupni začetek/.test(t) && /Linija: kuhinja/.test(t) && /Linija: slaščičarna/.test(t) && /Linija: točilni pult/.test(t) && /Skupni konec/.test(t), "6: razvejan diagram (skupni začetek, linije, skupni konec)");
  ok(/dostava, v procesu pa ni koraka dostave/.test(tf) && /V procesu je sladoled/.test(tf), "4: način prodaje usklajen s koraki; sladoled iz procesa manjka v opisu živil");
  ok(/Ana Kos – vodja HACCP skupine/.test(tf) && /Kultura varnosti hrane/.test(t) && /Vodstvo zagotavlja vire/.test(tf), "6: HACCP skupina z vlogami in kultura varnosti hrane v dokumentu");
  ok(/drevo odločanja predlaga CCP/.test(tf), "9: opozorilo ob neskladju drevesa odločanja in razvrstitve (OPRP1)");
  console.log("strani (kavarna):", k.strani); if (process.env.DEBUG_DOK) console.log(t.split("\n").filter(l => /Čiščenje|MANJKA|Ugotovite|nastavite|Pitna/.test(l)).join("\n"));
  // drug tip obrata
  const mesnica = { vrsta: "Mesnica", koraki: ["Prevzem mesa", "Skladiščenje", "Razsek", "Prodaja"], zivila: [{ naziv: "Mleto meso", alergeni: "ni alergenov" }], nevarnosti: [H("m1", "k1", "Rast patogenov", "B", 3, 4)], kontrole: { m1: { hid: "m1", vrsta: "CCP", kaj: "temperatura hladilnika", mejna: "≤ 4 °C", mejna_vir: "Uredba (ES) 853/2004", spremljanje: "termometer", pogostost: "2× dnevno", odgovoren: "mesar", korektivni: "premik", verifikacija: "tedenski pregled", evidenca: "temperatura" } } };
  const m = besedilo("mesnica", await izdelaj("Mesnica Rožman", mesnica));
  ok(/OSNUTEK/.test(m.t) && !/Uredba \(EU\) 2017\/2158/.test(m.t) && !/Strokovno potrdil\s+Luka/.test(m.t), "drug tip obrata (mesnica): brez Uredbe 2017/2158, brez lažne potrditve");
  ok(!errs.length, "brez napak JavaScript" + (errs.length ? ": " + errs[0] : ""));
  await br.close(); console.log(fails ? "NEUSPEH" : "VSE OK"); process.exit(fails ? 1 : 0);
})().catch(e => { console.log("IZJEMA", e.stack); process.exit(2); });
