// Optimizacija za iskalnike (SEO) javne spletne strani: naslov, opis in ključne besede po straneh (nastavi administrator),
// kanonični naslov, Open Graph in Twitter (deljenje), strukturirani podatki (JSON-LD), sitemap.xml in robots.txt.
// Predogled na domeni platforme (/stran/) in platforma sama sta za iskalnike zaprta (noindex), da ni podvojene vsebine.
const path = require("path");
const { hasRole } = require("./vloge");

const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const cist = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, n);
const jsonLd = o => `<script type="application/ld+json">${JSON.stringify(o).replace(/</g, "\\u003c")}</script>`;

// privzete nastavitve strani (administrator jih lahko spremeni v Spletna stran → SEO)
const STRANI = {
  "index.html": { ime: "Vstopna stran", naslov: "HACCP brez papirja – elektronske evidence in HACCP načrt | HiGiFood", opis: "HiGiFood je slovenska HACCP platforma: elektronske evidence, temperature hladilnikov, načrt čiščenja, HACCP načrt in poročila za inšpekcijo – za gostinske in živilske obrate.", kljucne: "HACCP, HACCP načrt, HACCP program, elektronske HACCP evidence, evidenca temperature hladilnika, načrt čiščenja, varna hrana, živilski obrat, gostinstvo, inšpekcija UVHVVR, HACCP svetovanje, HACCP Slovenija" },
  blog: { ime: "Blog (seznam člankov)", naslov: "Blog o HACCP in varni hrani – nasveti in predpisi | HiGiFood", opis: "Nasveti o HACCP, predpisih, inšpekciji in dobri higienski praksi za gostinske in živilske obrate – razloženo preprosto.", kljucne: "HACCP nasveti, varna hrana, predpisi o hrani, inšpekcija, dobra higienska praksa, gostinstvo" },
  "zasebnost.html": { ime: "Politika zasebnosti", naslov: "Politika zasebnosti | HiGiFood", opis: "Kako HiGiFood obdeluje osebne podatke s spletne strani: povpraševanja, novice, piškotki in vaše pravice po GDPR.", kljucne: "politika zasebnosti, GDPR, varstvo osebnih podatkov" },
  "piskotki.html": { ime: "Piškotki", naslov: "Piškotki | HiGiFood", opis: "Katere piškotke uporablja spletna stran HiGiFood in kako spremenite svojo izbiro.", kljucne: "piškotki, nastavitve piškotkov" },
  "novice.html": { ime: "Novice (prijava, odjava)", naslov: "Novice HiGiFood – prijava in odjava", opis: "Prijava na novice HiGiFood o HACCP in predpisih ter odjava.", kljucne: "novice HACCP", noindex: true }
};

module.exports = function seo({ DIR, S, send, bad, jbody, audit, kontakt, clanki }) {
  const F = path.join(DIR, "_seo.json");
  let cache = null;
  const preberi = () => { if (!cache) { try { cache = S.beri(F, {}); } catch { cache = {}; } cache = Object.assign({ strani: {} }, cache); } return cache; };
  const stran = k => Object.assign({}, STRANI[k] || {}, (preberi().strani || {})[k] || {});
  const organizacija = base => { const k = kontakt() || {}; return { "@type": "Organization", "@id": base + "#organizacija", name: k.naziv || "HiGiFood", url: base, logo: base + "logo-svetlo.png", slogan: "Z znanjem do varne hrane!", ...(k.email ? { email: k.email } : {}), ...(k.telefon ? { telephone: k.telefon } : {}), ...(k.naslov ? { address: k.naslov } : {}) }; };

  // oznake v <head>: title, description, keywords, robots, canonical, Open Graph, Twitter, JSON-LD
  function meta({ naslov, opis, kljucne, url, slika, tip, jsonld, noindex, objavljeno, spremenjeno }) {
    return [`<title>${esc(naslov)}</title>`, `<meta name="description" content="${esc(opis)}">`, kljucne ? `<meta name="keywords" content="${esc(kljucne)}">` : "",
      `<meta name="robots" content="${noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large"}">`, url && !noindex ? `<link rel="canonical" href="${esc(url)}">` : "",
      `<meta property="og:locale" content="sl_SI">`, `<meta property="og:site_name" content="HiGiFood">`, `<meta property="og:type" content="${tip || "website"}">`, `<meta property="og:title" content="${esc(naslov)}">`, `<meta property="og:description" content="${esc(opis)}">`,
      url ? `<meta property="og:url" content="${esc(url)}">` : "", slika ? `<meta property="og:image" content="${esc(slika)}">` : "",
      objavljeno ? `<meta property="article:published_time" content="${esc(objavljeno)}">` : "", spremenjeno ? `<meta property="article:modified_time" content="${esc(spremenjeno)}">` : "",
      ...String(kljucne || "").split(",").map(x => x.trim()).filter(Boolean).slice(0, 10).map(t => tip === "article" ? `<meta property="article:tag" content="${esc(t)}">` : ""),
      `<meta name="twitter:card" content="${slika ? "summary_large_image" : "summary"}">`, `<meta name="twitter:title" content="${esc(naslov)}">`, `<meta name="twitter:description" content="${esc(opis)}">`, slika ? `<meta name="twitter:image" content="${esc(slika)}">` : "",
      ...(jsonld || []).map(jsonLd)].filter(Boolean).join("\n");
  }
  // statična stran (index.html, zasebnost.html …): zamenja <title> in opis z nastavitvami ter doda ostale oznake
  function obdelajStran(rel, html, base, predogled) {
    const k = rel === "" || rel === "index.html" ? "index.html" : rel; if (!STRANI[k]) return html;
    const s = stran(k), url = base + (k === "index.html" ? "" : k), jl = [];
    if (k === "index.html") jl.push({ "@context": "https://schema.org", "@graph": [organizacija(base), { "@type": "WebSite", "@id": base + "#splet", url: base, name: "HiGiFood", inLanguage: "sl-SI", publisher: { "@id": base + "#organizacija" } }, { "@type": "SoftwareApplication", name: "HiGiFood HACCP", applicationCategory: "BusinessApplication", operatingSystem: "Spletni brskalnik, Windows", description: s.opis, inLanguage: "sl-SI", publisher: { "@id": base + "#organizacija" } }] });
    const glava = meta({ naslov: s.naslov, opis: s.opis, kljucne: s.kljucne, url, slika: base + "logo-svetlo.png", noindex: predogled || s.noindex, jsonld: jl });
    return html.replace(/<title>[\s\S]*?<\/title>\s*/i, "").replace(/<meta name="description"[^>]*>\s*/i, "").replace(/<meta name="robots"[^>]*>\s*/i, "").replace(/<\/head>/i, glava + "\n</head>");
  }
  // sitemap.xml: vstopna stran, blog in objavljeni članki, pravne strani (brez strani z noindex)
  function sitemap(base) {
    const L = [[base, "weekly", "1.0"], [base + "blog/", "weekly", "0.8"], ...clanki().map(c => [base + "blog/" + c.slug, "monthly", "0.7", c.spremenjeno || c.objavljeno]), [base + "zasebnost.html", "yearly", "0.2"], [base + "piskotki.html", "yearly", "0.2"]];
    return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${L.map(([u, f, p, m]) => `<url><loc>${esc(u)}</loc>${m ? `<lastmod>${esc(String(m).slice(0, 10))}</lastmod>` : ""}<changefreq>${f}</changefreq><priority>${p}</priority></url>`).join("\n")}\n</urlset>\n`;
  }
  // robots.txt: spletna stran odprta (brez /api/ in strani za odjavo), platforma in predogled zaprta
  const robots = (base, javna) => javna ? `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /novice.html\n\nSitemap: ${base}sitemap.xml\n` : "User-agent: *\nDisallow: /\n";

  // administrator: nastavitve SEO po straneh
  async function rAdmin(req, res, p, url, me, ip) {
    if (p !== "/api/seo-admin") return undefined;
    if (!hasRole(me, "admin")) { bad(res, 403, "To lahko naredi samo administrator."); return true; }
    if (req.method === "GET") { send(res, 200, { strani: Object.keys(STRANI).map(k => Object.assign({ id: k, privzeto: STRANI[k] }, stran(k))) }); return true; }
    if (req.method === "PUT") {
      const b = await jbody(req, res); if (!b) return true; const d = preberi(), o = {};
      for (const k of Object.keys(STRANI)) { const x = (b.strani || {})[k]; if (!x) continue; o[k] = { naslov: cist(x.naslov, 120) || STRANI[k].naslov, opis: cist(x.opis, 320) || STRANI[k].opis, kljucne: cist(x.kljucne, 400) }; }
      d.strani = Object.assign({}, d.strani, o); S.pisi(F, d); audit(me, "seo-nastavitve", "", "", Object.keys(o).join(","), ip); send(res, 200, { ok: true }); return true;
    }
    return undefined;
  }
  return { meta, obdelajStran, sitemap, robots, rAdmin, stran, organizacija, jsonLd };
};
