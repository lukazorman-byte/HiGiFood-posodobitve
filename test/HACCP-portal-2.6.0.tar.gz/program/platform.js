// Platforma HiGiFood: prijava, vloge, ločevanje strank, revizijska sled, evidence z revizijami, varnostne kopije.
// Brez odvisnosti. Vse preverjanje dostopa poteka na strežniku.
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

module.exports = function (o) {
  const { DIR, DB, send, body } = o;
  const TESTNO = !!o.testno, TEST_GESLO = process.env.HACCP_TEST_GESLO || "Testiram-123"; // geslo testnih računov (samo testni način, javno prikazano testerjem)
  const PRIL = path.join(DIR, "priloge"), SLOGO = path.join(DIR, "logotipi-strank");
  const BKP = path.join(DIR, "_kopije");
  fs.mkdirSync(PRIL, { recursive: true });
  fs.mkdirSync(BKP, { recursive: true });

  // ---------- shramba ----------
  const cache = {};
  // zbirke se hranijo v podatkovni bazi SQLite (shramba.js; zapišejo se samo spremenjeni zapisi) ali v datotekah JSON
  const S = require("./shramba")(DIR);
  function load(n) {
    if (!cache[n]) { try { cache[n] = S.preberi(n); } catch (e) { console.error("Branje zbirke " + n + " ni uspelo: " + e.message); cache[n] = []; } }
    return cache[n];
  }
  function save(n) {
    S.zapisi(n, cache[n]);
    spremembeOdKopije = true;
  }
  let spremembeOdKopije = true; // dnevna kopija se osveži, če so se podatki od nje spremenili
  const uid = () => crypto.randomBytes(9).toString("base64url");
  function vsebinaUstreza(buf, tip) { // preverjanje prvih bajtov (ne zaupamo samo tipu, ki ga pošlje brskalnik)
    const h = buf.subarray(0, 12), a = h.toString("latin1");
    if (tip === "image/png") return a.startsWith("\x89PNG");
    if (tip === "image/jpeg") return h[0] === 0xff && h[1] === 0xd8 && h[2] === 0xff;
    if (tip === "image/webp") return a.startsWith("RIFF") && a.slice(8, 12) === "WEBP";
    if (tip === "image/gif") return a.startsWith("GIF8");
    if (tip === "application/pdf") return a.startsWith("%PDF");
    if (tip === "text/plain") return !buf.subarray(0, 4096).includes(0);
    return false;
  }
  const now = () => new Date().toISOString();
  const NAPAKE = []; // zadnje napake strežnika (Administracija, Stanje sistema)
  { const ce = console.error.bind(console); console.error = (...a) => { NAPAKE.push({ cas: now(), sporocilo: a.map(x => typeof x === "string" ? x : (x && x.message) || String(x)).join(" ").slice(0, 300) }); if (NAPAKE.length > 20) NAPAKE.shift(); ce(...a); }; }

  // ---------- revizijska sled (veriga zgoščenk) ----------
  // Tekoča datoteka _revizijska-sled.jsonl se pri ~5 MB arhivira v _revizijska-sled-<čas>.jsonl; veriga se nadaljuje čez datoteke.
  const AUDIT = path.join(DIR, "_revizijska-sled.jsonl"), SLED_MAX = +process.env.HACCP_SLED_MAX || 5e6;
  const sledArhivi = () => { try { return fs.readdirSync(DIR).filter(f => /^_revizijska-sled-.+\.jsonl$/.test(f)).sort(); } catch { return []; } };
  const vrstice = f => { try { return fs.readFileSync(f, "utf8").split("\n").filter(Boolean); } catch { return []; } };
  let lastHash = "0";
  const auditLast = () => {
    lastHash = "0";
    for (const f of [...sledArhivi().map(a => path.join(DIR, a)), AUDIT]) { const t = vrstice(f); if (t.length) try { lastHash = JSON.parse(t[t.length - 1]).h; } catch {} }
    preverjeniArhivi.clear();
  };
  const preverjeniArhivi = new Map(); // arhiv -> {mtime, prev, h, n}: arhivi se ne spreminjajo, zato se preverijo enkrat
  auditLast();
  function audit(user, akcija, zbirka, id, opis, ip) {
    const e = { cas: now(), uporabnik: user ? user.id : null, ime: user ? user.ime : null, akcija, zbirka: zbirka || "", id: id || "", opis: opis || "", ip: ip || "" };
    e.h = crypto.createHash("sha256").update(lastHash + JSON.stringify(e)).digest("hex");
    lastHash = e.h;
    fs.appendFileSync(AUDIT, JSON.stringify(e) + "\n");
    try { if (fs.statSync(AUDIT).size > SLED_MAX) fs.renameSync(AUDIT, path.join(DIR, "_revizijska-sled-" + now().replace(/[:.]/g, "-") + ".jsonl")); } catch {}
  }
  function auditRead(limit) {
    const out = []; const files = [AUDIT, ...sledArhivi().reverse().map(a => path.join(DIR, a))];
    for (const f of files) { const t = vrstice(f); for (let k = t.length - 1; k >= 0 && out.length < limit; k--) try { out.push(JSON.parse(t[k])); } catch {} if (out.length >= limit) break; }
    return out;
  }
  function auditVerify() {
    let prev = "0", n = 0, arhivov = 0;
    const preveri = (lines, start) => { let pv = start, c = 0; for (const l of lines) { const e = JSON.parse(l), h = e.h; delete e.h; if (crypto.createHash("sha256").update(pv + JSON.stringify(e)).digest("hex") !== h) return { napaka: c + 1 }; pv = h; c++; } return { h: pv, n: c }; };
    try {
      for (const a of sledArhivi()) {
        const f = path.join(DIR, a), mt = fs.statSync(f).mtimeMs, c = preverjeniArhivi.get(a);
        let r = c && c.mtime === mt && c.prev === prev ? c : null;
        if (!r) { const x = preveri(vrstice(f), prev); if (x.napaka) return { ok: false, vrstica: n + x.napaka, datoteka: a }; r = { mtime: mt, prev, h: x.h, n: x.n }; preverjeniArhivi.set(a, r); }
        prev = r.h; n += r.n; arhivov++;
      }
      const x = preveri(vrstice(AUDIT), prev); if (x.napaka) return { ok: false, vrstica: n + x.napaka };
      n += x.n;
    } catch { return { ok: false }; }
    return { ok: true, vnosov: n, arhivov };
  }

  // ---------- gesla in seje ----------
  const hashPw = (pw, salt) => { salt = salt || crypto.randomBytes(16).toString("hex"); return salt + ":" + crypto.scryptSync(pw, salt, 64).toString("hex"); };
  const checkPw = (pw, st) => {
    const [salt, h] = String(st || "").split(":");
    if (!salt || !h) return false;
    const a = Buffer.from(h, "hex"), b = crypto.scryptSync(pw, salt, 64);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  };
  // seje: zgoščen žeton -> {uid, do}; shranjene v _seje.json (samo zgoščenke), da ponovni zagon ne odjavi vseh
  const SEJF = path.join(DIR, "_seje.json");
  const LAZNO_GESLO = hashPw(crypto.randomBytes(16).toString("hex")); // za enak odzivni čas pri neznanem e-naslovu
  let sejeT = null;
  const sejeShrani = () => { try { S.pisi(SEJF, [...SESS].filter(([, s]) => s.do > Date.now())); } catch {} };
  const sejeDirty = () => { if (!sejeT) sejeT = setTimeout(() => { sejeT = null; sejeShrani(); }, 1000); };
  class Seje extends Map { set(k, v) { super.set(k, v); sejeDirty(); return this; } delete(k) { const r = super.delete(k); if (r) sejeDirty(); return r; } clear() { super.clear(); sejeDirty(); } }
  const SESS = new Seje();
  try { for (const [k, s] of S.beri(SEJF)) if (s && s.do > Date.now()) Map.prototype.set.call(SESS, k, s); } catch {}
  setInterval(() => { if (SESS.size) sejeShrani(); }, 10 * 60e3).unref();
  const TTL = 12 * 3600e3;
  const sh = t => crypto.createHash("sha256").update(t).digest("hex");
  function cookies(req) {
    const r = {};
    for (const p of String(req.headers.cookie || "").split(";")) { const i = p.indexOf("="); if (i > 0) r[p.slice(0, i).trim()] = p.slice(i + 1).trim(); }
    return r;
  }
  // odgovorna oseba / zaposleni izbrisane stranke nima dostopa (dokler stranke ne obnovite iz Koša ali ji ne dodelite druge)
  const brezStranke = u => ["odgovorna", "zaposleni"].includes(u.vloga) && !load("stranke").some(s => s.id === u.stranka_id);
  function userOf(req) {
    const t = cookies(req).hs;
    if (!t) return null;
    const s = SESS.get(sh(t));
    if (!s || s.do < Date.now()) { SESS.delete(sh(t)); return null; }
    const u = load("uporabniki").find(x => x.id === s.uid && x.aktiven !== false);
    if (!u || brezStranke(u)) return null;
    s.do = Date.now() + TTL;
    return u;
  }
  // ---------- dvostopenjska prijava (TOTP, RFC 6238: 30 s, 6 števk, SHA-1; združljivo z Google/Microsoft Authenticator) ----------
  const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const b32enc = buf => { let bits = 0, val = 0, out = ""; for (const x of buf) { val = (val << 8) | x; bits += 8; while (bits >= 5) { out += B32[(val >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) out += B32[(val << (5 - bits)) & 31]; return out; };
  const b32dec = s => { let bits = 0, val = 0; const out = []; for (const ch of String(s).toUpperCase().replace(/[^A-Z2-7]/g, "")) { val = (val << 5) | B32.indexOf(ch); bits += 5; if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; } } return Buffer.from(out); };
  const totpKoda = (key, ctr) => { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); const h = crypto.createHmac("sha1", key).update(b).digest(), o = h[h.length - 1] & 15; return String(((h.readUInt32BE(o) & 0x7fffffff) % 1e6)).padStart(6, "0"); };
  function totpPreveri(key, koda, zadnji) { // vrne števec ob uspehu (okno ±1 interval), sicer null; ista koda se ne sme uporabiti dvakrat
    const k = String(koda || "").replace(/\s/g, ""); if (!/^\d{6}$/.test(k)) return null;
    const c = Math.floor(Date.now() / 30000);
    for (const d of [0, -1, 1]) { const x = c + d; if (x > (zadnji || 0) && crypto.timingSafeEqual(Buffer.from(totpKoda(key, x)), Buffer.from(k))) return x; }
    return null;
  }
  // zaupanja vredna naprava (piškotek hz, na strežniku samo zgoščenka): po prijavi s kodo se koda na tej napravi ne zahteva 30 dni;
  // sprememba gesla, izklop ali ponovni vklop dvostopenjske prijave in »Pozabi naprave« zaupanje prekličejo
  const ZAUPANJE_DNI = 30;
  const napravaZaupana = (u, req) => { const t = cookies(req).hz; return !!t && (u.totp_naprave || []).some(x => x.h === sh(t) && x.do > Date.now()); };
  function zapomniNapravo(res, req, u) {
    const t = crypto.randomBytes(32).toString("base64url"), secure = req.headers["x-forwarded-proto"] === "https";
    u.totp_naprave = (u.totp_naprave || []).filter(x => x.do > Date.now()).slice(-9).concat([{ h: sh(t), do: Date.now() + ZAUPANJE_DNI * 864e5, cas: now() }]);
    dodajPiskotek(res, `hz=${t}; HttpOnly; SameSite=Strict; Path=/api/auth; Max-Age=${ZAUPANJE_DNI * 86400}${secure ? "; Secure" : ""}`);
  }
  const dodajPiskotek = (res, c) => { const p = res.getHeader("Set-Cookie"); res.setHeader("Set-Cookie", [].concat(p || [], c)); };
  function drugiKorak(u, koda) { // preveri TOTP ali rezervno kodo; ob uspehu posodobi uporabnika
    const ctr = totpPreveri(b32dec(u.totp_skrivnost), koda, u.totp_zadnji);
    if (ctr) { u.totp_zadnji = ctr; return true; }
    const hv = sh(String(koda || "").trim().toUpperCase()), i = (u.totp_rezervne || []).indexOf(hv);
    if (i >= 0) { u.totp_rezervne.splice(i, 1); return true; }
    return false;
  }
  // obvezna dvostopenjska prijava po vlogah (Administracija → Varnost prijave)
  const VARF = path.join(DIR, "_varnost.json");
  const varnostNast = () => { try { return Object.assign({ obvezna_2fa: [] }, S.beri(VARF)); } catch { return { obvezna_2fa: [] }; } };
  const mora2fa = u => !u.totp_vklop && varnostNast().obvezna_2fa.includes(u.vloga);
  // e-poštni opomniki uporabnika: pogostost (dnevno / tedensko ob ponedeljkih / izklop) in vrste (roki, manjkajoči vnosi)
  const opomnikiOf = u => Object.assign({ pogostost: "dnevno", roki: true, vnosi: true }, u.opomniki || {});
  const pub = u => ({ geslo_ponastavljeno: !!u.geslo_ponastavljeno, opomniki: opomnikiOf(u), mora_2fa: mora2fa(u), povabljen: !!u.povabljen, totp: !!u.totp_vklop, totp_naprave: (u.totp_naprave || []).filter(x => x.do > Date.now()).length, id: u.id, email: u.email, ime: u.ime, vloga: u.vloga, stranka_id: u.stranka_id || null, stranke: u.stranke || [], aktiven: u.aktiven !== false, zadnja_prijava: u.zadnja_prijava || null, mora_zamenjati: !!u.mora_zamenjati });
  const fails = new Map();
  function limited(key) { const f = fails.get(key); return f && f.n >= 5 && f.t > Date.now(); }
  function fail(key) { const f = fails.get(key) || { n: 0 }; f.n++; f.t = Date.now() + 60e3; fails.set(key, f); }

  const VLOGE = ["admin", "svetovalec", "odgovorna", "zaposleni"];
  const pwOk = pw => typeof pw === "string" && pw.length >= 10 && pw.length < 200 && pw.trim().length >= 10; // samo presledki niso geslo

  // ---------- zbirke podatkov in pravice ----------
  // rd/wr/cr/del: črke vlog (A admin, S svetovalec, O odgovorna oseba, Z zaposleni)
  const COLL = {
    stranke: { rd: "ASOZ", cr: "AS", wr: "ASO", del: "A", req: ["naziv"] },
    obrati: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "AS", req: ["naziv"] },
    osebje: { rd: "ASO", cr: "ASO", wr: "ASO", del: "ASO", req: ["ime"] },
    dobavitelji: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["naziv"] },
    oprema: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["naziv"] },
    usposabljanja: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["tema"] },
    nacrti: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "AS", req: ["naziv"], rev: true },
    navodila: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "AS", req: ["naslov"], rev: true },
    evidence: { rd: "ASOZ", cr: "ASOZ", wr: "ASOZ", del: "", req: ["vrsta"], rev: true, rec: true },
    capa: { rd: "ASOZ", cr: "ASOZ", wr: "ASO", del: "", req: ["opis"], rev: true },
    ciscenje_nacrt: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["opravilo"] },
    vabe: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["oznaka"] },
    kemikalije: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["naziv"] },
    tlorisi: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["naziv"], rev: true },
    urnik: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["vrsta"] },
    dogodki: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["naslov", "datum"] },
    storitve: { rd: "ASO", cr: "AS", wr: "AS", del: "A", req: ["datum"] },
    priloge: { rd: "ASOZ", cr: "ASOZ", wr: "ASO", del: "AS", req: ["ime"] },
    sarze: { rd: "ASOZ", cr: "ASOZ", wr: "ASOZ", del: "ASO", req: ["izdelek"], rev: true },
    jedi: { rd: "ASOZ", cr: "ASO", wr: "ASO", del: "ASO", req: ["naziv"] },
    certifikacija: { rd: "ASO", cr: "ASO", wr: "ASO", del: "ASO", req: ["standard", "tocka"] }
  };
  const CASCADE = ["obrati", "osebje", "dobavitelji", "oprema", "usposabljanja", "nacrti", "navodila", "dogodki", "storitve", "urnik", "priloge", "ciscenje_nacrt", "vabe", "kemikalije", "tlorisi", "sarze", "jedi", "certifikacija", "potrditve"];
  const KOS_DNI = 30;
  function kosPocisti() {
    const meja = Date.now() - KOS_DNI * 864e5, kos = load("_kos"), ostane = [];
    for (const it of kos) { if (new Date(it.cas).getTime() >= meja) { ostane.push(it); continue; } for (const pr of (it.zbirka === "priloge" ? [it.zapis] : (it.otroci && it.otroci.priloge) || [])) try { fs.unlinkSync(path.join(PRIL, pr.id)); } catch {} }
    if (ostane.length !== kos.length) { cache["_kos"] = ostane; save("_kos"); }
  }
  const RAZLOG_MIN = 3; // najkrajši razlog popravka zapisa evidence ali neskladnosti
  const RESERVED = ["id", "ustvarjeno", "ustvaril", "ustvaril_ime", "spremenjeno", "spremenil", "spremenil_ime", "revizije", "_t"];
  const letter = u => ({ admin: "A", svetovalec: "S", odgovorna: "O", zaposleni: "Z" }[u.vloga]);
  const can = (u, perm) => perm && perm.includes(letter(u));
  function tenantOk(u, sid) {
    if (u.vloga === "admin") return true;
    if (!sid) return false;
    if (u.vloga === "svetovalec") return (u.stranke || []).includes(sid);
    return u.stranka_id === sid;
  }
  const sidOf = (c, r) => c === "stranke" ? r.id : r.stranka_id;
  function visible(u, c, r) { return tenantOk(u, sidOf(c, r)); }

  const INTERNAL = { stranke: ["notranje"], storitve: ["cena"] };
  function outv(u, c, r) {
    if (u.vloga === "admin" || u.vloga === "svetovalec" || !INTERNAL[c]) return r;
    const x = Object.assign({}, r);
    for (const k of INTERNAL[c]) delete x[k];
    return x;
  }
  function clean(obj) {
    const r = {};
    for (const [k, v] of Object.entries(obj || {})) if (!RESERVED.includes(k) && !k.startsWith("__")) r[k] = typeof v === "string" ? v.replace(/\u0000/g, "") : v; // ničelni bajti ne sodijo v besedilo
    return r;
  }
  const bad = (res, code, m) => send(res, code, { napaka: m });

  // preverjanje vnosa za zbirke: tipi polj (datumi, števila, besedila), dovoljene vrednosti in velikost zapisa.
  // Datumov in števil ni mogoče zlorabiti za HTML; prevelika polja ne upočasnijo strežnika za vse uporabnike.
  const P_DATUM = new Set(["cas", "datum", "datum_odhoda", "datum_potrditve", "datum_prevzema", "datum_vzorcenja", "datum_zapiranja", "higienski_do", "zdravniski_do", "veljavno_do", "naslednja_ocena", "naslednji_pregled", "naslednji_servis", "rok", "rok_uporabe", "zacetek"]);
  const P_STEV = new Set(["alkohol", "alkohol_min", "alkohol_max", "brix", "brix_min", "brix_max", "ph", "ph_min", "ph_max", "cas_min", "cena", "entero", "entero_meja", "sms", "sms_meja", "frekvenca_ur", "interval_dni", "pogostost_dni", "opomnik_dni", "max", "min", "meja_min", "meja_max", "max_trajanje", "trajanje", "minute", "povrsina", "sirina_m", "visina_m", "stevilo", "vrednost", "zacetna"]);
  const P_BESEDILO = new Set(["naziv", "kratko_ime", "ime", "naslov", "opis", "opomba", "vrsta", "status", "tveganje", "nujnost", "odgovoren", "oprema", "izdelek", "tema", "opravilo", "podrocje", "oznaka", "email", "telefon", "davcna", "maticna", "dejavnost", "kategorija", "lokacija", "tip", "funkcija", "odgovorna_oseba", "naprava", "ura", "paket", "notranje"]);
  const P_IZBIRA = { tveganje: ["", "nizko", "srednje", "visoko"], nujnost: ["", "običajna", "nujna", "takojšnja"] };
  const P_STANJE = { evidence: ["vneseno", "potrjeno"], capa: ["odprto", "v izvajanju", "čaka preverjanje", "zaprto"] };
  const DATUM_RE = /^\d{4}-\d\d-\d\d(T\d\d:\d\d(:\d\d(\.\d{1,3})?)?(Z|[+-]\d\d:?\d\d)?)?$/;
  // gnezdeni podatki tlorisa in HACCP načrta: samo pričakovane oblike (id-ji, števila), sicer bi se lahko v prikaz vrinila koda
  const ID_RE = /^[^<>"'`&\s]{1,100}$/, TL_T = new Set(["soba", "stena", "vrata", "oprema", "pot", "vaba", "besedilo"]), TL_ST = ["x", "y", "w", "h", "x1", "y1", "x2", "y2", "vel", "rot"];
  const jeObj = o => o && typeof o === "object" && !Array.isArray(o), jeSt = v => typeof v === "number" && isFinite(v);
  function preveriTloris(el) {
    if (!Array.isArray(el) || el.length > 5000) return "Neveljavni elementi tlorisa.";
    for (const e of el) {
      if (!jeObj(e) || !TL_T.has(e.t) || typeof e.id !== "string" || !ID_RE.test(e.id)) return "Neveljaven element tlorisa.";
      for (const k of TL_ST) if (e[k] !== undefined && e[k] !== null && !jeSt(e[k])) return "Neveljavna mera elementa tlorisa.";
      if (e.pts !== undefined && (!Array.isArray(e.pts) || e.pts.length > 500 || !e.pts.every(p => Array.isArray(p) && p.length === 2 && jeSt(p[0]) && jeSt(p[1])))) return "Neveljavna pot v tlorisu.";
      for (const [k, v] of Object.entries(e)) if (k !== "pts" && !TL_ST.includes(k) && v !== null && v !== undefined && typeof v !== "string" && typeof v !== "boolean" && !jeSt(v)) return "Neveljaven podatek elementa tlorisa.";
    }
    return null;
  }
  function preveriVsebinoNacrta(W) {
    if (!jeObj(W)) return "Neveljavna vsebina načrta.";
    for (const zb of ["koraki", "nevarnosti", "zivila"]) {
      if (W[zb] === undefined) continue;
      if (!Array.isArray(W[zb])) return "Neveljavna vsebina načrta.";
      for (const x of W[zb]) if (!jeObj(x) || (x.id !== undefined && (typeof x.id !== "string" || !ID_RE.test(x.id)))) return "Neveljavna vsebina načrta.";
    }
    for (const h of W.nevarnosti || []) for (const k of ["verjetnost", "teza"]) if (h[k] !== undefined && h[k] !== null && !/^[1-5]?$/.test(String(h[k]))) return "Verjetnost in teža sta števili od 1 do 5.";
    if (W.kontrole !== undefined) { if (!jeObj(W.kontrole)) return "Neveljavna vsebina načrta."; for (const [k, c] of Object.entries(W.kontrole)) if (!ID_RE.test(k) || !jeObj(c) || (c.vrsta !== undefined && !/^[\wčšžČŠŽ -]{0,30}$/.test(String(c.vrsta)))) return "Neveljavna vsebina načrta."; }
    return null;
  }
  const ima = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
  // pravila za razpone, meje, intervale, uro in e-naslov: ista datoteka kot v obrazcih (portal/pravila.js)
  const PRAVILA = (() => { const sb = { module: {} }; require("vm").runInNewContext(fs.readFileSync(path.join(__dirname, "portal", "pravila.js"), "utf8"), sb); return sb.module.exports; })();
  const preveriPravila = (c, r) => { const n = PRAVILA.preveri(c, r); return n.length ? n.map(x => x[1]).join(" ") : null; };
  function preveriZapis(c, r) {
    for (const [k, v] of Object.entries(r)) {
      if (k.length > 64) return "Neveljavno ime polja.";
      if (v === null) { r[k] = ""; continue; }
      if (typeof v === "string" && v.length > 400000) return `Polje »${k}« je predolgo (največ 400 000 znakov).`;
      if (P_DATUM.has(k)) {
        if (v === "") continue;
        const t = typeof v === "string" ? Date.parse(v.length === 10 ? v + "T00:00:00Z" : v) : NaN, y = typeof v === "string" ? +v.slice(0, 4) : 0;
        if (typeof v !== "string" || !DATUM_RE.test(v) || isNaN(t) || y < 1990 || y > 2100 || (v.length === 10 && new Date(t).toISOString().slice(0, 10) !== v)) return `Polje »${k}« mora biti veljaven datum.`; // 2026-02-30 ni veljaven
      } else if (P_STEV.has(k)) {
        if (v === "" || typeof v === "number" && isFinite(v)) continue;
        const n = typeof v === "string" && /^\s*-?\d+([.,]\d+)?\s*$/.test(v) ? Number(v.replace(",", ".")) : NaN;
        if (!isFinite(n)) return `Polje »${k}« mora biti število.`;
        r[k] = n;
      } else if (P_BESEDILO.has(k)) {
        if (typeof v === "number" && isFinite(v)) r[k] = String(v);
        else if (typeof v !== "string") return `Polje »${k}« mora biti besedilo.`;
      }
      if (ima(P_IZBIRA, k) && !P_IZBIRA[k].includes(r[k])) return `Neveljavna vrednost polja »${k}«.`;
    }
    if (c === "urnik" && r.frekvenca_ur !== undefined && r.frekvenca_ur !== "" && !(+r.frekvenca_ur > 0)) return "Pogostost vnosa mora biti več kot 0 ur.";
    if (c === "tlorisi" && r.elementi !== undefined) { const e = preveriTloris(r.elementi); if (e) return e; }
    if (c === "nacrti" && r.vsebina !== undefined && r.vsebina !== "") { const e = preveriVsebinoNacrta(r.vsebina); if (e) return e; }
    if (r.status !== undefined && P_STANJE[c] && !P_STANJE[c].includes(r.status)) return "Neveljavno stanje zapisa.";
    if (JSON.stringify(r).length > (c === "nacrti" || c === "tlorisi" ? 8e6 : 1e6)) return "Zapis je prevelik.";
    return null;
  }

  // največja globina gnezdenja JSON (brez upoštevanja nizov) – zelo globok JSON bi pri obdelavi prekoračil sklad
  function globinaJson(s) { let d = 0, m = 0, niz = false; for (let i = 0; i < s.length; i++) { const ch = s[i]; if (niz) { if (ch === "\\") i++; else if (ch === '"') niz = false; } else if (ch === '"') niz = true; else if (ch === "{" || ch === "[") { if (++d > m) m = d; } else if (ch === "}" || ch === "]") d--; } return m; }
  async function jbody(req, res, max) {
    let s;
    // brez prijave (prijava, pozabljeno geslo …) zadošča majhno telo; sicer bi neprijavljeni lahko pošiljali po 20 MB
    try { s = await body(req, max || (userOf(req) ? 20e6 : 1e5)); } catch { bad(res, 413, "Poslani podatki so preveliki."); return null; }
    if (globinaJson(s) > 60) { bad(res, 400, "Preveč gnezden JSON."); return null; }
    let j; try { j = JSON.parse(s); } catch { bad(res, 400, "Podatki niso v pravilni obliki (neveljaven JSON)."); return null; }
    if (!j || typeof j !== "object" || Array.isArray(j)) { bad(res, 400, "Telo zahtevka mora biti objekt JSON."); return null; } // null, število, niz: brez tega bi zahtevek ostal brez odgovora
    return j;
  }

  // ---------- varnostne kopije (zip brez stiskanja) ----------
  const CT = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CT[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function zipMake(files) { // [{name, data:Buffer}]
    const loc = [], cen = []; let off = 0;
    for (const f of files) {
      const nm = Buffer.from(f.name), c = crc(f.data), h = Buffer.alloc(30);
      h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt32LE(c, 14); h.writeUInt32LE(f.data.length, 18); h.writeUInt32LE(f.data.length, 22); h.writeUInt16LE(nm.length, 26);
      const e = Buffer.alloc(46);
      e.writeUInt32LE(0x02014b50, 0); e.writeUInt16LE(20, 4); e.writeUInt16LE(20, 6); e.writeUInt16LE(0x0800, 8); e.writeUInt32LE(c, 16); e.writeUInt32LE(f.data.length, 20); e.writeUInt32LE(f.data.length, 24); e.writeUInt16LE(nm.length, 28); e.writeUInt32LE(off, 42);
      loc.push(h, nm, f.data); cen.push(e, nm);
      off += 30 + nm.length + f.data.length;
    }
    const cb = Buffer.concat(cen), end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cb.length, 12); end.writeUInt32LE(off, 16);
    return Buffer.concat([...loc, cb, end]);
  }
  function zipRead(buf) {
    let e = buf.length - 22;
    while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
    if (e < 0) throw new Error("ni zip datoteka");
    const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
    for (let i = 0; i < n; i++) {
      if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error("pokvarjen zip");
      const method = buf.readUInt16LE(p + 10), size = buf.readUInt32LE(p + 24), nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
      const name = buf.slice(p + 46, p + 46 + nl).toString();
      if (method !== 0) throw new Error("nepodprta oblika zip (uporabite kopijo iz programa)");
      const ln = buf.readUInt16LE(lo + 26), lx = buf.readUInt16LE(lo + 28), st = lo + 30 + ln + lx;
      out.push({ name, data: buf.slice(st, st + size) });
      p += 46 + nl + xl + cl;
    }
    return out;
  }
  function walk(d, pre) {
    const r = [];
    if (!fs.existsSync(d)) return r;
    for (const f of fs.readdirSync(d)) {
      if (f.startsWith("_kopije") || f.startsWith("_backup") || f.startsWith("_zavezanci") || f.endsWith(".tmp")) continue;
      const fp = path.join(d, f), st = fs.statSync(fp);
      if (st.isDirectory()) r.push(...walk(fp, pre + f + "/"));
      else r.push({ name: pre + f, data: fs.readFileSync(fp) });
    }
    return r;
  }
  function makeBackup() {
    const files = [...walk(DB, "baza/").filter(f => !f.name.startsWith("baza/_")), ...walk(DIR, "podatki/").filter(f => !/^podatki\/(_kljuc|_seje\.json|_zetoni\.json)$/.test(f.name) && !/\.obnova-\d+$/.test(f.name) && !S.DB_DATOTEKE.test(f.name.slice(8)) && !(S.nacin === "sqlite" && S.DATOTEKE.has(f.name.slice(8)))), ...S.izvozi()]; // nastavitve in stanja iz baze, ne zrcalne datoteke
    return zipMake(files);
  }
  // mapa za kopije: ustvari se samo zadnja raven (nadrejena mapa mora obstajati)
  const mkdirPlitvo = d => { if (!fs.existsSync(d)) { if (!fs.existsSync(path.dirname(d))) throw new Error("nadrejena mapa ne obstaja: " + path.dirname(d)); fs.mkdirSync(d); } };
  // ---------- šifriranje kopij: HFBK1 | sol(16) | iv(12) | oznaka(16) | šifrat (AES-256-GCM, ključ iz gesla prek scrypt) ----------
  const MAGIC = Buffer.from("HFBK1");
  const kljuc = (geslo, sol) => crypto.scryptSync(String(geslo), sol, 32, { N: 1 << 15, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
  function sifriraj(buf, geslo) { const sol = crypto.randomBytes(16), iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", kljuc(geslo, sol), iv), ct = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([MAGIC, sol, iv, c.getAuthTag(), ct]); }
  function desifriraj(buf, geslo) { const sol = buf.subarray(5, 21), iv = buf.subarray(21, 33), tag = buf.subarray(33, 49), d = crypto.createDecipheriv("aes-256-gcm", kljuc(geslo, sol), iv); d.setAuthTag(tag); try { return Buffer.concat([d.update(buf.subarray(49)), d.final()]); } catch { throw new Error("Napačno geslo ali poškodovana datoteka."); } }
  const jeSifrirana = buf => buf.length > 49 && buf.subarray(0, 5).equals(MAGIC);
  const KSTAT = path.join(DIR, "_kopija-stanje.json");
  const kstat = () => { try { return S.beri(KSTAT); } catch { return {}; } };
  const imeVen = name => (nast().kopija_geslo ? name.replace(/\.zip$/, ".hfbk") : name);
  function kopijaVenzaj(zip, name) {
    const dir = (nast().kopija_mapa || "").trim(); if (!dir) return;
    try {
      const g = nast().kopija_geslo; name = imeVen(name); mkdirPlitvo(dir); fs.writeFileSync(path.join(dir, name), g ? sifriraj(zip, g) : zip);
      const all = fs.readdirSync(dir).filter(x => /^kopija-.*\.(zip|hfbk)$/.test(x)).sort();
      for (const old of all.slice(0, Math.max(0, all.length - 30))) fs.unlinkSync(path.join(dir, old));
      S.pisi(KSTAT, { cas: now(), ok: true, mapa: dir, datoteka: name });
    } catch (e) { S.pisi(KSTAT, { cas: now(), ok: false, mapa: dir, napaka: e.message }); }
  }
  function autoBackup(force) {
    try {
      const name = "kopija-" + now().slice(0, 10) + ".zip", f = path.join(BKP, name), ext = (nast().kopija_mapa || "").trim();
      const extMissing = ext && !fs.existsSync(path.join(ext, imeVen(name)));
      const os_ = oblakStanje(), oblakManjka = !!oblakNast() && !(os_.ok && os_.datoteka === name.replace(/\.zip$/, ".hfbk")) && !oblakTece;
      if (!fs.existsSync(f) || force || extMissing || spremembeOdKopije || oblakManjka) {
        spremembeOdKopije = false;
        const zip = makeBackup();
        fs.writeFileSync(f, zip);
        const all = fs.readdirSync(BKP).filter(x => /^kopija-.*\.zip$/.test(x)).sort();
        for (const old of all.slice(0, Math.max(0, all.length - 30))) fs.unlinkSync(path.join(BKP, old));
        kopijaVenzaj(zip, name);
        kopijaVOblak(zip, name).catch(() => {});
      }
    } catch (e) { console.error("Samodejna kopija ni uspela: " + e.message); }
  }
  // ---------- kopija izven strežnika: šifrirana kopija v shrambo S3 (Backblaze B2, Cloudflare R2, AWS S3, Wasabi …) ----------
  const REG = require("./register"), ZAV = REG.seznam(DIR), OBL = require("./oblak"), OST = path.join(DIR, "_oblak-stanje.json");
  const oblakStanje = () => { try { return S.beri(OST); } catch { return {}; } };
  const oblakNast = c => { c = c || nast(); return c.oblak_vedro && c.oblak_endpoint && c.oblak_kljuc_id && c.oblak_skrivnost ? { endpoint: c.oblak_endpoint, regija: c.oblak_regija || "auto", vedro: c.oblak_vedro, kljucId: c.oblak_kljuc_id, skrivnost: c.oblak_skrivnost, predpona: c.oblak_predpona || "" } : null; };
  let oblakTece = false;
  async function kopijaVOblak(zip, name) {
    const n = oblakNast(); if (!n || oblakTece) return oblakStanje();
    const g = nast().kopija_geslo, ime = name.replace(/\.zip$/, ".hfbk");
    if (!g) { const st = { cas: now(), ok: false, napaka: "Za kopijo v oblak nastavite geslo za šifriranje kopij." }; S.pisi(OST, st); return st; }
    oblakTece = true;
    try {
      const buf = sifriraj(zip, g); await OBL.nalozi(n, ime, buf);
      const star = new Date(Date.now() - 31 * 864e5).toISOString().slice(0, 10); await OBL.izbrisi(n, "kopija-" + star + ".hfbk").catch(() => {}); // hrani se zadnjih 30 dni
      const st = { cas: now(), ok: true, datoteka: ime, velikost: buf.length, vedro: n.vedro }; S.pisi(OST, st); return st;
    } catch (e) { const st = { cas: now(), ok: false, napaka: e.message, datoteka: ime }; S.pisi(OST, st); console.error("Kopija v oblak ni uspela: " + e.message); return st; }
    finally { oblakTece = false; }
  }


  // ---------- obvestila po e-pošti (SMTP je neobvezen; nastavitve in geslo ostanejo na strežniku) ----------
  const net = require("net"), tls = require("tls");
  const NAST = path.join(DIR, "_nastavitve.json");
  // Gesla v nastavitvah (SMTP, šifriranje kopij) so na disku šifrirana (AES-256-GCM). Ključ: okoljska spremenljivka HACCP_KLJUC
  // ali datoteka _kljuc (ustvari se sama; ni del varnostnih kopij). Brez ključa gesel iz nastavitev ni mogoče prebrati.
  const GK = (() => {
    if (process.env.HACCP_KLJUC) return crypto.createHash("sha256").update(process.env.HACCP_KLJUC).digest();
    const f = path.join(DIR, "_kljuc");
    try { const k = Buffer.from(fs.readFileSync(f, "utf8").trim(), "hex"); if (k.length === 32) return k; } catch {}
    const k = crypto.randomBytes(32); fs.writeFileSync(f, k.toString("hex"), { mode: 0o600 }); return k;
  })();
  const zakleni = t => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv("aes-256-gcm", GK, iv), ct = Buffer.concat([c.update(String(t), "utf8"), c.final()]); return "enc1:" + Buffer.concat([iv, c.getAuthTag(), ct]).toString("base64"); };
  const odkleni = t => { if (typeof t !== "string" || !t.startsWith("enc1:")) return t; try { const b = Buffer.from(t.slice(5), "base64"), d = crypto.createDecipheriv("aes-256-gcm", GK, b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString("utf8"); } catch { console.error("Gesla v nastavitvah ni mogoče odkleniti (drug ključ?). Vnesite ga znova v Administraciji."); return ""; } };
  const SKRIVNO = ["geslo", "kopija_geslo", "oblak_skrivnost", "api_kljuc"];
  const nastSurovo = () => { try { return S.beri(NAST); } catch { return {}; } };
  const nast = () => { const c = nastSurovo(); for (const k of SKRIVNO) if (c[k]) c[k] = odkleni(c[k]); return c; };
  const nastShrani = c => { const o = Object.assign({}, c); for (const k of SKRIVNO) if (o[k]) o[k] = zakleni(o[k]); S.pisi(NAST, o); };
  { const s0 = nastSurovo(); if (SKRIVNO.some(k => s0[k] && !String(s0[k]).startsWith("enc1:"))) nastShrani(nast()); } // obstoječa nešifrirana gesla se šifrirajo
  // razumljivo sporočilo o napaki SMTP za administratorja namesto surove napake omrežja ali strežnika;
  // faza pove, kje v pogovoru s strežnikom je prišlo do napake
  function smtpRazlozi(e, c, faza) {
    const vrata = +c.vrata || (c.varnost === "ssl" ? 465 : 587), kje = c.streznik + ":" + vrata, m = String(e.message || e);
    const koda = (m.match(/^SMTP: (\d{3})/) || [])[1] || "", odg = koda ? " (Odgovor strežnika: " + m.slice(6, 200) + ")" : "";
    const neujemanje = "Vrata in varnost se ne ujemata: za vrata 465 izberite SSL, za 587 STARTTLS.";
    if (["ENOTFOUND", "EAI_AGAIN"].includes(e.code)) return "Strežnika " + c.streznik + " ni mogoče najti. Preverite ime strežnika SMTP.";
    if (e.code === "ERR_SSL_WRONG_VERSION_NUMBER" || /wrong version number|packet length too long/i.test(m)) return neujemanje;
    if (/CERT|SELF_SIGNED|UNABLE_TO_VERIFY|UNABLE_TO_GET_ISSUER/.test(e.code || "")) return "Potrdila strežnika " + c.streznik + " ni mogoče preveriti (" + e.code + "). Preverite ime strežnika.";
    if (e.code === "ETIMEDOUT" && faza !== "povezava") return "Strežnik " + kje + " se v 10 s ni odzval (ETIMEDOUT, korak: " + faza + "). " + (vrata === 465 && c.varnost !== "ssl" ? neujemanje : "Poskusite znova ali preverite vrata in varnost.");
    if (faza === "povezava" && ["ETIMEDOUT", "ECONNREFUSED", "ENETUNREACH", "EHOSTUNREACH"].includes(e.code)) return "Povezava s " + kje + " ni uspela (" + e.code + "). Odhodna vrata " + vrata + " so verjetno zaprta (požarni zid ali ponudnik strežnika). Uporabite drug način pošiljanja: HTTPS API (Resend ali Brevo) v nastavitvah e-pošte.";
    if (faza === "povezava") return "Povezava s " + kje + " ni mogoča (" + (e.code || m.replace(/^SMTP: /, "")) + "). Preverite strežnik in vrata ter da požarni zid dovoli odhodna vrata " + vrata + ".";
    if (faza === "pozdrav" && !koda) return vrata === 465 && c.varnost !== "ssl" ? neujemanje : "Strežnik " + kje + " se ni odzval kot strežnik SMTP. " + neujemanje;
    if (/STARTTLS/i.test(m) && c.varnost === "brez") return "Strežnik zahteva šifrirano povezavo: izberite STARTTLS (vrata 587) ali SSL (vrata 465)." + odg;
    if (faza === "prijava" && /^5/.test(koda)) return (/(^|\.)(gmail|google|googlemail)\.com$/i.test(c.streznik)
      ? "Google je zavrnil prijavo: napačno uporabniško ime ali geslo. Za Gmail in Google Workspace vnesite geslo za aplikacije (16 črk, ustvarite ga na myaccount.google.com/apppasswords; račun mora imeti vklopljeno dvostopenjsko preverjanje), ne običajnega gesla računa."
      : "Strežnik je zavrnil prijavo: preverite uporabniško ime in geslo.") + odg;
    if (faza === "posiljatelj" && /^5/.test(koda)) return "Strežnik ne dovoli pošiljanja z naslova »" + c.od + "«. Naslov pošiljatelja mora pripadati prijavljenemu računu ali njegovemu vzdevku." + odg;
    if (faza === "prejemnik" && /^5/.test(koda)) return "Strežnik je zavrnil naslov prejemnika." + odg;
    return "Pošiljanje e-pošte ni uspelo: " + m.replace(/^SMTP: /, "");
  }
  // e-pošta je nastavljena: SMTP (strežnik) ali HTTPS API (Resend, Brevo – deluje tudi, ko so odhodna vrata SMTP zaprta)
  const API_POSTA = { resend: { ime: "Resend", url: () => process.env.HACCP_RESEND_URL || "https://api.resend.com/emails" }, brevo: { ime: "Brevo", url: () => process.env.HACCP_BREVO_URL || "https://api.brevo.com/v3/smtp/email" } };
  const postaNastavljena = c => !!(c && c.od) && (API_POSTA[c.nacin] ? !!c.api_kljuc : !!c.streznik);
  // pošiljanje enega sporočila; napaka je razložena (e.smtp) in zapisana med »Zadnje napake strežnika«
  async function smtpSend(c, to, subject, text) {
    let faza = "povezava";
    try { if (API_POSTA[c.nacin]) await apiPosta(c, to, subject, text); else await smtpPogovor(c, to, subject, text, f => { faza = f; }); }
    catch (e) { const n = new Error(e.smtp ? e.message : smtpRazlozi(e, c, faza)); n.smtp = true; console.error("E-pošta (" + (API_POSTA[c.nacin] ? API_POSTA[c.nacin].ime : (c.streznik || "") + ":" + (+c.vrata || (c.varnost === "ssl" ? 465 : 587))) + "): " + n.message); throw n; }
  }
  async function apiPosta(c, to, subject, text) {
    const NASLOV = /^[^\s<>@,;"]+@[^\s<>@,;"]+\.[^\s<>@,;"]+$/, od = String(c.od || "").replace(/[\r\n]/g, " ").trim(), addr = od.replace(/^.*<|>.*$/g, "").trim(), ime = od.includes("<") ? od.slice(0, od.indexOf("<")).trim().replace(/^"|"$/g, "") : "";
    const nap = m => { const e = new Error(m); e.smtp = true; return e; };
    to = String(to || "").trim(); if (!NASLOV.test(to)) throw nap("Neveljaven e-naslov prejemnika."); if (!NASLOV.test(addr)) throw nap("Neveljaven e-naslov pošiljatelja v nastavitvah.");
    const A = API_POSTA[c.nacin], url = A.url(), host = (() => { try { return new URL(url).host; } catch { return url; } })();
    const telo = c.nacin === "brevo" ? { sender: Object.assign({ email: addr }, ime ? { name: ime } : {}), to: [{ email: to }], subject, textContent: text } : { from: ime ? ime + " <" + addr + ">" : addr, to: [to], subject, text };
    const glave = c.nacin === "brevo" ? { "api-key": c.api_kljuc } : { Authorization: "Bearer " + c.api_kljuc };
    let r; try { r = await fetch(url, { method: "POST", signal: AbortSignal.timeout(10000), headers: Object.assign({ "Content-Type": "application/json", Accept: "application/json" }, glave), body: JSON.stringify(telo) }); }
    catch (e) { const k = (e.cause && e.cause.code) || (e.name === "TimeoutError" ? "ETIMEDOUT" : e.code || e.message); throw nap("Povezava s " + host + " ni uspela (" + k + "). Preverite internetno povezavo strežnika."); }
    if (r.ok) return;
    let j = {}; try { j = await r.json(); } catch {}
    const msg = String(j.message || j.error || j.code || "").slice(0, 200);
    if (r.status === 401 || (r.status === 403 && /key|unauthori/i.test(msg))) throw nap(A.ime + " je zavrnil ključ API (" + r.status + "). Preverite ključ v nastavitvah e-pošte.");
    if (r.status === 403 || r.status === 422 || r.status === 400) throw nap(A.ime + " je zavrnil sporočilo (" + r.status + "): " + (msg || "preverite, da je domena pošiljatelja »" + addr.split("@")[1] + "« potrjena pri " + A.ime + "."));
    if (r.status === 429) throw nap(A.ime + ": preveč sporočil v kratkem času (429). Poskusite znova kasneje.");
    throw nap(A.ime + " ni sprejel sporočila (HTTP " + r.status + (msg ? ": " + msg : "") + ").");
  }
  async function smtpPogovor(c, to, subject, text, faza) {
    const b64 = s => Buffer.from(s).toString("base64"), NASLOV = /^[^\s<>@,;"]+@[^\s<>@,;"]+\.[^\s<>@,;"]+$/;
    to = String(to || "").trim(); const od = String(c.od || "").replace(/[\r\n]/g, " ").trim(), addr = od.replace(/^.*<|>.*$/g, "").trim();
    // brez tega bi prazen naslov ali CRLF v naslovu vrinil dodatne ukaze SMTP
    if (!NASLOV.test(to)) throw new Error("Neveljaven e-naslov prejemnika.");
    if (!NASLOV.test(addr)) throw new Error("Neveljaven e-naslov pošiljatelja v nastavitvah.");
    const ime = od.includes("<") ? od.slice(0, od.indexOf("<")).trim().replace(/^"|"$/g, "") : "";
    const fromGlava = ime ? (/^[\x20-\x7e]*$/.test(ime) ? '"' + ime.replace(/"/g, "") + '" <' + addr + ">" : "=?UTF-8?B?" + b64(ime) + "?= <" + addr + ">") : addr;
    let sock = await new Promise((ok, no) => {
      const opt = { host: c.streznik, port: +c.vrata || (c.varnost === "ssl" ? 465 : 587) };
      const s = c.varnost === "ssl" ? tls.connect(opt, () => ok(s)) : net.connect(opt, () => ok(s));
      // časovna omejitev velja tudi pozneje (npr. STARTTLS na vratih 465, kjer strežnik čaka na TLS): prekine povezavo z napako
      s.once("error", no); s.setTimeout(10000, () => { const e = new Error("SMTP: časovna omejitev"); e.code = "ETIMEDOUT"; no(e); s.destroy(e); }); // 10 s brez odziva (povezava, pozdrav, ukazi)
    });
    faza("pozdrav");
    let buf = "", waiter = null, err = null;
    const attach = s => { s.on("data", d => { buf += d.toString(); pump(); }); s.on("error", e => { err = e; if (waiter) waiter.no(e); }); s.on("close", () => { if (waiter) waiter.no(new Error("SMTP: povezava prekinjena")); }); };
    const pump = () => {
      if (!waiter) return;
      const lines = buf.split("\r\n"); // zadnji element je nepopoln
      for (let i = 0; i < lines.length - 1; i++) if (/^\d{3} /.test(lines[i])) { const code = lines[i].slice(0, 3), text = lines.slice(0, i + 1).join(" | "); buf = lines.slice(i + 1).join("\r\n"); const w = waiter; waiter = null; return w.ok({ code, text }); }
    };
    const read = () => err ? Promise.reject(err) : new Promise((ok, no) => { waiter = { ok, no }; pump(); });
    const cmd = async (s, expect) => { if (s !== null) sock.write(s + "\r\n"); const r = await read(); if (!r.code.startsWith(expect)) throw new Error("SMTP: " + r.text); return r; };
    attach(sock);
    try {
      await cmd(null, "220");
      let r = await cmd("EHLO higifood.local", "250");
      if (c.varnost === "starttls") {
        faza("STARTTLS"); await cmd("STARTTLS", "220");
        sock.removeAllListeners("data"); sock.removeAllListeners("close"); sock.removeAllListeners("error");
        buf = "";
        sock = await new Promise((ok, no) => { const t = tls.connect({ socket: sock, servername: c.streznik }, () => ok(t)); t.once("error", no); t.setTimeout(10000, () => { const e = new Error("SMTP: časovna omejitev"); e.code = "ETIMEDOUT"; no(e); t.destroy(e); }); });
        attach(sock);
        await cmd("EHLO higifood.local", "250");
      }
      if (c.uporabnik) { faza("prijava"); await cmd("AUTH LOGIN", "334"); await cmd(b64(c.uporabnik), "334"); await cmd(b64(c.geslo || ""), "235"); }
      faza("posiljatelj"); await cmd("MAIL FROM:<" + addr + ">", "250");
      faza("prejemnik"); await cmd("RCPT TO:<" + to + ">", "25");
      faza("vsebina"); await cmd("DATA", "354");
      const msg = ["From: " + fromGlava, "To: " + to, "Subject: =?UTF-8?B?" + b64(subject) + "?=", "MIME-Version: 1.0", "Content-Type: text/plain; charset=utf-8", "Content-Transfer-Encoding: base64", "", b64(text).replace(/(.{76})/g, "$1\r\n")].join("\r\n");
      await cmd(msg + "\r\n.", "250");
      // vljuden zaključek: počakaj na »221« (največ 2 s), nato zapri; takojšnja prekinitev nekateri strežniki štejejo kot napako
      const quit = cmd("QUIT", "221").catch(() => {}); await Promise.race([quit, new Promise(r => setTimeout(r, 2000))]);
    } finally { try { sock.destroy(); } catch {} }
  }
  // pošiljanje posameznega sporočila (ponastavitev gesla, povabilo); napaka, če e-pošta ni nastavljena
  async function posljiPosto(to, zadeva, besedilo) {
    const c = nast(); if (!postaNastavljena(c)) throw new Error("E-pošta ni nastavljena v Administraciji.");
    if (TESTNO) return; // testni način ne pošilja
    await smtpSend(c, to, zadeva, besedilo);
  }
  // enkratni žetoni za nastavitev gesla (pozabljeno geslo, povabilo): hrani se samo zgoščenka
  const ZF = path.join(DIR, "_zetoni.json");
  const beriZetone = () => { try { return S.beri(ZF).filter(z => z.velja_do > Date.now()); } catch { return []; } };
  function novZeton(u, namen, ure) {
    const t = crypto.randomBytes(32).toString("base64url");
    const l = beriZetone().filter(z => z.uid !== u.id); l.push({ h: sh(t), uid: u.id, namen, velja_do: Date.now() + ure * 3600e3 });
    S.pisi(ZF, l); return t;
  }
  const najdiZeton = t => t ? beriZetone().find(z => z.h === sh(String(t))) || null : null;
  const porabiZeton = z => S.pisi(ZF, beriZetone().filter(x => x.uid !== z.uid));
  const povezavaGeslo = t => { const a = (nast().naslov_aplikacije || "").trim().replace(/\/+$/, ""); if (!/^https?:\/\//.test(a)) throw new Error("V nastavitvah e-pošte vpišite »Naslov aplikacije v sporočilu« (npr. https://haccp.vasa-domena.si)."); return a + "/#/geslo/" + t; };
  async function posljiPovabilo(u, kdo) {
    const t = novZeton(u, "povabilo", 7 * 24), sm = Object.fromEntries(load("stranke").map(s => [s.id, s.naziv]));
    const vloge = { admin: "administrator", svetovalec: "HACCP-svetovalec", odgovorna: "odgovorna oseba", zaposleni: "zaposleni" };
    await posljiPosto(u.email, "Povabilo v HiGiFood HACCP", "Pozdravljeni" + (u.ime && u.ime !== u.email ? " " + u.ime : "") + ",\n\n" + (kdo ? kdo.ime + " vas je povabil(a)" : "povabljeni ste") + " v HiGiFood HACCP (" + vloge[u.vloga] + (u.stranka_id && sm[u.stranka_id] ? ", " + sm[u.stranka_id] : "") + ").\n\nGeslo si nastavite na tej povezavi (velja 7 dni):\n" + povezavaGeslo(t) + "\n\nVaš e-naslov za prijavo: " + u.email + "\n");
  }
  // koledarski dnevi po lokalnem času (privzeto Europe/Ljubljana, HACCP_TZ), ne po UTC: zapis ob 00:30 je današnji
  const TZ = process.env.HACCP_TZ || "Europe/Ljubljana", DAN_F = new Intl.DateTimeFormat("sv-SE", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" });
  const lokDanS = s => { if (!s) return ""; s = String(s); if (s.length <= 10) return s; const d = new Date(s); return isNaN(d) ? s.slice(0, 10) : DAN_F.format(d); };
  const danesS = () => DAN_F.format(new Date());
  const dTo = s => s ? Math.round((Date.parse(String(s).slice(0, 10) + "T00:00:00Z") - Date.parse(danesS() + "T00:00:00Z")) / 864e5) : null;
  // imena vrst evidenc za opomnike – iz iste datoteke kot v aplikaciji (portal/m-evidence.js), da se ne razideta
  const EV_IMENA = (() => { const o = {}; try { const t = fs.readFileSync(path.join(__dirname, "portal", "m-evidence.js"), "utf8"), re = /^  (\w+): \{ ime: "([^"]+)"/mg; let m; while ((m = re.exec(t))) o[m[1]] = m[2]; } catch {} return o; })();
  function dueItems() {
    const L = [], sm = Object.fromEntries(load("stranke").map(s => [s.id, s.naziv]));
    const add = (d, tip, naslov, sid, pre) => { if (d) L.push({ datum: String(d).slice(0, 10), tip, naslov, sid, pre: pre === undefined ? 7 : pre, stranka: sm[sid] || "" }); };
    for (const s of load("stranke")) add(s.naslednji_pregled, "Pregled", "Pregled stranke: " + s.naziv, s.id);
    for (const n of load("nacrti")) if (n.status !== "zastarelo") add(n.naslednji_pregled, "Pregled", "Pregled HACCP načrta: " + n.naziv, n.stranka_id);
    for (const n of load("navodila")) if (n.status !== "zastarelo") add(n.naslednji_pregled, "Pregled", "Pregled navodila: " + n.naslov, n.stranka_id);
    for (const o of load("osebje")) { add(o.higienski_do, "Izobraževanje", "Poteče izobraževanje: " + o.ime, o.stranka_id); add(o.zdravniski_do, "Zdravniški pregled", "Poteče zdravniški pregled: " + o.ime, o.stranka_id); }
    for (const u of load("usposabljanja")) add(u.veljavno_do, "Usposabljanje", "Poteče usposabljanje: " + u.tema, u.stranka_id);
    for (const o of load("oprema")) add(o.naslednji_servis, "Oprema", "Servis/umerjanje: " + o.naziv, o.stranka_id);
    for (const o of load("dobavitelji")) add(o.naslednja_ocena, "Dobavitelj", "Ocena dobavitelja: " + o.naziv, o.stranka_id);
    for (const c of load("capa")) if (c.status !== "zaprto") add(c.rok, "CAPA", "Rok ukrepa CAPA: " + String(c.opis || "").slice(0, 70), c.stranka_id, 3);
    { const ev = load("evidence"); for (const n of load("ciscenje_nacrt")) { if (n.aktivno === false || !(+n.pogostost_dni > 0)) continue; const last = ev.filter(e => e.vrsta === "ciscenje" && e.nacrt_id === n.id && e.izvedeno).map(e => lokDanS(e.cas)).sort().pop(); let next; if (last) { const d = new Date(last + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + (+n.pogostost_dni)); next = d.toISOString().slice(0, 10); } else next = n.zacetek || String(n.ustvarjeno || "").slice(0, 10); add(next, "Čiščenje", "Čiščenje: " + (n.podrocje ? n.podrocje + " – " : "") + n.opravilo, n.stranka_id, 0); } }
    for (const k of load("kemikalije")) add(k.rok_uporabe, "Čistilo", "Poteče rok uporabe čistila: " + k.naziv, k.stranka_id, 14);
    for (const e of load("dogodki")) if (e.status !== "opravljeno") add(e.datum, e.vrsta || "Dogodek", e.naslov, e.stranka_id, e.opomnik_dni === undefined || e.opomnik_dni === "" ? 3 : +e.opomnik_dni);
    // naprava se ujema tudi s prejšnjimi imeni (preimenovanje ne sme izbrisati zgodovine vnosov)
    { const ev = load("evidence"), today = danesS(), imena = (sid, n) => { const o = load("oprema").find(x => x.stranka_id === sid && x.naziv === n); return new Set([n, ...((o && o.prejsnja_imena) || [])]); };
      for (const u of load("urnik")) { if (!(+u.frekvenca_ur > 0)) continue; const im = u.naprava ? imena(u.stranka_id, u.naprava) : null; const last = ev.filter(e => e.vrsta === u.vrsta && e.stranka_id === u.stranka_id && (!u.naprava || im.has(e.oprema) || im.has(e.izdelek)) && (!u.obrat_id || e.obrat_id === u.obrat_id)).map(e => e.cas).sort().pop(); const hrs = last ? (Date.now() - new Date(last)) / 36e5 : Infinity; if (hrs > +u.frekvenca_ur) add(today, "Manjka vnos", "Manjka vnos »" + (EV_IMENA[u.vrsta] || u.vrsta) + "«" + (u.naprava ? " – " + u.naprava : "") + (last ? " (zadnji pred " + Math.round(hrs) + " h, dovoljeno " + u.frekvenca_ur + " h)" : " (še ni vnosa)"), u.stranka_id, 0); } }
    { const meja = new Date(Date.now() - 7 * 864e5).toISOString(); for (const st of load("stranke")) if (!NAR.zaklenjeno(st.id, "umiki")) for (const n of umikiZa(st.id)) if (n.zadetki.length && n.cas_prejema > meja) add(danesS(), "Umik / odpoklic", "Možen umik/odpoklic: " + n.naslov + " (" + n.zadetki.slice(0, 3).join(", ") + ")", st.id, 0); }
    return L;
  }
  function digests() { // prejemniki → seznam postavk (poteklo ali v opomniku)
    const per = {}, users = load("uporabniki").filter(u => u.aktiven !== false);
    const izklop = new Set(load("stranke").filter(s => s.opomniki_izklop === true).map(s => s.id));
    for (const it of dueItems()) {
      const n = dTo(it.datum); if (n === null || n > it.pre || izklop.has(it.sid)) continue;
      it.vnos = it.tip === "Manjka vnos" || it.tip === "Čiščenje"; // manjkajoči dnevni vnosi
      it.obv = it.tip === "Umik / odpoklic"; // obvestila (umiki) gredo vedno, razen ob izklopu opomnikov
      const rec = new Set();
      for (const u of users) if (((u.vloga === "odgovorna" && u.stranka_id === it.sid) || (u.vloga === "svetovalec" && (u.stranke || []).includes(it.sid))) && (it.obv || opomnikiOf(u)[it.vnos ? "vnosi" : "roki"] !== false) && (!it.obv || vidno(u, "umiki"))) rec.add(u.email); // umik ne gre tistemu, ki mu je razdelek Umiki skrit
      for (const e of rec) (per[e] = per[e] || []).push(Object.assign({ n }, it));
    }
    try { const adm = users.filter(x => x.vloga === "admin"); for (const it of NAR.opomniki()) for (const u of adm) (per[u.email] = per[u.email] || []).push({ n: it.dni, datum: it.datum, naslov: it.naslov, obv: true }); } catch {}
    try { const op = stanjeSistema().opozorila; if (op.length) for (const u of users.filter(x => x.vloga === "admin")) for (const t of op) (per[u.email] = per[u.email] || []).push({ n: 0, datum: danesS(), naslov: "Sistem: " + t, obv: true }); } catch {}
    return per;
  }
  // ---------- obvestila o umikih in odpoklicih živil (viri RSS/Atom, ki jih določi administrator, in ročni vnos) ----------
  const UF = path.join(DIR, "_umiki.json"), UN = path.join(DIR, "_umiki-viri.json");
  const rjson = (f, d) => { try { return S.beri(f, d); } catch { return d; } };
  const nrm = x => String(x || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const strip = x => String(x || "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/\s+/g, " ").trim();
  // privzeti viri (dokler administrator ne nastavi svojih): seznam »Nevarni in neskladni izdelki« na gov.si (UVHVVR, ZIRS, TIRS) + RASFF
  const PRIVZETI_VIRI = [{ ime: "UVHVVR / MKGP – Nevarni in neskladni izdelki (gov.si)", url: "https://www.gov.si/podrocja/podjetnistvo-in-gospodarstvo/varstvo-potrosnikov-in-konkurence/nevarni-in-neskladni-izdelki/" }];
  // spletna stran brez RSS: povezave na podstrani seznama (ali na obvestila »nevarni-in-neskladni-izdelki«)
  function parseStran(html, url) {
    const baza = new URL(url), out = [], videno = new Set();
    for (const m of String(html).matchAll(/<a\s[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi)) {
      let u; try { u = new URL(m[1], baza); } catch { continue; }
      const pod = u.pathname.startsWith(baza.pathname) && u.pathname.replace(/\/$/, "") !== baza.pathname.replace(/\/$/, ""), obv = /\/nevarni-in-neskladni-izdelki\/[^/]+/.test(u.pathname);
      if (u.host !== baza.host || !(pod || obv) || videno.has(u.href)) continue;
      const naslov = strip(m[2]); if (naslov.length < 4) continue; videno.add(u.href);
      out.push({ naslov: naslov.slice(0, 300), povezava: u.href, opis: "", objavljeno: "", guid: u.href });
    }
    return out;
  }
  function parseFeed(xml) {
    const out = [];
    for (const m of String(xml).matchAll(/<(item|entry)[\s>][\s\S]*?<\/\1>/gi)) {
      const b = m[0], tag = n => { const r = new RegExp("<" + n + "[^>]*>([\\s\\S]*?)</" + n + ">", "i").exec(b); return r ? strip(r[1]) : ""; };
      let link = tag("link"); if (!link) { const h = /<link[^>]*href=["']([^"']+)["']/i.exec(b); link = h ? h[1] : ""; }
      const naslov = tag("title"); if (!naslov) continue;
      out.push({ naslov, povezava: /^https?:\/\//i.test(link) ? link : "", opis: (tag("description") || tag("summary") || tag("content")).slice(0, 1500), objavljeno: tag("pubDate") || tag("published") || tag("updated") || tag("dc:date"), guid: tag("guid") || tag("id") || link || naslov });
    }
    return out;
  }
  let umikiStanje = { cas: "", napaka: "" };
  // RASFF Window (EU): neuradni, nedokumentiran backend endpoint; privzeto vklopljen (izklop v nastavitvah virov). Dnevni uvoz, 15 s timeout, 3 poskusi.
  const UR = path.join(DIR, "_umiki-rasff.json");
  const RASFF_URL = () => process.env.HACCP_RASFF_URL || "https://webgate.ec.europa.eu/rasff-window/backend/public/notification/search/consolidated/en/";
  const rasffNast = () => Object.assign({ vklopljeno: true, klasifikacija: [306], izvor: [5075], zadnje: "" }, rjson(UR, {})); // privzeto vklopljen (izklop v Umiki → Viri)
  const rtxt = v => v == null ? "" : typeof v === "string" ? v.trim() : typeof v === "number" ? String(v) : Array.isArray(v) ? v.map(rtxt).filter(Boolean).join(", ") : typeof v === "object" ? rtxt(v.description || v.name || v.label || v.title || v.value || v.code) : "";
  const rget = (o, keys) => { const lo = {}; for (const k of Object.keys(o)) lo[k.toLowerCase()] = o[k]; for (const k of keys) { const v = lo[k.toLowerCase()]; if (v !== undefined && v !== null && v !== "") return v; } return null; };
  function rasffItems(j) {
    if (Array.isArray(j)) return j.filter(x => x && typeof x === "object");
    const q = [j]; for (let d = 0; d < 3 && q.length; d++) { const nx = []; for (const n of q) { if (!n || typeof n !== "object") continue; for (const k of ["notifications", "notificationList", "content", "items", "results", "data", "rows"]) if (Array.isArray(n[k])) return n[k].filter(x => x && typeof x === "object"); for (const v of Object.values(n)) { if (Array.isArray(v) && v.length && v.every(x => x && typeof x === "object")) return v; if (v && typeof v === "object") nx.push(v); } } q.length = 0; q.push(...nx); }
    return [];
  }
  async function rasffKlic(c) {
    let zadnja = null;
    for (let i = 1; i <= 3; i++) {
      try {
        const r = await fetch(RASFF_URL(), { method: "POST", signal: AbortSignal.timeout(15000), headers: { "Content-Type": "application/json", Accept: "application/json", "User-Agent": "MojaPlatforma/1.0" }, body: JSON.stringify({ parameters: { pageNumber: 1, itemsPerPage: 50 }, notificationClassification: c.klasifikacija, originCountry: c.izvor }) });
        if (!r.ok) { const e = new Error("HTTP " + r.status); e.trajno = r.status < 500 && r.status !== 429 && r.status !== 408; throw e; }
        return await r.json();
      } catch (e) { zadnja = e; if (e.trajno || i === 3) break; await new Promise(res => setTimeout(res, 1000 * 2 ** (i - 1))); }
    }
    throw zadnja;
  }
  async function osveziRasff(force) {
    const c = rasffNast(); if (!c.vklopljeno) return { novih: 0, napaka: "" };
    if (!force && c.zadnje && Date.now() - new Date(c.zadnje).getTime() < 20 * 36e5) return { novih: 0, napaka: "" };
    const vsi = rjson(UF, []), have = new Set(vsi.map(x => x.kljuc)); let novih = 0;
    const j = await rasffKlic(c);
    for (const it of rasffItems(j)) {
      const ref = rtxt(rget(it, ["reference", "notificationReference", "ecReference", "number"])) || rtxt(rget(it, ["notificationId", "id"])); if (!ref) continue;
      const kljuc = "rasff|" + ref; if (have.has(kljuc)) continue; have.add(kljuc);
      const id = rtxt(rget(it, ["notificationId", "id"])), subj = rtxt(rget(it, ["subject", "title", "description"])) || ("RASFF " + ref);
      const dt = rget(it, ["validationDate", "validatedOn", "ecValidationDate", "validatedAt", "notificationDate", "date"]), d = dt ? new Date(dt) : null;
      vsi.push({ id: uid(), kljuc, vir: "RASFF", cas_prejema: now(), naslov: subj.slice(0, 300) + " (RASFF " + ref + ")", povezava: /^\d+$/.test(id) ? "https://webgate.ec.europa.eu/rasff-window/screen/notification/" + id : "", opis: [rtxt(rget(it, ["productCategory", "category", "productType"])), rtxt(rget(it, ["riskDecision", "risk", "riskLevel"])) && "tveganje: " + rtxt(rget(it, ["riskDecision", "risk", "riskLevel"])), rtxt(rget(it, ["originCountries", "originCountry", "origin"])) && "izvor: " + rtxt(rget(it, ["originCountries", "originCountry", "origin"]))].filter(Boolean).join("; "), objavljeno: d && !isNaN(d) ? d.toISOString().slice(0, 10) : "" });
      prevediSlovar(vsi[vsi.length - 1]);
      novih++;
    }
    vsi.sort((a, b) => b.cas_prejema.localeCompare(a.cas_prejema)); S.pisi(UF, vsi.slice(0, 500));
    c.zadnje = now(); S.pisi(UR, c); return { novih, napaka: "" };
  }
  // prevod obvestil RASFF v slovenščino (glej prevod.js): izvirnik ostane v »izvirnik«, naslov in opis sta prevedena
  const PREV = require("./prevod");
  function prevediSlovar(n) {
    if (!n.izvirnik) { const m = /^([\s\S]*?)\s*(\(RASFF [^)]*\))$/.exec(n.naslov || ""); n.izvirnik = { naslov: m ? m[1] : n.naslov || "", opis: n.opis || "", ref: m ? m[2] : "" }; }
    n.naslov = (PREV.slovarNaslov(n.izvirnik.naslov) + " " + n.izvirnik.ref).trim().slice(0, 400); n.opis = PREV.izrazi(n.izvirnik.opis); n.prevod = "slovar";
  }
  // DeepL (če je nastavljen DEEPL_KLJUC) prevede obvestila, ki so prevedena samo s slovarjem; največ 100 na osvežitev
  async function prevediRasff(napake) {
    const vsi = rjson(UF, []); let sprem = false;
    for (const n of vsi) if (n.vir === "RASFF" && !n.prevod) { prevediSlovar(n); sprem = true; }
    const cak = vsi.filter(n => n.vir === "RASFF" && n.prevod === "slovar").slice(0, 100);
    if (cak.length && PREV.nacin() === "deepl") {
      try {
        const t = await PREV.deepl(cak.flatMap(n => [n.izvirnik.naslov, n.izvirnik.opis || "-"]));
        cak.forEach((n, i) => { n.naslov = (t[2 * i] + " " + n.izvirnik.ref).trim().slice(0, 400); n.opis = n.izvirnik.opis ? t[2 * i + 1] : ""; n.prevod = "deepl"; }); sprem = true;
      } catch (e) { napake.push("Prevod DeepL: " + prijazno(e) + " – obvestila so prevedena s slovarjem"); }
    }
    if (sprem) S.pisi(UF, vsi);
  }
  // razumljivo sporočilo o napaki omrežja ali e-pošte (tehnični razlog ostane v oklepaju)
  function prijazno(e) {
    if (e && e.smtp) return e.message; // smtpSend je napako že razložil (smtpRazlozi)
    const c = (e && e.cause) || {}, koda = String(c.code || (e && e.code) || ""), msg = String((e && e.message) || e || ""), vse = koda + " " + msg + " " + (c.message || "");
    const r = /ENOTFOUND|EAI_AGAIN/.test(vse) ? "strežnika ni mogoče najti – preverite naslov in internetno povezavo"
      : /ECONNREFUSED/.test(vse) ? "strežnik je zavrnil povezavo – preverite naslov in vrata"
      : /ETIMEDOUT|TimeoutError|AbortError|aborted due to timeout|timeout|časovna omejitev/i.test(vse) ? "strežnik se ni odzval pravočasno – poskusite znova kasneje"
      : /ECONNRESET|EPIPE|socket hang up/i.test(vse) ? "povezava je bila prekinjena – poskusite znova"
      : /CERT|certificate|self.signed|SSL|TLS/i.test(vse) ? "težava s certifikatom TLS strežnika"
      : /^5(35|34)\b|\b535\b|authentication|auth/i.test(msg) ? "prijava na poštni strežnik ni uspela – preverite uporabniško ime in geslo"
      : /\b55[0-4]\b|recipient|mailbox/i.test(msg) ? "poštni strežnik je zavrnil prejemnika – preverite e-poštni naslov"
      : /^HTTP (\d+)/.test(msg) ? "vir je vrnil napako " + msg.slice(5) : "";
    return r ? r + " (" + (koda && !msg.includes(koda) ? koda + ": " : "") + msg + ")" : msg;
  }
  async function osveziUmike(force) {
    const viri = rjson(UN, PRIVZETI_VIRI), vsi = rjson(UF, []), have = new Set(vsi.map(x => x.kljuc)); let novih = 0; const napake = [];
    for (const v of viri) {
      if (!/^https?:\/\//i.test(v.url || "")) continue;
      try {
        const r = await fetch(v.url, { signal: AbortSignal.timeout(20000), headers: { "User-Agent": "HiGiFood-HACCP" } }); if (!r.ok) throw new Error("HTTP " + r.status);
        const txt = await r.text(), feed = parseFeed(txt);
        for (const it of (feed.length || !/<html/i.test(txt) ? feed : parseStran(txt, v.url)).slice(0, 100)) { const kljuc = v.url + "|" + it.guid; if (have.has(kljuc)) continue; have.add(kljuc); vsi.push({ id: uid(), kljuc, vir: v.ime || v.url, cas_prejema: now(), naslov: it.naslov, povezava: it.povezava, opis: it.opis, objavljeno: it.objavljeno }); novih++; }
      } catch (e) { napake.push((v.ime || v.url) + ": " + prijazno(e)); }
    }
    vsi.sort((a, b) => b.cas_prejema.localeCompare(a.cas_prejema)); S.pisi(UF, vsi.slice(0, 500));
    try { novih += (await osveziRasff(force)).novih; } catch (e) { napake.push("RASFF: " + prijazno(e)); }
    try { await prevediRasff(napake); } catch (e) { napake.push("Prevod: " + prijazno(e)); }
    umikiStanje = { cas: now(), napaka: napake.join("; ") }; return { novih, napake };
  }
  function umikiZa(sid) { // obvestila, ki omenjajo izdelke, šarže ali dobavitelje te stranke
    // ujemanje po celih besedah (»Mleko« ne zadene »mlekarna«, šarža LOT-1 ne zadene LOT-12 ali LOT-1/2026); pravna oblika dobavitelja se ne upošteva
    const besede = x => " " + nrm(x).replace(/[^a-z0-9]+/g, " ").trim() + " ";
    // šarže in EAN: »/« in ».« v sredini sta del oznake (LOT-1/2026 ≠ LOT-1), ločilo na koncu stavka ni
    const besedeS = x => " " + nrm(x).replace(/[^a-z0-9/.]+/g, " ").replace(/[/.]+(?= |$)/g, "").replace(/(^| )[/.]+/g, " ").trim() + " ";
    const tok = new Map(), tokS = new Map();
    const add = (t, o, min, brezOblike) => { let k = besede(t).trim(); if (brezOblike) k = k.replace(/(\s+(d o o|d d|s p|d n o|k d|z o o|gmbh|ltd|srl|s r l|spa|s p a|ag|sa|kg|doo))+$/, "").trim(); if (k.replace(/ /g, "").length >= min && !tok.has(k)) tok.set(k, o); };
    const addS = (t, o) => { const k = besedeS(t).trim(); if (k.replace(/ /g, "").length >= 2 && !tokS.has(k)) tokS.set(k, o); }; // tudi kratke šarže (A12) – so najbolj natančen podatek
    for (const x of load("sarze").filter(x => x.stranka_id === sid)) { addS(x.ean, "EAN " + x.ean); addS(x.sarza, "šarža " + x.sarza); add(x.izdelek, "izdelek " + x.izdelek, 4); }
    for (const x of load("dobavitelji").filter(x => x.stranka_id === sid)) add(x.naziv, "dobavitelj " + x.naziv, 3, true);
    for (const x of load("jedi").filter(x => x.stranka_id === sid)) for (const p of String(x.sestavine || "").split(/[,;\n]/)) add(p, "sestavina " + p.trim(), 4);
    return rjson(UF, []).map(n => {
      const bes = n.naslov + " " + n.opis + (n.izvirnik ? " " + n.izvirnik.naslov + " " + n.izvirnik.opis : ""); // ujemanje tudi z angleškim izvirnikom
      const t = besede(bes), tS = besedeS(bes), z = [];
      for (const [k, o] of tokS) if (tS.includes(" " + k + " ") && !z.includes(o)) z.push(o);
      for (const [k, o] of tok) if (t.includes(" " + k + " ") && !z.includes(o)) z.push(o);
      return Object.assign({}, n, { kljuc: undefined, zadetki: z });
    });
  }
  setTimeout(() => osveziUmike().catch(() => {}), 90e3).unref();
  setInterval(() => osveziUmike().catch(() => {}), 6 * 3600e3).unref();
  // ---------- nastavitve vidnosti (admin določi, kaj vidita "Stranka" = zaposleni stranke in odgovorna oseba; privzeto + po stranki) ----------
  const VF = path.join(DIR, "_vidnost.json");
  const MODULI = [
    ["danes", "Danes (opravila)", "Meni platforme"], ["umiki", "Umiki in odpoklici", "Meni platforme"], ["koledar", "Koledar in roki", "Meni platforme"], ["pregled-zapisov", "Pregled zapisov", "Meni platforme"], ["obrazci", "Obrazci za tisk", "Meni platforme"], ["uvoz", "Uvoz podatkov", "Meni platforme"], ["kos", "Koš (izbrisano)", "Meni platforme"], ["generator", "Generator dokumentacije", "Generator"],
    ["tab:obrati", "Obrati", "Zavihki v profilu stranke"], ["tab:tloris", "Tloris", "Zavihki v profilu stranke"], ["tab:osebje", "Zaposleni in usposabljanja", "Zavihki v profilu stranke"], ["tab:dobavitelji", "Dobavitelji", "Zavihki v profilu stranke"], ["tab:oprema", "Oprema in instrumenti", "Zavihki v profilu stranke"], ["tab:nacrti", "HACCP načrti", "Zavihki v profilu stranke"], ["tab:navodila", "Navodila in obrazci", "Zavihki v profilu stranke"], ["tab:evidence", "Evidence", "Zavihki v profilu stranke"], ["tab:higiena", "Higiena", "Zavihki v profilu stranke"], ["tab:capa", "Neskladnosti / CAPA", "Zavihki v profilu stranke"], ["tab:inspekcija", "Inšpekcija", "Zavihki v profilu stranke"], ["tab:koledar", "Koledar (zavihek)", "Zavihki v profilu stranke"], ["tab:priloge", "Priloge", "Zavihki v profilu stranke"], ["tab:potrditve", "Potrditve in različice", "Zavihki v profilu stranke"], ["tab:sledljivost", "Sledljivost", "Zavihki v profilu stranke"], ["tab:alergeni", "Alergeni in jedilnik", "Zavihki v profilu stranke"], ["tab:certifikacija", "Certifikacija", "Zavihki v profilu stranke"], ["tab:storitve", "Storitve", "Zavihki v profilu stranke"], ["tab:uporabniki", "Uporabniki", "Zavihki v profilu stranke"]
  ].map(m => ({ id: m[0], label: m[1], skupina: m[2] }));
  const MODUL_IDS = new Set(MODULI.map(m => m.id));
  // zbirka podatkov je dostopna, če je viden vsaj en modul, ki jo uporablja
  const ZBIRKA_MODULI = {
    evidence: ["tab:evidence", "tab:higiena", "danes", "pregled-zapisov", "tab:inspekcija", "obrazci"], osebje: ["tab:osebje", "tab:evidence", "tab:higiena", "tab:inspekcija", "obrazci"], usposabljanja: ["tab:osebje", "tab:inspekcija", "obrazci"],
    dobavitelji: ["tab:dobavitelji", "tab:sledljivost", "tab:evidence", "tab:inspekcija"], oprema: ["tab:oprema", "tab:evidence", "tab:higiena", "obrazci", "tab:inspekcija", "tab:nacrti"],
    nacrti: ["tab:nacrti", "tab:inspekcija", "tab:potrditve", "tab:navodila"], navodila: ["tab:navodila", "tab:potrditve", "tab:inspekcija", "tab:nacrti"], capa: ["tab:capa", "tab:sledljivost", "danes", "tab:inspekcija"],
    ciscenje_nacrt: ["tab:higiena", "danes", "obrazci", "tab:inspekcija"], vabe: ["tab:higiena", "tab:inspekcija"], kemikalije: ["tab:higiena", "tab:inspekcija"], tlorisi: ["tab:tloris", "tab:inspekcija", "tab:nacrti"],
    sarze: ["tab:sledljivost"], jedi: ["tab:alergeni"], certifikacija: ["tab:certifikacija"], dogodki: ["tab:koledar", "koledar"], storitve: ["tab:storitve"], urnik: ["tab:evidence", "danes"],
    priloge: ["tab:priloge", "tab:capa", "tab:evidence", "tab:inspekcija", "tab:navodila"]
  };
  const vidnost = () => Object.assign({ privzeto: {}, stranke: {} }, rjson(VF, {}));
  const VLOGA_KLJUC = { zaposleni: "stranka", odgovorna: "odgovorna" };
  const SISTEMSKO_SKRITO = { "tab:certifikacija": ["stranka"], "tab:potrditve": ["stranka"], "generator": ["stranka"], "tab:inspekcija": ["stranka"] }; // privzeto za zaposlene (preprostejši meni)
  // plačljivi paketi: modul, ki ga paket stranke ne vsebuje, je za njene uporabnike zaklenjen (glej narocnine.js)
  const NAR = require("./narocnine")({ DIR, S, load, audit, send, bad, jbody, tenantOk, now, uid, osveziPodatke: () => { spremembeOdKopije = true; }, moduli: MODULI.map(m => m.id), obPaketu: (sid, id) => { const st = load("stranke").find(x => x.id === sid); if (st && (st.paket || "") !== (id || "")) { st.paket = id || ""; save("stranke"); } } });
  // starejši podatki: administrator ali svetovalec, vezan na stranko (prek skritega polja obrazca), ne sme biti vezan nanjo
  { let n = 0; for (const u of load("uporabniki")) if (!["odgovorna", "zaposleni"].includes(u.vloga) && u.stranka_id) { u.stranka_id = null; n++; } if (n) save("uporabniki"); }
  // »Paket storitev« stranke je izbira paketa (id); starejši prosti vnosi se ob zagonu prenesejo: ime paketa → id, ostalo v interne opombe
  (function paketiStrank() {
    let sp = 0; const pk = NAR.paketi();
    for (const st of load("stranke")) {
      const nar = NAR.narocninaPaket(st.id); // naročnina je vir podatka: paket v profilu stranke jo zrcali
      if (nar !== undefined && st.paket !== nar) { st.paket = nar; sp++; continue; }
      if (st.paket === undefined || st.paket === null || st.paket === "" || pk.some(x => x.id === st.paket)) continue;
      const po = pk.find(x => x.ime.toLowerCase() === String(st.paket).trim().toLowerCase());
      if (po) st.paket = po.id; else { st.notranje = [st.notranje, `Prejšnji vnos »Paket storitev«: ${st.paket}`].filter(Boolean).join("\n"); st.paket = ""; }
      sp++;
    }
    if (sp) { save("stranke"); console.log(`Paket storitev: prenos starejših vnosov strank (${sp}).`); }
  })();
  function vidno(u, modul, cfg, brezPaketa) { // admin in svetovalec vidita vse
    const k = VLOGA_KLJUC[u.vloga]; if (!k) return true;
    if (!brezPaketa && NAR.zaklenjeno(u.stranka_id, modul)) return false;
    cfg = cfg || vidnost();
    const po = cfg.stranke[u.stranka_id] && cfg.stranke[u.stranka_id][modul], pr = cfg.privzeto[modul];
    if (po && typeof po[k] === "boolean") return po[k];
    if (pr && typeof pr[k] === "boolean") return pr[k];
    return !(SISTEMSKO_SKRITO[modul] || []).includes(k);
  }
  function vidnoZaVlogo(vloga, sid, modul, cfg) { return vidno({ vloga, stranka_id: sid }, modul, cfg); }
  function modulZaPot(p) {
    const md = p.match(/^\/api\/d\/([a-z_]+)/); if (md) return ima(ZBIRKA_MODULI, md[1]) ? ZBIRKA_MODULI[md[1]] : null;
    if (p === "/api/umiki" || p.startsWith("/api/umiki/")) return ["umiki"];
    if (p === "/api/potrdi" || p === "/api/potrditve") return ["tab:potrditve"];
    if (p === "/api/kos" || p.startsWith("/api/kos/")) return ["kos"];
    if (p === "/api/priloga" || p.startsWith("/api/priloga/")) return ZBIRKA_MODULI.priloge; // nastavitve vidnosti veljajo tudi za neposredne poti
    if (p === "/api/uporabniki" || p.startsWith("/api/uporabniki/")) return ["tab:uporabniki"];
    return null;
  }
  const SENT = path.join(DIR, "_obvestila.json");
  // besedilo opomnika po skupinah: roki v zamudi, roki danes in kmalu, manjkajoči vnosi
  function besediloOpomnika(items) {
    const vr = i => `- ${i.n < 0 ? "zamuda " + -i.n + " d" : i.n === 0 ? "danes" : "čez " + i.n + " d"} (${i.datum}): ${i.naslov}${i.stranka ? " [" + i.stranka + "]" : ""}`;
    const sk = [["OBVESTILA", items.filter(i => i.obv)], ["ROKI V ZAMUDI", items.filter(i => !i.vnos && !i.obv && i.n < 0)], ["ROKI DANES IN V NASLEDNJIH DNEH", items.filter(i => !i.vnos && !i.obv && i.n >= 0)], ["MANJKAJOČI VNOSI EVIDENC", items.filter(i => i.vnos)]].filter(x => x[1].length);
    return "Pozdravljeni,\n\nopomnik HiGiFood HACCP:\n\n" + sk.map(([n, a]) => n + " (" + a.length + ")\n" + a.map(vr).join("\n")).join("\n\n") + "\n\nPogostost in vrsto opomnikov nastavite v aplikaciji: Moj račun (klik na svoje ime) → E-poštni opomniki.\n\nHiGiFood HACCP";
  }
  async function posljiObvestila(force) {
    const c = nast(), per = digests(), out = { prejemniki: Object.keys(per).length, poslano: 0, napake: [], predogled: [] };
    let sent = {}; try { sent = S.beri(SENT); } catch {}
    const day = danesS(), ponedeljek = new Date(day + "T12:00:00Z").getUTCDay() === 1, users = load("uporabniki");
    for (const [to, items] of Object.entries(per)) {
      const u = users.find(x => x.email === to), po = u ? opomnikiOf(u).pogostost : "dnevno";
      items.sort((a, b) => a.n - b.n);
      const text = besediloOpomnika(items);
      out.predogled.push({ komu: to, postavk: items.length, tekst: items.map(i => i.naslov), pogostost: po, besedilo: text });
      if (po === "izklop" || (po === "tedensko" && !ponedeljek)) continue; // tudi ročno pošiljanje (»Pošlji zdaj«) upošteva nastavitev prejemnika
      if (TESTNO || !postaNastavljena(c) || c.vklopljeno === false) continue;
      const key = to + "|" + day;
      if (sent[key] && !force) continue;
      try { await smtpSend(c, to, "HiGiFood HACCP: opomnik (" + items.length + ")", text); sent[key] = 1; out.poslano++; } catch (e) { out.napake.push(to + ": " + prijazno(e)); }
    }
    for (const k of Object.keys(sent)) if (k.split("|")[1] < new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10)) delete sent[k];
    S.pisi(SENT, sent);
    return out;
  }
  setTimeout(() => posljiObvestila().catch(() => {}), 60e3).unref();
  setInterval(() => posljiObvestila().catch(() => {}), 3600e3).unref();



  // ---------- strežniška ocena skladnosti evidenc (pravila enaka kot v odjemalcu; odjemalčeva vrednost se prepiše) ----------
  const Nn = x => x === "" || x === undefined || x === null || isNaN(Number(x)) ? null : Number(x);
  function ocenaEvidence(o) {
    const range = () => { const v = Nn(o.vrednost), lo = Nn(o.min), hi = Nn(o.max); if (v === null || (lo === null && hi === null)) return null; return (lo === null || v >= lo) && (hi === null || v <= hi); };
    switch (o.vrsta) {
      case "temperatura": case "toplotna": case "drugo": return range();
      // števila primerjamo kot števila (»10« > »4«); brez mejnih vrednosti ocena ni mogoča
      case "prevzem": { const v = Nn(o.vrednost), hi = Nn(o.max); if (!(o.embalaza_ok && o.dokumenti_ok)) return false; if (hi === null) return v !== null ? null : true; return v === null || v <= hi; }
      case "hlajenje": { const v = Nn(o.vrednost), hi = Nn(o.max), t = Nn(o.trajanje), th = Nn(o.max_trajanje); if (hi === null && th === null) return null; return (hi === null || v === null || v <= hi) && (th === null || t === null || t <= th); }
      case "ciscenje": return !!(o.izvedeno && o.kontrola_ok);
      case "higiena": return ["osebna", "povrsine", "skladisce", "skodljivci", "odpadki", "roke"].every(k => o[k]);
      case "oprema": return !!(o.delovanje_ok && o.umerjeno_ok);
      case "sledljivost": return !!o.uspesno;
      case "ddd_obisk": return !!o.brez_znakov;
      case "zdravje": return !o.simptomi;
      case "skodljivci": return (Nn(o.stevilo) || 0) > 0 ? false : null;
      case "bris": { const r = []; if (Nn(o.sms) !== null && Nn(o.sms_meja) !== null) r.push(Nn(o.sms) <= Nn(o.sms_meja)); if (Nn(o.entero) !== null && Nn(o.entero_meja) !== null) r.push(Nn(o.entero) <= Nn(o.entero_meja)); if (o.listeria) r.push(o.listeria !== "zaznano"); if (o.salmonella) r.push(o.salmonella !== "zaznano"); return r.length ? r.every(Boolean) : null; }
      case "hitri_test": { if (o.kvalitativno) return o.kvalitativno !== "pozitiven"; return range(); }
      case "analiza": { if (o.kvalitativno) return o.kvalitativno === "ustreza"; return range(); }
      case "meritev_serije": { const r = []; for (const k of ["alkohol", "brix", "ph"]) { const v = Nn(o[k]), lo = Nn(o[k + "_min"]), hi = Nn(o[k + "_max"]); if (v !== null && (lo !== null || hi !== null)) r.push((lo === null || v >= lo) && (hi === null || v <= hi)); } return r.length ? r.every(Boolean) : null; }
      case "pregled_embalaze": return !!(o.ciste_ok && o.zapiralo_ok && o.etiketa_ok);
      default: return null;
    }
  }

  // preverjanje podatkov stranke (prazna polja so dovoljena); vrne opis napake ali null, davčno in matično številko normalizira
  const STATUS_SISTEMA = ["v pripravi", "v potrjevanju", "aktivna", "neaktivna"]; // enako kot portal/specs.js
  function preveriStranko(o) {
    // tipi in dolžine polj stranke (prej so »[object Object]« ali niz "true" prišli v profil)
    for (const [k, mx] of [["naziv", 300], ["kratko_ime", 100], ["naslov", 300], ["opis_dejavnosti", 5000], ["odgovorna_oseba", 200], ["email", 200], ["telefon", 60]]) {
      if (o[k] === undefined || o[k] === null) continue;
      if (typeof o[k] !== "string") return `Polje »${k}« mora biti besedilo.`;
      if (o[k].length > mx) return `Polje »${k}« je predolgo (največ ${mx} znakov).`;
    }
    if (o.email !== undefined) o.email = String(o.email).trim();
    if (o.dodatne_dejavnosti !== undefined && o.dodatne_dejavnosti !== "" && (!Array.isArray(o.dodatne_dejavnosti) || o.dodatne_dejavnosti.some(x => typeof x !== "string"))) return "Dodatne dejavnosti morajo biti seznam.";
    if (o.opomniki_izklop !== undefined) { if (o.opomniki_izklop === "true" || o.opomniki_izklop === "false") o.opomniki_izklop = o.opomniki_izklop === "true"; if (typeof o.opomniki_izklop !== "boolean" && o.opomniki_izklop !== "") return "Polje »opomniki_izklop« je da/ne."; }
    if (o.status !== undefined && o.status !== "" && !STATUS_SISTEMA.includes(o.status)) return "Neveljavno stanje HACCP sistema.";
    if (o.davcna !== undefined && String(o.davcna).trim() !== "") { const d = REG.preveriDavcno(o.davcna); if (!d) return "Davčna številka ni veljavna (8 števk s kontrolno števko)."; o.davcna = d; }
    if (o.maticna !== undefined && String(o.maticna).trim() !== "") { const m = String(o.maticna).replace(/\s/g, ""); if (!/^(\d{7}|\d{10})$/.test(m)) return "Matična številka mora imeti 7 ali 10 števk."; o.maticna = m; }
    if (o.email !== undefined && String(o.email).trim() !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(o.email).trim())) return "E-naslov ni v pravilni obliki (npr. ime@podjetje.si).";
    if (o.paket !== undefined && o.paket !== null && o.paket !== "" && !NAR.paketi().some(x => x.id === o.paket)) return "Paket storitev ne obstaja – izberite paket iz Naročnin.";
    if (o.telefon !== undefined && String(o.telefon).trim() !== "") { const t = String(o.telefon).trim(); if (!/^[0-9 +\/()-]+$/.test(t) || (t.match(/\d/g) || []).length < 6) return "Telefon lahko vsebuje samo števke, presledke, +, /, - in oklepaje (vsaj 6 števk)."; }
    return null;
  }

  // ---------- usmerjanje ----------
  async function handle(req, res, p, url) {
    if (!p.startsWith("/api/") || p === "/api/health") return false;
    const xff = req.headers["x-forwarded-for"];
    const ip = process.env.HACCP_PROXY === "1" && xff ? String(xff).split(",").pop().trim() : (req.socket.remoteAddress || "");
    const users = load("uporabniki");

    // --- javno: cenik za spletno stran (brez prijave) ---
    if (p === "/api/javno/cenik" && req.method === "GET") { send(res, 200, Object.assign(NAR.javniCenik(), { aplikacija: /^https:\/\//.test(process.env.HACCP_APLIKACIJA_URL || "") ? process.env.HACCP_APLIKACIJA_URL : "" })); return true; }
    // --- stanje / prva nastavitev ---
    if (p === "/api/auth/stanje" && req.method === "GET") { send(res, 200, { nastavljeno: users.length > 0, testno: TESTNO, verzija: o.verzija, racuni: TESTNO ? TEST_RACUNI.map(r => ({ email: r[0], vloga: r[1], opis: r[2] })).concat([]) : undefined, geslo: TESTNO ? TEST_GESLO : undefined }); return true; }
    if (p === "/api/auth/nastavi" && req.method === "POST") {
      if (users.length) { bad(res, 403, "Program je že nastavljen – prijavite se z obstoječim računom."); return true; }
      const b = await jbody(req, res); if (!b) return true;
      if (typeof b.email !== "string" || !/^\S+@\S+\.\S+$/.test(b.email) || !pwOk(b.geslo)) { bad(res, 400, "Vnesite veljaven e-naslov in geslo z vsaj 10 znaki."); return true; }
      const u = { id: uid(), email: b.email.trim().toLowerCase(), ime: String(b.ime || "Administrator").slice(0, 80), vloga: "admin", geslo: hashPw(b.geslo), aktiven: true, ustvarjeno: now() };
      users.push(u); save("uporabniki");
      audit(u, "nastavitev", "uporabniki", u.id, "prvi administrator", ip);
      return startSession(res, u), send(res, 200, pub(u)), true;
    }
    // pozabljeno geslo: vedno enak odgovor (ne razkrije, ali račun obstaja)
    if (p === "/api/auth/pozabljeno" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true;
      const em = String(b.email || "").trim().toLowerCase(), key = "pozab|" + ip;
      if (limited(key)) { bad(res, 429, "Preveč zahtev. Poskusite čez minuto."); return true; } fail(key);
      const c = nast(); if (!postaNastavljena(c) || !/^https?:\/\//.test(c.naslov_aplikacije || "")) { bad(res, 400, "Ponastavitev po e-pošti ni nastavljena. Obrnite se na administratorja."); return true; }
      const u = users.find(x => x.email === em && x.aktiven !== false);
      if (u) { try { posljiPosto(u.email, "Ponastavitev gesla – HiGiFood HACCP", "Pozdravljeni,\n\nza račun " + u.email + " v HiGiFood HACCP je bila zahtevana ponastavitev gesla.\nNovo geslo nastavite na tej povezavi (velja 1 uro):\n" + povezavaGeslo(novZeton(u, "ponastavitev", 1)) + "\n\nČe ponastavitve niste zahtevali, sporočilo prezrite – geslo ostane nespremenjeno.\n") // brez čakanja: odzivni čas ne razkrije, ali račun obstaja
        .then(() => audit(u, "geslo-pozabljeno", "uporabniki", u.id, "", ip), e => audit(u, "geslo-pozabljeno-napaka", "uporabniki", u.id, e.message.slice(0, 120), ip)); } catch (e) { audit(u, "geslo-pozabljeno-napaka", "uporabniki", u.id, e.message.slice(0, 120), ip); } }
      send(res, 200, { ok: true, sporocilo: "Če račun s tem e-naslovom obstaja, smo nanj poslali povezavo za nastavitev gesla (velja 1 uro)." }); return true;
    }
    if (p === "/api/auth/zeton" && req.method === "GET") {
      const z = najdiZeton(url.searchParams.get("t")), u = z && users.find(x => x.id === z.uid && x.aktiven !== false); // onemogočen račun: povezava ne velja
      if (!u) { bad(res, 404, "Povezava ni veljavna ali je potekla. Zahtevajte novo."); return true; }
      send(res, 200, { email: u.email, namen: z.namen }); return true;
    }
    if (p === "/api/auth/nastavi-geslo" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true; const key = "zeton|" + ip;
      if (limited(key)) { bad(res, 429, "Preveč poskusov. Poskusite čez minuto."); return true; }
      const z = najdiZeton(b.zeton), u = z && users.find(x => x.id === z.uid && x.aktiven !== false); // povezava ne aktivira onemogočenega računa
      if (!u) { fail(key); bad(res, 404, "Povezava ni veljavna ali je potekla. Zahtevajte novo."); return true; }
      if (!pwOk(b.geslo)) { bad(res, 400, "Geslo mora imeti vsaj 10 znakov."); return true; }
      porabiZeton(z); u.geslo = hashPw(b.geslo); u.mora_zamenjati = false; delete u.geslo_ponastavljeno; delete u.povabljen; delete u.totp_naprave;
      for (const [k, s] of SESS) if (s.uid === u.id) SESS.delete(k);
      save("uporabniki"); audit(u, z.namen === "povabilo" ? "povabilo-sprejeto" : "geslo-ponastavljeno", "uporabniki", u.id, "", ip);
      send(res, 200, { ok: true, email: u.email }); return true;
    }
    if (p === "/api/auth/prijava" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true;
      const em = String(b.email || "").trim().toLowerCase(), key = ip + "|" + em;
      if (limited(key)) { bad(res, 429, "Preveč poskusov. Poskusite čez minuto."); return true; }
      const u = users.find(x => x.email === em && x.aktiven !== false);
      const gesloOk = checkPw(String(b.geslo || ""), u ? u.geslo : LAZNO_GESLO); // tudi za neznan naslov izračunamo zgoščenko (enak odzivni čas)
      if (!u || !gesloOk) { fail(key); audit(null, "prijava-neuspela", "uporabniki", "", em, ip); bad(res, 401, "Napačen e-naslov ali geslo."); return true; }
      if (brezStranke(u)) { audit(null, "prijava-brez-stranke", "uporabniki", u.id, em, ip); bad(res, 403, "Stranka, ki ji pripada ta račun, ne obstaja več. Obrnite se na administratorja."); return true; }
      let zaupana = false;
      if (u.totp_vklop) {
        zaupana = napravaZaupana(u, req); // koda je bila na tej napravi vnesena v zadnjih 30 dneh
        if (!zaupana) {
          if (!b.koda) { send(res, 401, { napaka: "Vnesite kodo iz aplikacije za preverjanje (ali rezervno kodo). Na tej napravi jo bomo spet zahtevali čez " + ZAUPANJE_DNI + " dni.", potrebna_koda: true }); return true; }
          if (!drugiKorak(u, b.koda)) { fail(key); audit(null, "prijava-napacna-koda", "uporabniki", u.id, em, ip); send(res, 401, { napaka: "Koda ni pravilna ali je že bila uporabljena.", potrebna_koda: true }); return true; }
          if (b.zapomni !== false) zapomniNapravo(res, req, u);
        }
      }
      fails.delete(key);
      u.zadnja_prijava = now(); save("uporabniki");
      audit(u, "prijava", "uporabniki", u.id, zaupana ? "zaupanja vredna naprava (brez kode)" : "", ip);
      startSession(res, u); send(res, 200, pub(u)); return true;
    }
    function startSession(res, u) {
      const secure = req.headers["x-forwarded-proto"] === "https";
      const t = crypto.randomBytes(32).toString("base64url");
      SESS.set(sh(t), { uid: u.id, do: Date.now() + TTL });
      dodajPiskotek(res, `hs=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${TTL / 1000}${secure ? "; Secure" : ""}`);
    }

    const me = userOf(req);
    if (p === "/api/auth/odjava" && req.method === "POST") {
      const t = cookies(req).hs; if (t) SESS.delete(sh(t));
      res.setHeader("Set-Cookie", "hs=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");
      if (me) audit(me, "odjava", "uporabniki", me.id, "", ip);
      send(res, 200, { ok: true }); return true;
    }
    if (p === "/api/auth/jaz" && req.method === "GET") { if (!me) bad(res, 401, "Niste prijavljeni ali je seja potekla. Prijavite se znova."); else send(res, 200, pub(me)); return true; }

    // vse spodaj zahteva prijavo
    const PUBLIC_BAZA = false;
    if (!me && !PUBLIC_BAZA) { bad(res, 401, "Niste prijavljeni ali je seja potekla. Prijavite se znova."); return true; }
    // brez obvezne dvostopenjske prijave: dovoljena le njena nastavitev, sprememba gesla in branje nastavitev prikaza
    if (mora2fa(me) && !/^\/api\/auth\/(2fa\/(zacni|potrdi)|geslo)$/.test(p) && !(req.method === "GET" && /^\/api\/(vidnost|tisk)$/.test(p))) { send(res, 403, { napaka: "Za vašo vlogo je obvezna dvostopenjska prijava. Najprej jo nastavite.", potrebna_2fa: true }); return true; }

    // geslo je ponastavil administrator: dokler ga uporabnik ne zamenja, je dovoljena samo menjava gesla (tudi prek API)
    if (me.geslo_ponastavljeno && p !== "/api/auth/geslo" && !(req.method === "GET" && /^\/api\/(vidnost|tisk)$/.test(p))) { send(res, 403, { napaka: "Najprej zamenjajte začasno geslo, ki ga je nastavil administrator.", mora_zamenjati: true }); return true; }
    { const mods = modulZaPot(p); if (mods && !mods.some(m => vidno(me, m))) { bad(res, 403, "Nimate dostopa do tega razdelka."); return true; } }
    for (const pot of [rRacun, rVzdrzevanje, rUporabniki, rBazaDokumenti, rStoritve, rKopije, rPriloge, NAR.rNarocnine, rZbirke]) { const r = await pot(req, res, p, url, me, ip, users); if (r !== undefined) return r; }
    bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true;
  }
  // Poti: nastavitve vidnosti, dvostopenjska prijava, sprememba gesla. Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  // ---------- vzdrževanje: GDPR (izvoz, anonimizacija, roki hrambe), preizkus obnove, stanje sistema ----------
  const GDPRF = path.join(DIR, "_gdpr.json"), PREIZF = path.join(DIR, "_preizkus-obnove.json");
  const gdprNast = () => Object.assign({ hramba_osebje_let: 2 }, rjson(GDPRF, {}));
  const ANON = "[izbrisana oseba]";
  const nrmI = x => String(x || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
  // vzorec za ime ali e-naslov osebe: cele besede (»Jan Novak« ne zadene »Jan Novakovič«), šumniki enakovredni (»Ziga Scek« = »Žiga Šček«), velike/male črke
  const SUM = { c: "[cčć]", s: "[sš]", z: "[zž]", d: "[dđ]" };
  const vzorecOsebe = q => new RegExp("(?<![\\p{L}\\p{N}])" + [...nrmI(q)].map(ch => SUM[ch] || ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+")).join("") + "(?![\\p{L}\\p{N}])", "giu");
  function vsebuje(v, iskani) { // ali kateri koli niz v zapisu (tudi gnezdeno) vsebuje ime ali e-naslov (iskani: vzorci vzorecOsebe)
    if (typeof v === "string") return iskani.some(re => { re.lastIndex = 0; return re.test(v); });
    if (Array.isArray(v)) return v.some(x => vsebuje(x, iskani));
    if (v && typeof v === "object") return Object.values(v).some(x => vsebuje(x, iskani));
    return false;
  }
  function zamenjaj(v, vzorci) { // zamenja ime/e-naslov v vseh nizih (tudi v zgodovini sprememb); vrne [nova vrednost, število zamenjav]
    let n = 0;
    const f = x => { if (typeof x === "string") { let y = x; for (const re of vzorci) y = y.replace(re, () => { n++; return ANON; }); return y; } if (Array.isArray(x)) return x.map(f); if (x && typeof x === "object") { const o = {}; for (const [k, w] of Object.entries(x)) o[k] = f(w); return o; } return x; };
    const r = f(v); return [r, n];
  }
  function preizkusObnove() {
    const kandidati = fs.readdirSync(BKP).filter(f => /\.(zip|hfbk)$/.test(f)).map(f => ({ f, t: fs.statSync(path.join(BKP, f)).mtimeMs })).sort((a, b) => b.t - a.t);
    const r = { cas: now(), ok: false, datoteka: kandidati[0] ? kandidati[0].f : null, podrobnosti: [] };
    try {
      if (!kandidati.length) throw new Error("ni nobene varnostne kopije");
      let raw = fs.readFileSync(path.join(BKP, r.datoteka));
      if (jeSifrirana(raw)) { const g = nast().kopija_geslo; if (!g) throw new Error("kopija je šifrirana, geslo ni nastavljeno"); raw = desifriraj(raw, g); }
      const files = zipRead(raw), ime = n => files.find(x => x.name === n);
      const us = ime("podatki/uporabniki.json"); if (!us) throw new Error("kopija ne vsebuje uporabnikov");
      const usr = JSON.parse(us.data.toString("utf8")); if (!Array.isArray(usr) || !usr.length) throw new Error("seznam uporabnikov je prazen");
      let jsonov = 0; for (const x of files) if (x.name.endsWith(".json")) { JSON.parse(x.data.toString("utf8")); jsonov++; }
      const sled = files.filter(x => /^podatki\/_revizijska-sled(-.+)?\.jsonl$/.test(x.name)).sort((a, b) => (a.name === "podatki/_revizijska-sled.jsonl") - (b.name === "podatki/_revizijska-sled.jsonl") || a.name.localeCompare(b.name));
      let prev = "0", vnosov = 0;
      for (const x of sled) for (const l of x.data.toString("utf8").split("\n").filter(Boolean)) { const e = JSON.parse(l), h = e.h; delete e.h; if (crypto.createHash("sha256").update(prev + JSON.stringify(e)).digest("hex") !== h) throw new Error("revizijska sled v kopiji ni veljavna (vnos " + (vnosov + 1) + ")"); prev = h; vnosov++; }
      const st = c => { const x = ime("podatki/" + c + ".json"); return x ? JSON.parse(x.data.toString("utf8")).length : 0; };
      r.podrobnosti = [files.length + " datotek", jsonov + " zbirk JSON brez napak", usr.length + " uporabnikov", st("stranke") + " strank", st("evidence") + " evidenc", vnosov + " vnosov revizijske sledi (veriga veljavna)"];
      r.ok = true;
    } catch (e) { r.napaka = e.message; console.error("Preizkus obnove ni uspel: " + e.message); }
    S.pisi(PREIZF, r); return r;
  }
  function stanjeSistema() {
    let disk = null; try { const s = fs.statfsSync(DIR); disk = { prosto: s.bavail * s.bsize, skupaj: s.blocks * s.bsize }; } catch {}
    let velikost = 0; for (const f of walk(DIR, "")) velikost += f.data ? f.data.length : 0;
    const ks = kstat(), pr = rjson(PREIZF, null), zadnja = fs.readdirSync(BKP).filter(f => /^kopija-.*\.zip$/.test(f)).sort().pop();
    const opozorila = [];
    if (disk && disk.prosto < 1e9) opozorila.push("Na disku je manj kot 1 GB prostora.");
    if (!zadnja || Date.now() - fs.statSync(path.join(BKP, zadnja)).mtimeMs > 2 * 864e5) opozorila.push("Zadnja samodejna kopija je starejša od 2 dni.");
    if (ks && ks.ok === false) opozorila.push("Kopija v zunanjo mapo ni uspela: " + (ks.napaka || ""));
    { const on = oblakNast(), os_ = oblakStanje();
      if (on && os_.ok === false) opozorila.push("Kopija v oblak ni uspela: " + (os_.napaka || ""));
      else if (on && (!os_.cas || Date.now() - new Date(os_.cas).getTime() > 2 * 864e5)) opozorila.push("Zadnja kopija v oblak je starejša od 2 dni.");
      else if (!on && !(nast().kopija_mapa || "").trim() && process.env.HACCP_PROXY === "1" && !TESTNO) opozorila.push("Kopija izven strežnika ni nastavljena (Administracija → Kopija v oblak)."); }
    // na strežniku (za posrednikom): obvezna dvostopenjska prijava za administratorje in svetovalce
    if (process.env.HACCP_PROXY === "1" && !TESTNO) {
      const ob = varnostNast().obvezna_2fa, manjka = ["admin", "svetovalec"].filter(v => !ob.includes(v));
      if (manjka.length) opozorila.push("Dvostopenjska prijava ni obvezna za: " + manjka.map(v => v === "admin" ? "administratorje" : "svetovalce").join(" in ") + " (Administracija → Varnost prijave).");
      const brez = load("uporabniki").filter(u => u.aktiven !== false && ["admin", "svetovalec"].includes(u.vloga) && !u.totp_vklop).length;
      if (brez) opozorila.push(brez + " administratorjev in svetovalcev še nima vklopljene dvostopenjske prijave.");
    }
    // baza znanja: predpisi brez preverjanja v zadnjih 12 mesecih
    { let zak = []; try { zak = JSON.parse(fs.readFileSync(path.join(DB, "zakonodaja.json"), "utf8")); } catch {} const st = zak.filter(z => z.status !== "razveljavljen" && (!z.preverjeno || Date.now() - new Date(z.preverjeno).getTime() > 365 * 864e5)).length; if (st) { const m = st % 100; opozorila.push(st + (m === 1 ? " predpis" : m === 2 ? " predpisa" : m === 3 || m === 4 ? " predpisi" : " predpisov") + " v bazi znanja (preverjeno pred več kot 12 meseci ali nikoli) – preverite v Baza znanja → Zakonodaja."); } }
    if (!pr) opozorila.push("Obnova iz kopije še ni bila preizkušena.");
    else if (!pr.ok) opozorila.push("Zadnji preizkus obnove ni uspel: " + pr.napaka);
    else if (Date.now() - new Date(pr.cas).getTime() > 35 * 864e5) opozorila.push("Preizkus obnove je starejši od 35 dni.");
    const zbirke = {}; for (const c of Object.keys(COLL)) zbirke[c] = load(c).length;
    return { shramba: S.nacin === "sqlite" ? "podatkovna baza SQLite" : "datoteke JSON", verzija: o.verzija, testno: TESTNO, deluje_od: new Date(Date.now() - process.uptime() * 1000).toISOString(), node: process.version, disk, velikost_podatkov: velikost, zadnja_kopija: zadnja || null, kopija_zunaj: ks, preizkus_obnove: pr, zbirke, napake: NAPAKE.slice().reverse(), opozorila, smtp: !!nast().streznik };
  }
  async function rVzdrzevanje(req, res, p, url, me, ip, users) {
    if (!p.startsWith("/api/gdpr") && !p.startsWith("/api/sistem") && p !== "/api/kopija/preizkus" && !p.startsWith("/api/posodobitev-programa")) return;
    if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
    const POS = o.posodobitev;
    if (p.startsWith("/api/posodobitev-programa") && !POS) { bad(res, 404, "Ta podatek ni na voljo."); return true; }
    if (p === "/api/posodobitev-programa" && req.method === "GET") { send(res, 200, { trenutna: o.verzija, naslov: POS.naslov(), privzeti: POS.PRIVZETI_URL, nacin: POS.nacin(), zadnje: POS.zadnje() }); return true; }
    if (p === "/api/posodobitev-programa/preveri" && req.method === "POST") { try { send(res, 200, await POS.preveri()); } catch (e) { bad(res, 502, "Preverjanje ni uspelo: " + e.message); } return true; }
    if (p === "/api/posodobitev-programa/nastavitve" && req.method === "PUT") {
      const b = await jbody(req, res); if (!b) return true; const u = String(b.url || "").trim();
      if (u && !/^https:\/\/[^\s]+$/.test(u) && !/^([a-zA-Z]:[\\/]|\\\\|file:\/\/|\/).+\.json$/i.test(u)) { bad(res, 400, "Vpišite naslov https://… ali pot do datoteke posodobitev.json (npr. E:\\posodobitev\\posodobitev.json)."); return true; }
      POS.nastavi(u); audit(me, "posodobitev-naslov", "", "", u || "privzeti", ip); send(res, 200, { ok: true, naslov: POS.naslov() }); return true;
    }
    if (p === "/api/posodobitev-programa/namesti" && req.method === "POST") {
      try {
        autoBackup(true); // varnostna kopija podatkov pred zamenjavo programa
        const r = await POS.namesti(); audit(me, "posodobitev-programa", "", "", o.verzija + " → " + r.verzija, ip);
        send(res, 200, { ok: true, verzija: r.verzija }); setTimeout(() => o.ponovniZagon(r.exe), 300);
      } catch (e) { bad(res, 502, e.message); }
      return true;
    }
    if (p === "/api/sistem" && req.method === "GET") { send(res, 200, stanjeSistema()); return true; }
    // obstoječi zapisi, ki ne ustrezajo pravilom za vnose (npr. shranjeni pred uvedbo preverjanja): seznam za popravek
    if (p === "/api/sistem/preverjanje-podatkov" && req.method === "GET") {
      const sm = Object.fromEntries(load("stranke").map(s => [s.id, s.naziv])), out = [];
      for (const c of ["oprema", "usposabljanja", "storitve", "dogodki", "osebje", "sarze", "capa", "ciscenje_nacrt", "obrati", "urnik", "evidence"]) {
        if (!ima(COLL, c)) continue;
        for (const r of load(c)) { const n = PRAVILA.preveri(c, r); if (n.length) out.push({ zbirka: c, id: r.id, stranka_id: r.stranka_id || "", stranka: sm[r.stranka_id] || "", naziv: String(r.naziv || r.ime || r.tema || r.naslov || r.izdelek || r.opravilo || r.vrsta || r.opis || r.id).slice(0, 80), napake: n.map(x => x[1]) }); }
      }
      send(res, 200, { pregledano: now(), zapisov: out.length, napake: out.slice(0, 1000) }); return true;
    }
    if (p === "/api/kopija/preizkus") {
      if (req.method === "GET") { send(res, 200, rjson(PREIZF, null)); return true; }
      if (req.method === "POST") { autoBackup(); const r = preizkusObnove(); audit(me, "preizkus-obnove", "", "", r.ok ? "uspešno" : "neuspešno: " + r.napaka, ip); send(res, 200, r); return true; }
    }
    if (p === "/api/gdpr/nastavitve") {
      if (req.method === "GET") { send(res, 200, gdprNast()); return true; }
      if (req.method === "PUT") { const b = await jbody(req, res); if (!b) return true; const n = { hramba_osebje_let: Math.max(0, Math.min(50, +b.hramba_osebje_let || 0)) }; S.pisi(GDPRF, n); audit(me, "gdpr-nastavitve", "", "", JSON.stringify(n), ip); send(res, 200, n); return true; }
    }
    if (p === "/api/gdpr/potekli" && req.method === "GET") { // nekdanji zaposleni, katerih rok hrambe je potekel
      const let_ = gdprNast().hramba_osebje_let, meja = new Date(Date.now() - let_ * 365.25 * 864e5).toISOString().slice(0, 10);
      const sm = Object.fromEntries(load("stranke").map(s => [s.id, s.naziv]));
      send(res, 200, { hramba_osebje_let: let_, meja, osebe: load("osebje").filter(x => x.datum_odhoda && x.datum_odhoda <= meja && x.ime !== ANON).map(x => ({ id: x.id, ime: x.ime, email: x.email || "", stranka: sm[x.stranka_id] || "", datum_odhoda: x.datum_odhoda })) }); return true;
    }
    const b = req.method === "POST" ? await jbody(req, res) : null; if (req.method === "POST" && !b) return true;
    const ime = String((b && b.ime) || "").trim(), email = String((b && b.email) || "").trim().toLowerCase();
    if ((p === "/api/gdpr/izvoz" || p === "/api/gdpr/anonimiziraj") && req.method === "POST") {
      if (ime.length < 3 && email.length < 5) { bad(res, 400, "Vnesite ime in priimek ali e-naslov osebe."); return true; }
      const iskani = [ime, email].filter(x => nrmI(x).length >= 3).map(vzorecOsebe);
      if (p === "/api/gdpr/izvoz") {
        const zadetki = {}; for (const c of Object.keys(COLL)) { const z = load(c).filter(r => vsebuje(r, iskani)); if (z.length) zadetki[c] = z; }
        { const z = load("_kos").filter(it => vsebuje(it, iskani)); if (z.length) zadetki["koš (izbrisano)"] = z; } // tudi izbrisani zapisi, ki se še lahko obnovijo
        const u = users.filter(x => (email && x.email === email) || (ime && nrmI(x.ime) === nrmI(ime))).map(pub);
        const sled = auditRead(100000).filter(e => vsebuje([e.ime, e.opis], iskani));
        audit(me, "gdpr-izvoz", "", "", "zadetkov " + Object.values(zadetki).reduce((a, x) => a + x.length, 0), ip);
        send(res, 200, { izvozeno: now(), oseba: { ime, email }, uporabniski_racuni: u, zapisi: zadetki, revizijska_sled: sled }); return true;
      }
      if (b.potrdi !== true) { bad(res, 400, "Potrditev manjka."); return true; }
      const vzorci = iskani;
      let zamenjav = 0, zapisov = 0;
      for (const c of Object.keys(COLL)) {
        const arr = load(c); let sprememba = false;
        for (let i = 0; i < arr.length; i++) {
          if (!vsebuje(arr[i], iskani)) continue;
          const [nv, n] = zamenjaj(arr[i], vzorci); if (!n) continue;
          if (c === "osebje" && nv.ime === ANON) { for (const k of ["email", "telefon", "opomba", "zdravniski_do", "higienski_do"]) delete nv[k]; }
          arr[i] = nv; zamenjav += n; zapisov++; sprememba = true;
        }
        if (sprememba) save(c);
      }
      { const kos = load("_kos"); let sp = false; for (let i = 0; i < kos.length; i++) { if (!vsebuje(kos[i], iskani)) continue; const [nv, n] = zamenjaj(kos[i], vzorci); if (!n) continue; kos[i] = nv; zamenjav += n; zapisov++; sp = true; } if (sp) save("_kos"); } // koš: po obnovi se oseba ne sme vrniti
      let racunov = 0;
      for (const u of users) if ((email && u.email === email) || (ime && nrmI(u.ime) === nrmI(ime))) {
        if (u.id === me.id) continue;
        u.ime = ANON; u.email = "izbrisan-" + u.id + "@anonimizirano.invalid"; u.aktiven = false; for (const k of ["totp_vklop", "totp_skrivnost", "totp_rezervne", "totp_zadnji"]) delete u[k];
        for (const [k, s] of SESS) if (s.uid === u.id) SESS.delete(k); racunov++;
      }
      if (racunov) save("uporabniki");
      audit(me, "gdpr-anonimizacija", "", "", "zapisov " + zapisov + ", zamenjav " + zamenjav + ", računov " + racunov + " (oseba: " + sh(nrmI(ime) + "|" + email).slice(0, 12) + ")", ip);
      send(res, 200, { zapisov, zamenjav, racunov }); return true;
    }
    bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true;
  }

  async function rRacun(req, res, p, url, me, ip, users) {
    if (p === "/api/varnost") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      if (req.method === "GET") { const brez = {}; for (const u of users) if (u.aktiven !== false && !u.totp_vklop) brez[u.vloga] = (brez[u.vloga] || 0) + 1; send(res, 200, Object.assign(varnostNast(), { brez_2fa: brez })); return true; }
      if (req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true;
        const o = Array.isArray(b.obvezna_2fa) ? [...new Set(b.obvezna_2fa.filter(v => VLOGE.includes(v)))] : [];
        S.pisi(VARF, Object.assign(varnostNast(), { obvezna_2fa: o })); audit(me, "varnost-2fa", "", "", o.join(",") || "nič", ip); send(res, 200, { ok: true, obvezna_2fa: o }); return true;
      }
    }
    if (p === "/api/vidnost") {
      const cfg = vidnost();
      if (req.method === "GET") {
        const q = new URL(req.url, "http://x").searchParams, kot = q.get("kot");
        let vloga = me.vloga, sid = me.stranka_id;
        if (kot) { if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; } vloga = kot === "stranka" ? "zaposleni" : "odgovorna"; sid = q.get("stranka_id") || null; }
        const moje = {}, zaklenjeno = {}; for (const m of MODULI) { moje[m.id] = vidnoZaVlogo(vloga, sid, m.id, cfg); const z = VLOGA_KLJUC[vloga] && NAR.zaklenjeno(sid, m.id); if (z && vidno({ vloga, stranka_id: sid }, m.id, cfg, true)) zaklenjeno[m.id] = z; }
        send(res, 200, me.vloga === "admin" && !kot ? { moje, moduli: MODULI, privzeto: cfg.privzeto, stranke: cfg.stranke, sistemsko: SISTEMSKO_SKRITO } : { moje, zaklenjeno, paket: VLOGA_KLJUC[vloga] ? NAR.paketOf(sid) : null }); return true;
      }
      if (req.method === "PUT") {
        if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
        const b = await jbody(req, res); if (!b) return true;
        const sid = b.stranka_id || null; if (sid && !load("stranke").some(x => x.id === sid)) { bad(res, 400, "Stranka ne obstaja."); return true; }
        if (b.ponastavi) { if (!sid) { bad(res, 400, "Ponastavitev velja za posamezno stranko."); return true; } delete cfg.stranke[sid]; }
        else {
          if (!MODUL_IDS.has(b.modul) || !["stranka", "odgovorna"].includes(b.vloga) || typeof b.vidno !== "boolean") { bad(res, 400, "Neveljavna nastavitev."); return true; }
          const tgt = sid ? (cfg.stranke[sid] = cfg.stranke[sid] || {}) : cfg.privzeto; tgt[b.modul] = Object.assign({}, tgt[b.modul], { [b.vloga]: b.vidno });
        }
        S.pisi(VF, cfg); audit(me, "nastavitve-vidnosti", "", sid || "", b.ponastavi ? "ponastavitev" : b.modul + " " + b.vloga + "=" + b.vidno, ip); send(res, 200, { ok: true }); return true;
      }
    }
    if (p === "/api/auth/2fa/zacni" && req.method === "POST") {
      // že vklopljene 2FA ni mogoče zamenjati samo s sejo (ugrabljena seja bi preusmerila kode na svojo napravo): najprej izklop z geslom in kodo
      if (me.totp_vklop) { bad(res, 400, "Dvostopenjska prijava je že vklopljena. Za novo napravo jo najprej izklopite (z geslom in kodo), nato vklopite znova."); return true; }
      const sk = crypto.randomBytes(20); me.totp_cakanje = b32enc(sk); // kot zgoščenke gesel: v uporabniki.json (ključ _kljuc ni potreben, kopije delujejo tudi na drugem računalniku) save("uporabniki");
      const s32 = b32enc(sk), lbl = encodeURIComponent("HiGiFood:" + me.email);
      send(res, 200, { skrivnost: s32.replace(/(.{4})/g, "$1 ").trim(), uri: `otpauth://totp/${lbl}?secret=${s32}&issuer=HiGiFood&algorithm=SHA1&digits=6&period=30` }); return true;
    }
    if (p === "/api/auth/2fa/potrdi" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true; const gk = "2fa|" + me.id;
      if (limited(gk)) { bad(res, 429, "Preveč poskusov. Poskusite čez minuto."); return true; }
      if (!me.totp_cakanje || me.totp_vklop) { bad(res, 400, "Najprej začnite nastavitev."); return true; }
      const ctr = totpPreveri(b32dec(me.totp_cakanje), b.koda, 0);
      if (!ctr) { fail(gk); bad(res, 400, "Koda ni pravilna. Preverite uro na telefonu in poskusite znova."); return true; }
      const rez = Array.from({ length: 8 }, () => crypto.randomBytes(5).toString("hex").toUpperCase());
      me.totp_skrivnost = me.totp_cakanje; delete me.totp_cakanje; delete me.totp_naprave; me.totp_vklop = true; me.totp_zadnji = ctr; me.totp_rezervne = rez.map(sh); save("uporabniki");
      audit(me, "2fa-vklop", "uporabniki", me.id, "", ip); send(res, 200, { ok: true, rezervne: rez }); return true;
    }
    // pozabi vse zaupanja vredne naprave (naslednja prijava povsod zahteva kodo)
    if (p === "/api/auth/2fa/pozabi-naprave" && req.method === "POST") {
      const n = (me.totp_naprave || []).filter(x => x.do > Date.now()).length; delete me.totp_naprave; save("uporabniki");
      dodajPiskotek(res, "hz=; HttpOnly; SameSite=Strict; Path=/api/auth; Max-Age=0"); audit(me, "2fa-pozabi-naprave", "uporabniki", me.id, String(n), ip); send(res, 200, { ok: true, pozabljenih: n }); return true;
    }
    if (p === "/api/auth/2fa/izklopi" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true; const gk = "2fa|" + me.id;
      if (limited(gk)) { bad(res, 429, "Preveč poskusov. Poskusite čez minuto."); return true; }
      if (!me.totp_vklop) { send(res, 200, { ok: true }); return true; }
      if (!checkPw(String(b.geslo || ""), me.geslo) || !drugiKorak(me, b.koda)) { fail(gk); bad(res, 400, "Geslo ali koda ni pravilna."); return true; }
      for (const k of ["totp_vklop", "totp_skrivnost", "totp_zadnji", "totp_rezervne", "totp_naprave"]) delete me[k]; save("uporabniki");
      audit(me, "2fa-izklop", "uporabniki", me.id, "", ip); send(res, 200, { ok: true }); return true;
    }
    if (p === "/api/auth/opomniki" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true;
      if (!["admin", "svetovalec", "odgovorna"].includes(me.vloga)) { bad(res, 403, "E-poštnih opomnikov ta vloga ne prejema."); return true; }
      if (!["dnevno", "tedensko", "izklop"].includes(b.pogostost)) { bad(res, 400, "Neveljavna pogostost."); return true; }
      const u = users.find(x => x.id === me.id); u.opomniki = { pogostost: b.pogostost, roki: b.roki !== false, vnosi: b.vnosi !== false }; save("uporabniki");
      audit(me, "nastavitve-opomnikov", "uporabniki", me.id, b.pogostost, ip); send(res, 200, pub(u)); return true;
    }
    if (p === "/api/auth/geslo" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true;
      const gk = "geslo|" + me.id;
      if (limited(gk)) { bad(res, 429, "Preveč poskusov. Poskusite čez minuto."); return true; }
      if (!checkPw(String(b.staro || ""), me.geslo) || !pwOk(b.novo)) { fail(gk); bad(res, 400, "Staro geslo ni pravilno ali novo geslo je prekratko (vsaj 10 znakov)."); return true; }
      fails.delete(gk);
      me.geslo = hashPw(b.novo); me.mora_zamenjati = false; delete me.geslo_ponastavljeno; delete me.totp_naprave; save("uporabniki"); porabiZeton({ uid: me.id }); // stara povezava »pozabljeno geslo« ne velja več
      { const moja = sh(cookies(req).hs || ""); for (const [k, s] of [...SESS]) if (s.uid === me.id && k !== moja) SESS.delete(k); } // odjava drugih naprav
      audit(me, "sprememba-gesla", "uporabniki", me.id, "", ip);
      send(res, 200, { ok: true }); return true;
    }

  }

  // Poti: uporabniki. Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  async function rUporabniki(req, res, p, url, me, ip, users) {
    // --- uporabniki ---
    if (p === "/api/uporabniki") {
      if (req.method === "GET") {
        if (me.vloga === "admin") { send(res, 200, users.map(pub)); return true; }
        const vezan = u => ["odgovorna", "zaposleni"].includes(u.vloga);
        if (me.vloga === "svetovalec") { send(res, 200, users.filter(u => vezan(u) && u.stranka_id && me.stranke.includes(u.stranka_id)).map(pub)); return true; }
        if (me.vloga === "odgovorna") { send(res, 200, users.filter(u => vezan(u) && u.stranka_id === me.stranka_id).map(pub)); return true; }
        bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true;
      }
      if (req.method === "POST") {
        const b = await jbody(req, res); if (!b) return true;
        if (typeof b.email !== "string" || !b.email.trim() || preveriPravila("uporabniki", { email: b.email })) { bad(res, 400, "E-naslov ni veljaven (npr. ana.novak@podjetje.si)."); return true; }
        if (!VLOGE.includes(b.vloga) || (!b.povabilo && !pwOk(b.geslo))) { bad(res, 400, "Neveljavni podatki (vloga, geslo vsaj 10 znakov)."); return true; }
        if (b.povabilo) { const c = nast(); if (!postaNastavljena(c) || !/^https?:\/\//.test(c.naslov_aplikacije || "")) { bad(res, 400, "Za povabilo po e-pošti v Administraciji nastavite e-pošto (SMTP) in naslov aplikacije."); return true; } }
        const em = b.email.trim().toLowerCase();
        if (users.some(x => x.email === em)) { bad(res, 409, "E-naslov že obstaja."); return true; }
        // na stranko sta vezana samo odgovorna oseba in zaposleni (svetovalec ima seznam strank, admin nobene)
        let sid = ["odgovorna", "zaposleni"].includes(b.vloga) ? b.stranka_id || null : null;
        const imeN = b.ime === undefined ? em : typeof b.ime === "string" ? b.ime.trim() : "";
        if (!imeN) { bad(res, 400, "Vpišite ime in priimek."); return true; }
        if (me.vloga === "odgovorna") { if (b.vloga !== "zaposleni") { bad(res, 403, "Dodate lahko samo zaposlene."); return true; } sid = me.stranka_id; }
        else if (me.vloga === "svetovalec") { if (!["odgovorna", "zaposleni"].includes(b.vloga) || !tenantOk(me, sid)) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; } }
        else if (me.vloga !== "admin") { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
        if (["odgovorna", "zaposleni"].includes(b.vloga) && !sid) { bad(res, 400, "Izberite stranko."); return true; }
        if (sid && !load("stranke").some(s => s.id === sid)) { bad(res, 400, "Stranka ne obstaja."); return true; }
        if (b.vloga === "svetovalec" && Array.isArray(b.stranke)) { const obst = new Set(load("stranke").map(s => s.id)); b.stranke = [...new Set(b.stranke.filter(id => obst.has(id)))]; }
        const u = { id: uid(), email: em, ime: imeN.slice(0, 80), vloga: b.vloga, stranka_id: sid, stranke: b.vloga === "svetovalec" ? (Array.isArray(b.stranke) ? b.stranke : []) : [], geslo: hashPw(b.povabilo ? crypto.randomBytes(24).toString("hex") : b.geslo), aktiven: true, mora_zamenjati: !b.povabilo, ustvarjeno: now() };
        if (b.povabilo) u.povabljen = true;
        users.push(u); save("uporabniki");
        audit(me, "uporabnik-nov", "uporabniki", u.id, u.vloga + " " + u.email + (b.povabilo ? " (povabilo)" : ""), ip);
        let napaka = null; if (b.povabilo) { try { await posljiPovabilo(u, me); audit(me, "povabilo-poslano", "uporabniki", u.id, u.email, ip); } catch (e) { napaka = prijazno(e); } }
        send(res, 200, Object.assign(pub(u), napaka ? { povabilo_napaka: napaka } : {})); return true;
      }
    }
    const mu = p.match(/^\/api\/uporabniki\/([\w-]+)$/);
    if (mu) {
      const u = users.find(x => x.id === mu[1]);
      const mayManage = u && (me.vloga === "admin" || (me.vloga === "odgovorna" && u.stranka_id === me.stranka_id && u.vloga === "zaposleni") || (me.vloga === "svetovalec" && u.stranka_id && me.stranke.includes(u.stranka_id) && ["odgovorna", "zaposleni"].includes(u.vloga)));
      if (!mayManage) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      if (url.searchParams.get("povabilo") === "1" && req.method === "POST") {
        try { await posljiPovabilo(u, me); audit(me, "povabilo-poslano", "uporabniki", u.id, u.email, ip); send(res, 200, { ok: true }); } catch (e) { bad(res, e.smtp ? 422 : 502, "Povabila ni bilo mogoče poslati: " + prijazno(e)); }
        return true;
      }
      // izbris uporabnika (samo administrator): uporabnik gre v koš (30 dni, obnovljiv); njegovi zapisi ostanejo z imenom avtorja
      if (req.method === "DELETE") {
        if (me.vloga !== "admin") { bad(res, 403, "Uporabnike briše samo administrator."); return true; }
        if (u.id === me.id) { bad(res, 400, "Sebe ne morete izbrisati."); return true; }
        if (u.vloga === "admin" && users.filter(x => x.vloga === "admin" && x.aktiven !== false && x.id !== u.id).length === 0) { bad(res, 400, "Zadnjega aktivnega administratorja ni mogoče izbrisati."); return true; }
        users.splice(users.indexOf(u), 1); save("uporabniki");
        for (const [k, s] of SESS) if (s.uid === u.id) SESS.delete(k);
        porabiZeton({ uid: u.id }); // povabilo izbrisanega uporabnika ne velja (tudi po obnovi iz koša)
        const kos = load("_kos"); kos.push({ id: uid(), zbirka: "uporabniki", stranka_id: u.stranka_id || null, ime: (u.ime || "") + " (" + u.email + ")", cas: now(), izbrisal: me.ime, zapis: u }); save("_kos");
        audit(me, "izbris", "uporabniki", u.id, u.email, ip); send(res, 200, { ok: true }); return true;
      }
      if (req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true;
        // preverjanje pred spremembami: odgovorna oseba in zaposleni morata imeti obstoječo stranko (brez nje bi videla račune brez stranke, npr. administratorje)
        const vl = me.vloga === "admin" && b.vloga !== undefined && VLOGE.includes(b.vloga) && u.id !== me.id ? b.vloga : u.vloga, nsid = me.vloga === "admin" && b.stranka_id !== undefined ? b.stranka_id || null : u.stranka_id || null;
        const ostaneAktiven = b.aktiven !== undefined ? !!b.aktiven : u.aktiven !== false; // neaktiven račun izbrisane stranke je mogoče urediti in onemogočiti
        if (me.vloga === "admin" && ostaneAktiven && ["odgovorna", "zaposleni"].includes(vl) && (!nsid || !load("stranke").some(s => s.id === nsid))) { bad(res, 400, "Odgovorna oseba in zaposleni morata imeti izbrano obstoječo stranko."); return true; }
        if (b.ime !== undefined) { if (!String(b.ime).trim()) { bad(res, 400, "Ime ne sme biti prazno."); return true; } u.ime = String(b.ime).trim().slice(0, 80); }
        if (b.aktiven !== undefined) { if (u.id === me.id && !b.aktiven) { bad(res, 400, "Sebe ne morete onemogočiti."); return true; } u.aktiven = !!b.aktiven; if (!u.aktiven) porabiZeton({ uid: u.id }); if (!u.aktiven) for (const [k, s] of SESS) if (s.uid === u.id) SESS.delete(k); }
        if (b.geslo !== undefined) { if (!pwOk(b.geslo)) { bad(res, 400, "Geslo je prekratko."); return true; } u.geslo = hashPw(b.geslo); delete u.totp_naprave; u.mora_zamenjati = true; u.geslo_ponastavljeno = true; for (const [k, s] of SESS) if (s.uid === u.id) SESS.delete(k); }
        if (me.vloga === "admin") {
          if (b.izklopi_2fa === true) { for (const k of ["totp_vklop", "totp_skrivnost", "totp_zadnji", "totp_rezervne", "totp_cakanje", "totp_naprave"]) delete u[k]; for (const [k, s] of SESS) if (s.uid === u.id) SESS.delete(k); }
          if (b.stranke !== undefined && u.vloga === "svetovalec") {
            // stranke v košu obrazec ne prikaže; njihova dodelitev ostane, da se po obnovi vrne
            const obst = new Set(load("stranke").map(s => s.id)), vKosu = new Set(load("_kos").filter(k => k.zbirka === "stranke").map(k => k.zapis && k.zapis.id));
            u.stranke = [...new Set([...(Array.isArray(b.stranke) ? b.stranke.filter(id => obst.has(id)) : []), ...(u.stranke || []).filter(id => vKosu.has(id))])];
          }
          u.vloga = vl; u.stranka_id = ["odgovorna", "zaposleni"].includes(vl) ? nsid || u.stranka_id || null : null; if (vl !== "svetovalec") u.stranke = [];
        }
        save("uporabniki"); audit(me, "uporabnik-spremenjen", "uporabniki", u.id, Object.keys(b).filter(k => k !== "geslo").join(","), ip);
        send(res, 200, pub(u)); return true;
      }
      bad(res, 405, "Ta zahteva ni podprta."); return true;
    }

  }

  // Poti: baza znanja, posodobitve, potrjevanje dokumentov. Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  async function rBazaDokumenti(req, res, p, url, me, ip, users) {
    // --- baza znanja (branje: vsi prijavljeni; pisanje: samo administrator) ---
    if (p === "/api/baza" || p.startsWith("/api/baza/") || p === "/api/posodobitve") {
      if (req.method !== "GET" && me.vloga !== "admin") { bad(res, 403, "Bazo znanja lahko ureja samo administrator."); return true; }
      if (req.method !== "GET") res.on("finish", () => { if (res.statusCode < 300) audit(me, "baza-pisanje", "baza", p.split("/")[3] || "", req.method, ip); });
      return false;
    }
    if (p === "/api/posodobitev") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      res.on("finish", () => audit(me, "baza-posodobitev", "baza", "", "", ip));
      return false;
    }


    // ---------- potrjevanje dokumentov (odgovorna oseba potrdi trenutno različico; sprememba potrditev razveljavi) ----------
    const hashZapisa = r => { const o = {}; for (const k of Object.keys(r).sort()) if (!RESERVED.includes(k) && !k.startsWith("_") && !["verzija", "skladno", "status"].includes(k)) o[k] = r[k]; return sh(JSON.stringify(o)); };
    if (p === "/api/potrdi" && req.method === "POST") {
      if (!can(me, "ASO")) { bad(res, 403, "Dokument lahko potrdi odgovorna oseba ali svetovalec."); return true; }
      const b = await jbody(req, res); if (!b) return true;
      if (!["nacrti", "navodila"].includes(b.zbirka)) { bad(res, 400, "Neveljavna zbirka."); return true; }
      const r = load(b.zbirka).find(x => x.id === b.id);
      if (!r || !visible(me, b.zbirka, r)) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      const pot = load("potrditve"), z = { id: uid(), stranka_id: r.stranka_id, zbirka: b.zbirka, ref_id: r.id, naslov: r.naslov || r.naziv || "", verzija: r.verzija || 1, hash: hashZapisa(r), potrdil: me.id, potrdil_ime: me.ime, cas: now(), opomba: String(b.opomba || "").slice(0, 500) };
      pot.push(z); save("potrditve"); audit(me, "potrdi", b.zbirka, r.id, z.naslov + " v" + z.verzija, ip); send(res, 200, z); return true;
    }
    if (p === "/api/potrditve" && req.method === "GET") {
      const sid = new URL(req.url, "http://x").searchParams.get("stranka_id") || me.stranka_id;
      if (!tenantOk(me, sid)) { bad(res, 403, "Nimate dostopa do izbrane stranke."); return true; }
      const out = load("potrditve").filter(x => x.stranka_id === sid).map(x => { const r = load(x.zbirka).find(y => y.id === x.ref_id); return Object.assign({}, x, { hash: undefined, veljavna: !!r && hashZapisa(r) === x.hash, obstaja: !!r }); });
      send(res, 200, out); return true;
    }
  }

  // Poti: arhiv, umiki, omrežje, testno okolje, tisk, nastavitve, obvestila, logotip, koš. Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  async function rStoritve(req, res, p, url, me, ip, users) {
    // ---------- podatki podjetja po davčni številki (register EU VIES) – za osebje pri vnosu stranke ----------
    const mReg = /^\/api\/podjetje\/([^/]+)$/.exec(p);
    if (mReg && req.method === "GET") {
      if (me.vloga !== "admin" && me.vloga !== "svetovalec") { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
      const t = Date.now(), zad = (rStoritve.reg = rStoritve.reg || new Map()).get(me.id) || [];
      const nedavni = zad.filter(x => t - x < 60e3); if (nedavni.length >= 20) { bad(res, 429, "Preveč poizvedb v minuti. Poskusite čez minuto."); return true; }
      rStoritve.reg.set(me.id, [...nedavni, t]);
      const d = REG.preveriDavcno(decodeURIComponent(mReg[1])); if (!d) { bad(res, 400, "Davčna številka ni veljavna (8 števk, preverite kontrolno števko)."); return true; }
      let z = null; try { z = ZAV.poDavcni(d); } catch {}
      if (z) { send(res, 200, z); return true; }
      try { send(res, 200, await REG.poisci(d)); } catch (e) { bad(res, e.koda || 502, e.message); }
      return true;
    }
    if (p === "/api/podjetje" && req.method === "GET") { // iskanje po nazivu v seznamu FURS
      if (me.vloga !== "admin" && me.vloga !== "svetovalec") { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
      let r = []; try { r = ZAV.poNazivu(url.searchParams.get("q"), 10); } catch {}
      send(res, 200, { zadetki: r, seznam: ZAV.stanje().zapisov > 0 }); return true;
    }
    // ---------- seznam zavezancev FURS: stanje, nastavitve, osvežitev, ročni uvoz (samo administrator) ----------
    if (p.startsWith("/api/zavezanci")) {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      if (p === "/api/zavezanci" && req.method === "GET") { send(res, 200, Object.assign(ZAV.stanje(), { naslovi: zavNaslovi(), privzeti: REG.FURS_PRIVZETO })); return true; }
      if (p === "/api/zavezanci" && req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true;
        const n = [].concat(b.naslovi || []).map(x => String(x).trim()).filter(Boolean);
        if (n.some(x => !/^https:\/\//.test(x))) { bad(res, 400, "Naslovi morajo biti https://"); return true; }
        ZAV.zapisiStanje({ naslovi: n, samodejno: b.samodejno !== false }); audit(me, "nastavitve", "zavezanci", null, "seznam zavezancev FURS", ip);
        send(res, 200, Object.assign(ZAV.stanje(), { naslovi: zavNaslovi(), privzeti: REG.FURS_PRIVZETO })); return true;
      }
      if (p === "/api/zavezanci/osvezi" && req.method === "POST") {
        try { send(res, 200, await zavOsvezi(true)); } catch (e) { bad(res, 502, "Prenos seznama ni uspel: " + e.message); } return true;
      }
      if (p === "/api/zavezanci/uvozi" && req.method === "POST") { // telo: datoteka (zip, csv ali txt) v base64
        let t; try { t = await body(req, 150e6); } catch { bad(res, 413, "Datoteka je prevelika."); return true; }
        try { const n = ZAV.uvozi([Buffer.from(String(t), "base64")], "ročni uvoz"); audit(me, "uvoz", "zavezanci", null, n + " zapisov", ip); send(res, 200, ZAV.stanje()); }
        catch (e) { bad(res, 400, e.message); } return true;
      }
    }
    // ---------- arhiv starih evidenc (samo administrator; stisnjeno v podatki/_arhiv, vrnitev mogoča) ----------
    if (p.startsWith("/api/arhiv")) {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const AD = path.join(DIR, "_arhiv"); fs.mkdirSync(AD, { recursive: true });
      const zl = require("zlib");
      if (p === "/api/arhiv" && req.method === "GET") {
        send(res, 200, fs.readdirSync(AD).filter(f => f.endsWith(".json.gz")).map(f => { const st = fs.statSync(path.join(AD, f)); return { ime: f, velikost: st.size, cas: st.mtime.toISOString() }; }).sort((a, b) => b.cas.localeCompare(a.cas))); return true;
      }
      if (p === "/api/arhiv" && req.method === "POST") {
        const b = await jbody(req, res); if (!b) return true; const leta = Math.max(1, Math.min(30, +b.leta || 0));
        if (!b.leta) { bad(res, 400, "Določite število let."); return true; }
        const meja = new Date(Date.now() - leta * 365.25 * 864e5).toISOString(), ev = load("evidence"), stare = ev.filter(e => String(e.cas || e.ustvarjeno) < meja && (!b.stranka_id || e.stranka_id === b.stranka_id));
        if (b.samo_preveri) { send(res, 200, { stevilo: stare.length, meja: meja.slice(0, 10) }); return true; }
        if (!stare.length) { send(res, 200, { stevilo: 0 }); return true; }
        const ime = "evidence-do-" + meja.slice(0, 10) + "-" + Date.now().toString(36) + ".json.gz";
        fs.writeFileSync(path.join(AD, ime), zl.gzipSync(JSON.stringify({ zbirka: "evidence", meja, zapisi: stare })));
        const ids = new Set(stare.map(e => e.id)); cache["evidence"] = ev.filter(e => !ids.has(e.id)); save("evidence");
        audit(me, "arhiviraj", "evidence", "", stare.length + " zapisov v " + ime, ip); send(res, 200, { stevilo: stare.length, datoteka: ime }); return true;
      }
      const m2 = p.match(/^\/api\/arhiv\/([\w.\-]+\.json\.gz)(\/obnovi)?$/);
      if (m2) {
        const f = path.join(AD, m2[1]); if (!fs.existsSync(f)) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
        if (m2[2] && req.method === "POST") {
          const d = JSON.parse(zl.gunzipSync(fs.readFileSync(f)).toString("utf8")), cur = load("evidence"), have = new Set(cur.map(e => e.id)); let n = 0;
          for (const e of d.zapisi) if (!have.has(e.id)) { cur.push(e); n++; }
          save("evidence"); fs.unlinkSync(f); audit(me, "obnovi-arhiv", "evidence", "", n + " zapisov iz " + m2[1], ip); send(res, 200, { stevilo: n }); return true;
        }
        if (req.method === "GET") { res.writeHead(200, { "Content-Type": "application/gzip", "Content-Disposition": `attachment; filename="${m2[1]}"` }); res.end(fs.readFileSync(f)); return true; }
      }
    }
    if (p === "/api/umiki" || p.startsWith("/api/umiki/")) {
      const staff = me.vloga === "admin" || me.vloga === "svetovalec";
      if (p === "/api/umiki" && req.method === "GET") {
        const sid = new URL(req.url, "http://x").searchParams.get("stranka_id") || me.stranka_id;
        if (sid && !tenantOk(me, sid)) { bad(res, 403, "Nimate dostopa do izbrane stranke."); return true; }
        const l = sid ? umikiZa(sid) : rjson(UF, []).map(n => Object.assign({}, n, { kljuc: undefined, zadetki: [] }));
        send(res, 200, { obvestila: l.slice(0, 200), viri: me.vloga === "admin" ? rjson(UN, PRIVZETI_VIRI) : undefined, rasff: me.vloga === "admin" ? Object.assign(rasffNast(), { prevod: PREV.nacin() }) : undefined, stanje: umikiStanje }); return true;
      }
      if (p === "/api/umiki" && req.method === "POST") {
        if (!staff) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
        const b = await jbody(req, res); if (!b) return true; const naslov = String(b.naslov || "").trim(); if (!naslov) { bad(res, 400, "Vnesite naslov obvestila."); return true; }
        const l = rjson(UF, []); l.unshift({ id: uid(), kljuc: "rocno|" + uid(), vir: "ročni vnos", cas_prejema: now(), naslov: naslov.slice(0, 300), povezava: /^https?:\/\//i.test(b.povezava || "") ? b.povezava : "", opis: String(b.opis || "").slice(0, 3000), objavljeno: String(b.objavljeno || "").slice(0, 40) });
        S.pisi(UF, l); audit(me, "umik-vnos", "", "", naslov.slice(0, 80), ip); send(res, 200, { ok: true }); return true;
      }
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      if (p === "/api/umiki/viri" && req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true;
        const viri = (Array.isArray(b.viri) ? b.viri : []).map(v => ({ ime: String(v.ime || "").slice(0, 80), url: String(v.url || "").trim() })).filter(v => /^https?:\/\//i.test(v.url)).slice(0, 10);
        S.pisi(UN, viri); audit(me, "umik-viri", "", "", String(viri.length), ip); send(res, 200, { ok: true }); return true;
      }
      if (p === "/api/umiki/osvezi" && req.method === "POST") { send(res, 200, await osveziUmike(true)); return true; }
      if (p === "/api/umiki/rasff" && req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true; const ids = a => (Array.isArray(a) ? a : String(a || "").split(",")).map(x => String(x).trim()).filter(Boolean).map(Number).filter(Number.isInteger);
        const o = rasffNast(); o.vklopljeno = b.vklopljeno === true; const k = ids(b.klasifikacija), i2 = ids(b.izvor); if (k.length) o.klasifikacija = k; if (i2.length) o.izvor = i2;
        S.pisi(UR, o); audit(me, "umik-rasff", "", "", o.vklopljeno ? "vklopljen" : "izklopljen", ip); send(res, 200, o); return true;
      }
      const mu = p.match(/^\/api\/umiki\/([\w-]+)$/);
      if (mu && req.method === "DELETE") { S.pisi(UF, rjson(UF, []).filter(x => x.id !== mu[1])); send(res, 200, { ok: true }); return true; }
    }
    if (p === "/api/omrezje" && req.method === "GET") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const inf = o.omrezje ? o.omrezje() : { host: "127.0.0.1", port: 3000 }, ips = [];
      for (const l of Object.values(require("os").networkInterfaces())) for (const a of l || []) if (a.family === "IPv4" && !a.internal) ips.push(a.address);
      send(res, 200, { host: inf.host, port: inf.port, omrezje: inf.host === "0.0.0.0", testno: TESTNO, naslovi: inf.host === "0.0.0.0" ? ips.map(i => "http://" + i + ":" + inf.port + "/") : [] }); return true;
    }
    if (p === "/api/testno/ponastavi" && req.method === "POST") {
      if (!TESTNO) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      S.ponastavi();
      for (const f of fs.readdirSync(DIR)) { const fp = path.join(DIR, f); if (f.startsWith("_revizijska") || f === "_kopije" || S.DB_DATOTEKE.test(f)) continue; try { if (fs.statSync(fp).isDirectory()) { if (f === "priloge") for (const g of fs.readdirSync(fp)) fs.unlinkSync(path.join(fp, g)); } else fs.unlinkSync(fp); } catch {} }
      for (const k of Object.keys(cache)) delete cache[k];
      SESS.clear(); testniPodatki(); audit(null, "testno-ponastavitev", "", "", me.email, ip); send(res, 200, { ok: true }); return true;
    }
    if (p === "/api/tisk") {
      const TF = path.join(DIR, "_tisk.json");
      const KAT = { haccp: "HACCP načrt (PDF, Word, Excel)", navodila: "Delovna navodila", evidence: "Evidence in higiena (izpisi)", capa: "Korektivni ukrepi (CAPA)", inspekcija: "Inšpekcijska mapa", obrazci: "Prazni obrazci", qr: "QR kode (tisk)", ostalo: "Ostali izpisi (tloris, storitve ...)" };
      const VLOGE = ["svetovalec", "odgovorna", "zaposleni"];
      const priv = { haccp: { svetovalec: true, odgovorna: true, zaposleni: false }, navodila: { svetovalec: true, odgovorna: true, zaposleni: true }, evidence: { svetovalec: true, odgovorna: true, zaposleni: true }, capa: { svetovalec: true, odgovorna: true, zaposleni: false }, inspekcija: { svetovalec: true, odgovorna: true, zaposleni: false }, obrazci: { svetovalec: true, odgovorna: true, zaposleni: true }, qr: { svetovalec: true, odgovorna: true, zaposleni: true }, ostalo: { svetovalec: true, odgovorna: true, zaposleni: false } };
      let sh = {}; try { sh = S.beri(TF); } catch {}
      const pravila = {}; for (const k of Object.keys(KAT)) { pravila[k] = {}; for (const v of VLOGE) pravila[k][v] = sh[k] && typeof sh[k][v] === "boolean" ? sh[k][v] : priv[k][v]; }
      if (req.method === "GET") {
        const moje = {}; for (const k of Object.keys(KAT)) moje[k] = me.vloga === "admin" ? true : !!pravila[k][me.vloga];
        send(res, 200, me.vloga === "admin" ? { moje, kategorije: KAT, pravila } : { moje }); return true;
      }
      if (req.method === "PUT") {
        if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
        const b = await jbody(req, res); if (!b) return true; const n = {};
        for (const k of Object.keys(KAT)) { n[k] = {}; for (const v of VLOGE) n[k][v] = b.pravila && b.pravila[k] && typeof b.pravila[k][v] === "boolean" ? b.pravila[k][v] : pravila[k][v]; }
        S.pisi(TF, n); audit(me, "nastavitve-tiska", "", "", "", ip); send(res, 200, { ok: true }); return true;
      }
    }
    if (p === "/api/nastavitve") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      if (req.method === "GET") { const c = nast(); send(res, 200, Object.assign({}, c, { geslo: c.geslo ? "********" : "", kopija_geslo: undefined, oblak_skrivnost: c.oblak_skrivnost ? "********" : "", api_kljuc: c.api_kljuc ? "********" : "" })); return true; }
      if (req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true; const old = nast();
        // ostale nastavitve (kopija v oblak, kopija na drugo mesto …) ostanejo; spremenijo se samo polja e-pošte
        const n = { ...old, kopija_mapa: old.kopija_mapa, kopija_geslo: old.kopija_geslo, vklopljeno: b.vklopljeno !== false, streznik: String(b.streznik || "").trim(), vrata: +b.vrata || "", varnost: ["ssl", "starttls", "brez"].includes(b.varnost) ? b.varnost : "starttls", uporabnik: String(b.uporabnik || ""), geslo: b.geslo && b.geslo !== "********" ? String(b.geslo) : old.geslo || "", od: String(b.od || "").trim(), naslov_aplikacije: String(b.naslov_aplikacije || "").trim(), nacin: API_POSTA[b.nacin] ? b.nacin : "smtp", api_kljuc: b.api_kljuc && b.api_kljuc !== "********" ? String(b.api_kljuc).trim() : b.api_kljuc === "" ? "" : old.api_kljuc || "" };
        nastShrani(n); audit(me, "nastavitve-obvestil", "", "", n.streznik, ip); send(res, 200, { ok: true }); return true;
      }
    }


    if (p === "/api/obvestila/zdaj" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const r = await posljiObvestila(true); audit(me, "obvestila-poslana", "", "", JSON.stringify({ poslano: r.poslano }), ip); send(res, 200, r); return true;
    }
    if (p === "/api/obvestila/test" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const b = await jbody(req, res); if (!b) return true; const c = nast();
      if (!postaNastavljena(c)) { bad(res, 400, "E-pošta ni nastavljena: vnesite pošiljatelja in strežnik SMTP ali ključ API."); return true; }
      // napaka pošiljanja je 400 z razlago (ne 502: Cloudflare bi 5xx prikazal kot napako prehoda); zapiše se tudi v »Zadnje napake strežnika«
      try { await smtpSend(c, String(b.komu || ""), "HiGiFood HACCP: testno sporočilo", "Testno sporočilo. Pošiljanje obvestil deluje."); send(res, 200, { ok: true }); } catch (e) { if (!e.smtp) console.error("E-pošta: " + prijazno(e)); bad(res, 400, e.smtp ? e.message : "Pošiljanje ni uspelo: " + prijazno(e)); }
      return true;
    }
    // preverjanje odhodnih vrat SMTP iz strežnika (namesto »nc -vz« v vsebniku Docker)
    if (p === "/api/obvestila/vrata" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const b = await jbody(req, res); if (!b) return true; const host = String(b.streznik || nast().streznik || "smtp.gmail.com").trim();
      if (!/^[a-z0-9.-]{1,253}$/i.test(host)) { bad(res, 400, "Neveljavno ime strežnika."); return true; }
      const poskus = port => new Promise(ok => { const t0 = Date.now(), s = net.connect({ host, port }); const kon = (r) => { try { s.destroy(); } catch {} ok(Object.assign({ vrata: port, ms: Date.now() - t0 }, r)); }; s.setTimeout(5000, () => kon({ odprta: false, napaka: "ETIMEDOUT" })); s.once("connect", () => kon({ odprta: true })); s.once("error", e => kon({ odprta: false, napaka: e.code || e.message })); });
      send(res, 200, { streznik: host, rezultati: await Promise.all([465, 587].map(poskus)) }); return true;
    }

    // brez lastnega logotipa GET vrne 204 (uporabi se privzeti HiGiFood), ne 404
    if (p === "/api/logo") {
      const lf = path.join(DIR, "logo.bin"), lm = path.join(DIR, "logo.json");
      if (req.method === "GET") { if (!fs.existsSync(lf)) { res.writeHead(204, { "Cache-Control": "no-store" }); res.end(); return true; } const m = JSON.parse(fs.readFileSync(lm, "utf8")); res.writeHead(200, { "Content-Type": m.tip, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" }); res.end(fs.readFileSync(lf)); return true; }
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      if (req.method === "POST") {
        const b = await jbody(req, res); if (!b) return true; const buf = Buffer.from(String(b.podatki || ""), "base64");
        if (!buf.length || buf.length > 1.5e6 || !/^image\/(png|jpeg|webp)$/.test(b.tip || "") || !vsebinaUstreza(buf, b.tip)) { bad(res, 400, "Logotip: PNG, JPEG ali WebP do 1,5 MB."); return true; }
        fs.writeFileSync(lf, buf); fs.writeFileSync(lm, JSON.stringify({ tip: b.tip })); audit(me, "logotip-nov", "", "", b.tip, ip); send(res, 200, { ok: true }); return true;
      }
      if (req.method === "DELETE") { for (const f of [lf, lm]) try { fs.unlinkSync(f); } catch {} audit(me, "logotip-odstranjen", "", "", "", ip); send(res, 200, { ok: true }); return true; }
    }
    // logotip posamezne stranke: vidijo ga vsi z dostopom do stranke, spremenijo administrator, svetovalec in odgovorna oseba
    const msl = p.match(/^\/api\/stranka-logo\/([\w-]+)$/);
    if (msl) {
      const sid = msl[1];
      if (!tenantOk(me, sid) || !load("stranke").some(s => s.id === sid)) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      const lf = path.join(SLOGO, sid + ".bin"), lm = path.join(SLOGO, sid + ".json");
      if (req.method === "GET") { if (!fs.existsSync(lf)) { res.writeHead(204, { "Cache-Control": "private, no-store" }); res.end(); return true; } const m = JSON.parse(fs.readFileSync(lm, "utf8")); res.writeHead(200, { "Content-Type": m.tip, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" }); res.end(fs.readFileSync(lf)); return true; }
      if (!can(me, COLL.stranke.wr)) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
      if (req.method === "POST") {
        const b = await jbody(req, res); if (!b) return true; const buf = Buffer.from(String(b.podatki || ""), "base64");
        if (!buf.length || buf.length > 1.5e6 || !/^image\/(png|jpeg|webp)$/.test(b.tip || "") || !vsebinaUstreza(buf, b.tip)) { bad(res, 400, "Logotip: PNG, JPEG ali WebP do 1,5 MB."); return true; }
        fs.mkdirSync(SLOGO, { recursive: true }); fs.writeFileSync(lf, buf); fs.writeFileSync(lm, JSON.stringify({ tip: b.tip })); audit(me, "logotip-stranke-nov", "stranke", sid, b.tip, ip); send(res, 200, { ok: true }); return true;
      }
      if (req.method === "DELETE") { for (const f of [lf, lm]) try { fs.unlinkSync(f); } catch {} audit(me, "logotip-stranke-odstranjen", "stranke", sid, "", ip); send(res, 200, { ok: true }); return true; }
    }

    if (p === "/api/kos" && req.method === "GET") {
      // preostali dnevi: cela dneva navzdol (ne navzgor); izbris = čas dokončnega izbrisa
      const out = load("_kos").filter(it => it.zbirka === "uporabniki" ? me.vloga === "admin" : ima(COLL, it.zbirka) && can(me, COLL[it.zbirka].del) && tenantOk(me, it.stranka_id)).map(it => ({ id: it.id, zbirka: it.zbirka, ime: it.ime, cas: it.cas, izbrisal: it.izbrisal, stranka_id: it.stranka_id, stranka: (load("stranke").find(s => s.id === it.stranka_id) || (it.zbirka === "stranke" ? it.zapis : {})).naziv || "", otrok: it.otroci ? Object.values(it.otroci).reduce((a, x) => a + x.length, 0) : 0, preostalo_dni: Math.max(0, Math.floor((new Date(it.cas).getTime() + KOS_DNI * 864e5 - Date.now()) / 864e5)), izbris: new Date(new Date(it.cas).getTime() + KOS_DNI * 864e5).toISOString() })).sort((a, b) => b.cas.localeCompare(a.cas));
      send(res, 200, out); return true;
    }
    const mk = p.match(/^\/api\/kos\/([\w-]+)(\/obnovi)?$/);
    if (mk) {
      const kos = load("_kos"), it = kos.find(x => x.id === mk[1]);
      if (!it || (it.zbirka === "uporabniki" ? me.vloga !== "admin" : !ima(COLL, it.zbirka) || !can(me, COLL[it.zbirka].del) || !tenantOk(me, it.stranka_id))) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      if (mk[2] && req.method === "POST" && it.zbirka === "uporabniki") {
        const us = load("uporabniki"); if (us.some(x => x.id === it.zapis.id || x.email === it.zapis.email)) { bad(res, 409, "Uporabnik s tem e-naslovom že obstaja."); return true; }
        us.push(it.zapis); save("uporabniki"); cache["_kos"] = kos.filter(x => x !== it); save("_kos"); audit(me, "obnovi", "uporabniki", it.zapis.id, it.ime, ip); send(res, 200, { ok: true }); return true;
      }
      if (mk[2] && req.method === "POST") {
        if (it.zbirka !== "stranke" && !load("stranke").some(s => s.id === it.stranka_id)) { bad(res, 409, "Najprej obnovite stranko, kateri zapis pripada."); return true; }
        const tgt = load(it.zbirka); if (tgt.some(x => x.id === it.zapis.id)) { bad(res, 409, "Zapis s to oznako že obstaja."); return true; }
        tgt.push(it.zapis); save(it.zbirka);
        for (const [k, arr] of Object.entries(it.otroci || {})) { const cur = load(k); for (const x of arr) if (!cur.some(y => y.id === x.id)) cur.push(x); save(k); }
        cache["_kos"] = kos.filter(x => x !== it); save("_kos"); audit(me, "obnovi", it.zbirka, it.zapis.id, it.ime, ip); send(res, 200, { ok: true }); return true;
      }
      if (!mk[2] && req.method === "DELETE") {
        if (me.vloga !== "admin") { bad(res, 403, "Trajno briše samo administrator."); return true; }
        for (const pr of (it.zbirka === "priloge" ? [it.zapis] : (it.otroci && it.otroci.priloge) || [])) try { fs.unlinkSync(path.join(PRIL, pr.id)); } catch {}
        cache["_kos"] = kos.filter(x => x !== it); save("_kos"); audit(me, "izbris-trajno", it.zbirka, it.zapis.id, it.ime, ip); send(res, 200, { ok: true }); return true;
      }
      bad(res, 405, "Ta zahteva ni podprta."); return true;
    }
  }

  // Poti: varnostne kopije, obnova, ustavitev. Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  async function rKopije(req, res, p, url, me, ip, users) {
    // --- skrbniške funkcije ---
    if (p === "/api/revizijska-sled" && req.method === "GET") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      send(res, 200, { preveritev: auditVerify(), vnosi: auditRead(Math.min(parseInt(url.searchParams.get("n") || "200", 10) || 200, 2000)) }); return true;
    }

    if (p.startsWith("/api/kopija/oblak")) {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const c = nast(), javno = () => { const x = nast(); return { endpoint: x.oblak_endpoint || "", regija: x.oblak_regija || "", vedro: x.oblak_vedro || "", kljuc_id: x.oblak_kljuc_id || "", skrivnost: x.oblak_skrivnost ? "********" : "", predpona: x.oblak_predpona || "", sifrirano: !!x.kopija_geslo, stanje: oblakStanje() }; };
      if (p === "/api/kopija/oblak" && req.method === "GET") { send(res, 200, javno()); return true; }
      if ((p === "/api/kopija/oblak" && req.method === "PUT") || (p === "/api/kopija/oblak/preizkus" && req.method === "POST")) {
        const b = await jbody(req, res); if (!b) return true;
        const v = { oblak_endpoint: String(b.endpoint || "").trim(), oblak_regija: String(b.regija || "").trim(), oblak_vedro: String(b.vedro || "").trim(), oblak_kljuc_id: String(b.kljuc_id || "").trim(), oblak_predpona: String(b.predpona || "").trim().replace(/^\/+|\/+$/g, "") };
        v.oblak_skrivnost = b.skrivnost === "********" || b.skrivnost === undefined ? c.oblak_skrivnost || "" : String(b.skrivnost || "");
        if (v.oblak_endpoint && !/^https:\/\/[^\s/]+/.test(v.oblak_endpoint) && !/^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?/.test(v.oblak_endpoint)) { bad(res, 400, "Končna točka mora biti https://…"); return true; }
        if (v.oblak_vedro && !/^[a-z0-9][a-z0-9.\-]{1,62}$/.test(v.oblak_vedro)) { bad(res, 400, "Ime vedra: male črke, številke, pika in vezaj."); return true; }
        if (v.oblak_predpona && !/^[\w.\-/]{1,100}$/.test(v.oblak_predpona)) { bad(res, 400, "Predpona: črke, številke, _ . - in /."); return true; }
        if (p.endsWith("/preizkus")) { const n = oblakNast(Object.assign({}, c, v)); if (!n) { bad(res, 400, "Izpolnite končno točko, vedro, ključ in skrivni ključ."); return true; } try { await OBL.preizkusi(n); send(res, 200, { ok: true }); } catch (e) { bad(res, 400, e.message); } return true; }
        if (v.oblak_vedro && !c.kopija_geslo) { bad(res, 400, "Najprej nastavite geslo za šifriranje kopij (Kopija na drugo mesto). Kopije v oblak so vedno šifrirane."); return true; }
        nastShrani(Object.assign(c, v)); audit(me, "kopija-oblak", "", "", v.oblak_vedro ? v.oblak_endpoint + " / " + v.oblak_vedro : "izklopljeno", ip);
        send(res, 200, javno()); return true;
      }
      if (p === "/api/kopija/oblak/zdaj" && req.method === "POST") {
        if (!oblakNast()) { bad(res, 400, "Kopija v oblak ni nastavljena."); return true; }
        const zip = makeBackup(), st = await kopijaVOblak(zip, "kopija-" + now().slice(0, 10) + ".zip"); audit(me, "kopija-oblak-zdaj", "", "", st.ok ? st.datoteka : "napaka: " + st.napaka, ip);
        if (st.ok) send(res, 200, st); else bad(res, 502, st.napaka || "napaka"); return true;
      }
      bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true;
    }
    if (p === "/api/kopija/nastavitve") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      if (req.method === "GET") { send(res, 200, { mapa: nast().kopija_mapa || "", sifrirano: !!nast().kopija_geslo, stanje: kstat() }); return true; }
      if (req.method === "PUT") {
        const b = await jbody(req, res); if (!b) return true; const all = nast(), dir = String(b.mapa || "").trim();
        if (dir) { try { mkdirPlitvo(dir); const t = path.join(dir, ".test-" + uid()); fs.writeFileSync(t, "x"); fs.unlinkSync(t); } catch (e) { bad(res, 400, "V mapo ni mogoče pisati: " + e.message); return true; } }
        if (b.geslo !== undefined && b.geslo !== "********") { if (b.geslo && String(b.geslo).length < 8) { bad(res, 400, "Geslo za šifriranje mora imeti vsaj 8 znakov."); return true; } all.kopija_geslo = String(b.geslo || ""); if (!all.kopija_geslo) delete all.kopija_geslo; }
        all.kopija_mapa = dir; nastShrani(all); audit(me, "kopija-mapa", "", "", dir, ip);
        autoBackup(true); send(res, 200, { ok: true, stanje: kstat() }); return true;
      }
    }
    if (p === "/api/ustavi" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      audit(me, "program-ustavljen", "", "", "", ip); send(res, 200, { ok: true }); setTimeout(() => process.exit(0), 400); return true;
    }
    if (p === "/api/kopija/sifrirana" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const b = await jbody(req, res); if (!b) return true; if (!b.geslo || String(b.geslo).length < 8) { bad(res, 400, "Geslo mora imeti vsaj 8 znakov."); return true; }
      const z = sifriraj(makeBackup(), b.geslo); audit(me, "kopija-prenos-sifrirana", "", "", z.length + " B", ip);
      res.writeHead(200, { "Content-Type": "application/octet-stream", "Content-Disposition": `attachment; filename="higifood-kopija-${now().slice(0, 10)}.hfbk"`, "Cache-Control": "no-store" }); res.end(z); return true;
    }
    if (p === "/api/kopija/zdaj" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      autoBackup(true); audit(me, "kopija-zdaj", "", "", "", ip); send(res, 200, { ok: true, stanje: kstat() }); return true;
    }
    if (p === "/api/kopija" && req.method === "GET") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      const z = makeBackup(); audit(me, "kopija-prenos", "", "", z.length + " B", ip);
      res.writeHead(200, { "Content-Type": "application/zip", "Content-Disposition": `attachment; filename="higifood-kopija-${now().slice(0, 10)}.zip"`, "Cache-Control": "no-store" });
      res.end(z); return true;
    }
    if (p === "/api/obnovi" && req.method === "POST") {
      if (me.vloga !== "admin") { bad(res, 403, "To lahko naredi samo administrator."); return true; }
      // kopija pride kot binarna datoteka (application/octet-stream, do 1 GB) ali – starejši odjemalci – kot base64 v besedilu
      const binarno = /octet-stream/.test(req.headers["content-type"] || "");
      let s; try { s = await body(req, binarno ? 1e9 : 200e6, binarno ? "buf" : undefined); } catch { bad(res, 413, "Datoteka je prevelika."); return true; }
      let files; try { let raw = binarno ? s : Buffer.from(s, "base64"); if (jeSifrirana(raw)) { let g = req.headers["x-kopija-geslo"]; if (g && req.headers["x-kopija-geslo-kodirano"]) try { g = decodeURIComponent(g); } catch {} if (!g) { bad(res, 400, "Kopija je šifrirana: vnesite geslo."); return true; } raw = desifriraj(raw, g); } files = zipRead(raw); } catch (e) { bad(res, 400, e.message); return true; }
      const ok = files.filter(f => /^(baza|podatki)\/[\w\-./]+$/.test(f.name) && !f.name.includes("..") && !/^podatki\/(_kljuc|_seje\.json)$/.test(f.name));
      if (!ok.some(f => f.name.startsWith("podatki/uporabniki.json"))) { bad(res, 400, "Kopija ne vsebuje uporabnikov – ni veljavna."); return true; }
      { const g = nast().kopija_geslo, z = makeBackup(); fs.writeFileSync(path.join(BKP, "pred-obnovo-" + now().replace(/[:.]/g, "-") + (g ? ".hfbk" : ".zip")), g ? sifriraj(z, g) : z);
        // hranimo zadnjih 5 kopij »pred obnovo« (vsaka je polna kopija podatkov)
        try { const st = fs.readdirSync(BKP).filter(f => /^pred-obnovo-/.test(f)).sort(); for (const f of st.slice(0, Math.max(0, st.length - 5))) fs.unlinkSync(path.join(BKP, f)); } catch {} }
      for (const f of ok) {
        const target = f.name.startsWith("baza/") ? path.join(DB, f.name.slice(5)) : path.join(DIR, f.name.slice(8));
        fs.mkdirSync(path.dirname(target), { recursive: true });
        // atomično: najprej začasna datoteka, nato preimenovanje (prekinitev med obnovo ne pusti okrnjene datoteke)
        const tmp = target + ".obnova-" + process.pid; fs.writeFileSync(tmp, f.data); fs.renameSync(tmp, target);
      }
      for (const k of Object.keys(cache)) delete cache[k];
      S.uvoziDatoteke(Object.keys(COLL).concat(["uporabniki", "_kos"])); // obnovljene zbirke (JSON iz kopije) v podatkovno bazo
      auditLast(); // revizijska sled je bila zamenjana z datoteko iz kopije
      audit(me, "obnova", "", "", ok.length + " datotek", ip);
      send(res, 200, { ok: true, datotek: ok.length }); return true;
    }

  }

  // Poti: priloge. Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  async function rPriloge(req, res, p, url, me, ip, users) {
    // --- priloge (datoteke) ---
    if (p === "/api/priloga" && req.method === "POST") {
      const b = await jbody(req, res); if (!b) return true;
      if (!tenantOk(me, b.stranka_id) || !can(me, COLL.priloge.cr)) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
      if (typeof b.podatki !== "string") { bad(res, 400, "Manjka vsebina datoteke."); return true; }
      const buf = Buffer.from(b.podatki, "base64");
      if (!buf.length || buf.length > 8e6) { bad(res, 400, "Datoteka je prazna ali večja od 8 MB."); return true; }
      if (!/^(image\/(png|jpeg|webp|gif)|application\/pdf|text\/plain)$/.test(b.tip || "") || !vsebinaUstreza(buf, b.tip)) { bad(res, 400, "Dovoljene so slike, PDF in besedilo (vsebina datoteke se mora ujemati z vrsto)."); return true; }
      const id = uid();
      fs.writeFileSync(path.join(PRIL, id), buf);
      const r = { id, stranka_id: b.stranka_id, obrat_id: b.obrat_id || null, ime: String(b.ime || "priloga").slice(0, 120), tip: b.tip, velikost: buf.length, povezava: b.povezava || null, ustvarjeno: now(), ustvaril: me.id };
      load("priloge").push(r); save("priloge");
      audit(me, "priloga-nova", "priloge", id, r.ime, ip);
      send(res, 200, r); return true;
    }
    const mp = p.match(/^\/api\/priloga\/([\w-]+)$/);
    if (mp && req.method === "GET") {
      const r = load("priloge").find(x => x.id === mp[1]);
      if (!r || !visible(me, "priloge", r)) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      res.writeHead(200, { "Content-Type": r.tip, "Content-Disposition": `inline; filename="${encodeURIComponent(r.ime)}"`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff", "Content-Security-Policy": "sandbox" });
      res.end(fs.readFileSync(path.join(PRIL, r.id))); return true;
    }

  }

  // Poti: podatkovne zbirke (/api/d/…). Vrne true (obdelano), false (prepusti strežniku) ali undefined (naslednja skupina poti).
  async function rZbirke(req, res, p, url, me, ip, users) {
    // --- podatkovne zbirke (stranke, obrati, evidence, CAPA …) ---
    // fotografije k obstoječemu zapisu evidence (npr. prevzem blaga prek QR kode): doda jih lahko vsak z dostopom do stranke,
    // potrjen zapis le odgovorna oseba ali svetovalec; dodajo se samo priloge iste stranke, sprememba gre v zgodovino
    const msl = p.match(/^\/api\/d\/evidence\/([\w-]+)\/slike$/);
    if (msl && req.method === "POST") {
      if (!can(me, COLL.evidence.wr)) { bad(res, 403, "Za dodajanje fotografij nimate pravic."); return true; }
      const data = load("evidence"), r = data.find(x => x.id === msl[1]);
      if (!r || !visible(me, "evidence", r)) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      if (r.status === "potrjeno" && !can(me, "ASO")) { bad(res, 403, "Zapis je potrjen – fotografije lahko doda le odgovorna oseba ali svetovalec."); return true; }
      const b = await jbody(req, res); if (!b) return true;
      const ids = Array.isArray(b.slike) ? [...new Set(b.slike.filter(x => typeof x === "string"))] : [];
      if (!ids.length) { bad(res, 400, "Izberite vsaj eno fotografijo."); return true; }
      const pr = load("priloge"); if (ids.some(id => !pr.some(x => x.id === id && x.stranka_id === r.stranka_id))) { bad(res, 400, "Fotografija ne pripada tej stranki."); return true; }
      const prej = Array.isArray(r.slike) ? r.slike : [], nove = [...new Set(prej.concat(ids))];
      if (nove.length > 30) { bad(res, 400, "Zapis ima lahko največ 30 fotografij."); return true; }
      r.revizije = r.revizije || []; r.revizije.push({ n: r.verzija || 1, cas: now(), uporabnik: me.id, ime: me.ime, razlog: "dodane fotografije (" + (nove.length - prej.length) + ")", prej: { slike: prej } }); r.verzija = (r.verzija || 1) + 1;
      r.slike = nove; r.spremenjeno = now(); r.spremenil = me.id; r.spremenil_ime = me.ime;
      save("evidence"); audit(me, "fotografije", "evidence", r.id, String(nove.length - prej.length), ip); send(res, 200, outv(me, "evidence", r)); return true;
    }
    // paketna potrditev zapisov evidenc (Pregled zapisov): ena zahteva, en zapis na disk; vrne potrjene in zavrnjene po id
    if (p === "/api/d/evidence/_potrdi" && req.method === "POST") {
      if (!can(me, "ASO") || !can(me, COLL.evidence.wr)) { bad(res, 403, "Zapis lahko potrdi odgovorna oseba ali svetovalec."); return true; }
      const b = await jbody(req, res); if (!b) return true;
      const ids = Array.isArray(b.ids) ? [...new Set(b.ids.filter(x => typeof x === "string"))] : null;
      if (!ids || !ids.length || ids.length > 2000) { bad(res, 400, "Pošljite seznam ids (1–2000)."); return true; }
      const data = load("evidence"), byId = new Map(data.map(r => [r.id, r])), potrjeni = [], napake = {}, cas = now();
      for (const id of ids) {
        const r = byId.get(id);
        if (!r || !visible(me, "evidence", r)) { napake[id] = "zapisa ni mogoče najti ali do njega nimate dostopa"; continue; }
        if (r.status === "potrjeno") { potrjeni.push(id); continue; }
        r.revizije = r.revizije || []; r.revizije.push({ n: r.verzija || 1, cas, uporabnik: me.id, ime: me.ime, razlog: "potrditev zapisa", prej: { status: r.status } }); r.verzija = (r.verzija || 1) + 1;
        r.status = "potrjeno"; r.spremenjeno = cas; r.spremenil = me.id; r.spremenil_ime = me.ime; potrjeni.push(id);
      }
      if (potrjeni.length) { save("evidence"); audit(me, "potrdi-zapise", "evidence", "", String(potrjeni.length), ip); }
      send(res, 200, { potrjeni, napake }); return true;
    }
    const md = p.match(/^\/api\/d\/([a-z_]+)(?:\/([\w-]+))?$/);
    if (md) {
      const c = md[1], cfg = ima(COLL, c) ? COLL[c] : null; // »constructor«, »__proto__« niso zbirke
      if (c === "priloge" && req.method !== "GET") { bad(res, 400, "Priloge nalagajte prek /api/priloga."); return true; }
      if (!cfg) { bad(res, 404, "Ta vrsta podatkov ne obstaja."); return true; }
      const data = load(c);
      if (!md[2]) {
        if (req.method === "GET") {
          if (!can(me, cfg.rd)) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
          let r = data.filter(x => visible(me, c, x)).map(x => outv(me, c, x));
          for (const [k, v] of url.searchParams) if (!k.startsWith("_") && /^[a-z_]+$/.test(k)) r = r.filter(x => String(x[k]) === v);
          send(res, 200, r); return true;
        }
        if (req.method === "POST") {
          if (!can(me, cfg.cr)) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
          const b = await jbody(req, res); if (!b) return true;
          const r = clean(b);
          if (c === "stranke" && me.vloga !== "admin") delete r.paket; // paket = naročnina, ureja jo samo administrator
          r.id = uid();
          if (c !== "stranke") {
            if (me.vloga === "odgovorna" || me.vloga === "zaposleni") r.stranka_id = me.stranka_id;
            if (!tenantOk(me, r.stranka_id)) { bad(res, 403, "Nimate dostopa do izbrane stranke."); return true; }
            if (!load("stranke").some(s => s.id === r.stranka_id)) { bad(res, 400, "Stranka ne obstaja."); return true; }
            if (r.obrat_id) {
              const ob = load("obrati").find(x => x.id === r.obrat_id);
              if (!ob || ob.stranka_id !== r.stranka_id) { bad(res, 400, "Obrat ne pripada stranki."); return true; }
            }
          }
          { const e = preveriZapis(c, r) || preveriPravila(c, r); if (e) { bad(res, 400, e); return true; } }
          for (const k of cfg.req) if (r[k] === undefined || String(r[k]).replace(/[\u200b-\u200d\u2060\ufeff]/g, "").trim() === "") { bad(res, 400, `Polje »${k}« je obvezno.`); return true; }
          if (c === "stranke") { const e = preveriStranko(r); if (e) { bad(res, 400, e); return true; } }
          r.ustvarjeno = now(); r.ustvaril = me.id; r.ustvaril_ime = me.ime;
          if (cfg.rev) { r.revizije = []; r.verzija = 1; }
          if (c === "evidence") r.skladno = ocenaEvidence(r);
          if (c === "sarze" && PRAVILA.pretecena(r, danesS())) r.status = "pretečeno"; // rok uporabe je že potekel
          // čas zapisa ne sme biti v prihodnosti (napačna ura telefona, vrsta brez povezave): popravimo ga na zdaj, prvotni ostane zapisan
          if (cfg.rec && r.cas && Date.parse(r.cas) > Date.now() + 5 * 60e3) { r.cas_naprave = r.cas; r.cas = now(); }
          if (cfg.rec) { r.cas = r.cas && /^\d{4}-\d\d-\d\d/.test(r.cas) ? r.cas : now(); r.status = r.status === "potrjeno" && !can(me, "ASO") ? "vneseno" : (r.status || "vneseno"); }
          if (c === "stranke" && me.vloga === "svetovalec") { me.stranke = [...(me.stranke || []), r.id]; save("uporabniki"); }
          data.push(r); save(c);
          if (c === "stranke" && r.paket) NAR.nastaviPaket(r.id, r.paket); // paket iz obrazca stranke = naročnina
          audit(me, "ustvari", c, r.id, r.naziv || r.vrsta || r.naslov || "", ip);
          send(res, 200, outv(me, c, r)); return true;
        }
        bad(res, 405, "Ta zahteva ni podprta."); return true;
      }
      const r = data.find(x => x.id === md[2]);
      if (!r || !visible(me, c, r) || !can(me, cfg.rd)) { bad(res, 404, "Zapisa ni mogoče najti – morda je bil izbrisan ali do njega nimate dostopa."); return true; }
      if (req.method === "GET") { send(res, 200, outv(me, c, r)); return true; }
      if (req.method === "PUT") {
        if (!can(me, cfg.wr)) { bad(res, 403, "Za to dejanje nimate pravic. Če ga potrebujete, se obrnite na administratorja."); return true; }
        const b = await jbody(req, res); if (!b) return true;
        const nw = clean(b), razlog = String(b._razlog || b.razlog_spremembe || "").trim();
        delete nw.razlog_spremembe; delete nw._razlog; delete nw._ver;
        { const e = preveriZapis(c, nw) || preveriPravila(c, Object.assign({}, r, nw)); if (e) { bad(res, 400, e); return true; } }
        if (c === "stranke") { const e = preveriStranko(nw); if (e) { bad(res, 400, e); return true; } }
        if (b._ver && b._ver !== (r.spremenjeno || r.ustvarjeno)) { const kdo = (load("uporabniki").find(x => x.id === r.spremenil) || {}).ime || "drug uporabnik"; bad(res, 409, `Zapis je medtem spremenil(a) ${kdo} (${String(r.spremenjeno || "").slice(0, 16).replace("T", " ")} UTC). Zaprite obrazec, osvežite stran in vnesite spremembo znova.`); return true; }
        if (cfg.rec) {
          if (r.status === "potrjeno" && !can(me, "ASO")) { bad(res, 403, "Potrjenega zapisa zaposleni ne morejo spreminjati."); return true; }
          if (nw.status === "potrjeno" && !can(me, "ASO")) { bad(res, 403, "Zapis lahko potrdi odgovorna oseba ali svetovalec."); return true; }
          if (r.status === "potrjeno" && !razlog) { bad(res, 400, "Za popravek potrjenega zapisa vnesite razlog."); return true; }
          if (r.status !== "potrjeno" && r.ustvaril !== me.id && !can(me, "ASO")) { bad(res, 403, "Zapis lahko popravi samo avtor ali odgovorna oseba."); return true; }
        }
        if (c === "capa" && r.status === "zaprto" && !razlog) { bad(res, 400, "Zaprt ukrep lahko spremenite samo z razlogom."); return true; }
        // potrjen HACCP načrt ali navodilo je zaklenjen tudi prek API: najprej (z razlogom) spremenite stanje, nato vsebino
        if ((c === "nacrti" || c === "navodila") && r.status === "potrjeno") {
          const spr = Object.keys(nw).filter(k => k !== "naslednji_pregled" && k !== "status" && JSON.stringify(r[k]) !== JSON.stringify(nw[k]));
          if ((nw.status === undefined || nw.status === "potrjeno") && spr.length) { bad(res, 409, "Potrjen dokument je zaklenjen. Za spremembo vsebine najprej spremenite stanje (z razlogom)."); return true; }
          if (nw.status !== undefined && nw.status !== "potrjeno" && !razlog) { bad(res, 400, "Za odklepanje potrjenega dokumenta vnesite razlog."); return true; }
        }
        if (c !== "stranke") { nw.stranka_id = r.stranka_id; }
        if (c === "stranke" && me.vloga === "odgovorna") { for (const k of ["svetovalec", "paket", "cena", "notranje", "opomniki_izklop"]) delete nw[k]; }
        if (c === "stranke" && me.vloga !== "admin") delete nw.paket; // svetovalec prek obrazca stranke ne sme spremeniti ali izbrisati naročnine
        if (nw.obrat_id) {
          const ob = load("obrati").find(x => x.id === nw.obrat_id);
          if (!ob || ob.stranka_id !== r.stranka_id) { bad(res, 400, "Obrat ne pripada stranki."); return true; }
        }
        for (const k of cfg.req) if (nw[k] !== undefined && String(nw[k]).replace(/[\u200b-\u200d\u2060\ufeff]/g, "").trim() === "") { bad(res, 400, `Polje »${k}« je obvezno.`); return true; }
        // polja, ki jih PUT ne more spremeniti (id, avtor, različica, čas zapisa evidence), ne štejejo kot sprememba
        for (const k of ["id", "ustvarjeno", "ustvaril", "ustvaril_ime", "revizije", "verzija"].concat(cfg.rec ? ["cas"] : [])) delete nw[k];
        if (cfg.rev) {
          const prej = {};
          for (const k of Object.keys(nw)) if (JSON.stringify(r[k]) !== JSON.stringify(nw[k])) prej[k] = r[k];
          if (!Object.keys(prej).length) { send(res, 200, r); return true; }
          // zapis evidence in neskladnost (CAPA): vsaka sprememba obstoječe različice mora imeti razlog (sledljivost za inšpekcijo)
          if ((c === "evidence" || c === "capa") && razlog.length < RAZLOG_MIN) { bad(res, 400, `Vnesite razlog popravka (vsaj ${RAZLOG_MIN} znake).`); return true; }
          r.revizije.push({ n: r.verzija, cas: now(), uporabnik: me.id, ime: me.ime, razlog, prej });
          r.verzija++;
        }
        const staroIme = r.naziv;
        const keep = { id: r.id, ustvarjeno: r.ustvarjeno, ustvaril: r.ustvaril, ustvaril_ime: r.ustvaril_ime, revizije: r.revizije, verzija: r.verzija, cas: cfg.rec ? r.cas : undefined };
        Object.assign(r, nw);
        for (const [k, v] of Object.entries(keep)) if (v !== undefined) r[k] = v;
        if (c === "evidence") r.skladno = ocenaEvidence(r);
        if (c === "sarze" && PRAVILA.pretecena(r, danesS())) r.status = "pretečeno";
        r.spremenjeno = now(); r.spremenil = me.id; r.spremenil_ime = me.ime;
        // preimenovana naprava: urnik pogostosti vnosov sledi novemu imenu (sicer bi ostalo trajno opozorilo »Manjka vnos«)
        if (c === "oprema" && nw.naziv !== undefined && staroIme && r.naziv !== staroIme) { r.prejsnja_imena = [...new Set([...(Array.isArray(r.prejsnja_imena) ? r.prejsnja_imena : []), staroIme])].filter(x => x !== r.naziv).slice(-20); let n = 0; for (const u of load("urnik")) if (u.stranka_id === r.stranka_id && u.naprava === staroIme) { u.naprava = r.naziv; n++; } if (n) save("urnik"); }
        save(c); if (c === "stranke" && nw.paket !== undefined) NAR.nastaviPaket(r.id, r.paket); audit(me, "spremeni", c, r.id, razlog, ip);
        send(res, 200, outv(me, c, r)); return true;
      }
      if (req.method === "DELETE") {
        if (!can(me, cfg.del)) { bad(res, 403, cfg.del === "" ? "Zapisov te vrste ni mogoče brisati (revizijska sled)." : "Za brisanje teh zapisov nimate pravic."); return true; }
        // mehko brisanje: zapis (in pri stranki vsi podrejeni zapisi) gre v koš za 30 dni
        const kos = load("_kos"), item = { id: uid(), zbirka: c, stranka_id: c === "stranke" ? r.id : r.stranka_id, ime: r.naziv || r.ime || r.naslov || r.oznaka || r.opravilo || r.tema || "", cas: now(), izbrisal: me.ime, zapis: r };
        data.splice(data.indexOf(r), 1);
        if (c === "stranke") { item.otroci = {}; for (const k of CASCADE) { item.otroci[k] = load(k).filter(x => x.stranka_id === r.id); cache[k] = load(k).filter(x => x.stranka_id !== r.id); save(k); } }
        kos.push(item); save("_kos");
        save(c); audit(me, "izbriši", c, r.id, item.ime, ip);
        send(res, 200, { ok: true }); return true;
      }
      bad(res, 405, "Ta zahteva ni podprta."); return true;
    }
  }


  // ---------- testno okolje: demo podatki in testni računi (samo ob zagonu z --testno) ----------
  const TEST_RACUNI = [["admin@test.si", "admin", "Administrator: vse, tudi nastavitve (samo za vodje testiranja)"], ["svetovalec@test.si", "svetovalec", "HACCP-svetovalec: dela s strankami"], ["odgovorna@test.si", "odgovorna", "Odgovorna oseba stranke"], ["zaposleni@test.si", "zaposleni", "Zaposleni stranke (najmanj pravic)"]];
  function testniPodatki() {
    if (load("uporabniki").length) return;
    const t = n => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10), c0 = now();
    const ins = (c, r) => { const x = Object.assign({ id: uid(), ustvarjeno: c0, ustvaril: "test", ustvaril_ime: "Testni podatki" }, r); if (COLL[c].rev) { x.revizije = []; x.verzija = 1; } load(c).push(x); return x; };
    const s = ins("stranke", { naziv: "Testna gostilna d.o.o.", dejavnost: "Gostinstvo", odgovorna_oseba: "Mojca Testna", naslov: "Testna ulica 1, Ljubljana", naslednji_pregled: t(25) });
    const sid = s.id, P = r => Object.assign({ stranka_id: sid }, r);
    ins("obrati", P({ naziv: "Kuhinja" }));
    ins("oprema", P({ naziv: "Hladilnik 1", tip: "hladilnik", lokacija: "Kuhinja", naslednji_servis: t(14) })); ins("oprema", P({ naziv: "Zamrzovalnik 1", tip: "zamrzovalnik", lokacija: "Skladišče" }));
    ins("osebje", P({ ime: "Ana Testna", funkcija: "Kuharica", higienski_do: t(60), zdravniski_do: t(-3) })); ins("osebje", P({ ime: "Boris Testni", funkcija: "Natakar", higienski_do: t(200) }));
    ins("usposabljanja", P({ tema: "Osebna higiena", datum: t(-30), udelezenci: "Ana Testna, Boris Testni", izvajalec: "Testni izvajalec", veljavno_do: t(335) }));
    ins("dobavitelji", P({ naziv: "Testna mesarija", kategorija: "meso", kontakt: "041 000 000", ocena: "odobren", naslednja_ocena: t(90) })); ins("dobavitelji", P({ naziv: "Testna zelenjava", kategorija: "zelenjava", ocena: "pogojno odobren" }));
    ins("nacrti", P({ naziv: "HACCP načrt kuhinje (test)", status: "osnutek", naslednji_pregled: t(60) })); ins("navodila", P({ naslov: "Higiena rok (test)", vrsta: "navodilo", status: "veljavno" }));
    [3, 4, 3.5, 8].forEach((v, i) => { const e = ins("evidence", P({ vrsta: "temperatura", oprema: "Hladilnik 1", vrednost: v, min: 0, max: 4, cas: new Date(Date.now() - i * 432e5).toISOString(), status: "vneseno" })); e.skladno = ocenaEvidence(e); });
    ins("capa", P({ opis: "Temperatura hladilnika nad mejo (test)", status: "odprto", tveganje: "srednje", rok: t(3), odgovoren: "Mojca Testna" }));
    ins("ciscenje_nacrt", P({ podrocje: "Kuhinja", opravilo: "Pranje tal", sredstvo: "Čistilo A", pogostost_dni: 1 })); ins("urnik", P({ vrsta: "temperatura", naprava: "Zamrzovalnik 1", frekvenca_ur: 24 }));
    ins("sarze", P({ izdelek: "Goveje meso", sarza: "LOT-TEST-1", dobavitelj: "Testna mesarija", datum_prevzema: t(-2), rok_uporabe: t(5), uporabljeno: "gulaž" }));
    ins("jedi", P({ naziv: "Palačinke", skupina: "sladica", sestavine: "moka, mleko, jajca", alergeni: ["Žita z glutenom", "Jajca", "Mleko"] }));
    for (const c of ["stranke", "obrati", "oprema", "osebje", "usposabljanja", "dobavitelji", "nacrti", "navodila", "evidence", "capa", "ciscenje_nacrt", "urnik", "sarze", "jedi"]) save(c);
    S.pisi(path.join(DIR, "_umiki.json"), ([{ id: uid(), kljuc: "test|1", vir: "ročni vnos", cas_prejema: c0, naslov: "TEST: odpoklic govejega mesa, šarža LOT-TEST-1", povezava: "", opis: "Testno obvestilo za preizkus ujemanja.", objavljeno: "" }]));
    const us = TEST_RACUNI.map(r => ({ id: uid(), email: r[0], ime: r[0].split("@")[0].replace(/^./, x => x.toUpperCase()) + " (test)", vloga: r[1], stranka_id: r[1] === "odgovorna" || r[1] === "zaposleni" ? sid : null, stranke: r[1] === "svetovalec" ? [sid] : [], geslo: hashPw(TEST_GESLO), aktiven: true, mora_zamenjati: false, ustvarjeno: c0 }));
    cache["uporabniki"] = us; save("uporabniki");
  }
  if (TESTNO) testniPodatki();
  autoBackup(); kosPocisti();
  setInterval(() => { autoBackup(); kosPocisti(); }, 6 * 3600e3).unref();
  // seznam davčnih zavezancev FURS: osvežitev enkrat na dan (ob zagonu po 2 minutah, nato vsakih 6 ur preveri starost)
  const zavNaslovi = () => { const st = ZAV.stanje(); return (process.env.HACCP_ZAVEZANCI_URL ? process.env.HACCP_ZAVEZANCI_URL.split(",") : st.naslovi && st.naslovi.length ? st.naslovi : REG.FURS_PRIVZETO).map(x => x.trim()).filter(Boolean); };
  async function zavOsvezi(sila) {
    const st = ZAV.stanje(); if (!ZAV.na_voljo() || (!sila && (st.samodejno === false || TESTNO))) return st;
    if (!sila && st.osvezeno && Date.now() - Date.parse(st.osvezeno) < 20 * 3600e3) return st;
    if (zavOsvezi.tece) return st; zavOsvezi.tece = true;
    try { const n = zavNaslovi(), bufs = []; for (const u of n) bufs.push(await REG.prenesi(u, 200e6)); ZAV.uvozi(bufs, n.join(", ")); }
    catch (e) { ZAV.zapisiStanje({ napaka: e.message, poskus: new Date().toISOString() }); if (sila) throw e; }
    finally { zavOsvezi.tece = false; }
    return ZAV.stanje();
  }
  setTimeout(() => zavOsvezi().catch(() => {}), 120e3).unref();
  setInterval(() => zavOsvezi().catch(() => {}), 6 * 3600e3).unref();

  return { handle, userOf, audit, load, save, makeBackup, COLL, vidno, zapri: () => { if (sejeT) clearTimeout(sejeT); sejeShrani(); if (spremembeOdKopije) autoBackup(); S.zapri(); ZAV.zapri(); } };
};
