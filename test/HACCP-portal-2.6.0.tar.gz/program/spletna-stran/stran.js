// Spletna stran HiGiFood: cenik in kontakt iz platforme (/api/javno/cenik), povezava za prijavo.
(function () {
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const eur = n => Number(n).toLocaleString("sl-SI", { minimumFractionDigits: Number(n) % 1 ? 2 : 0, maximumFractionDigits: 2 }) + " €";
  const mn = (n, o) => { const k = Math.abs(n) % 100; return o[k === 1 ? 0 : k === 2 ? 1 : k === 3 || k === 4 ? 2 : 3]; };
  document.getElementById("leto").textContent = new Date().getFullYear();
  // po zamenjavi strani: zapisi evidenc, ki jih je platforma na tej domeni shranila brez povezave (localStorage), se ne smejo izgubiti
  let q = []; try { q = JSON.parse(localStorage.getItem("haccp_offq") || "[]"); } catch {}
  if (Array.isArray(q) && q.length) {
    const b = document.createElement("div"); b.className = "w"; b.setAttribute("role", "alert");
    b.innerHTML = `<div class="k" style="margin:16px 0;border:2px solid #b3261e"><h3>Na tej napravi so neposlani zapisi evidenc (${q.length})</h3><p>Zapisi so bili vneseni brez internetne povezave in še niso na strežniku.</p><p style="margin-top:12px"><button class="btn" id="poslji-q" type="button">Pošlji zapise zdaj</button> <span id="poslji-r"></span></p></div>`;
    document.querySelector("main").prepend(b);
    document.getElementById("poslji-q").onclick = async () => {
      const r = document.getElementById("poslji-r"); let poslano = 0, napaka = "";
      for (const it of q.slice()) {
        try {
          const x = await fetch("/api/d/" + encodeURIComponent(it.c), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(it.body) });
          if (x.status === 401) { napaka = "Prijava je potekla – prijavite se v platformo in zapise pošljite tam."; break; }
          if (!x.ok) { const j = await x.json().catch(() => ({})); napaka = j.napaka || "Napaka " + x.status; break; }
          poslano++; q = q.filter(y => y !== it); localStorage.setItem("haccp_offq", JSON.stringify(q));
        } catch { napaka = "Ni povezave s strežnikom. Poskusite znova."; break; }
      }
      r.textContent = (poslano ? "Poslano: " + poslano + ". " : "") + (napaka || (q.length ? "" : "Vsi zapisi so poslani."));
      if (!q.length) b.remove();
    };
  }
  fetch("/api/javno/cenik", { headers: { Accept: "application/json" } }).then(r => r.ok ? r.json() : Promise.reject(r.status)).then(c => {
    if (c.aplikacija) document.querySelectorAll("[data-prijava]").forEach(a => { a.href = c.aplikacija; });
    const pk = (c.paketi || []).filter(p => p && p.ime);
    if (pk.length) document.getElementById("paketi").innerHTML = pk.map((p, i) => `<div class="k${i === Math.min(1, pk.length - 1) ? " pri" : ""}"><h3>${esc(p.ime)}</h3><div class="cena">${eur(p.cena)} <small>/ mesec</small></div><p>${esc(p.opis)}</p><a class="btn${i === Math.min(1, pk.length - 1) ? "" : " o"}" href="#kontakt">Izberi ${esc(p.ime)}</a></div>`).join("");
    const op = ["Cene so brez DDV" + (c.ddv ? " (" + esc(c.ddv) + " %)" : "") + " in veljajo za en obrat."];
    if (+c.popust_obrat > 0) op.push("Vsak dodatni obrat " + esc(c.popust_obrat) + " % ceneje.");
    if (+c.brezplacni_meseci > 0) op.push("Pri letnem plačilu " + esc(c.brezplacni_meseci) + " " + mn(+c.brezplacni_meseci, ["mesec", "meseca", "meseci", "mesecev"]) + " brezplačno.");
    document.getElementById("cenik-opomba").textContent = op.join(" ");
    const k = c.kontakt || {}, v = [];
    if (k.email) v.push(`<p>E-pošta: <a href="mailto:${esc(k.email)}?subject=${encodeURIComponent("Predstavitev HiGiFood")}">${esc(k.email)}</a></p>`);
    if (k.telefon) v.push(`<p>Telefon: <a href="tel:${esc(String(k.telefon).replace(/[^\d+]/g, ""))}">${esc(k.telefon)}</a></p>`);
    if (k.naslov) v.push(`<p>${esc(k.naslov)}</p>`);
    if (v.length) document.getElementById("kontakt-podatki").innerHTML = `<h3>${esc(k.naziv || "HiGiFood")}</h3>${v.join("")}${k.email ? `<p style="margin-top:14px"><a class="btn" href="mailto:${esc(k.email)}?subject=${encodeURIComponent("Predstavitev HiGiFood")}">Dogovorimo se za predstavitev</a></p>` : ""}`;
  }).catch(() => {});
})();
