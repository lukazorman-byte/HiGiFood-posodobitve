// Čarovnik HACCP: 7 korakov. Predlogi so označeni in zahtevajo strokovno potrditev; CCP/OPRP/PRP vedno izbere uporabnik.
const WSTEPS = ["Zbiranje podatkov", "Dejavnost in živila", "Procesni koraki", "Analiza nevarnosti", "Kontrolni ukrepi", "Pregled osnutka", "Izvoz"];
const HTIPI = { B: "Biološka", K: "Kemična", F: "Fizikalna", A: "Alergen", C: "Navzkrižna kontaminacija", T: "Čas / temperatura", D: "Druga" };
const KTIPI = ["tehnološki", "prevzem", "skladiščenje", "priprava", "toplotna obdelava", "hlajenje", "pakiranje", "prodaja / izdaja", "drugo"];
const DEF_METODA = { nizko_do: 4, srednje_do: 11, verjetnost: ["1 – zelo malo verjetno", "2 – malo verjetno", "3 – možno", "4 – verjetno", "5 – zelo verjetno"], teza: ["1 – neznatne posledice", "2 – lažje posledice", "3 – zmerne posledice", "4 – hude posledice", "5 – zelo hude / smrtne posledice"] };
const rizikRazred = (r, m) => r <= m.nizko_do ? "nizko" : r <= m.srednje_do ? "srednje" : "visoko";
const rizik = h => (+h.verjetnost || 0) * (+h.teza || 0);
const CCPPOL = ["kaj", "mejna", "mejna_vir", "spremljanje", "pogostost", "odgovoren", "korektivni", "verifikacija"];
const uidc = () => Math.random().toString(36).slice(2, 9);
// enotno stanje nevarnosti: potrjena je samo s kljukico »pregledal in potrjujem«; urejen predlog in ročni vnos čakata na potrditev,
// sprememba ali izbris koraka zahteva ponovni pregled (starejši ročni vnosi brez oznake veljajo za potrjene)
const HSTAT = { potrjeno: ["ok", "potrjeno"], predlog: ["warn", "predlog"], urejeno: ["warn", "uredil uporabnik – potrdi"], nepotrjeno: ["warn", "nepotrjeno"], preveri: ["bad", "korak spremenjen – preveri"] };
function hazStatus(h) {
  if (h.preveri_korak) return "preveri";
  if (h.potrjeno === true || (h.potrjeno === undefined && !h.predlog && !h.urejeno)) return "potrjeno";
  return h.urejeno ? "urejeno" : h.predlog ? "predlog" : "nepotrjeno";
}
const hazBadge = h => { const [c, t] = HSTAT[hazStatus(h)]; return `<span class="badge ${c}">${t}</span>`; };
// oštevilčenje CCP in OPRP po vrstnem redu korakov (CCP1, CCP2 …) za tabele, diagram in dokument
function ccpOznake(W) {
  const red = id => { const i = W.koraki.findIndex(k => k.id === id); return i < 0 ? 1e6 : i; }, n = { CCP: 0, OPRP: 0 }, out = {};
  W.nevarnosti.filter(h => ["CCP", "OPRP"].includes((W.kontrole[h.id] || {}).vrsta)).sort((a, b) => red(a.korak_id) - red(b.korak_id))
    .forEach(h => { const v = W.kontrole[h.id].vrsta; out[h.id] = v + (++n[v]); });
  return out;
}
const ccpNaKoraku = (W, kid) => { const o = ccpOznake(W); return W.nevarnosti.filter(h => h.korak_id === kid && /^CCP/.test(o[h.id] || "")).map(h => o[h.id]); };

// vsebina načrta z vsemi polji (tudi starejši zapisi)
// opis režima iz baze: razpon ali enostranska meja (≥ / ≤), ne »72 do «
const rezimOpis = r => { if (r.enota) return r.predloga || ""; const od = r.od !== undefined && r.od !== null && r.od !== "", dO = r.do !== undefined && r.do !== null && r.do !== ""; return od && dO ? r.od + " do " + r.do + " °C" : od ? "≥ " + r.od + " °C" : dO ? "≤ " + r.do + " °C" : ""; };
// kdo in kdaj je potrdil načrt: potrditev načrta (Osnovni podatki) ima prednost pred vnosom v koraku 6 čarovnika
// Potrditev velja kot opravljena samo, če je načrt v stanju »potrjeno«, potrjevalec je vpisan in datum ni v prihodnosti.
// Sicer je to le »predvideni strokovni pregled« (osnutek). Potrjevalec se nikoli ne vzame iz prijavljenega uporabnika.
function potrditevNacrta(rec, W) {
  const pr = (W || (rec.vsebina && typeof rec.vsebina === "object" ? rec.vsebina : {})).pregled || {};
  const potrdil = rec.status === "potrjeno" && rec.potrdil ? rec.potrdil : pr.potrdil || rec.potrdil || "", datum = (rec.status === "potrjeno" && rec.potrdil ? rec.datum_potrditve || pr.datum : pr.datum || rec.datum_potrditve) || "";
  const prihodnost = !!datum && String(datum).slice(0, 10) > today();
  return { potrdil, datum, prihodnost, opravljena: rec.status === "potrjeno" && !!potrdil && !!datum && !prihodnost };
}
// zgodovina načrta za dokument: samo vsebinske spremembe z razlogom in spremembe stanja (brez samodejnih shranjevanj čarovnika)
const SAMODEJNO_SHRANJEVANJE = /^(Posodobitev vsebine v čarovniku|Samodejno shranjevanje.*|Urejanje tlorisa.*|)$/i;
function zgodovinaNacrta(rec) { return (rec.revizije || []).filter(r => !SAMODEJNO_SHRANJEVANJE.test(String(r.razlog || "").trim()) || (r.prej && "status" in r.prej)); }
function vsebinaNacrta(rec) {
  const W = rec.vsebina && typeof rec.vsebina === "object" ? rec.vsebina : {};
  W.zbiranje = W.zbiranje || {}; W.zivila = W.zivila || []; W.koraki = W.koraki || []; W.nevarnosti = W.nevarnosti || []; W.kontrole = W.kontrole || {}; W.metoda = Object.assign({}, DEF_METODA, W.metoda || {}); W.pregled = W.pregled || {}; W.besedila = W.besedila || {}; W.branza = W.branza || "";
  return W;
}
async function pageCarovnik(v, m) {
  const id = m[1];
  const plans = await D.list("nacrti"), rec = plans.find(p => p.id === id);
  if (!rec) throw new Error("Načrt ni najden ali nimate dostopa.");
  const stranka = (await D.list("stranke")).find(s => s.id === rec.stranka_id); await loadStrankaLogo(stranka);
  const obrati = await D.list("obrati", { stranka_id: rec.stranka_id });
  const tlorisi = await D.list("tlorisi", { stranka_id: rec.stranka_id }).catch(() => []);
  const osebje = await D.list("osebje", { stranka_id: rec.stranka_id }).catch(() => []);
  const db = await baza();
  const W = vsebinaNacrta(rec);
  const editable = canManage() && rec.status !== "potrjeno";
  let step = +(sessionStorage.getItem("wstep:" + id) || 0), dirty = false;
  $("#title").textContent = "Čarovnik: " + rec.naziv;
  let urejanj = 0; // števec sprememb: shranjevanje v ozadju ne sme izbrisati oznake za spremembe, narejene med shranjevanjem
  const mark = () => { dirty = true; urejanj++; const b = $("#wsave"); if (b) b.textContent = "Shrani spremembe *"; };
  const verOznaka = () => `${esc(sIme(stranka))} · ${badge(rec.status)} · različica zapisa ${rec.verzija}`;
  const save = async (razlog, samodejno) => {
    const pri = urejanj, r = await D.set("nacrti", id, { vsebina: W, _razlog: razlog || "Posodobitev vsebine v čarovniku" }); Object.assign(rec, r);
    if (pri === urejanj) { dirty = false; const b = $("#wsave"); if (b) b.textContent = "Shrani"; }
    const o = $("#wver"); if (o) o.innerHTML = verOznaka();
    toast((samodejno ? "Shranjeno samodejno" : "Shranjeno") + " (različica " + r.verzija + ")");
  };
  // menjava koraka: neshranjene spremembe se shranijo samodejno
  const pojdi = n => {
    const shrani = dirty && editable;
    step = Math.max(0, Math.min(WSTEPS.length - 1, n)); draw(); window.scrollTo(0, 0);
    if (shrani) save("Samodejno shranjevanje ob menjavi koraka", true).catch(fail);
  };
  // stanje koraka za koračnik: "" (prazno), "delno", "polno"
  const stanjeKoraka = i => {
    const Z = W.zbiranje, sig = W.nevarnosti.filter(h => rizik(h) > W.metoda.nizko_do);
    switch (i) {
      case 0: return Z.obseg && Z.hacc_ekipa ? "polno" : Z.zaposleni || Z.obseg || Z.hacc_ekipa || Z.kupci ? "delno" : "";
      case 1: return W.zivila.length ? (W.zivila.every(z => z.naziv) ? "polno" : "delno") : "";
      case 2: return W.koraki.length ? (W.koraki.every(k => k.naziv) ? "polno" : "delno") : "";
      case 3: return !W.nevarnosti.length ? "" : W.nevarnosti.every(h => rizik(h) && hazStatus(h) === "potrjeno" && W.koraki.some(k => k.id === h.korak_id)) ? "polno" : "delno";
      case 4: return !sig.length ? "" : sig.every(h => (W.kontrole[h.id] || {}).vrsta) ? "polno" : Object.keys(W.kontrole).length ? "delno" : "";
      case 5: return W.pregled.potrdil && W.pregled.datum ? "polno" : W.pregled.potrdil || W.besedila.uvod ? "delno" : "";
      default: return "";
    }
  };
  const KRATKO = ["Podatki", "Živila", "Koraki", "Nevarnosti", "Ukrepi", "Pregled", "Izvoz"], STOPIS = { "": "ni izpolnjeno", delno: "delno izpolnjeno", polno: "izpolnjeno" };
  const korakIme = kid => (W.koraki.find(k => k.id === kid) || {}).naziv || "–";
  const num = i => { const k = W.koraki.findIndex(x => x.id === i); return k < 0 ? "" : k + 1; };

  const draw = () => {
    sessionStorage.setItem("wstep:" + id, step);
    v.innerHTML = `${!editable ? `<p class="note">${rec.status === "potrjeno" ? "Načrt je potrjen in zaklenjen za urejanje. Za spremembo najprej spremenite stanje načrta (z razlogom) v osnovnih podatkih." : "Za urejanje nimate pravic."}</p>` : ""}
    <div class="row"><a href="#/stranka/${rec.stranka_id}/nacrti" class="btn ghost sec sm">‹ Nazaj</a><span class="mut" id="wver">${verOznaka()}</span><span class="sp"></span>${editable ? `<button class="btn" id="wsave">${dirty ? "Shrani spremembe *" : "Shrani"}</button>` : ""}</div>
    <nav class="steps stepper" aria-label="Koraki čarovnika">${WSTEPS.map((s, i) => { const st = stanjeKoraka(i); return `<button data-s="${i}" class="${i === step ? "on" : ""} st-${st || "prazno"}" title="${i + 1}. ${s} – ${STOPIS[st]}" ${i === step ? 'aria-current="step"' : ""}><span class="st-n">${st === "polno" ? "✓" : i + 1}</span><span class="st-t">${KRATKO[i]}</span></button>`; }).join("")}</nav>
    <div id="wbody"></div>
    <div class="row" style="margin-top:14px"><button class="btn ghost sec" id="wprev" ${step === 0 ? "disabled" : ""}>‹ Nazaj</button><span class="sp"></span><button class="btn" id="wnext" ${step === 6 ? "disabled" : ""}>Naprej ›</button></div>`;
    $$(".steps button", v).forEach(b => b.onclick = () => pojdi(+b.dataset.s));
    $("#wprev").onclick = () => pojdi(step - 1); $("#wnext").onclick = () => pojdi(step + 1);
    if ($("#wsave")) $("#wsave").onclick = () => save().catch(fail);
    const body = $("#wbody");
    [s1, s2, s3, s4, s5, s6, s7][step](body);
    if (!editable) $$("#wbody input,#wbody select,#wbody textarea,#wbody .edit").forEach(e => { if (e.tagName === "BUTTON") e.disabled = true; else e.disabled = true; });
  };
  // povezava vnosnega polja na objekt
  const bindAll = (el, obj) => $$("[data-k]", el).forEach(i => { const k = i.dataset.k; if (i.type === "checkbox") i.checked = !!obj[k]; else i.value = obj[k] === undefined ? "" : obj[k]; i.oninput = i.onchange = () => { obj[k] = i.type === "checkbox" ? i.checked : i.value; mark(); }; });
  const inp = (k, l, o) => `<label class="f ${o && o.wide ? "wide" : ""}"><span>${l}</span>${o && o.area ? `<textarea data-k="${k}"></textarea>` : o && o.sel ? `<select data-k="${k}"><option value=""></option>${o.sel.map(x => `<option value="${esc(Array.isArray(x) ? x[0] : x)}">${esc(Array.isArray(x) ? x[1] : x)}</option>`).join("")}</select>` : `<input data-k="${k}" ${o && o.type ? `type="${o.type}"` : ""}>`}</label>`;

  // 1. zbiranje podatkov
  function s1(el) {
    const Z = W.zbiranje, ob = obrati.find(o => o.id === rec.obrat_id);
    const miss = missingData({ obrati, osebje: [{ stranka_id: stranka.id }], nacrti: [rec], dobavitelji: [{ stranka_id: stranka.id }] }, stranka).filter(x => !["seznam zaposlenih", "dobavitelji", "HACCP načrt"].includes(x));
    el.innerHTML = `<div class="card"><h2>1. Zbiranje podatkov</h2>${miss.length ? `<p class="note">V profilu stranke manjka: ${miss.map(esc).join(", ")}. <a href="#/stranka/${stranka.id}/podatki">Dopolni profil</a></p>` : ""}
    <p class="mut">Podatki podjetja in obrata se prevzamejo iz profila stranke. Tu dodajte, kar je pomembno za HACCP načrt.</p>
    <table class="t"><tr><th style="width:30%">Podjetje</th><td>${esc(stranka.naziv)}, ${esc(stranka.naslov || "naslov ni vnesen")}</td></tr><tr><th>Odgovorna oseba</th><td>${esc(stranka.odgovorna_oseba || "ni vnesena")}</td></tr><tr><th>Obrat</th><td>${ob ? esc(ob.naziv + (ob.naslov ? ", " + ob.naslov : "")) : "ni izbran (izberite v osnovnih podatkih načrta)"}</td></tr><tr><th>Prostori</th><td>${esc(ob ? seznamObrata(ob.prostori, ob.opis_prostorov) || "ni vnesen" : "")}</td></tr></table>
    <div class="fgrid" style="margin-top:12px">${inp("zaposleni", "Število zaposlenih", { type: "number" })}${inp("delovni_cas", "Delovni čas / sezonskost")}${inp("kupci", "Kupci in ciljne skupine (npr. splošna populacija, otroci, bolniki)")}${inp("prodaja", "Način prodaje / distribucije")}${inp("obseg", "Obseg HACCP načrta (kaj pokriva)", { wide: 1, area: 1 })}${inp("posebnosti", "Posebnosti (nove tehnologije, sezonske ponudbe, dostava …)", { wide: 1, area: 1 })}${inp("hacc_ekipa", "HACCP skupina (člani in vloge)", { wide: 1, area: 1 })}<div class="wide" style="grid-column:1/-1"><label class="f"><span>Tloris, narisan v aplikaciji (vstavi se v dokumentacijo)</span><select id="tl_sel"><option value="">brez / uporabi naloženo sliko</option>${tlorisi.map(t => `<option value="${esc(t.id)}" ${Z.tloris_nacrt_id === t.id ? "selected" : ""}>${esc(t.naziv)}</option>`).join("")}</select></label><span class="mut">ali naložena slika tlorisa</span><div class="row" style="margin-top:4px"><input type="file" id="tl_f" accept="image/*" style="max-width:300px"><button class="btn ghost edit" id="tl_up">Naloži tloris</button><button class="btn ghost sec edit" id="tl_del">Odstrani</button><span id="tl_st" class="mut">${Z.tloris_id ? '<a href="/api/priloga/' + Z.tloris_id + '" target="_blank" rel="noopener">tloris je naložen</a>' : "ni naloženega"}</span></div></div></div></div>`;
    const ekipa = () => osebje.map(o => o.ime + (o.funkcija ? " – " + o.funkcija : "")).join("\n");
    $(".fgrid", el).insertAdjacentHTML("beforebegin", osebje.length ? `<p class="note info" id="os_info">Razdelek Zaposleni: ${mnx(osebje.length, ["oseba", "osebi", "osebe", "oseb"])}. Število zaposlenih se prevzame samodejno, če ni vpisano. <button class="btn sm ghost edit" id="os_ek">Prevzemi zaposlene v HACCP skupino</button></p>` : `<p class="note" id="os_info">Razdelek Zaposleni je prazen. <a href="#/stranka/${stranka.id}/osebje">Dodajte zaposlene</a>, da se število zaposlenih in HACCP skupina izpolnita samodejno.</p>`);
    if (editable && !Z.zaposleni && osebje.length) { Z.zaposleni = String(osebje.length); mark(); }
    $(".fgrid", el).insertAdjacentHTML("afterend", `<h3>Registracija in dejavnost</h3><div class="fgrid">${inp("registracija", "Registracija / odobritev obrata (številka, organ)")}${inp("skd", "Šifra dejavnosti po SKD 2025")}${inp("dejavnost_registracija", "Dejavnost po registraciji", { wide: 1 })}</div><p class="mut" id="skd_op"></p>
    <h3>Način prodaje</h3><div class="row" id="np">${[["lokal", "v lokalu"], ["s_seboj", "za s seboj"], ["dostava", "dostava"]].map(([k, l]) => `<label style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-np="${k}" style="width:auto"> ${l}</label>`).join("")}</div>
    <h3>Kultura varnosti hrane</h3><p class="mut">Uredba (EU) 2021/382: zaveza vodstva, sporočanje težav, usposabljanje in redni pregled.</p><div class="fgrid">${inp("kultura_zaveza", "Zaveza vodstva", { wide: 1, area: 1 })}${inp("kultura_sporocanje", "Kako zaposleni sporočijo težave", { wide: 1, area: 1 })}${inp("kultura_usposabljanje", "Usposabljanje o varnosti hrane", { wide: 1, area: 1 })}${inp("kultura_pregled", "Pregled kulture varnosti hrane (kdaj, kdo)", { wide: 1, area: 1 })}</div>
    <h3>HACCP skupina</h3><div id="clani"></div>`);
    Z.nacin_prodaje = Array.isArray(Z.nacin_prodaje) ? Z.nacin_prodaje : [];
    $$("[data-np]", el).forEach(c => { c.checked = Z.nacin_prodaje.includes(c.dataset.np); c.onchange = () => { Z.nacin_prodaje = $$("[data-np]", el).filter(x => x.checked).map(x => x.dataset.np); mark(); }; });
    // SKD: opozorilo na star šifrant (SKD 2008 velja do konca leta 2024)
    const skdOp = () => { const v = String(Z.skd || "").trim(); $("#skd_op", el).textContent = v ? (Z.skd_2025 ? "" : "Preverite, da je šifra iz šifranta SKD 2025 (velja od 1. 1. 2025) in ne iz starega šifranta SKD 2008.") : ""; };
    const clani = () => { Z.clani = Array.isArray(Z.clani) ? Z.clani : []; const c = $("#clani", el);
      c.innerHTML = `<div class="tw"><table class="t"><tr><th>Ime in priimek</th><th>Vloga v HACCP skupini</th><th></th></tr>${Z.clani.map((x, i) => `<tr data-c="${i}"><td><input data-k="ime" aria-label="Ime člana ${i + 1}"></td><td><input data-k="vloga" aria-label="Vloga člana ${i + 1}" placeholder="npr. vodja HACCP skupine"></td><td><button type="button" class="btn sm ghost sec edit" data-cx="${i}" aria-label="Odstrani člana">✕</button></td></tr>`).join("")}</table></div><div class="row"><button type="button" class="btn sm ghost edit" id="c_add">+ Član</button>${osebje.length ? '<button type="button" class="btn sm ghost edit" id="c_os">Prevzemi zaposlene</button>' : ""}</div>`;
      $$("tr[data-c]", c).forEach(tr => bindAll(tr, Z.clani[+tr.dataset.c]));
      $("#c_add", c).onclick = () => { Z.clani.push({ ime: "", vloga: "" }); mark(); clani(); };
      $$("[data-cx]", c).forEach(b => b.onclick = () => { Z.clani.splice(+b.dataset.cx, 1); mark(); clani(); });
      const co = $("#c_os", c); if (co) co.onclick = () => { for (const o of osebje) if (!Z.clani.some(x => x.ime === o.ime)) Z.clani.push({ ime: o.ime, vloga: o.funkcija || "" }); mark(); clani(); };
    };
    bindAll(el, Z); clani(); skdOp(); $("[data-k=skd]", el).addEventListener("input", skdOp);
    const ek = $("#os_ek"); if (ek) ek.onclick = () => { const go = () => { Z.hacc_ekipa = ekipa(); $("[data-k=hacc_ekipa]", el).value = Z.hacc_ekipa; mark(); }; if (Z.hacc_ekipa && Z.hacc_ekipa.trim()) confirmBox("HACCP skupino zamenjam s seznamom zaposlenih (" + osebje.length + ")?", go); else go(); };
    $("#tl_sel").onchange = e => { Z.tloris_nacrt_id = e.target.value; mark(); };
    $("#tl_up").onclick = async () => { const f = $("#tl_f").files[0]; if (!f) return toast("Izberite sliko.", true); try { const up = await uploadFile(f, rec.stranka_id, "tloris", rec.obrat_id || null); Z.tloris_id = up.id; mark(); toast("Tloris naložen (ne pozabite shraniti)"); s1(el); } catch (e) { fail(e); } };
    $("#tl_del").onclick = () => { delete Z.tloris_id; mark(); s1(el); };
  }

  // 2. dejavnost in živila
  function s2(el) {
    el.innerHTML = `<div class="card"><h2>2. Dejavnost in živila</h2><div class="row"><label class="f" style="margin:0;min-width:280px"><span>Predloga dejavnosti (prilagodljiva)</span><select id="wb"><option value=""></option>${db.branze.map(b => `<option value="${esc(b.id)}" ${W.branza === b.id ? "selected" : ""}>${esc(b.naziv)}</option>`).join("")}</select></label><button class="btn ghost edit" id="wload">Naloži predlog korakov in nevarnosti</button></div>
    ${(() => { const dej = [stranka.dejavnost].concat(stranka.dodatne_dejavnosti || []).filter(Boolean), ids = [...new Set(dej.flatMap(d => DEJ_PREDLOGE[d] || []))].filter(i => db.branze.some(b => b.id === i)); return ids.length ? `<p class="mut" id="wpred">Predlagano glede na dejavnosti stranke (${esc(dej.join(", "))}): ${ids.map(i => `<button type="button" class="btn sm ghost edit" data-pb="${i}">${esc(db.branze.find(b => b.id === i).naziv)}</button>`).join(" ")}</p>` : ""; })()}
    <p class="note info">Predlog iz baze znanja je izhodišče: korake in nevarnosti lahko dodajate, brišete in spreminjate. Naložene vrstice so označene kot »predlog« in zahtevajo vašo potrditev.</p>
    <h3>Živila / skupine živil</h3><div class="tw"><table class="t"><tr><th>Naziv</th><th>Skupina</th><th>Alergeni</th><th>RTE</th><th>Ciljna skupina</th><th>Shranjevanje, rok uporabe</th><th></th></tr>${W.zivila.map((z, i) => `<tr data-i="${i}"><td><input data-k="naziv"></td><td><input data-k="skupina"></td><td><button type="button" class="btn sm ghost sec edit al-izb" data-al="${i}" style="white-space:normal;text-align:left;max-width:220px">${esc(z.alergeni || "izberi …")}</button></td><td><input type="checkbox" data-k="rte"></td><td><input data-k="ciljna"></td><td><input data-k="shranjevanje"></td><td><button class="btn sm ghost sec edit" data-del="${i}">✕</button></td></tr>`).join("") || '<tr><td colspan="7" class="empty">Dodajte živila.</td></tr>'}</table></div><div class="row" style="margin-top:8px"><button class="btn edit" id="zadd">+ Dodaj živilo</button></div></div>`;
    $$("tr[data-i]", el).forEach(tr => bindAll(tr, W.zivila[+tr.dataset.i]));
    // podrobnosti živila (sestava, priprava, pakiranje, rok, stanje alergenov) in prevzem alergenov iz razdelka »Alergeni in jedilnik«
    $$("tr[data-i]", el).forEach(tr => { const i = +tr.dataset.i, z = W.zivila[i]; tr.lastElementChild.insertAdjacentHTML("afterbegin", `<button type="button" class="btn sm ghost sec edit" data-zp="${i}">Podrobnosti${z.alergeni_potrjeni ? "" : " · alergeni nepotrjeni"}</button> `); });
    $$("[data-zp]", el).forEach(b => b.onclick = () => { const z = W.zivila[+b.dataset.zp];
      const d = modal("Živilo: " + (z.naziv || ""), `<div class="fgrid">${[["sestava", "Sestava (glavne sestavine)"], ["priprava", "Priprava"], ["pakiranje", "Pakiranje"], ["shranjevanje", "Shranjevanje"], ["rok", "Rok uporabe"], ["ciljna", "Ciljna skupina"], ["odprto", "Odprto (kaj še preveriti)"]].map(([k, l]) => `<label class="f wide"><span>${l}</span><input data-k="${k}"></label>`).join("")}<label class="f wide" style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-k="alergeni_potrjeni" style="width:auto"> <b>Alergeni so preverjeni in potrjeni</b> (specifikacije dobaviteljev, recepture)</label></div>`, [{ t: "Zapri", cls: "ghost sec", fn: () => { s2(el); } }]);
      bindAll(d, z); if (!editable) d.querySelectorAll("input").forEach(x => { x.disabled = true; }); });
    if (editable && W.zivila.length && !$("#z_jed")) $("#zadd").insertAdjacentHTML("afterend", ' <button type="button" class="btn ghost sec" id="z_jed">Prevzemi alergene iz jedilnika</button>');
    const zj = $("#z_jed"); if (zj) zj.onclick = async () => { const jedi = await D.list("jedi", { stranka_id: rec.stranka_id }).catch(() => []); let n = 0;
      for (const z of W.zivila) { const j = jedi.find(x => String(x.naziv || "").trim().toLowerCase() === String(z.naziv || "").trim().toLowerCase()); if (!j) continue; const a = algKode(j.alergeni || []); z.alergeni = (j.alergeni || []).length ? (j.alergeni || []).join(", ") : "ni alergenov"; z.alergeni_jedilnik = a.join(", "); n++; }
      mark(); toast(n ? "Alergeni prevzeti iz jedilnika za " + mnx(n, ["živilo", "živili", "živila", "živil"]) + ". Potrdite jih v »Podrobnosti«." : "V jedilniku ni jedi z enakim imenom.", !n); s2(el); };
    $("#wb").onchange = e => { W.branza = e.target.value; mark(); };
    $$("[data-pb]", el).forEach(b => b.onclick = () => { W.branza = b.dataset.pb; $("#wb").value = W.branza; mark(); });
    $("#zadd").onclick = () => { W.zivila.push({ id: uidc() }); mark(); s2(el); };
    $$("[data-del]", el).forEach(b => b.onclick = () => { W.zivila.splice(+b.dataset.del, 1); mark(); s2(el); });
    $$("[data-al]", el).forEach(b => b.onclick = () => alergeniIzbor(W.zivila[+b.dataset.al], () => s2(el)));
    $("#wload").onclick = () => {
      const br = db.branze.find(b => b.id === W.branza); if (!br) return toast("Izberite dejavnost.", true);
      // zamenjaj: predlog nadomesti korake, nevarnosti in ukrepe; dodaj: koraki z enakim imenom se ne podvojijo, nevarnosti se dodajo
      const apply = nacin => {
        const nov = nacin === "zamenjaj"; if (nov) { W.koraki = []; W.nevarnosti = []; W.kontrole = {}; }
        const pred = W.koraki.length, predH = W.nevarnosti.length, idKoraka = {};
        for (const n of br.koraki) { const obst = W.koraki.find(k => (k.naziv || "").trim().toLowerCase() === n.toLowerCase()); if (obst) idKoraka[n] = obst.id; else { const k = { id: uidc(), naziv: n, tip: guessTip(n), predlog: true }; W.koraki.push(k); idKoraka[n] = k.id; } }
        // »Dodaj k obstoječim«: nevarnost, ki na istem koraku že obstaja (po imenu), se ne podvoji
        const ze = h => W.nevarnosti.some(x => x.korak_id === (idKoraka[h.faza] || "") && String(x.nevarnost || "").trim().toLowerCase() === String(h.nevarnost || "").trim().toLowerCase());
        for (const h of br.nevarnosti || []) if (!ze(h)) W.nevarnosti.push({ id: uidc(), korak_id: idKoraka[h.faza] || "", tip: ["B", "K", "F", "A"].includes(h.tip) ? h.tip : "D", nevarnost: h.nevarnost, obstojec: h.ukrep || "", verjetnost: "", teza: "", predlog: true, potrjeno: false });
        mark(); toast(nov ? "Predlog naložen: " + W.koraki.length + " korakov, " + W.nevarnosti.length + " nevarnosti. Verjetnost in težo ocenite sami." : "Dodano: " + (W.koraki.length - pred) + " korakov, " + (W.nevarnosti.length - predH) + " nevarnosti."); pojdi(2);
      };
      if (!W.koraki.length && !W.nevarnosti.length) return apply("zamenjaj");
      modal("Naloži predlog: " + br.naziv, `<p>Načrt že ima ${mnx(W.koraki.length, ["korak", "koraka", "koraki", "korakov"])} in ${mnx(W.nevarnosti.length, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])}${Object.keys(W.kontrole).length ? " ter " + mnx(Object.keys(W.kontrole).length, ["kontrolni ukrep", "kontrolna ukrepa", "kontrolne ukrepe", "kontrolnih ukrepov"]) : ""}.</p><ul><li><b>Zamenjaj</b>: obstoječi koraki, nevarnosti in kontrolni ukrepi se izbrišejo in nadomestijo s predlogom.</li><li><b>Dodaj k obstoječim</b>: obstoječe ostane; dodajo se koraki in nevarnosti, ki jih še ni (po imenu).</li></ul>`,
        [{ t: "Prekliči", cls: "ghost sec" }, { t: "Dodaj k obstoječim", cls: "ghost", fn: () => apply("dodaj") }, { t: "Zamenjaj", cls: "danger", fn: () => apply("zamenjaj") }]);
    };
  }
  // izbor alergenov (14 alergenov EU, »ni alergenov«, opomba »preveriti«); shrani se kot besedilo, kot doslej
  const ALG = (db.alergeni || []).map(a => a.naziv);
  const algUjema = (a, d) => { const A = a.toLowerCase(), x = d.toLowerCase(); return A === x || (x.length >= 4 && A.includes(x.slice(0, Math.min(5, x.length)))) || (/gluten|pšenic|ječmen|rž|oves/.test(x) && /gluten/.test(A)) || (/sulfit|so2|žvepl/.test(x) && /žvepl/.test(A)) || (/oreh|lešnik|mandelj|pistacij/.test(x) && /oreščk/.test(A)); };
  function alergeniIzbor(z, done) {
    const cur = String(z.alergeni || ""), prev = /\(preveriti\)/i.test(cur), deli = cur.replace(/\s*\(preveriti\)\s*/ig, "").split(/[,;]/).map(x => x.trim()).filter(Boolean);
    const izb = new Set(), drugo = [];
    for (const d of deli) { if (/^ni alergenov$/i.test(d)) continue; const a = ALG.find(a => algUjema(a, d)); if (a) izb.add(a); else drugo.push(d); }
    const html = `<p class="mut">Izberite alergene po Prilogi II Uredbe (EU) št. 1169/2011, ki jih živilo vsebuje.</p><div class="al-mreza">${ALG.map(a => `<label><input type="checkbox" data-a="${esc(a)}" ${izb.has(a) ? "checked" : ""}> ${esc(a)}</label>`).join("")}</div>
      <label style="display:flex;gap:6px;align-items:center;margin-top:10px"><input type="checkbox" id="al_ni" ${/ni alergenov/i.test(cur) ? "checked" : ""} style="width:auto"> <b>Ni alergenov</b></label>
      <label style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="al_pr" ${prev ? "checked" : ""} style="width:auto"> Preveriti (specifikacija dobavitelja ni potrjena, možna navzkrižna kontaminacija)</label>
      <label class="f" style="margin-top:8px"><span>Drugo / opomba (neobvezno)</span><input id="al_dr" value="${esc(drugo.join(", "))}"></label>`;
    const d = modal("Alergeni: " + (z.naziv || "živilo"), html, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: () => {
      const sel = $$("[data-a]", d).filter(i => i.checked).map(i => i.dataset.a), ni = $("#al_ni", d).checked, dr = $("#al_dr", d).value.trim();
      if (ni && sel.length) { toast("Izberite alergene ali »Ni alergenov«, ne obojega.", true); return false; }
      z.alergeni = (ni ? ["ni alergenov"] : sel).concat(dr ? [dr] : []).join(", ") + ($("#al_pr", d).checked ? " (preveriti)" : ""); mark(); done();
    } }]);
    $("#al_ni", d).onchange = e => { if (e.target.checked) $$("[data-a]", d).forEach(i => { i.checked = false; }); };
    $$("[data-a]", d).forEach(i => i.onchange = () => { if (i.checked) $("#al_ni", d).checked = false; });
    if (!editable) d.querySelectorAll("input").forEach(e => { e.disabled = true; });
  }
  const guessTip = n => { n = n.toLowerCase(); return /prevzem/.test(n) ? "prevzem" : /skladi/.test(n) ? "skladiščenje" : /toplotn|kuhan|peče|pečen|pasteriz/.test(n) ? "toplotna obdelava" : /hlaj/.test(n) ? "hlajenje" : /pakir/.test(n) ? "pakiranje" : /odprema|prodaj|izdaj|serv/.test(n) ? "prodaja / izdaja" : "priprava"; };

  // 3. procesni koraki
  const odprtOpis = new Set();
  // nevarnosti koraka, ki je bil preimenovan ali izbrisan, je treba ponovno pregledati (vezava je na ID koraka, ne na številko)
  const oznaciKorak = (kid, kaj) => { const hs = W.nevarnosti.filter(h => h.korak_id === kid); hs.forEach(h => { h.preveri_korak = kaj; h.potrjeno = false; delete h.urejeno; if (kaj === "izbrisan") h.korak_id = ""; }); return hs.length; };
  const zaPreverjanje = () => W.nevarnosti.filter(h => h.preveri_korak || !W.koraki.some(k => k.id === h.korak_id)).length;
  const risiFlow = () => {
    const f = $("#kflow"); if (!f) return;
    f.innerHTML = W.koraki.map((k, i) => { const c = ccpNaKoraku(W, k.id); return `${i ? '<div class="a">▼</div>' : ""}<div class="n${c.length ? " ccp" : ""}">${i + 1}. ${esc(k.naziv || "(brez imena)")}${c.length ? ` <span class="badge bad">${c.join(", ")}</span>` : ""}</div>`; }).join("") || '<p class="empty">Diagram se izriše iz korakov.</p>';
  };
  function s3(el) {
    const vezane = kid => W.nevarnosti.filter(h => h.korak_id === kid).length;
    el.innerHTML = `<div class="grid g2 kor-lay"><div class="card"><h2>3. Procesni koraki</h2><p class="mut">Vrstni red določa diagram poteka. Korake premikate z vlečenjem (⠿) ali s puščicama. Nevarnosti so vezane na korak, ne na številko: pri premiku ostanejo pri svojem koraku.</p>
    <div id="k_prev"></div>
    <div id="klist">${W.koraki.map((k, i) => `<div class="krow" data-i="${i}"><span class="kdrag" title="Povlecite za premik" aria-hidden="true">⠿</span><b class="kst">${i + 1}.</b><input data-k="naziv" placeholder="Naziv koraka" aria-label="Naziv koraka ${i + 1}"><select data-k="tip" aria-label="Vrsta koraka ${i + 1}">${KTIPI.map(t => `<option>${t}</option>`).join("")}</select>${vezane(k.id) ? `<span class="badge" title="Povezane nevarnosti">${vezane(k.id)} nev.</span>` : ""}${k.predlog ? '<span class="badge warn" title="Predlog iz baze – potrdite ali popravite">predlog</span>' : ""}<span class="kgumbi"><button class="btn sm ghost sec" data-o="${i}" aria-expanded="${odprtOpis.has(k.id) || !!k.opis}" title="Opis koraka">⋯</button><button class="btn sm ghost sec edit" data-up="${i}" aria-label="Premakni gor">↑</button><button class="btn sm ghost sec edit" data-dn="${i}" aria-label="Premakni dol">↓</button><button class="btn sm ghost sec edit" data-x="${i}" aria-label="Izbriši korak">✕</button></span><input class="kopis" data-k="opis" placeholder="Opis koraka (neobvezno)" aria-label="Opis koraka ${i + 1}" ${odprtOpis.has(k.id) || k.opis ? "" : "hidden"}></div>`).join("") || '<p class="empty">Ni korakov. Naložite predlog (korak 2) ali dodajte ročno.</p>'}</div><button class="btn edit" id="kadd">+ Dodaj korak</button> <button class="btn ghost sec edit" id="knap">Predlagaj iz naprav obrata</button></div>
    <div class="card kor-diag"><h2>Diagram poteka</h2><div class="flow" id="kflow"></div><div class="row" style="margin-top:10px"><button class="btn ghost sec" id="dpdf">Diagram v PDF</button></div></div></div>`;
    const pasica = () => { const n = zaPreverjanje(), b = $("#k_prev", el); if (!b) return; b.innerHTML = n ? `<p class="note">${mnx(n, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} ${mn(n, ["je vezana", "sta vezani", "so vezane", "je vezanih"])} na spremenjen ali izbrisan korak – preverite jih. <button class="btn sm ghost" id="k_go4">Pojdi na analizo nevarnosti</button></p>` : ""; const g = $("#k_go4", el); if (g) g.onclick = () => pojdi(3); };
    pasica(); risiFlow();
    // veja procesa (npr. kuhinja, hladna priprava, slaščičarna, točilni pult); koraki brez veje so skupni začetek ali konec
    $$(".krow", el).forEach(c => { const t = $("select[data-k=tip]", c); if (t) t.insertAdjacentHTML("afterend", `<input data-k="veja" list="veje_l" placeholder="veja (neobvezno)" aria-label="Veja procesa" style="max-width:150px">`); });
    if (!$("#veje_l")) document.body.insertAdjacentHTML("beforeend", '<datalist id="veje_l"><option>kuhinja</option><option>hladna priprava</option><option>slaščičarna</option><option>točilni pult</option></datalist>');
    $$(".krow", el).forEach(c => {
      const k = W.koraki[+c.dataset.i]; bindAll(c, k);
      const ime = $("input[data-k=naziv]", c); let prej = k.naziv || "";
      ime.addEventListener("input", risiFlow);
      ime.addEventListener("focus", () => { prej = k.naziv || ""; });
      ime.addEventListener("change", () => {
        if ((k.naziv || "").trim() === prej.trim()) return; k.predlog = false;
        // isti korak (ista vezava) z novim imenom: nevarnosti ostanejo potrjene, le obvestilo
        if (prej.trim() && vezane(k.id)) toast("Korak je preimenovan; " + vezane(k.id) + " povezanih nevarnosti ostane potrjenih – po potrebi jih preglejte.");
        prej = k.naziv || "";
      });
      // premik z vlečenjem (samo za ročico, da v poljih deluje izbiranje besedila)
      const roc = $(".kdrag", c);
      roc.onmousedown = roc.ontouchstart = () => { if (editable) c.draggable = true; };
      c.ondragstart = e => { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", c.dataset.i); c.classList.add("vlecem"); };
      c.ondragend = () => { c.draggable = false; c.classList.remove("vlecem"); $$(".krow.cilj", el).forEach(x => x.classList.remove("cilj")); };
      c.ondragover = e => { e.preventDefault(); c.classList.add("cilj"); };
      c.ondragleave = () => c.classList.remove("cilj");
      c.ondrop = e => { e.preventDefault(); const a = +e.dataTransfer.getData("text/plain"), b = +c.dataset.i; if (isNaN(a) || a === b) return; const [m] = W.koraki.splice(a, 1); W.koraki.splice(b, 0, m); mark(); s3(el); };
    });
    $$("[data-o]", el).forEach(b => b.onclick = () => { const k = W.koraki[+b.dataset.o], o = b.closest(".krow").querySelector(".kopis"); if (o.hidden) { odprtOpis.add(k.id); o.hidden = false; o.focus(); } else { odprtOpis.delete(k.id); o.hidden = true; } b.setAttribute("aria-expanded", String(!o.hidden)); });
    $("#knap").onclick = () => { const r = korakiIzNaprav(W, db, obrati.find(o => o.id === rec.obrat_id)); if (!r.nk.length && !r.nh.length) return toast(rec.obrat_id ? "Iz naprav obrata ni novih korakov ali nevarnosti (obkljukajte naprave pri obratu)." : "Načrt ni povezan z obratom.", true); mark(); s3(el); toast("Dodano iz naprav: " + mnx(r.nk.length, ["korak", "koraka", "koraki", "korakov"]) + ", " + mnx(r.nh.length, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"]) + " (predlog – oceni in potrdi v koraku 4)."); };
    $("#kadd").onclick = () => { W.koraki.push({ id: uidc(), naziv: "", tip: "priprava" }); mark(); s3(el); const z = $$(".krow input[data-k=naziv]", el).pop(); if (z) z.focus(); };
    $$("[data-x]", el).forEach(b => b.onclick = () => {
      const i = +b.dataset.x, k = W.koraki[i], n = vezane(k.id);
      const izbrisi = () => { oznaciKorak(k.id, "izbrisan"); W.koraki.splice(i, 1); mark(); s3(el); if (n) toast(n + " nevarnosti je ostalo brez koraka – preverite jih v koraku 4."); };
      if (n) confirmBox(`Korak »${k.naziv || i + 1}« ima ${n} povezanih nevarnosti. Po izbrisu bodo brez koraka in označene za preverjanje. Izbrišem korak?`, izbrisi, true); else izbrisi();
    });
    $$("[data-up]", el).forEach(b => b.onclick = () => { const i = +b.dataset.up; if (i) { [W.koraki[i - 1], W.koraki[i]] = [W.koraki[i], W.koraki[i - 1]]; mark(); s3(el); } });
    $$("[data-dn]", el).forEach(b => b.onclick = () => { const i = +b.dataset.dn; if (i < W.koraki.length - 1) { [W.koraki[i + 1], W.koraki[i]] = [W.koraki[i], W.koraki[i + 1]]; mark(); s3(el); } });
    $("#dpdf").onclick = () => dlBlob(pdfBuild({ naslov: "Diagram poteka – " + rec.naziv, stranka: stranka.naziv, verzija: rec.verzija_oznaka || "1.0" }, d => { d.h(1, "Diagram poteka"); d.flow(W.koraki.map((k, i) => { const c = ccpNaKoraku(W, k.id); return { n: i + 1, t: k.naziv, ccp: !!c.length, tag: c.join(", ") }; })); }), "diagram-poteka.pdf");
  }

  // 4. analiza nevarnosti
  let samoPreveri = false;
  const kratko = (t, n) => { t = t || "–"; return t.length > n ? t.slice(0, n - 1) + "…" : t; };
  const redKoraka = kid => { const i = W.koraki.findIndex(k => k.id === kid); return i < 0 ? 1e6 : i; };
  function s4(el) {
    const M = W.metoda, npr = zaPreverjanje(), nep = W.nevarnosti.filter(h => hazStatus(h) !== "potrjeno").length;
    const vrste = W.nevarnosti.map((h, i) => [h, i]).sort((a, b) => redKoraka(a[0].korak_id) - redKoraka(b[0].korak_id) || a[1] - b[1]).map(x => x[0])
      .filter(h => !samoPreveri || h.preveri_korak || !W.koraki.some(k => k.id === h.korak_id));
    // matrika tveganja: število nevarnosti po verjetnosti (vrstice, 5 → 1) in teži (stolpci 1 → 5)
    const mat = [5, 4, 3, 2, 1].map(vv => `<tr><th>${vv}</th>${[1, 2, 3, 4, 5].map(tt => { const n = W.nevarnosti.filter(h => +h.verjetnost === vv && +h.teza === tt).length, r = rizikRazred(vv * tt, M); return `<td class="rm-${r}" title="V ${vv} × T ${tt} = ${vv * tt} (${r})">${n || ""}</td>`; }).join("")}</tr>`).join("");
    let prejKorak = null;
    el.innerHTML = `<div class="card"><h2>4. Analiza nevarnosti</h2>
    <details><summary><b>Metodologija ocene tveganja</b> (privzeta, prilagodljiva – potrdi strokovnjak)</summary><p>Tveganje = verjetnost (1–5) × teža posledic (1–5). Razredi: nizko ≤ <input type="number" data-k="nizko_do" style="width:70px;display:inline-block">, srednje ≤ <input type="number" data-k="srednje_do" style="width:70px;display:inline-block">, visoko nad tem. Pomembne nevarnosti (srednje in visoko) obravnavate v koraku 5. Verjetnost: ${M.verjetnost.join("; ")}. Teža: ${M.teza.join("; ")}. Metodologija se izpiše v dokumentaciji.</p></details>
    <div class="nev-vrh"><div><p class="note info">Vrstice z oznako »predlog« so izhodišče iz baze znanja. Ocene verjetnosti in teže niso vnaprej določene – vnesete jih za konkretni obrat. <b>Nevarnost je potrjena samo, ko obkljukate »pregledal in potrjujem«</b> (tudi ročno dodana ali urejena).</p>
    ${npr ? `<p class="note" style="border-left:4px solid var(--bad)">${mnx(npr, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} ${mn(npr, ["je vezana", "sta vezani", "so vezane", "je vezanih"])} na spremenjen ali izbrisan korak – preverite povezavo s korakom. <button class="btn sm ghost" id="h_flt">${samoPreveri ? "Pokaži vse" : "Pokaži samo te"}</button></p>` : ""}
    <div class="row"><button class="btn edit" id="hadd">+ Dodaj nevarnost</button>${nep ? `<button class="btn ghost sec edit" id="hok">Potrdi vse nepotrjene (${nep})</button>` : ""}</div></div>
    <table class="rmat" aria-label="Matrika tveganja"><caption>Matrika tveganja (število nevarnosti)</caption><tr><th>V \\ T</th>${[1, 2, 3, 4, 5].map(t => `<th>${t}</th>`).join("")}</tr>${mat}</table></div>
    <div class="tw"><table class="t nev-t"><thead><tr><th>Korak</th><th>Vrsta</th><th>Nevarnost</th><th>Obstoječi ukrepi</th><th>V</th><th>T</th><th>Tveganje</th><th>Stanje</th></tr></thead><tbody>${vrste.map(h => {
      const r = rizik(h), kor = W.koraki.find(k => k.id === h.korak_id), nova = h.korak_id !== prejKorak; prejKorak = h.korak_id;
      const kc = kor ? `<td class="kgr" title="${esc((redKoraka(h.korak_id) + 1) + ". " + kor.naziv)}"><b>${redKoraka(h.korak_id) + 1}.</b> ${esc(kratko(kor.naziv, 22))}</td>` : '<td class="kgr"><span class="badge bad">brez koraka</span></td>';
      return `<tr class="click${nova ? " grp" : ""}" data-h="${esc(h.id)}">${nova ? kc : '<td class="kgr-n" aria-hidden="true"></td>'}<td>${esc(HTIPI[h.tip] || h.tip)}</td><td>${esc(h.nevarnost)}</td><td>${esc((h.obstojec || "").slice(0, 80))}</td><td>${esc(h.verjetnost || "?")}</td><td>${esc(h.teza || "?")}</td><td>${r ? `<span class="badge ${r <= M.nizko_do ? "ok" : r <= M.srednje_do ? "warn" : "bad"}">${r} ${rizikRazred(r, M)}</span>` : '<span class="badge">neocenjeno</span>'}</td><td>${hazBadge(h)}</td></tr>`; }).join("") || '<tr><td colspan="8" class="empty">Ni nevarnosti.</td></tr>'}</tbody></table></div></div>`;
    bindAll($("details", el), M);
    $("#hadd").onclick = () => hazForm(null, () => s4(el));
    const f = $("#h_flt"); if (f) f.onclick = () => { samoPreveri = !samoPreveri; s4(el); };
    const ok = $("#hok"); if (ok) ok.onclick = () => {
      const brez = W.nevarnosti.filter(h => hazStatus(h) !== "potrjeno" && !W.koraki.some(k => k.id === h.korak_id)).length;
      confirmBox(`Potrdim ${mnx(nep - brez, ["nepotrjeno nevarnost", "nepotrjeni nevarnosti", "nepotrjene nevarnosti", "nepotrjenih nevarnosti"])}? Potrdite samo, če ste vsako pregledali.${brez ? ` ${mnx(brez, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} brez koraka ${mn(brez, ["ostane nepotrjena", "ostaneta nepotrjeni", "ostanejo nepotrjene", "ostane nepotrjenih"])} – najprej jim določite korak.` : ""}`, () => {
        W.nevarnosti.forEach(h => { if (hazStatus(h) !== "potrjeno" && W.koraki.some(k => k.id === h.korak_id)) { h.potrjeno = true; delete h.urejeno; delete h.preveri_korak; } }); mark(); s4(el);
      });
    };
    $$("tr[data-h]", el).forEach(tr => tr.onclick = () => hazForm(W.nevarnosti.find(h => h.id === tr.dataset.h), () => s4(el)));
  }
  function hazForm(h, done) {
    const isNew = !h; h = h || { id: uidc(), korak_id: "", tip: "B", potrjeno: false };
    const fl = [["korak_id", "Korak", "sel", W.koraki.map((k, i) => [k.id, (i + 1) + ". " + k.naziv])], ["tip", "Vrsta nevarnosti", "sel", Object.entries(HTIPI)], ["nevarnost", "Nevarnost (opis)", "area"], ["vir", "Vir nevarnosti", "area"], ["posledica", "Možna posledica", "area"], ["obstojec", "Obstoječi ukrepi", "area"], ["verjetnost", "Verjetnost (1–5)", "sel", W.metoda.verjetnost.map((x, i) => [i + 1, x])], ["teza", "Teža posledic (1–5)", "sel", W.metoda.teza.map((x, i) => [i + 1, x])], ["dodatni", "Dodatni ukrepi", "area"], ["odgovoren", "Odgovorna oseba"], ["preverjanje", "Preverjanje (verifikacija)"]];
    const opozorilo = h.preveri_korak ? `<p class="note" style="border-left:4px solid var(--bad)">Korak te nevarnosti je bil ${h.preveri_korak === "izbrisan" ? "izbrisan" : "preimenovan"}. Preverite, ali nevarnost še sodi h koraku (po potrebi izberite drugega), in jo znova potrdite.</p>` : "";
    const html = `${opozorilo}<div class="fgrid">${fl.map(([k, l, t, o]) => `<label class="f ${t === "area" ? "wide" : ""} ${k === "korak_id" || k === "nevarnost" ? "req" : ""}"><span>${l}</span>${t === "area" ? `<textarea data-k="${k}"></textarea>` : t === "sel" ? `<select data-k="${k}"><option value=""></option>${o.map(x => `<option value="${esc(x[0])}">${esc(x[1])}</option>`).join("")}</select>` : `<input data-k="${k}">`}</label>`).join("")}</div><div id="rr"></div>
      <label class="f potrdi-h"><input type="checkbox" data-k="potrjeno" style="width:auto"> <b>Nevarnost sem pregledal in potrjujem</b>${h.predlog ? " (predlog iz baze znanja)" : ""}</label>`;
    const copy = Object.assign({}, h, { potrjeno: hazStatus(h) === "potrjeno" });
    const d = modal(isNew ? "Nova nevarnost" : "Nevarnost", html, [{ t: "Prekliči", cls: "ghost sec" }, ...(!isNew && editable ? [{ t: "Izbriši", cls: "danger", fn: async () => { await new Promise(r => setTimeout(r, 0)); if (!window.confirm("Izbrišem nevarnost" + (W.kontrole[h.id] ? " in njen kontrolni ukrep" : "") + "?")) return false; W.nevarnosti = W.nevarnosti.filter(x => x.id !== h.id); delete W.kontrole[h.id]; mark(); done(); } }] : []), { t: "Shrani", fn: () => {
      if (!copy.nevarnost) { toast("Vnesite opis nevarnosti.", true); return false; }
      if (!copy.korak_id && W.koraki.length) { toast("Izberite korak.", true); return false; }
      const spremenjeno = ["korak_id", "tip", "nevarnost", "vir", "posledica", "obstojec"].some(k => String(copy[k] || "") !== String(h[k] || ""));
      if (copy.potrjeno) delete copy.urejeno; else if (!isNew && h.predlog && spremenjeno) copy.urejeno = true;
      delete copy.preveri_korak; // uporabnik je zapis pregledal
      if (copy.potrjeno && rizik(copy) > W.metoda.nizko_do && !(W.kontrole[h.id] || {}).vrsta) toast("Potrjena nevarnost še nima vrste kontrolnega ukrepa – določite jo v koraku 5.", "opozorilo");
      if (h.potrjeno && !copy.potrjeno && !isNew) toast("Potrditev nevarnosti je odstranjena – nevarnost je spet nepotrjena.", "opozorilo");
      Object.keys(h).forEach(k => { if (!(k in copy)) delete h[k]; }); Object.assign(h, copy); if (isNew) W.nevarnosti.push(h); mark(); done();
    } }]);
    bindAll(d, copy); const live = () => { const r = rizik(copy); $("#rr", d).innerHTML = r ? `Tveganje: <b>${r}</b> (${rizikRazred(r, W.metoda)})` : '<span class="mut">Vnesite verjetnost in težo.</span>'; };
    d.querySelectorAll("[data-k]").forEach(i => i.addEventListener("input", live)); live();
    if (!editable) d.querySelectorAll("input,select,textarea").forEach(e => e.disabled = true);
  }

  // 5. kontrolni ukrepi (PRP / OPRP / CCP)
  const vrstaBadge = (h, oz) => { const c = W.kontrole[h.id] || {}; if (!c.vrsta) return '<span class="badge">ni izbrano</span>'; if (c.vrsta === "nobeno") return '<span class="badge">ni potreben</span>'; return `<span class="badge vu-${esc(String(c.vrsta).toLowerCase())}">${esc(oz[h.id] || c.vrsta)}</span>`; };
  function s5(el) {
    const ocenjene = W.nevarnosti.filter(h => rizik(h)), sig = ocenjene.filter(h => rizik(h) > W.metoda.nizko_do), nizke = ocenjene.filter(h => rizik(h) <= W.metoda.nizko_do);
    const unr = W.nevarnosti.length - ocenjene.length, oz = ccpOznake(W), poKoraku = (a, b) => redKoraka(a.korak_id) - redKoraka(b.korak_id);
    const vrstica = (h, atr) => { const c = W.kontrole[h.id] || {}; return `<tr ${atr}="${esc(h.id)}"><td title="${esc(korakIme(h.korak_id))}">${num(h.korak_id)} ${esc(kratko(korakIme(h.korak_id), 22))}</td><td>${esc(h.nevarnost)}</td><td><span class="badge ${({ visoko: "bad", srednje: "warn", nizko: "ok" })[rizikRazred(rizik(h), W.metoda)]}">${rizikRazred(rizik(h), W.metoda)}</span></td><td>${vrstaBadge(h, oz)}${c.vrsta === "CCP" && (c.mejna_predlog || CCPPOL.some(k => !c[k])) ? ' <span class="badge warn">potrebna strokovna potrditev</span>' : ""}</td><td>${esc((c.ukrep || h.obstojec || "").slice(0, 90))}</td><td><button class="btn sm edit" data-o="${esc(h.id)}">Uredi</button></td></tr>`; };
    const glava = '<thead><tr><th>Korak</th><th>Nevarnost</th><th>Tveganje</th><th>Vrsta ukrepa</th><th>Ukrep / opis</th><th></th></tr></thead>';
    const brezNizkih = nizke.filter(h => !(W.kontrole[h.id] || {}).vrsta).length;
    el.innerHTML = `<div class="card"><h2>5. Kontrolni ukrepi</h2>
    <p class="note info"><span class="badge vu-prp">PRP</span> predpogojni program (splošna higiena), <span class="badge vu-oprp">OPRP</span> operativni predpogojni program (specifičen ukrep z merili), <span class="badge vu-ccp">CCP</span> kritična kontrolna točka (zadnji korak nadzora, mejne vrednosti, spremljanje, korektivni ukrepi). Odločitveno drevo daje samo <b>predlog</b>; vrsto ukrepa vedno izberete vi. Ni vsak temperaturni nadzor CCP.</p>
    ${unr ? `<p class="note">${mnx(unr, ["nevarnost", "nevarnosti", "nevarnosti", "nevarnosti"])} še ${mn(unr, ["nima", "nimata", "nimajo", "nima"])} ocene tveganja (korak 4).</p>` : ""}
    <h3>Pomembne nevarnosti (srednje in visoko tveganje)</h3>
    <div class="tw"><table class="t">${glava}<tbody>${sig.sort(poKoraku).map(h => vrstica(h, "data-h")).join("") || '<tr><td colspan="6" class="empty">Ni pomembnih nevarnosti (ocenite tveganje v koraku 4).</td></tr>'}</tbody></table></div>
    ${nizke.length ? `<details class="nizka" style="margin-top:12px"><summary><b>${mnx(nizke.length, ["nizko tveganje", "nizki tveganji", "nizka tveganja", "nizkih tveganj"])} – PRP</b>${brezNizkih ? ` <span class="mut">(${brezNizkih} brez izbrane vrste ukrepa)</span>` : ""}</summary><p class="mut">Nizka tveganja se praviloma obvladujejo s predpogojnimi programi. Vrsto ukrepa lahko določite posamično ali vsem hkrati.</p>${brezNizkih ? '<div class="row"><button class="btn sm ghost edit" id="nprp">Vsem brez ukrepa dodeli PRP</button></div>' : ""}<div class="tw"><table class="t">${glava}<tbody>${nizke.sort(poKoraku).map(h => vrstica(h, "data-hn")).join("")}</tbody></table></div></details>` : ""}</div>`;
    $$("[data-o]", el).forEach(b => b.onclick = () => ctrlForm(W.nevarnosti.find(h => h.id === b.dataset.o), () => s5(el)));
    const np = $("#nprp"); if (np) np.onclick = () => { nizke.forEach(h => { if (!(W.kontrole[h.id] || {}).vrsta) W.kontrole[h.id] = { hid: h.id, vrsta: "PRP", utemeljitev: "Nizko tveganje – obvladuje se s predpogojnimi programi (dobra higienska praksa)." }; }); mark(); s5(el); $("details.nizka", el).open = true; };
  }
  // predlogi meril iz baze režimov: temperaturni (od–do °C) in druga merila (alkohol, sladkor, pH, a_w, metanol, SO2 …)
  // temperaturni režim: obe meji »0 do 4 °C«, samo spodnja »≥ 72 °C«, samo zgornja »≤ -18 °C«
  function ctrlForm(h, done) {
    const c = Object.assign({ hid: h.id }, W.kontrole[h.id] || {}), oz = ccpOznake(W);
    const rez = db.rezimi || [], grp = (l, a) => a.length ? `<optgroup label="${l}">${a.map(r => `<option value="${esc(r.id)}">${esc(r.naziv + " (" + rezimOpis(r) + ")")}</option>`).join("")}</optgroup>` : "";
    const html = `<p><b>${esc(h.nevarnost)}</b><br><span class="mut">Korak: ${esc(korakIme(h.korak_id))} · tveganje ${rizik(h)} (${rizikRazred(rizik(h), W.metoda)})${oz[h.id] ? " · " + oz[h.id] : ""}</span></p>
    <details open class="odl-drevo"><summary><b>Odločitveno drevo (predlog)</b></summary><div id="dt">${["Ali na tem koraku že obstaja ukrep za obvladovanje te nevarnosti?", "Ali je ta korak posebej namenjen odstranitvi ali zmanjšanju nevarnosti na sprejemljivo raven?", "Ali bi lahko onesnaženje preseglo sprejemljive ravni ali se povečalo do nesprejemljivih ravni?", "Ali bo naslednji korak odstranil ali zmanjšal nevarnost na sprejemljivo raven?"].map((q, i) => `<label class="f odl-v"><span>V${i + 1}: ${q}</span><select data-q="${i}"><option value=""></option><option value="d">Da</option><option value="n">Ne</option></select></label>`).join("")}<div id="dtres" class="note info">Odgovorite na vprašanja.</div></div></details>
    <div class="fgrid"><label class="f req"><span>Vrsta ukrepa (izberete vi)</span><select data-k="vrsta"><option value=""></option><option>PRP</option><option>OPRP</option><option>CCP</option><option value="nobeno">Ni potreben dodaten nadzor</option></select></label>
    <label class="f wide"><span>Utemeljitev izbire</span><textarea data-k="utemeljitev"></textarea></label><label class="f wide"><span>Ukrep za obvladovanje / opis</span><textarea data-k="ukrep"></textarea></label>
    <div id="ccpf" class="wide fgrid" style="grid-column:1/-1"><p class="note wide">Za CCP in OPRP izpolnite spodaj. <b>Mejnih vrednosti ne predpisuje program</b>: vnesite jih sami ali uporabite predlog iz baze in ga strokovno potrdite.</p>
    <label class="f wide"><span>Kaj se nadzoruje</span><input data-k="kaj"></label><label class="f wide"><span>Enolični naziv (npr. Toplotna obdelava mesa)</span><input data-k="naziv"></label><label class="f"><span>Mejna vrednost / merilo</span><input data-k="mejna"></label><label class="f"><span>Vir meje</span><select data-k="mejna_vir_vrsta"><option value=""></option><option>predpis</option><option>smernica</option><option>navodila proizvajalca</option><option>validacija</option><option>lastne meritve</option></select></label><label class="f"><span>Temperatura</span><input data-k="temperatura" placeholder="npr. ≥ 75 °C v jedru"></label><label class="f"><span>Čas</span><input data-k="cas" placeholder="npr. 2 min"></label><label class="f"><span>Temperatura olja (cvrtje)</span><input data-k="temp_olja" placeholder="npr. ≤ 175 °C"></label><label class="f wide"><span>Validacija (zapis, kdo, kdaj)</span><textarea data-k="validacija"></textarea></label><label class="f wide"><span>Naziv evidence (pri »Drugo«)</span><input data-k="evidenca_naziv"></label><label class="f"><span>Predlog iz baze (neobvezno)</span><select id="regsel"><option value=""></option>${grp("Temperatura", rez.filter(r => !r.enota))}${grp("Druga merila (alkohol, sladkor, pH, a_w, metanol, SO2)", rez.filter(r => r.enota))}</select></label><label class="f wide"><span>Utemeljitev mejne vrednosti (vir)</span><textarea data-k="mejna_vir"></textarea></label>
    <label class="f"><span>Način spremljanja</span><input data-k="spremljanje"></label><label class="f"><span>Pogostost</span><input data-k="pogostost"></label><label class="f"><span>Odgovorna oseba</span><input data-k="odgovoren"></label><label class="f"><span>Povezane evidence</span><select data-k="evidenca">${[""].concat(Object.keys(EV)).map(k => `<option value="${k}">${k ? EV[k].ime : ""}</option>`).join("")}</select></label>
    <label class="f wide"><span>Korektivni ukrepi ob preseganju</span><textarea data-k="korektivni"></textarea></label><label class="f wide"><span>Verifikacija</span><textarea data-k="verifikacija"></textarea></label></div></div>`;
    const d = modal("Kontrolni ukrep", html, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: () => {
      if (!c.vrsta) { toast("Izberite vrsto ukrepa.", true); return false; }
      if (c.vrsta === "CCP") { const miss = CCPPOL.filter(k => !c[k]); if (miss.length && !confirm("Pri CCP manjkajo polja (" + miss.length + "). Shranim kot nepopolno? Dokument bo označen »potrebna strokovna potrditev«.")) return false; }
      W.kontrole[h.id] = c; mark(); done();
    } }]);
    bindAll(d, c);
    // polja za mejne vrednosti, spremljanje in korektivne ukrepe samo pri CCP in OPRP
    const ccpPolja = () => { $("#ccpf", d).hidden = !["CCP", "OPRP"].includes(c.vrsta); };
    $("[data-k=vrsta]", d).addEventListener("change", ccpPolja); ccpPolja();
    $("#regsel", d).onchange = e => { const r = rez.find(x => x.id === e.target.value); if (!r) return; $("[data-k=mejna]", d).value = c.mejna = r.naziv + ": " + rezimOpis(r); c.mejna_predlog = true; if (!c.mejna_vir) { c.mejna_vir = "Predlog iz baze znanja" + (r.vir ? " (" + r.vir + ")" : " (temperaturni režimi)") + " – potrebna strokovna potrditev."; $("[data-k=mejna_vir]", d).value = c.mejna_vir; } mark(); };
    $$("[data-q]", d).forEach((sel, i) => { sel.value = (c.drevo || [])[i] || ""; });
    const dt = () => { const a = $$("[data-q]", d).map(s => s.value); c.drevo = a; let r = "Odgovorite na vprašanja."; if (a[0] === "n") r = "V1 = Ne: uvedite ali spremenite ukrep na tem koraku/procesu; šele nato presodite razvrstitev."; else if (a[1] === "d") r = "Predlog: možna CCP (korak je namenjen obvladovanju nevarnosti). Presodite sami."; else if (a[1] === "n" && a[2] === "n") r = "Predlog: ni CCP – PRP ali OPRP."; else if (a[2] === "d" && a[3] === "d") r = "Predlog: ni CCP na tem koraku (nadzor na naslednjem koraku) – PRP ali OPRP."; else if (a[2] === "d" && a[3] === "n") r = "Predlog: možna CCP. Presodite sami."; $("#dtres", d).textContent = r; };
    $$("[data-q]", d).forEach(s => s.onchange = dt); if ((c.drevo || []).some(Boolean)) dt();
    if (!editable) d.querySelectorAll("input,select,textarea").forEach(e => e.disabled = true);
  }

  // 6. pregled osnutka
  function warnings() {
    const w = [];
    if (!W.koraki.length) w.push("Ni procesnih korakov.");
    if (!W.nevarnosti.length) w.push("Ni analize nevarnosti.");
    const zp = zaPreverjanje(); if (zp) w.push(zp + " nevarnosti je vezanih na spremenjen ali izbrisan korak – preverite povezavo s korakom.");
    const pr = W.nevarnosti.filter(h => ["predlog", "urejeno", "nepotrjeno"].includes(hazStatus(h))).length; if (pr) w.push(pr + " nevarnosti še ni potrjenih (predlogi, urejeni ali ročno dodani zapisi so nepreverjeni).");
    const un = W.nevarnosti.filter(h => !rizik(h)).length; if (un) w.push(un + " nevarnosti nima ocene tveganja.");
    const sig = W.nevarnosti.filter(h => rizik(h) > W.metoda.nizko_do), nc = sig.filter(h => !(W.kontrole[h.id] || {}).vrsta).length; if (nc) w.push(nc + " pomembnih nevarnosti nima izbrane vrste kontrolnega ukrepa.");
    const ccpNep = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" && CCPPOL.some(k => !c[k])).length; if (ccpNep) w.push(ccpNep + " CCP je nepopolnih (mejne vrednosti, spremljanje, korektivni ukrepi …).");
    const pm = Object.values(W.kontrole).filter(c => c.mejna_predlog).length; if (pm) w.push(pm + " mejnih vrednosti je predlog iz baze in zahteva strokovno potrditev.");
    if (!W.zivila.length) w.push("Niso vnesena živila.");
    if (!rec.obrat_id) w.push("Načrt ni povezan z obratom.");
    return w;
  }
  function s6(el) {
    const w = warnings(), P = W.pregled, B = W.besedila;
    el.innerHTML = `<div class="card"><h2>6. Pregled osnutka</h2>${w.length ? `<div class="note"><b>Pred potrditvijo:</b><ul style="margin:6px 0 0">${w.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div>` : '<p class="note info">Osnutek ni vseboval opaženih vrzeli. Strokovni pregled je vseeno obvezen.</p>'}
    <p class="mut">Osnutek lahko urejate pred izvozom. Tekst spodaj se vključi v dokument.</p>
    <div class="fgrid">${inp("uvod", "Uvodno besedilo dokumenta", { wide: 1, area: 1 })}${inp("opombe", "Dodatne opombe", { wide: 1, area: 1 })}</div>
    <h3>Strokovna potrditev</h3><p class="mut">Končni HACCP načrt mora pregledati in potrditi odgovorna oseba / strokovnjak. Potrditev vpišete tukaj; stanje načrta spremenite v osnovnih podatkih.</p>
    <div class="fgrid">${inp("potrdil", "Strokovno potrdil (ime, funkcija)")}${inp("datum", "Datum potrditve", { type: "date" })}${inp("komentar", "Komentar pregledovalca", { wide: 1, area: 1 })}${inp("interni_rok", "Interni rok naslednjega pregleda načrta", { type: "date" })}${inp("interni_rok_utemeljitev", "Utemeljitev roka", { wide: 1 })}</div>
    <h3>Povzetek</h3><table class="t"><tr><td>Koraki</td><td>${W.koraki.length}</td></tr><tr><td>Nevarnosti</td><td>${W.nevarnosti.length} (pomembnih ${W.nevarnosti.filter(h => rizik(h) > W.metoda.nizko_do).length})</td></tr><tr><td>PRP / OPRP / CCP</td><td>${["PRP", "OPRP", "CCP"].map(t => Object.values(W.kontrole).filter(c => c.vrsta === t).length).join(" / ")}${Object.keys(ccpOznake(W)).length ? " (" + Object.values(ccpOznake(W)).join(", ") + ")" : ""}</td></tr></table></div>`;
    const bs = el.querySelectorAll("[data-k]"); bs.forEach(i => { const k = i.dataset.k, tgt = ["uvod", "opombe"].includes(k) ? B : P; i.value = tgt[k] || ""; i.oninput = () => { tgt[k] = i.value; mark(); }; });
  }

  // 7. izvoz
  const prilagojeno = id => W.besedila_pogl && W.besedila_pogl[id] !== undefined && W.besedila_pogl[id] !== null;
  const besediloPoglavja = id => { if (prilagojeno(id)) return W.besedila_pogl[id]; const bp = besedilaPodatki(W, stranka, obrati.find(o => o.id === rec.obrat_id), db); return id === "prp" ? [besedilaTekst(db, "prp", bp.oznake, bp.vr), besedilaTekst(db, "alergeni", bp.oznake, bp.vr)].filter(Boolean).join("\n\n") : besedilaTekst(db, id, bp.oznake, bp.vr); };
  function pglEditor(el) {
    const P = W.poglavja, nm = i => (PGL_DEF.find(d => d[0] === P[i].id) || [])[1];
    el.innerHTML = `<h3>Poglavja dokumentacije</h3><p class="mut">Poglavja lahko vključite ali izključite, preimenujete, premaknete in dodate svoja. Številke se v dokumentu prištejejo samodejno.</p><div class="tw"><table class="t"><tr><th>Vključi</th><th>Naslov</th><th>Besedilo (lastna poglavja)</th><th></th></tr>${P.map((c, i) => `<tr data-i="${i}"><td><input type="checkbox" data-k="on"></td><td><input data-k="naslov"></td><td>${c.custom ? '<textarea data-k="besedilo" style="min-height:60px"></textarea>' : c.id === "priloga" ? '<span class="mut">samodejno iz baze zakonodaje</span>' : `<details class="pgl-b"><summary>${prilagojeno(c.id) ? '<span class="badge warn">besedilo prilagojeno</span>' : (besediloPoglavja(c.id) ? '<span class="mut">besedilo iz baze besedil</span>' : '<span class="mut">brez uvodnega besedila – po želji ga dodajte</span>')}</summary><textarea data-pb="${esc(c.id)}" style="min-height:160px" aria-label="Besedilo poglavja ${esc(c.naslov)}"></textarea><div class="row" style="margin:4px 0 0"><button class="btn sm ghost sec edit" data-pbr="${esc(c.id)}" ${prilagojeno(c.id) ? "" : "hidden"}>Ponastavi na besedilo iz baze</button><small class="mut">»## « začne podnaslov, »- « alinejo. Tabele se dodajo samodejno iz podatkov načrta.</small></div></details>`}</td><td style="white-space:nowrap"><button class="btn sm ghost sec edit" data-up="${i}">↑</button> <button class="btn sm ghost sec edit" data-dn="${i}">↓</button> ${c.custom ? `<button class="btn sm ghost sec edit" data-x="${i}">✕</button>` : ""}</td></tr>`).join("")}</table></div><div class="row" style="margin-top:8px"><button class="btn ghost edit" id="padd">+ Dodaj lastno poglavje</button><button class="btn ghost sec edit" id="preset">Ponastavi poglavja</button></div>`;
    $$("tr[data-i]", el).forEach(tr => bindAll(tr, P[+tr.dataset.i]));
    // besedilo vgrajenega poglavja: privzeto iz baze besedil (s podatki načrta); sprememba se shrani v načrt
    $$("[data-pb]", el).forEach(ta => { const id = ta.dataset.pb; ta.value = besediloPoglavja(id); ta.oninput = () => { W.besedila_pogl = W.besedila_pogl || {}; W.besedila_pogl[id] = ta.value; mark(); const r = $(`[data-pbr="${id}"]`, el); if (r) r.hidden = false; }; });
    $$("[data-pbr]", el).forEach(b => b.onclick = () => { delete W.besedila_pogl[b.dataset.pbr]; mark(); pglEditor(el); });
    $("#padd").onclick = () => { P.splice(Math.max(0, P.length - 1), 0, { id: "x" + uidc(), custom: true, on: true, naslov: "Novo poglavje", besedilo: "" }); mark(); pglEditor(el); };
    $("#preset").onclick = () => confirmBox("Ponastavim poglavja na privzeta (lastna poglavja bodo odstranjena)?", () => { W.poglavja = poglavjaCfg({}); mark(); pglEditor(el); }, true);
    $$("[data-up]", el).forEach(b => b.onclick = () => { const i = +b.dataset.up; if (i) { [P[i - 1], P[i]] = [P[i], P[i - 1]]; mark(); pglEditor(el); } });
    $$("[data-dn]", el).forEach(b => b.onclick = () => { const i = +b.dataset.dn; if (i < P.length - 1) { [P[i + 1], P[i]] = [P[i], P[i + 1]]; mark(); pglEditor(el); } });
    $$("[data-x]", el).forEach(b => b.onclick = () => { P.splice(+b.dataset.x, 1); mark(); pglEditor(el); });
    if (!editable) $$("input,textarea,button", el).forEach(e => e.disabled = true);
  }
  function s7(el) {
    W.poglavja = poglavjaCfg(W);
    el.innerHTML = `<div id="pgl" class="card"></div><div class="card"><h2>7. Izvoz dokumentacije</h2>${rec.status !== "potrjeno" ? '<p class="note">Načrt še ni potrjen – dokument bo označen kot OSNUTEK.</p>' : ""}${warnings().length ? '<p class="note">Odprte vrzeli iz koraka 6 bodo navedene v dokumentu.</p>' : ""}
    <div class="row"><button class="btn" id="xpdf">PDF dokumentacija (HiGiFood)</button><button class="btn" id="xdoc">Word (.docx, urejljivo)</button><button class="btn ghost sec" id="xxl">Excel (nevarnosti in ukrepi)</button><button class="btn ghost sec" id="xnav">PDF / Word posameznega navodila …</button></div>
    <p class="mut">Dokument vsebuje naslovnico, kazalo, številke strani, različico in datum. Ne pomeni uradne odobritve in ne zagotavlja samodejne skladnosti z zakonodajo.</p></div>`;
    pglEditor($("#pgl"));
    $("#xpdf").onclick = async () => { try { const navodila = await D.list("navodila", { stranka_id: rec.stranka_id }); const ex = { tloris: await tlorisForPlan(W) }; dlBlob(buildHaccpPdf(rec, W, stranka, obrati, navodila, db, warnings(), undefined, ex), "HACCP-" + stranka.naziv + ".pdf"); const dl = dolzinaDokumenta(pdfBuild.zadnji, 50); if (dl) toast(dl, "opozorilo"); } catch (e) { fail(e); } };
    $("#xdoc").onclick = async () => { try { const navodila = await D.list("navodila", { stranka_id: rec.stranka_id }); const ex = { tloris: await tlorisForPlan(W) }; dlBlob(buildHaccpPdf(rec, W, stranka, obrati, navodila, db, warnings(), "docx", ex), "HACCP-" + stranka.naziv + ".docx"); } catch (e) { fail(e); } };
    $("#xxl").onclick = () => downloadXlsx("HACCP-analiza-" + stranka.naziv + ".xlsx", [
      { ime: "Koraki", glava: ["Št.", "Korak", "Vrsta", "Opis"], vrste: W.koraki.map((k, i) => [i + 1, k.naziv, k.tip, k.opis || ""]) },
      { ime: "Analiza nevarnosti", glava: ["Korak", "Vrsta", "Nevarnost", "Vir", "Posledica", "Obstoječi ukrepi", "Verjetnost", "Teža", "Tveganje", "Razred", "Dodatni ukrepi", "Odgovoren", "Preverjanje", "Stanje"], vrste: W.nevarnosti.map(h => [korakIme(h.korak_id), HTIPI[h.tip] || h.tip, h.nevarnost, h.vir || "", h.posledica || "", h.obstojec || "", +h.verjetnost || "", +h.teza || "", rizik(h) || "", rizik(h) ? rizikRazred(rizik(h), W.metoda) : "", h.dodatni || "", h.odgovoren || "", h.preverjanje || "", HSTAT[hazStatus(h)][1]]) },
      { ime: "Kontrolni ukrepi", glava: ["Nevarnost", "Vrsta", "Ukrep / opis", "Utemeljitev izbire", "Kaj se nadzoruje", "Mejna vrednost", "Vir meje", "Spremljanje", "Pogostost", "Odgovoren", "Korektivni ukrepi", "Verifikacija"], vrste: Object.values(W.kontrole).map(c => { const h = W.nevarnosti.find(x => x.id === c.hid) || {}; return [h.nevarnost || "", ccpOznake(W)[c.hid] || (c.vrsta === "nobeno" ? "ni potreben" : c.vrsta), c.ukrep || "", c.utemeljitev || "", c.kaj || "", c.mejna || "", c.mejna_vir || "", c.spremljanje || "", c.pogostost || "", c.odgovoren || "", c.korektivni || "", c.verifikacija || ""]; }) }]);
    $("#xnav").onclick = async () => { const nav = await D.list("navodila", { stranka_id: rec.stranka_id }); if (!nav.length) return toast("Ni navodil.", true); modal("Izberi navodilo", `<select id="nsel" size="8" style="min-height:180px">${nav.map(n => `<option value="${esc(n.id)}">${esc(n.naslov)}</option>`).join("")}</select>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Word", cls: "ghost", fn: () => { const n = nav.find(x => x.id === $("#nsel").value); if (!n) return false; dlBlob(navodiloPdf(n, stranka, db, "docx"), "navodilo-" + n.naslov + ".docx"); } }, { t: "PDF", fn: () => { const n = nav.find(x => x.id === $("#nsel").value); if (!n) return false; dlBlob(navodiloPdf(n, stranka, db), "navodilo-" + n.naslov + ".pdf"); } }]); };
  }
  draw();
  // opozorilo ob zaprtju zavihka z neshranjenimi spremembami; ob odhodu na drugo stran aplikacije se shrani samodejno
  window.onbeforeunload = e => { if (dirty && editable) { e.preventDefault(); e.returnValue = ""; return ""; } };
  const odhod = () => {
    if (location.hash.startsWith("#/carovnik/" + id)) return;
    window.removeEventListener("hashchange", odhod); window.onbeforeunload = null;
    if (dirty && editable) save("Samodejno shranjevanje ob odhodu iz čarovnika", true).catch(fail);
  };
  window.addEventListener("hashchange", odhod);
}
function navodiloPravno(d, n, db) {
  const p = (db.navodila_predloge || []).find(x => x.id === n.predloga); if (!p) return;
  const zv = zakoniVrstice(p, db); if (!zv.length) return;
  d.h(2, "Pravna podlaga (stanje baze znanja na dan izpisa)");
  d.bullets(zv.map(x => x.txt));
  const w = navodiloOpozorila(n, db); if (w.length) d.box("Opozorilo: " + w.join("; ") + ".", "r");
}
function navodiloPdf(n, stranka, db, fmt) {
  return (fmt === "docx" ? docxBuild : pdfBuild)({ naslov: n.naslov, stranka: stranka.naziv, verzija: n.verzija_oznaka || "1.0", stanje: n.status }, d => { d.h(1, n.naslov); // zaporedne vrstice »- …« so alineje (prej so se izpustile)
    let al = []; const izpisi = () => { if (al.length) { d.bullets(al); al = []; } };
    String(n.vsebina || "").split("\n").forEach(l => { if (/^8\. PRAVNA/.test(l)) return; if (/^\s*[-•] /.test(l)) { al.push(l.replace(/^\s*[-•] /, "")); return; } izpisi(); if (/^\d+\. [A-ZČŠŽĆĐ ]+$/.test(l)) d.h(2, l); else if (l.trim()) d.p(l); else d.gap(4); }); izpisi(); navodiloPravno(d, n, db); });
}

// ---------- besedila poglavij iz baze znanja (zbirka »besedila«; enako v generatorju dokumentacije) ----------
// besedilo poglavja: izbrana besedila (po oznakah dejavnosti) z vstavljenimi podatki; oblika: »## naslov«, odstavki, »- « alineje
function besedilaTekst(db, pogl, oznake, vr) {
  return (db.besedila || []).filter(b => b.poglavje === pogl && (b.oznake && b.oznake.length ? b.oznake : ["*"]).some(o => oznake.has(o))).sort((a, b) => (a.vrstni_red || 0) - (b.vrstni_red || 0))
    .map(b => (b.naslov ? "## " + b.naslov + "\n\n" : "") + String(b.besedilo || "").replace(/\{(\w+)\}/g, (m, k) => vr[k] ? vr[k] : "____")).join("\n\n");
}
function besedilaBloki(t) {
  const out = [];
  for (const del of String(t || "").split(/\n\s*\n/)) {
    const v = del.trim(); if (!v) continue;
    if (v.startsWith("## ")) { out.push({ h: v.slice(3).trim() }); continue; }
    const uvod = [], al = [];
    for (const l of v.split("\n")) { if (/^\s*-\s+/.test(l)) al.push(l.replace(/^\s*-\s+/, "").trim()); else if (al.length) al[al.length - 1] += " " + l.trim(); else uvod.push(l.trim()); }
    if (uvod.length) out.push({ p: uvod.join(" ") }); if (al.length) out.push({ ul: al });
  }
  return out;
}
// podatki načrta za vstavljanje v besedila in oznake dejavnosti za izbor besedil
function besedilaPodatki(W, stranka, ob, db) {
  const br = (db.branze || []).find(b => b.id === W.branza), dej = [stranka.dejavnost].concat(stranka.dodatne_dejavnosti || []).filter(Boolean);
  const oznake = new Set(["*", ...((br && br.oznake) || []), ...dej.flatMap(d => (typeof DEJ_PREDLOGE !== "undefined" && DEJ_PREDLOGE[d] || []).flatMap(id => ((db.branze || []).find(b => b.id === id) || {}).oznake || []))]);
  if (W.zivila.some(z => z.rte)) oznake.add("rte");
  const oz = ccpOznake(W), ccp = W.nevarnosti.filter(h => /^CCP/.test(oz[h.id] || "")).sort((a, b) => oz[a.id].localeCompare(oz[b.id], "sl", { numeric: true }));
  const alg = [...new Set(W.zivila.flatMap(z => String(z.alergeni || "").replace(/\s*\(preveriti\)/ig, "").split(/[,;]/).map(x => x.trim()).filter(x => x && !/^ni alergenov$/i.test(x))))];
  const kor = W.koraki.map(k => k.naziv).filter(Boolean), cl = (W.zbiranje.clani || []).filter(x => x.ime), ekipa = cl.length ? cl.map(x => x.ime + (x.vloga ? " – " + x.vloga : "")) : String(W.zbiranje.hacc_ekipa || "").split("\n").map(x => x.trim()).filter(Boolean);
  return { oznake, vr: {
    podjetje: stranka.naziv, obrat: ob ? ob.naziv + (ob.naslov ? ", " + ob.naslov : "") : "", odgovorna_oseba: stranka.odgovorna_oseba || "",
    dejavnost: (ob && ob.vrsta) || [...new Set(dej.map(x => String(x).trim()).filter(Boolean))].join(", ") || (br ? br.naziv : ""), izdelki: W.zivila.map(z => z.naziv).filter(Boolean).join(", "), alergeni: alg.length ? alg.join(", ") : "alergeni niso navedeni",
    kupci: W.zbiranje.kupci || "splošna populacija", koraki_stevilo: String(kor.length), koraki_seznam: kor.join(" → "),
    ccp_stevilo: String(ccp.length), ccp_seznam: ccp.length ? ccp.map(h => oz[h.id] + " (" + ((W.koraki.find(k => k.id === h.korak_id) || {}).naziv || "–") + ")").join(", ") : "kritične kontrolne točke niso določene",
    skupina: ekipa.length ? ekipa.map(x => "- " + x).join("\n") : "- ____"
  } };
}

// PDF celotne dokumentacije (12 poglavij)
const PGL_DEF = [["uvod", "Namen in obseg sistema HACCP"], ["podjetje", "Podatki o podjetju in obratu"], ["skupina", "HACCP skupina in odgovornosti"], ["dejavnost", "Dejavnost in obseg"], ["zivila", "Opis živil"], ["diagram", "Diagram poteka"], ["metodologija", "Metodologija ocene tveganja"], ["nevarnosti", "Analiza nevarnosti"], ["ukrepi", "Kontrolni ukrepi (PRP, OPRP, CCP)"], ["ccp", "Kritične kontrolne točke – nadzorni list"], ["prp", "Predpogojni programi"], ["navodila", "Delovna navodila"], ["evidence", "Evidence in obrazci"], ["verifikacija", "Verifikacija in validacija"], ["potrditev", "Potrditev in zgodovina različic"], ["priloga", "Priloga: pravna podlaga"]];
// vrstni red, vključenost in lastna poglavja (shranjeno v načrtu: W.poglavja)
function poglavjaCfg(W) {
  const sv = Array.isArray(W.poglavja) ? W.poglavja : [], out = sv.filter(c => c.custom || PGL_DEF.some(d => d[0] === c.id)).map(c => Object.assign({ on: true }, c));
  // manjkajoče privzeto poglavje (npr. novo v novejši različici) se vstavi za predhodno poglavje iz privzetega vrstnega reda
  PGL_DEF.forEach(([id, naslov], i) => { if (out.some(c => c.id === id)) return; const pred = i ? out.findIndex(c => c.id === PGL_DEF[i - 1][0]) : -1; out.splice(pred + 1, 0, { id, naslov, on: true }); });
  return out;
}
function buildHaccpPdf(rec, W, stranka, obrati, navodila, db, warn, fmt, ex) {
  const ob = obrati.find(o => o.id === rec.obrat_id), M = W.metoda, korak = id => (W.koraki.find(k => k.id === id) || {}).naziv || "–", oz = ccpOznake(W);
  const kRed = id => { const i = W.koraki.findIndex(k => k.id === id); return i < 0 ? 1e6 : i; };
  const BP = besedilaPodatki(W, stranka, ob, db);
  // besedilo poglavja: prilagojeno v čarovniku (korak 7) ali iz baze besedil
  const T = (d, id) => { const pr = (W.besedila_pogl || {})[id], t = pr !== undefined && pr !== null ? pr : besedilaTekst(db, id, BP.oznake, BP.vr); for (const b of besedilaBloki(t)) { if (b.h) d.h(2, b.h); else if (b.ul) d.bullets(b.ul); else d.p(b.p); } };
  // izbira navodil (vsaka tema enkrat), številke poglavij za sklice, predpisi za prilogo, preverjanje pred izpisom
  const NV = izberiNavodila(navodila), NAV = NV.izbrana.slice().sort((a, b) => String(a.naslov || "").localeCompare(String(b.naslov || ""), "sl"));
  const cfg0 = poglavjaCfg(W).filter(c => c.on), PN = {}; { let n = 0; for (const c of cfg0) if (c.id !== "priloga") PN[c.id] = ((ex && ex.predpona) || "") + (++n); }
  const tekst = id => { const pr = (W.besedila_pogl || {})[id]; return pr !== undefined && pr !== null ? pr : besedilaTekst(db, id, BP.oznake, BP.vr); };
  const vseBesedilo = [W.koraki.map(k => k.naziv).join(" "), W.zivila.map(z => [z.naziv, z.priprava, z.sestava].join(" ")).join(" "), NAV.map(n => n.naslov + " " + n.vsebina).join(" "), Object.values(W.kontrole).map(c => [c.kaj, c.mejna, c.ukrep].join(" ")).join(" ")].join(" ");
  const cvre = /cvr|friter|ocvr/i.test(vseBesedilo);
  const tags = new Set(["*", W.branza, ...BP.oznake]); if (cvre) tags.add("acryl");
  const zakVsi = (db.zakonodaja || []).filter(z => z.status !== "razveljavljen");
  const izNavodil = new Set(NAV.flatMap(n => (((db.navodila_predloge || []).find(p => p.id === n.predloga) || {}).zakoni || []).map(q => q.predpis)));
  const predpisi = zakVsi.filter(z => (z.oznake || []).some(o => tags.has(o)) || izNavodil.has(z.predpis) || (cvre && /2017\/2158/.test(z.predpis)));
  const PR = typeof preveriNacrt === "function" ? preveriNacrt({ rec, W, stranka, ob, navodila: NAV, db, oz, besedila: Object.fromEntries(cfg0.filter(c => !c.custom && c.id !== "priloga").map(c => [c.id, tekst(c.id)])), poglavja: PN, predpisi }) : [];
  const porocilo = [...(warn || []).map(t => ({ tip: "odprto", txt: t })), ...PR, ...NV.porocilo.filter(x => x.tip !== "info")];
  const odprto = porocilo.some(x => x.tip === "odprto");
  const stat = potrditevNacrta(rec, W).opravljena && !odprto ? "potrjeno" : "OSNUTEK – potrebna strokovna potrditev";
  const POPIS = { ok: "da", ne: "ne" }, V = a => a === "d" ? "Da" : a === "n" ? "Ne" : "–";

  const CHS = {
    uvod: (d, H) => { d.h(1, H); T(d, "uvod"); },
    skupina: (d, H) => {
      d.h(1, H); T(d, "skupina");
      const Z = W.zbiranje, ku = [["Zaveza vodstva", Z.kultura_zaveza], ["Sporočanje težav", Z.kultura_sporocanje], ["Usposabljanje", Z.kultura_usposabljanje], ["Pregled", Z.kultura_pregled]].filter(r => r[1]);
      d.h(2, "Kultura varnosti hrane"); if (ku.length) d.table(["Področje", "Opis"], ku, [28, 72]); else d.p("[MANJKA – kultura varnosti hrane (Uredba (EU) 2021/382)]");
    },
    // predpogojni programi: iz vsakega programa 1–2 stavka in sklic na navodilo (protokol je izpisan samo v poglavju navodil)
    prp: (d, H) => {
      d.h(1, H); T(d, "prp");
      if (NAV.length) d.bullets(NAV.map(n => n.naslov + ": " + (namenNavodila(n, db) || "") + (PN.navodila ? ` Postopek: poglavje ${PN.navodila}.` : "")));
      if (!(W.besedila_pogl && W.besedila_pogl.prp != null)) { if (alergeniPotrjeni(W)) T(d, "alergeni"); else d.box("Matrika alergenov še ni popolna: alergeni niso potrjeni pri vseh živilih.", "w"); }
    },
    podjetje: (d, H) => {
      d.h(1, H); T(d, "podjetje");
      d.table(["Podatek", "Vrednost"], [["Naziv", stranka.naziv], ["Naslov", stranka.naslov || ""], ["Matična / davčna št.", [stranka.maticna, stranka.davcna].filter(Boolean).join(" / ")], ["Odgovorna oseba", stranka.odgovorna_oseba || ""], ["Obrat", ob ? ob.naziv + (ob.naslov ? ", " + ob.naslov : "") : ""], ["Registracija obrata", W.zbiranje.registracija || ""], ["Šifra dejavnosti (SKD 2025)", W.zbiranje.skd || ""], ["Površina", ob && ob.povrsina ? fnum(ob.povrsina) + " m²" : ""], ["Število zaposlenih", W.zbiranje.zaposleni || ""]].filter(r => r[1] !== ""), [30, 70]);
      if (ex && ex.tloris) { d.p("Tloris obrata", { bold: true }); d.img(ex.tloris, 470, 330, "Tloris obrata"); }
    },
    // dejavnost: samo opis dejavnosti, časovna organizacija, prostori, oprema, kupci in način prodaje (brez obsega, faz in protokolov)
    dejavnost: (d, H) => {
      d.h(1, H); T(d, "dejavnost");
      const rows = [["Dejavnost", BP.vr.dejavnost], ["Opis dejavnosti", stranka.opis_dejavnosti || ""], ["Časovna organizacija", W.zbiranje.delovni_cas || ""], ["Prostori", seznamObrata(ob && ob.prostori, ob && ob.opis_prostorov)], ["Naprave in pribor", seznamObrata(ob && ob.naprave, ob && ob.oprema_opis)], ["Kupci in ciljne skupine", W.zbiranje.kupci || ""], ["Način prodaje", [(W.zbiranje.nacin_prodaje || []).join(", "), W.zbiranje.prodaja].filter(Boolean).join(" – ")]].filter(r => r[1]);
      if (rows.length) d.table(["Podatek", "Opis"], rows, [28, 72]);
    },
    // opis živil: ločen stolpec »Odprto« (opombe niso alergeni), sestava, priprava, pakiranje, rok, stanje potrditve
    zivila: (d, H) => {
      d.h(1, H); T(d, "zivila");
      const alg = z => String(z.alergeni || "").replace(/\s*\((?:preveriti|preveri|odprto)[^)]*\)/ig, "").trim(), odp = z => [/(preveriti|\?)/i.test(z.alergeni || "") || z.alergeni_potrjeni !== true || !z.alergeni ? "alergeni nepotrjeni" : "", z.odprto || ""].filter(Boolean).join(", ");
      d.table(["Živilo", "Sestava", "Priprava / pakiranje", "Shranjevanje / rok", "RTE", "Ciljna skupina", "Alergeni", "Odprto"], W.zivila.map(z => [z.naziv, z.sestava || z.skupina || "", [z.priprava, z.pakiranje].filter(Boolean).join("; "), [z.shranjevanje, z.rok].filter(Boolean).join("; "), z.rte ? "da" : "ne", z.ciljna || "", alg(z) || "–", odp(z)]), [14, 16, 15, 14, 5, 11, 14, 11]);
    },
    diagram: (d, H) => {
      d.h(1, H);
      // stavek o preverjanju diagrama na kraju samem samo ob vpisanem datumu preverjanja
      const t = tekst("diagram"), brez = W.zbiranje.diagram_preverjen ? t : String(t || "").split(/\n/).filter(l => !/na kraju samem|preverjen\w* na lokaciji/i.test(l)).join("\n");
      for (const bl of besedilaBloki(brez)) { if (bl.h) d.h(2, bl.h); else if (bl.ul) d.bullets(bl.ul); else d.p(bl.p); }
      if (W.zbiranje.diagram_preverjen) d.p("Diagram poteka je bil preverjen na kraju samem dne " + fdate(W.zbiranje.diagram_preverjen) + ".");
      const el = (k, i) => { const c = ccpNaKoraku(W, k.id); return { n: i + 1, t: k.naziv, ccp: !!c.length, tag: c.join(", ") }; }, Ks = W.koraki.map((k, i) => [k, i]);
      if (!Ks.some(([k]) => k.veja)) d.flow(Ks.map(([k, i]) => el(k, i)));
      else {
        const prvi = Ks.findIndex(([k]) => k.veja), zadnji = Ks.length - 1 - [...Ks].reverse().findIndex(([k]) => k.veja), veje = [...new Set(Ks.filter(([k]) => k.veja).map(([k]) => k.veja))];
        if (prvi > 0) { d.p("Skupni začetek", { bold: true }); d.flow(Ks.slice(0, prvi).map(([k, i]) => el(k, i))); }
        for (const v of veje) { d.p("Linija: " + v, { bold: true }); d.flow(Ks.filter(([k]) => k.veja === v).map(([k, i]) => el(k, i))); }
        const kon = Ks.slice(zadnji + 1).filter(([k]) => !k.veja); if (kon.length) { d.p("Skupni konec", { bold: true }); d.flow(kon.map(([k, i]) => el(k, i))); }
      }
    },
    metodologija: (d, H) => {
      d.h(1, H); T(d, "metodologija");
      d.p(`Tveganje = verjetnost × teža posledic (obe na lestvici 1–5). Razredi: nizko (≤ ${M.nizko_do}), srednje (≤ ${M.srednje_do}), visoko (nad ${M.srednje_do}). Pomembne nevarnosti so v razredu srednje in visoko.`); d.p("Verjetnost: " + M.verjetnost.join("; ")); d.p("Teža posledic: " + M.teza.join("; "));
      d.p("Razvrstitev kontrolnih ukrepov (PRP, OPRP, CCP) je izvedla odgovorna oseba z uporabo odločitvenega drevesa Codex Alimentarius kot pripomočka. Mejne vrednosti so navedene z virom; vrednosti brez vira so navedene v poročilu pred izpisom.");
    },
    // analiza nevarnosti: ločena stolpca »Dodatni ukrepi« in »Odgovoren«
    nevarnosti: (d, H) => {
      d.h(1, H); T(d, "nevarnosti");
      const ur = W.nevarnosti.map((h, i) => [h, i]).sort((a, b) => kRed(a[0].korak_id) - kRed(b[0].korak_id) || a[1] - b[1]).map(x => x[0]);
      d.table(["Korak", "Vrsta", "Nevarnost / vir", "Obstoječi ukrepi", "V×T", "Razred", "Dodatni ukrepi", "Odgovoren"], ur.map(h => [korak(h.korak_id), HTIPI[h.tip] || h.tip, h.nevarnost + (h.vir ? " (vir: " + h.vir + ")" : ""), h.obstojec || "", rizik(h) ? (h.verjetnost + "×" + h.teza + "=" + rizik(h)) : "?", rizik(h) ? rizikRazred(rizik(h), M) : "neocenjeno", (h.dodatni || "") + (hazStatus(h) !== "potrjeno" ? " (" + HSTAT[hazStatus(h)][1] + ")" : ""), h.odgovoren || ""]), [12, 8, 22, 15, 7, 8, 18, 10]);
      const oc = W.nevarnosti.filter(h => rizik(h)); if (oc.length && !oc.some(h => rizik(h) <= M.nizko_do)) d.box("Opozorilo: nobena nevarnost ni ocenjena kot nizka – preverite oceno tveganja.", "w");
    },
    // razvrstitev ukrepov: faza, nevarnost, odgovori V1–V4, razvrstitev, utemeljitev (brez krajšanja besedila)
    ukrepi: (d, H) => {
      d.h(1, H); T(d, "ukrepi");
      const vr = W.nevarnosti.filter(h => W.kontrole[h.id]).sort((a, b) => kRed(a.korak_id) - kRed(b.korak_id));
      d.table(["Faza", "Nevarnost", "V1", "V2", "V3", "V4", "Razvrstitev", "Utemeljitev"], vr.map(h => { const c = W.kontrole[h.id], a = c.drevo || []; return [korak(h.korak_id), h.nevarnost || "", V(a[0]), V(a[1]), V(a[2]), V(a[3]), c.vrsta === "nobeno" ? "ni potreben" : oz[h.id] || c.vrsta, [c.utemeljitev, c.ukrep].filter(Boolean).join(" – ")]; }), [14, 22, 5, 5, 5, 5, 10, 34]);
    },
    // CCP in OPRP: naslov iz enoličnega naziva (OPRP6), vir meje, ločeno temperatura in čas
    ccp: (d, H) => {
      d.h(1, H); T(d, "ccp");
      const ccps = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" || c.vrsta === "OPRP");
      if (!ccps.length) d.p("Kritične kontrolne točke ali OPRP niso določene.");
      ccps.sort((a, b) => String(oz[a.hid] || "").localeCompare(String(oz[b.hid] || ""), "sl", { numeric: true })).forEach(c => {
        const h = W.nevarnosti.find(x => x.id === c.hid) || {};
        d.h(2, (oz[c.hid] || c.vrsta) + (c.naziv ? " – " + c.naziv : ""));
        d.table(["Postavka", "Vsebina"], [["Faza", korak(h.korak_id)], ["Nevarnost", h.nevarnost], ["Kaj se nadzoruje", c.kaj], ["Mejna vrednost / merilo", c.mejna || "[MANJKA – mejna vrednost]"], ["Temperatura", c.temperatura], ["Čas", c.cas], ["Temperatura olja", c.temp_olja], ["Vir meje", c.mejna_vir_vrsta ? c.mejna_vir_vrsta + (c.mejna_vir ? ": " + c.mejna_vir : "") : c.mejna_vir || "[MANJKA – vir meje]"], ["Spremljanje", c.spremljanje], ["Pogostost", c.pogostost], ["Odgovorna oseba", c.odgovoren], ["Korektivni ukrepi", c.korektivni], ["Evidenca", c.evidenca ? ((EV[c.evidenca] || {}).ime || c.evidenca) + (c.evidenca_naziv ? ": " + c.evidenca_naziv : "") : "[MANJKA – evidenca]"]].filter(r => r[1]), [28, 72]);
      });
    },
    // navodila: naslov poglavja enkrat, podjetje in različica enkrat v uvodu, vsak protokol (tema) enkrat, brez OPOMBE in pravne podlage
    navodila: (d, H) => {
      d.h(1, H); T(d, "navodila");
      if (!NAV.length) { d.p("Navodila še niso dodana."); return; }
      d.p(`Navodila veljajo za ${stranka.naziv}${ob ? ", " + ob.naziv : ""}. Pravna podlaga navodil je v prilogi.`);
      const vers = new Set(NAV.map(n => (n.verzija_oznaka || "") + "|" + (n.status || "")));
      if (vers.size > 1) d.table(["Navodilo", "Različica", "Stanje"], NAV.map(n => [n.naslov, n.verzija_oznaka || "", n.status || ""]), [60, 15, 25]);
      else d.p(`Vsa navodila: različica ${[...vers][0].split("|")[0] || "1.0"}, stanje ${[...vers][0].split("|")[1] || "osnutek"}.`, { size: 9 });
      NAV.forEach(n => {
        d.h(2, n.naslov); let al = []; const izpisi = () => { if (al.length) { d.bullets(al); al = []; } };
        for (const l of cistiNavodilo(n).vrstice) { if (/^\s*[-•] /.test(l)) { al.push(l.replace(/^\s*[-•] /, "")); continue; } izpisi(); if (/^\d+\.\s+[A-ZČŠŽĆĐ ]{3,}$/.test(l.trim())) d.p(l.trim(), { bold: true, size: 9.5 }); else if (l.trim()) d.p(l, { size: 9, gap: 1 }); }
        izpisi();
      });
    },
    // evidence: vsak CCP in OPRP ima evidenco; »Drugo« z nazivom
    evidence: (d, H) => {
      d.h(1, H); T(d, "evidence");
      const k = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" || c.vrsta === "OPRP").sort((a, b) => String(oz[a.hid] || "").localeCompare(String(oz[b.hid] || ""), "sl", { numeric: true }));
      if (k.length) d.table(["CCP / OPRP", "Faza", "Evidenca"], k.map(c => [oz[c.hid] || c.vrsta, korak((W.nevarnosti.find(x => x.id === c.hid) || {}).korak_id), c.evidenca ? (c.evidenca === "drugo" ? (c.evidenca_naziv || "[MANJKA – naziv evidence]") : (EV[c.evidenca] || {}).ime || c.evidenca) : "[MANJKA – evidenca]"]), [20, 30, 50]);
    },
    // verifikacija in validacija za vsak CCP in OPRP
    verifikacija: (d, H) => {
      d.h(1, H); T(d, "verifikacija");
      const k = Object.values(W.kontrole).filter(c => c.vrsta === "CCP" || c.vrsta === "OPRP").sort((a, b) => String(oz[a.hid] || "").localeCompare(String(oz[b.hid] || ""), "sl", { numeric: true }));
      if (k.length) d.table(["CCP / OPRP", "Plan verifikacije", "Validacija (zapis)"], k.map(c => [oz[c.hid] || c.vrsta, c.verifikacija || "[MANJKA – plan verifikacije]", c.validacija || "[MANJKA – zapis validacije]"]), [16, 42, 42]);
      if (W.pregled.interni_rok) d.p(`Interni rok naslednjega pregleda načrta: ${fdate(W.pregled.interni_rok)}${W.pregled.interni_rok_utemeljitev ? " – " + W.pregled.interni_rok_utemeljitev : ""}.`);
      if (W.pregled.komentar) d.p(W.pregled.komentar); if (W.besedila.opombe) d.p(W.besedila.opombe);
    },
    potrditev: (d, H) => {
      d.h(1, H); T(d, "potrditev");
      const po = potrditevNacrta(rec, W);
      // osnutek ne prikaže potrditve kot opravljene: le »Predvideni strokovni pregled«
      d.table(["Podatek", "Vrednost"], (po.opravljena ? [["Stanje načrta", stat], ["Strokovno potrdil", po.potrdil], ["Datum potrditve", fdate(po.datum)]]
        : [["Stanje načrta", stat], ["Predvideni strokovni pregled", [po.potrdil, po.datum ? "predviden datum " + fdate(po.datum) : ""].filter(Boolean).join(", ") || "ni določen"]]).concat([["Različica dokumenta", rec.verzija_oznaka || "1.0"], ["Interna revizija", "rev. " + (rec.verzija || 1)]]), [30, 70]);
      const zg = zgodovinaNacrta(rec);
      if (zg.length) { d.h(2, "Zgodovina sprememb"); d.table(["Rev.", "Kdaj", "Kdo", "Sprememba"], zg.slice(-15).map(r => [r.n, fdt(r.cas), r.ime, r.razlog || (r.prej && "status" in r.prej ? "sprememba stanja: " + (r.prej.status || "") + " → " : "")]), [8, 22, 22, 48]); }
    },
    // priloga: predpisi po tipu obrata in navodilih, datum zadnjega preverjanja; Uredba (EU) 2017/2158, kadar obrat cvre
    priloga: (d, H) => {
      d.h(1, H);
      d.p("Seznam predpisov iz baze znanja z datumom zadnjega preverjanja (izbor po dejavnosti obrata in navodilih). Pred uporabo preverite aktualno veljavnost v uradnih virih (EUR-Lex, PISRS).", { size: 9 });
      const skrajsaj = t => { t = String(t || ""); if (t.length <= 160) return t; const k = t.slice(0, 160); return k.slice(0, Math.max(k.lastIndexOf(" "), 120)) + " …"; };
      d.table(["Predpis", "Vsebina", "Preverjeno"], predpisi.slice(0, 80).map(z => [z.predpis, skrajsaj(z.vsebina), z.preverjeno ? fdate(z.preverjeno) : "ni preverjeno"]), [38, 50, 12]);
      if (predpisi.length > 80) d.p(`Navedenih je 80 od ${predpisi.length} predpisov; celoten seznam je v bazi znanja (Zakonodaja).`, { col: "m" });
    },
  };
  const cfg = poglavjaCfg(W).filter(c => c.on), pre = (ex && ex.predpona) || ""; // predpona številk poglavij, ko je načrt priloga drugega dokumenta
  const fill = d => {
    if (W.besedila.uvod) d.p(W.besedila.uvod);
    if (porocilo.length) { d.box(odprto ? `Preverjanje pred izpisom: dokument ostane OSNUTEK, dokler so odprta vprašanja (${porocilo.filter(x => x.tip === "odprto").length}).` : "Preverjanje pred izpisom: ni odprtih vprašanj; spodaj so strokovna opozorila.", odprto ? "r" : "w"); d.bullets(porocilo.map(x => (x.tip === "odprto" ? "Odprto: " : "Opozorilo: ") + x.txt)); }
    let n = 0;
    for (const c of cfg) {
      const pr = c.id === "priloga"; if (!pr) n++;
      const H = (pr ? (pre ? pre + " " : "") : pre + n + ". ") + c.naslov;
      if (c.custom) { d.h(1, H); String(c.besedilo || "").split("\n").forEach(l => { if (l.trim()) d.p(l); else d.gap(4); }); }
      else CHS[c.id](d, H);
    }
  };
  if (fmt === "fill") return fill; // samo vsebina (npr. priloga paketa za inšpekcijo)
  return (fmt === "docx" ? docxBuild : pdfBuild)({ naslov: "HACCP načrt: " + rec.naziv, podnaslov: ob ? ob.naziv : "", stranka: stranka.naziv, verzija: rec.verzija_oznaka || "1.0", avtor: ME.u.ime, stanje: stat, tocNivo: 1 }, fill);
}
route(/^\/carovnik\/([\w-]+)$/, pageCarovnik, "Čarovnik HACCP", "stranke");
