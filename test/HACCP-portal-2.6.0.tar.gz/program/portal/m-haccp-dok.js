// HACCP dokument: izbira navodil po ključu teme, čiščenje besedila navodil in preverjanje pred izpisom.
// Pravila: vsak protokol (ključ teme) se izpiše samo enkrat, prilagojen protokol ima prednost pred splošno predlogo;
// besedilo za izpolnjevalca ni končno besedilo; dokler je kaj odprto, ostane dokument v stanju OSNUTEK.

// ključ teme navodila: ključ predloge iz knjižnice (npr. ciscenje, voda, hlajenje) ali ročno izbran ključ;
// pri lastnem navodilu brez ključa se tema prepozna iz naslova
const TEME_NASLOV = [[/osebn\w* higien|zdravstven\w* stanj/i, "osebna_higiena"], [/čiščen|razkuž/i, "ciscenje"], [/prevzem/i, "prevzem"], [/skladišč/i, "skladiscenje"], [/temperatur|hladiln|zamrzoval|vroč\w* verig/i, "temperature"], [/navzkrižn/i, "navzkrizno"], [/alergen/i, "alergeni"], [/odpad/i, "odpadki"], [/škodljiv|\bddd\b|deratiz/i, "ddd"], [/\bvod[aei]\b|pitn/i, "voda"], [/vzdrževan/i, "vzdrzevanje"], [/merilni|umerjan|kalibr/i, "merilni_instrumenti"], [/sledljiv/i, "sledljivost"], [/odpoklic|umik/i, "odpoklic"], [/reklamac/i, "reklamacije"], [/usposablj/i, "usposabljanje"], [/notranj\w* kontrol|interni pregled/i, "notranja_kontrola"], [/pregled\w* dokumentac/i, "pregled_dokumentacije"], [/hlajenj/i, "hlajenje"], [/bris|hitri test|vzorčen/i, "vzorcenje"], [/čistil|kemikal/i, "kemikalije"], [/cvrt|friter|olj\w* za cvrt/i, "cvrtje"]];
// ključi tem za izbiro v obrazcu navodila (lastno navodilo z istim ključem nadomesti predlogo)
const TEME_KLJUCI = [["osebna_higiena", "Osebna higiena"], ["ciscenje", "Čiščenje in razkuževanje"], ["prevzem", "Prevzem blaga"], ["skladiscenje", "Skladiščenje"], ["temperature", "Temperature"], ["navzkrizno", "Navzkrižna kontaminacija"], ["alergeni", "Alergeni"], ["odpadki", "Odpadki"], ["ddd", "Škodljivci (DDD)"], ["voda", "Pitna voda"], ["vzdrzevanje", "Vzdrževanje"], ["merilni_instrumenti", "Merilni instrumenti"], ["sledljivost", "Sledljivost"], ["odpoklic", "Umik in odpoklic"], ["reklamacije", "Reklamacije"], ["usposabljanje", "Usposabljanje"], ["notranja_kontrola", "Notranja kontrola"], ["pregled_dokumentacije", "Pregled dokumentacije"], ["hlajenje", "Hlajenje"], ["vzorcenje", "Brisi in hitri testi"], ["kemikalije", "Čistila in razkužila"], ["cvrtje", "Cvrtje in olje"]];
function temaNavodila(n) {
  if (n.tema) return n.tema;
  if (n.predloga) return n.predloga;
  const t = TEME_NASLOV.find(([re]) => re.test(n.naslov || ""));
  return t ? t[1] : "lastno:" + String(n.naslov || n.id || "").trim().toLowerCase();
}
// prilagojen protokol: lastno navodilo, potrjeno navodilo ali navodilo z urejeno vsebino (ni le nespremenjena kopija predloge)
const navPrilagojeno = n => !n.predloga || n.status === "potrjeno" || (n.revizije || []).some(r => r.prej && "vsebina" in r.prej);
function izberiNavodila(navodila) {
  const skupine = new Map(), porocilo = [];
  for (const n of navodila || []) { if (n.status === "zastarelo") continue; const k = temaNavodila(n); if (!skupine.has(k)) skupine.set(k, []); skupine.get(k).push(n); }
  const ocena = n => (n.status === "potrjeno" ? 4 : 0) + (navPrilagojeno(n) ? 2 : 0);
  const izbrana = [];
  for (const [k, l] of skupine) {
    const ur = l.slice().sort((a, b) => ocena(b) - ocena(a) || String(b.spremenjeno || b.ustvarjeno || "").localeCompare(String(a.spremenjeno || a.ustvarjeno || "")));
    izbrana.push(Object.assign({}, ur[0], { _tema: k }));
    const prilagojena = ur.filter(navPrilagojeno);
    if (prilagojena.length > 1) porocilo.push({ tip: "odprto", txt: `Tema »${k}«: več prilagojenih navodil (${prilagojena.map(n => "»" + n.naslov + "«").join(", ")}) – izpisano je »${ur[0].naslov}«; razlike razrešite in odvečna navodila označite kot zastarela.` });
    else if (ur.length > 1) porocilo.push({ tip: "info", txt: `Tema »${k}«: splošna predloga ni izpisana, ker obstaja »${ur[0].naslov}«.` });
  }
  return { izbrana, porocilo };
}
// besedilo za izpolnjevalca (navodilo za uporabnika predloge), ki se ne sme izpisati kot končno besedilo
const IZPOLNJEVALEC = /\bugotovite vir\b|nastavite v sistemu|\bDOLOČITI\b|\bdoločite\b|\bvpišite\b|\bdopolnite\b|_{3,}|\[MANJKA\]|\bTODO\b/i;
// čisto besedilo navodila za dokument: brez naslova, podjetja, različice predloge, pravne podlage in OPOMBE (to so podatki, ne vsebina)
function cistiNavodilo(n) {
  const out = [], odprto = []; let pravna = false;
  const L = String(n.vsebina || "").split("\n");
  L.forEach((l, i) => {
    const t = l.trim();
    if (i === 0 && t === String(n.naslov || "").trim()) return;
    if (/^(Podjetje|Različica predloge)\s*:/i.test(t)) return;
    if (/^\d+\.\s*PRAVNA/i.test(t) || /^pravna (in strokovna )?podlaga/i.test(t)) { pravna = true; return; }
    if (pravna) { if (!t) { pravna = false; return; } if (/^\d+\.\s+[A-ZČŠŽ ]{4,}$/.test(t)) pravna = false; else return; }
    if (/^OPOMBA\s*:/i.test(t)) return;
    l = l.replace(/\s*\(KT\s?\d+\)|\bKT\s?\d+\s*[:–-]\s*/g, ""); // interne oznake kontrolnih točk (KT) se ne izpišejo
    if (t && IZPOLNJEVALEC.test(t)) { odprto.push(t.slice(0, 120)); out.push((/^\d+\.\s/.test(t) ? t.match(/^\d+\.\s/)[0] : "") + "[MANJKA – dopolnite po dejanskem stanju v obratu]"); return; }
    out.push(l);
  });
  while (out.length && !out[out.length - 1].trim()) out.pop();
  return { vrstice: out, odprto };
}
// prvi stavek namena navodila (za poglavje Predpogojni programi)
function namenNavodila(n, db) {
  const p = (db.navodila_predloge || []).find(x => x.id === n.predloga), L = String(n.vsebina || "").split("\n"), i = L.findIndex(l => /^\s*1\.\s*NAMEN/i.test(l));
  const t = (i >= 0 ? L.slice(i + 1).find(l => l.trim()) : "") || (p && p.namen) || "";
  const s = String(t).trim().replace(/\s+/g, " "), m = /^(.{20,220}?[.!?])(\s|$)/.exec(s);
  return m ? m[1] : s.slice(0, 200);
}

// preverjanje pred izpisom: seznam odprtih vprašanj (dokument ostane OSNUTEK) in strokovnih opozoril (brez samodejnih zaključkov)
// x: { rec, W, stranka, ob, navodila (izbrana), db, oz (oznake CCP/OPRP), besedila (izpisana besedila poglavij), poglavja (id → številka) }
function preveriNacrt(x) {
  const { rec, W, navodila, db, oz } = x, out = [], odp = t => out.push({ tip: "odprto", txt: t }), opo = t => out.push({ tip: "opozorilo", txt: t });
  const korak = id => (W.koraki.find(k => k.id === id) || {}).naziv || "–", ozn = h => oz[h.id] || (W.kontrole[h.id] || {}).vrsta || "";
  // potrditev
  const po = potrditevNacrta(rec, W);
  if (po.prihodnost) odp(`Datum potrditve (${fdate(po.datum)}) je v prihodnosti – potrditev ni opravljena.`);
  if (rec.status === "potrjeno" && !po.potrdil) odp("Načrt je označen kot potrjen, potrjevalec ni vpisan.");
  // alergeni
  const nepAlg = W.zivila.filter(z => !z.alergeni || /preverit|\?|neznan/i.test(z.alergeni) || z.alergeni_potrjeni !== true); // potrditev v čarovniku (Podrobnosti živila)
  if (nepAlg.length) odp("Nepotrjeni alergeni pri živilih: " + nepAlg.map(z => z.naziv).filter(Boolean).join(", ") + ".");
  // nevarnosti in ukrepi
  const brezVrste = W.nevarnosti.filter(h => hazStatus(h) === "potrjeno" && !(W.kontrole[h.id] || {}).vrsta);
  if (brezVrste.length) odp(`${brezVrste.length} potrjenih nevarnosti nima vrste ukrepa (npr. ${korak(brezVrste[0].korak_id)}: ${brezVrste[0].nevarnost}).`);
  const kont = W.nevarnosti.filter(h => ["CCP", "OPRP"].includes((W.kontrole[h.id] || {}).vrsta)).map(h => [h, W.kontrole[h.id]]);
  for (const [h, c] of kont) {
    const n = ozn(h);
    if (!c.mejna) odp(`${n} (${korak(h.korak_id)}): mejna vrednost ni določena.`);
    else if (!c.mejna_vir) odp(`${n} (${korak(h.korak_id)}): meja »${c.mejna}« nima utemeljitve (vir meje).`);
    if (!c.evidenca) odp(`${n} (${korak(h.korak_id)}): ni povezane evidence.`);
    if (!c.verifikacija) odp(`${n} (${korak(h.korak_id)}): ni plana verifikacije.`);
    if (c.mejna) {
      if (/[>≥]\s*-?\d+([.,]\d+)?\s*(°C)?\s*do\s/i.test(c.mejna)) odp(`${n}: neveljaven zapis meje »${c.mejna}« (npr. »>4 do 6 °C«) – navedite en razpon ali eno mejo.`);
      if (/>\s*-\s*\d/.test(c.mejna)) odp(`${n}: zapis »${c.mejna}« pomeni topleje od meje (npr. »>-18 °C«); za zamrzovanje uporabite »≤ -18 °C«.`);
      if (/\d+\s*do\s*\d+\s*(ur|h\b|min|dni)/i.test(c.mejna)) odp(`${n}: razpon »${c.mejna}« ni enolična meja – določite eno vrednost.`);
      if (/olj|cvr|friter/i.test(korak(h.korak_id) + " " + c.kaj + " " + h.nevarnost)) { const t = (/(\d{3})\s*°C/.exec(c.mejna) || [])[1]; if (t && +t > 175) odp(`${n}: temperatura olja ${t} °C presega priporočenih 175 °C (Uredba (EU) 2017/2158, akrilamid).`); }
    }
  }
  const oprp = kont.filter(([, c]) => c.vrsta === "OPRP").length; if (oprp > 8) opo(`Določenih je ${oprp} OPRP (več kot 8) – preverite, ali so vsi res potrebni.`);
  const ocenjene = W.nevarnosti.filter(h => rizik(h)); if (ocenjene.length && !ocenjene.some(h => rizik(h) <= W.metoda.nizko_do)) opo("Nobena nevarnost ni ocenjena kot nizka – preverite oceno tveganja.");
  // protislovja: hlajenje
  const hl = kont.filter(([h, c]) => /hlaj/i.test(korak(h.korak_id) + " " + (c.kaj || ""))).map(([, c]) => c.mejna).filter(Boolean);
  if (new Set(hl.map(m => (/(\d+(?:[.,]\d+)?)\s*(ur|h\b|min)/i.exec(m) || [])[0]).filter(Boolean)).size > 1) odp("Protislovje: različni časi hlajenja (" + hl.join("; ") + ").");
  // navodila: besedilo za izpolnjevalca, predpisi
  for (const n of navodila) {
    const c = cistiNavodilo(n); if (c.odprto.length) odp(`Navodilo »${n.naslov}«: nedokončano besedilo (${c.odprto.slice(0, 2).map(t => "»" + t.slice(0, 50) + "«").join(", ")}${c.odprto.length > 2 ? " …" : ""}).`);
    const w = typeof navodiloOpozorila === "function" ? navodiloOpozorila(n, db) : []; if (w.length) odp(`Navodilo »${n.naslov}«: ${w.join("; ")}.`);
  }
  // besedila poglavij: oznake [MANJKA] in besedilo za izpolnjevalca
  for (const [id, t] of Object.entries(x.besedila || {})) { const m = String(t || "").split("\n").filter(l => IZPOLNJEVALEC.test(l)); if (m.length) odp(`Poglavje ${(x.poglavja || {})[id] || id}: manjkajoči podatki (${m.slice(0, 2).map(l => "»" + l.trim().slice(0, 50) + "«").join(", ")}).`); }
  // sklici na poglavja: samo obstoječa
  const vsa = Object.values(x.poglavja || {}).map(Number), maks = Math.max(0, ...vsa);
  for (const [id, t] of Object.entries(x.besedila || {})) for (const m of String(t || "").matchAll(/poglavj\w*\s+(\d+)/gi)) if (+m[1] > maks || !vsa.includes(+m[1])) odp(`Neveljaven sklic »${m[0]}« v poglavju ${(x.poglavja || {})[id] || id}.`);
  // predpisi za preverjanje (datum zadnjega preverjanja starejši od 12 mesecev)
  const star = (x.predpisi || []).filter(z => !z.preverjeno || daysTo(String(z.preverjeno).slice(0, 10)) < -365); if (star.length) opo(`${star.length} predpisov v prilogi ni bilo preverjenih zadnjih 12 mesecev (npr. ${star[0].predpis}).`);
  const Z = W.zbiranje || {};
  if (!(Z.kultura_zaveza || Z.kultura_sporocanje || Z.kultura_usposabljanje || Z.kultura_pregled)) odp("Kultura varnosti hrane ni opisana (zaveza vodstva, sporočanje težav, usposabljanje, pregled).");
  // vloge iz navodil (odgovornosti) morajo biti določene v HACCP skupini
  const vloge = new Set((Z.clani || []).map(c => String(c.vloga || "").toLowerCase()).filter(Boolean)), ZNANE = ["vodja kuhinje", "vodja izmene", "vodja haccp", "odgovorna oseba", "vodja lokala", "vodja obrata"];
  if ((Z.clani || []).length) { const v = new Set(); for (const n of navodila) for (const z of ZNANE) if (String(n.vsebina || "").toLowerCase().includes(z) && ![...vloge].some(x => x.includes(z.split(" ")[0]) && x.includes(z.split(" ").pop()))) v.add(z); if (v.size) odp("Vloge iz navodil niso določene v HACCP skupini: " + [...v].join(", ") + "."); }
  else if (!Z.hacc_ekipa) odp("HACCP skupina ni določena (člani in vloge).");
  // način prodaje in koraki
  const kor = W.koraki.map(k => k.naziv).join(" ").toLowerCase(), np = Z.nacin_prodaje || [];
  if (np.includes("dostava") && !/dostav|transport|prevoz/.test(kor)) odp("Izbrana je dostava, v procesu pa ni koraka dostave ali transporta.");
  if (np.includes("s_seboj") && !/pakir|embal|s seboj/.test(kor)) odp("Izbrana je prodaja za s seboj, v procesu pa ni koraka pakiranja.");
  // živila iz procesa (sladoled, pijače, led) morajo biti v opisu živil
  const ziv = W.zivila.map(z => (z.naziv || "") + " " + (z.skupina || "")).join(" ").toLowerCase();
  [[/sladoled/, "sladoled"], [/pijač|točiln/, "pijače"], [/led|ledomat|kocke ledu/, "led"]].forEach(([re, ime]) => { if (re.test(kor) && !re.test(ziv) && !(ime === "pijače" && /pijač|kav|sok|vod/.test(ziv))) odp(`V procesu je ${ime}, v opisu živil (poglavje 5) pa ga ni.`); });
  // odločitveno drevo in razvrstitev
  for (const h of W.nevarnosti) { const c = W.kontrole[h.id]; if (!c || !c.drevo) continue; const p = drevoPredlog(c.drevo); if (p === "CCP" && c.vrsta !== "CCP") odp(`${korak(h.korak_id)}: drevo odločanja predlaga CCP, razvrstitev je ${c.vrsta || "ni določena"} – utemeljite ali uskladite.`); if (p === "ni CCP" && c.vrsta === "CCP") odp(`${ozn(h)} (${korak(h.korak_id)}): drevo odločanja ne predlaga CCP – utemeljite razvrstitev.`); }
  // vrednosti v navodilih in mejne vrednosti v poglavju CCP/OPRP (en vir vrednosti)
  for (const [h, c] of kont) { const kl = (korak(h.korak_id) + " " + (c.kaj || "")).toLowerCase(), tema = /hlaj/.test(kl) ? "hlajenje" : /cvr|olj/.test(kl) ? "cvrtje" : ""; if (!tema) continue;
    const n = navodila.find(x => temaNavodila(x) === tema); if (!n || !c.mejna) continue;
    const st = t => [...String(t).matchAll(/(\d+(?:[.,]\d+)?)\s*(°C|ur|h\b|min)/gi)].map(m => m[1].replace(",", ".") + m[2].toLowerCase()), mj = st(c.mejna), nv = st(n.vsebina);
    const razl = nv.filter(v => mj.length && !mj.includes(v) && mj.some(m => m.replace(/[\d.]/g, "") === v.replace(/[\d.]/g, "")));
    if (razl.length) odp(`Navodilo »${n.naslov}« navaja ${[...new Set(razl)].join(", ")}, ${ozn(h)} pa »${c.mejna}« – vrednosti uskladite (generator ne izbira med njimi).`); }
  // strokovna opozorila (brez samodejnih zaključkov)
  const vse = [W.zivila.map(z => [z.naziv, z.sestava, z.priprava].join(" ")).join(" "), W.koraki.map(k => k.naziv).join(" "), W.nevarnosti.map(h => h.nevarnost + " " + (h.obstojec || "")).join(" "), navodila.map(n => n.vsebina).join(" ")].join(" ").toLowerCase();
  [[/surov\w* jajc|tiramis|majonez\w* doma/, "Surova jajca: preverite uporabo pasteriziranih jajc ali ustrezno toplotno obdelavo."], [/rosbif|rare|nizk\w* temperatur\w* (pečen|kuhan)|sous.?vide/, "Meso pri nižji temperaturi (rosbif, sous-vide): potrebna je validacija časa in temperature."], [/tun[ae]?\b|skuš|sardel|inčun|histamin/, "Ribe z možnim histaminom (tuna, skuša, sardele): nadzor hladne verige in dobavitelja."], [/skupn\w* olj|isto olje|cvrtj/, "Cvrtje: preverite navzkrižni prenos alergenov v skupnem olju."], [/sp\w*ranj\w* surov\w* mes|umivanj\w* mes|pran\w* (piščan|perutnin|mes)/, "Spiranje surovega mesa ni priporočeno (razpršitev mikroorganizmov)."], [/mikroval\w*.{0,20}odtaj|odtaj\w*.{0,20}mikroval/, "Odtajanje v mikrovalovni pečici: živilo takoj toplotno obdelajte."]].forEach(([re, t]) => { if (re.test(vse)) opo(t); });
  return out;
}
// najdaljša poglavja dokumenta (iz statistike pdfBuild): opozorilo, če ima dokument več kot meja strani
function dolzinaDokumenta(st, meja) {
  if (!st || st.strani <= (meja || 50)) return "";
  const p = st.poglavja.map((e, i) => ({ s: e.s, n: (i + 1 < st.poglavja.length ? st.poglavja[i + 1].stran : st.strani + 1) - e.stran })).sort((a, b) => b.n - a.n).slice(0, 3);
  return `Dokument ima ${st.strani} strani (cilj približno 45–50). Največ dolžine: ${p.map(x => `${x.s} (${x.n} str.)`).join(", ")}.`;
}
// predlog odločitvenega drevesa (V1–V4): »CCP«, »ni CCP« ali "" (ni dovolj odgovorov)
function drevoPredlog(a) { a = a || []; if (a[0] === "n") return ""; if (a[1] === "d") return "CCP"; if (a[1] === "n" && a[2] === "n") return "ni CCP"; if (a[2] === "d" && a[3] === "d") return "ni CCP"; if (a[2] === "d" && a[3] === "n") return "CCP"; return ""; }
// ali vsi alergeni živil potrjeni (stavek o popolni matriki alergenov se izpiše samo takrat)
const alergeniPotrjeni = W => W.zivila.length > 0 && W.zivila.every(z => z.alergeni && !/preverit|\?|neznan/i.test(z.alergeni) && z.alergeni_potrjeni === true);
