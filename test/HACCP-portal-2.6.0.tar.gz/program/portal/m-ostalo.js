// Koledar, storitve (pregled), uporabniki, administracija.
let calState = { y: new Date().getFullYear(), m: new Date().getMonth() };
async function pageKoledar(v) {
  const flt = JSON.parse(sessionStorage.getItem("cflt") || "{}");
  const d = await loadAll(flt.sid ? { stranka_id: flt.sid } : null);
  const all = collectDeadlines(d);
  const types = [...new Set(all.map(x => x.tip))].sort();
  const dl = all.filter(x => !flt.tip || x.tip === flt.tip);
  const { y, m } = calState, first = new Date(y, m, 1), startDow = (first.getDay() + 6) % 7, nd = new Date(y, m + 1, 0).getDate();
  const MES = ["januar", "februar", "marec", "april", "maj", "junij", "julij", "avgust", "september", "oktober", "november", "december"];
  const cells = [];
  for (let i = 0; i < startDow; i++) cells.push(null);
  for (let dd = 1; dd <= nd; dd++) cells.push(`${y}-${pad(m + 1)}-${pad(dd)}`);
  const sm = mapOf(d.stranke);
  v.innerHTML = `<div class="row"><button class="btn ghost sec sm" id="cp">‹</button><b style="min-width:150px;text-align:center">${MES[m]} ${y}</b><button class="btn ghost sec sm" id="cn">›</button><button class="btn ghost sec sm" id="ct">Danes</button><span class="sp"></span>
   ${isStaff() ? `<select id="cs" style="max-width:220px"><option value="">Vse stranke</option>${(d.vseStranke || d.stranke).map(s => `<option value="${s.id}" ${flt.sid === s.id ? "selected" : ""}>${esc(sIme(s))}</option>`).join("")}</select>` : ""}
   <select id="ctip" style="max-width:200px"><option value="">Vse vrste</option>${types.map(t => `<option ${flt.tip === t ? "selected" : ""}>${esc(t)}</option>`).join("")}</select>
   ${isStaff() || ME.u.vloga === "odgovorna" ? '<button class="btn" id="cadd">+ Dogodek</button>' : ""}</div>
   <div class="cal">${["pon", "tor", "sre", "čet", "pet", "sob", "ned"].map(x => `<div class="h">${x}</div>`).join("")}${cells.map(c => c ? `<div class="d ${c === today() ? "today" : ""}"><b>${+c.slice(8)}</b>${dl.filter(x => x.datum === c).map((x, i) => `<a class="ev${i >= 4 ? " vec" : ""} ${daysTo(x.datum) < 0 ? "bad" : ""}" href="${x.href}" title="${esc(x.naslov + (x.stranka ? " – " + x.stranka : ""))}">${esc(x.naslov)}</a>`).join("")}${dl.filter(x => x.datum === c).length > 4 ? `<button class="cal-vec" type="button" aria-label="Prikaži vse dogodke dneva">+${dl.filter(x => x.datum === c).length - 4}</button>` : ""}</div>` : '<div class="d o"></div>').join("")}</div>
   <h2 style="margin-top:20px">Roki v zamudi in v naslednjih 30 dneh</h2><div class="tw"><table class="t"><tr><th>Rok</th><th>Vrsta</th><th>Kaj</th>${isStaff() ? "<th>Stranka</th>" : ""}</tr>${dl.filter(x => daysTo(x.datum) <= 30).map(x => `<tr class="click" onclick="location.hash='${x.href.slice(1)}'"><td>${dueBadge(x.datum)}</td><td>${esc(x.tip)}</td><td>${esc(x.naslov)}</td>${isStaff() ? `<td>${esc(x.stranka)}</td>` : ""}</tr>`).join("") || '<tr><td colspan="4" class="empty">Ni rokov.</td></tr>'}</table></div>
   <div class="row" style="margin-top:12px"><button class="btn ghost sec" id="cics">Izvozi v koledar (.ics)</button><span class="mut">Datoteko .ics uvozite v Google Koledar, Outlook ali telefon.</span></div>`;
  $("#cp").onclick = () => { calState = m ? { y, m: m - 1 } : { y: y - 1, m: 11 }; pageKoledar(v); };
  $("#cn").onclick = () => { calState = m < 11 ? { y, m: m + 1 } : { y: y + 1, m: 0 }; pageKoledar(v); };
  $("#ct").onclick = () => { calState = { y: new Date().getFullYear(), m: new Date().getMonth() }; pageKoledar(v); };
  const sv = () => { sessionStorage.setItem("cflt", JSON.stringify({ sid: $("#cs") ? $("#cs").value : "", tip: $("#ctip").value })); pageKoledar(v); };
  if ($("#cs")) $("#cs").onchange = sv; $("#ctip").onchange = sv;
  // na telefonu je celica preozka za vse dogodke: odpri seznam dneva v oknu, na širšem zaslonu razširi celico
  v.querySelectorAll(".cal-vec").forEach(b => b.onclick = () => {
    const d = b.closest(".d");
    if (matchMedia("(max-width:600px)").matches) return modal("Dogodki " + d.querySelector("b").textContent + ". dne", `<ul class="cal-sez">${$$(".ev", d).map(a => `<li><a href="${esc(a.getAttribute("href"))}">${esc(a.getAttribute("title") || a.textContent)}</a></li>`).join("")}</ul>`);
    d.classList.add("vse"); b.remove();
  });
  if ($("#cadd")) $("#cadd").onclick = () => {
    const pick = isStaff() ? `<label class="f req"><span>Stranka</span><select id="ps">${(d.vseStranke || d.stranke).map(s => `<option value="${s.id}">${esc(sIme(s))}</option>`).join("")}</select></label>` : "";
    const sid = isStaff() ? null : d.stranke[0] && d.stranke[0].id;
    if (!isStaff() && !sid) return toast("Ni stranke.", true);
    if (isStaff() && !(d.vseStranke || d.stranke).length) return toast("Najprej dodajte stranko (Stranke → + Dodaj).", true);
    if (isStaff()) modal("Dogodek za stranko", pick, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Naprej", fn: () => { const s = $("#ps").value; setTimeout(() => openForm("dogodki", null, { stranka_id: s, obrati: {} }, () => pageKoledar(v)), 50); } }]);
    else openForm("dogodki", null, { stranka_id: sid, obrati: {} }, () => pageKoledar(v));
  };
  $("#cics").onclick = () => {
    const L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//HiGiFood//HACCP//SL", "CALSCALE:GREGORIAN"];
    dl.forEach((x, i) => { const dt = x.datum.replace(/-/g, ""); L.push("BEGIN:VEVENT", `UID:${i}-${dt}@higifood`, `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").slice(0, 15)}Z`, `DTSTART;VALUE=DATE:${dt}`, `SUMMARY:${(x.naslov + (x.stranka ? " – " + x.stranka : "")).replace(/[,;\n]/g, " ")}`, "END:VEVENT"); });
    L.push("END:VCALENDAR");
    dlBlob(new Blob([L.join("\r\n")], { type: "text/calendar" }), "higifood-roki.ics");
  };
}

async function pageStoritve(v) {
  const d = await loadAll(); try { await paketi(); } catch {} // ime paketa namesto oznake
  const rows = d.stranke.map(s => {
    const st = d.storitve.filter(x => x.stranka_id === s.id).sort((a, b) => b.datum.localeCompare(a.datum));
    const last = st[0], min = st.reduce((a, r) => a + (Number(r.minute) || 0), 0), nxt = st.map(x => x.naslednji_pregled).filter(Boolean).sort().pop() || s.naslednji_pregled;
    return { s, n: st.length, last, min, nxt, miss: missingData(d, s) };
  });
  v.innerHTML = `<p class="note info">Pregled opravljenih storitev po strankah. Posamezne storitve vnesete v profilu stranke: levi podmeni, skupina »Pregledi in dokumenti« → »Storitve« (klik na stranko v tabeli odpre ta razdelek).</p><div class="tw"><table class="t"><tr><th>Stranka</th><th>Storitev</th><th>Zadnja</th><th>Čas</th><th>Paket</th><th>Dokumentacija</th><th>Naslednji pregled</th><th>Manjka</th></tr>${rows.map(r => `<tr class="click" onclick="location.hash='#/stranka/${r.s.id}/storitve'"><td><b>${esc(sIme(r.s))}</b></td><td>${r.n}</td><td>${r.last ? fdate(r.last.datum) + " – " + esc(r.last.vrsta || "") : "–"}</td><td>${(r.min / 60).toFixed(1)} h</td><td>${esc(imePaketaStranke(r.s.paket))}</td><td>${esc(r.last ? r.last.stanje_dokumentacije || "" : "")}</td><td>${dueBadge(r.nxt)}</td><td>${(r.miss.length ? `<details class="manjka" data-brez-odpiranja onclick="event.stopPropagation()"><summary title="${esc(r.miss.join(", "))}"><span class="badge warn">${r.miss.length}</span></summary><ul>${r.miss.map(m => `<li>${esc(m)}</li>`).join("")}</ul><a href="#/stranka/${r.s.id}/podatki">Dopolni profil</a></details>` : '<span class="badge ok">0</span>')}</td></tr>`).join("") || '<tr><td colspan="8" class="empty">Ni strank.</td></tr>'}</table></div>
  <div class="row" style="margin-top:12px"><button class="btn ghost sec" id="sx">Izvozi povzetek (Excel)</button></div>`;
  $("#sx").onclick = () => downloadXlsx("storitve-povzetek.xlsx", [{ ime: "Storitve", glava: ["Stranka", "Št. storitev", "Zadnja storitev", "Skupaj minut", "Paket", "Naslednji pregled", "Manjkajoči podatki"], vrste: rows.map(r => [r.s.naziv, r.n, r.last ? r.last.datum : "", r.min, imePaketaStranke(r.s.paket), r.nxt || "", r.miss.join("; ")]) }]);
}

async function pageUporabniki(v) {
  const us = await api("GET", "/api/uporabniki"), st = await D.list("stranke"), sm = mapOf(st);
  v.innerHTML = `<div class="row"><span class="sp"></span><button class="btn" id="un">+ Nov uporabnik</button></div><div class="tw"><table class="t kartice" id="ut"><thead><tr><th>Ime</th><th>E-naslov</th><th>Vloga</th><th>Stranka / dodeljene stranke</th><th>Stanje</th><th>2FA</th><th>Zadnja prijava</th></tr></thead><tbody>${us.map(u => `<tr class="click" data-id="${u.id}"><td data-l="Ime"><b>${esc(u.ime)}</b></td><td data-l="E-naslov" class="em">${esc(u.email)}</td><td data-l="Vloga">${esc(ROLE[u.vloga])}</td><td data-l="Stranke">${u.vloga === "svetovalec" ? esc(u.stranke.map(i => sm[i] || "?").join(", ") || "–") : esc(sm[u.stranka_id] || "–")}</td><td data-l="Stanje">${u.aktiven ? (u.povabljen ? '<span class="badge warn">povabljen</span>' : '<span class="badge ok">aktiven</span>') : '<span class="badge bad">onemogočen</span>'}</td><td data-l="2FA">${u.totp ? '<span class="badge ok">da</span>' : '<span class="mut">ne</span>'}</td><td data-l="Zadnja prijava">${fdt(u.zadnja_prijava)}</td></tr>`).join("")}</tbody></table></div>`;
  const form = (u) => {
    const isNew = !u;
    modal(isNew ? "Nov uporabnik" : "Uredi uporabnika", `<p class="err" id="ferr"></p><div class="fgrid"><label class="f req"><span>Ime in priimek</span><input id="u_i" value="${esc(u ? u.ime : "")}"></label><label class="f req"><span>E-naslov</span><input id="u_e" type="email" value="${esc(u ? u.email : "")}" ${u ? "disabled" : ""}></label>
    <label class="f"><span>Vloga</span><select id="u_v" ${u ? "disabled" : ""}>${Object.keys(ROLE).filter(r => u || ME.u.vloga === "admin" || ["odgovorna", "zaposleni"].includes(r)).map(r => `<option value="${r}" ${u && u.vloga === r ? "selected" : ""}>${ROLE[r]}</option>`).join("")}</select></label>
    <label class="f" id="u_s_w"><span>Stranka (za odgovorno osebo / zaposlenega)</span><select id="u_s"><option value=""></option>${st.map(s => `<option value="${s.id}" ${u && u.stranka_id === s.id ? "selected" : ""}>${esc(sIme(s))}</option>`).join("")}</select></label>
    <div class="f wide" id="u_ss_w"><span>Dodeljene stranke – svetovalec vidi samo te (<b id="u_ss_n">0</b>)</span>
      <div class="row" style="margin:4px 0"><input id="u_ss_q" placeholder="Išči stranko …" aria-label="Išči stranko" style="max-width:260px"><button type="button" class="btn sm ghost sec" id="u_ss_vse">Izberi prikazane</button><button type="button" class="btn sm ghost sec" id="u_ss_nic">Počisti</button></div>
      <div class="u-st-seznam">${st.slice().sort((a, b) => String(a.naziv).localeCompare(b.naziv, "sl")).map(s => `<label class="u-st"><input type="checkbox" value="${s.id}" ${u && (u.stranke || []).includes(s.id) ? "checked" : ""}> ${esc(sIme(s))}</label>`).join("") || '<span class="mut">Ni strank.</span>'}</div></div>
    ${u ? "" : '<label class="f wide" style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="u_pov" style="width:auto;min-height:0"> Pošlji povabilo po e-pošti – uporabnik si geslo nastavi sam (potrebna nastavljena e-pošta)</label>'}
    <label class="f ${u ? "" : "req"}" id="u_p_w"><span>${u ? "Novo začasno geslo (prazno = brez spremembe)" : "Začasno geslo (vsaj 10 znakov)"}</span><input id="u_p" autocomplete="off"></label>${u ? `<div class="f wide"><button type="button" class="btn sm ghost sec" id="u_inv">${u.povabljen ? "Pošlji povabilo znova" : "Pošlji povezavo za nastavitev gesla po e-pošti"}</button></div>` : ""}${u ? `<label class="f"><span>Aktiven</span><input type="checkbox" id="u_a" ${u.aktiven ? "checked" : ""}></label>` : ""}${u && u.totp && ME.u.vloga === "admin" ? `<label class="f wide"><span><input type="checkbox" id="u_2f"> Izklopi dvostopenjsko prijavo (uporabnik je izgubil telefon in rezervne kode)</span></label>` : ""}</div>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Shrani", fn: async () => {
      // napake ob poljih (kot pri drugih obrazcih), preden gre zahteva na strežnik
      $$(".f.bad", $("#dlg")).forEach(l => { l.classList.remove("bad"); $$(".f-err", l).forEach(x => x.remove()); $$("[aria-invalid]", l).forEach(x => x.removeAttribute("aria-invalid")); }); $("#ferr").textContent = "";
      const nap = [], vl = $("#u_v").value, pov = !u && $("#u_pov") && $("#u_pov").checked;
      if (!$("#u_i").value.trim()) nap.push(["u_i", "Vpišite ime in priimek."]);
      if (!u && (!$("#u_e").value.trim() || PRAVILA.preveri("uporabniki", { email: $("#u_e").value }).length)) nap.push(["u_e", "Vpišite veljaven e-naslov (npr. ana.novak@podjetje.si)."]);
      if (!u && ["odgovorna", "zaposleni"].includes(vl) && !$("#u_s").value) nap.push(["u_s", "Izberite stranko."]);
      if (((!u && !pov) || $("#u_p").value) && $("#u_p").value.length < 10) nap.push(["u_p", "Geslo mora imeti vsaj 10 znakov."]);
      for (const [id, m] of nap) oznaciPolje($("#" + id), m);
      if (nap.length) { $("#" + nap[0][0]).focus(); return false; }
      try {
        const sel = $$(".u-st input").filter(c => c.checked).map(c => c.value);
        if (u) { const b = { ime: $("#u_i").value, aktiven: $("#u_a").checked, stranke: sel, stranka_id: $("#u_s").value }; if ($("#u_p").value) b.geslo = $("#u_p").value; if ($("#u_2f") && $("#u_2f").checked) b.izklopi_2fa = true; await api("PUT", "/api/uporabniki/" + u.id, b); }
        else {
          const pov = $("#u_pov") && $("#u_pov").checked;
          const r = await api("POST", "/api/uporabniki", Object.assign({ ime: $("#u_i").value, email: $("#u_e").value, vloga: $("#u_v").value, stranka_id: ["odgovorna", "zaposleni"].includes($("#u_v").value) ? $("#u_s").value || null : null, stranke: sel }, pov ? { povabilo: true } : { geslo: $("#u_p").value }));
          if (r.povabilo_napaka) { toast("Uporabnik je dodan, povabila pa ni bilo mogoče poslati: " + r.povabilo_napaka, true); pageUporabniki(v); return; }
          if (pov) { toast("Povabilo poslano na " + r.email); pageUporabniki(v); return; }
        }
        toast("Shranjeno"); pageUporabniki(v);
      } catch (e) { $("#ferr").textContent = e.message; return false; }
    } }]);
    if (u && ME.u.vloga === "admin" && u.id !== ME.u.id) {
      const b = document.createElement("button"); b.className = "btn danger"; b.id = "u_del"; b.textContent = "Izbriši uporabnika"; $("#dlg-f").prepend(b);
      b.onclick = () => confirmBox(`Izbrišem uporabnika ${u.ime} (${u.email})? Dostop se takoj odvzame, uporabnik gre v Koš (obnovljiv 30 dni). Zapisi, ki jih je vnesel, ostanejo z njegovim imenom. Za začasno onemogočenje namesto izbrisa odkljukajte »Aktiven«.`, async () => { await api("DELETE", "/api/uporabniki/" + u.id); toast("Uporabnik izbrisan (v Košu)"); pageUporabniki(v); }, true);
    }
    form.vloga(); form.stej(); $("#u_v").onchange = form.vloga;
    if ($("#u_pov")) $("#u_pov").onchange = () => { $("#u_p_w").hidden = $("#u_pov").checked; };
    if ($("#u_inv")) $("#u_inv").onclick = async () => { try { await api("POST", "/api/uporabniki/" + u.id + "?povabilo=1", {}); toast("Poslano na " + u.email); } catch (e) { $("#ferr").textContent = e.message; } };
    $$(".u-st input").forEach(c => c.onchange = form.stej);
    $("#u_ss_q").oninput = () => { const q = $("#u_ss_q").value.trim().toLowerCase(); $$(".u-st").forEach(l => l.hidden = !!q && !l.textContent.toLowerCase().includes(q)); };
    $("#u_ss_vse").onclick = () => { $$(".u-st").filter(l => !l.hidden).forEach(l => l.querySelector("input").checked = true); form.stej(); };
    $("#u_ss_nic").onclick = () => { $$(".u-st input").forEach(c => c.checked = false); form.stej(); };
  };
  $("#un").onclick = () => form(null);
  // v obrazcu prikaži samo polja, ki veljajo za izbrano vlogo; iskanje in štetje dodeljenih strank
  form.vloga = () => { const vl = $("#u_v").value; $("#u_ss_w").hidden = vl !== "svetovalec"; $("#u_s_w").hidden = !["odgovorna", "zaposleni"].includes(vl); };
  form.stej = () => { $("#u_ss_n").textContent = $$(".u-st input").filter(c => c.checked).length; };
  $$("tr[data-id]", v).forEach(tr => tr.onclick = () => form(us.find(u => u.id === tr.dataset.id)));
}

// Kopija izven strežnika: šifrirana dnevna kopija v shrambo S3 (Backblaze B2, Cloudflare R2, AWS S3, Wasabi)
async function oblakCard(v) {
  const n = await api("GET", "/api/kopija/oblak").catch(() => null); if (!n || !v.isConnected) return;
  const PON = { b2: ["Backblaze B2", "https://s3.eu-central-003.backblazeb2.com", "eu-central-003"], r2: ["Cloudflare R2", "https://<ID-računa>.r2.cloudflarestorage.com", "auto"], aws: ["Amazon S3", "https://s3.eu-central-1.amazonaws.com", "eu-central-1"], wasabi: ["Wasabi", "https://s3.eu-central-1.wasabisys.com", "eu-central-1"], drugo: ["Drugo (združljivo s S3)", "https://…", ""] };
  const st = n.stanje || {};
  const stanje = () => st.cas ? (st.ok ? `<span class="badge ok">Zadnja kopija v oblak: ${fdt(st.cas)}</span> <span class="mut">${esc(st.datoteka || "")}${st.velikost ? ", " + Math.round(st.velikost / 1024) + " kB" : ""}</span>` : `<span class="badge bad">Zadnja kopija v oblak ni uspela: ${esc(st.napaka || "")}</span>`) : '<span class="mut">Še ni bilo kopije v oblak.</span>';
  v.insertAdjacentHTML("beforeend", `<div class="card" id="obl-card" style="margin-top:16px"><h2>Kopija v oblak (izven strežnika)</h2>
    <p class="mut">Vsak dan se šifrirana kopija naloži v vašo shrambo v oblaku; hrani se zadnjih 30 dni. Če strežnik odpove, podatke obnovite iz te kopije (prenesite datoteko .hfbk in uporabite »Obnovi iz kopije«). Kopije so šifrirane z geslom za šifriranje kopij${n.sifrirano ? "" : ' – <b>geslo še ni nastavljeno</b> (polje zgoraj pri »Kopija na drugo mesto«)'}; geslo shranite na varno, brez njega kopije ni mogoče obnoviti.</p>
    <div class="fgrid">
      <label class="f"><span>Ponudnik</span><select id="ob_p">${Object.entries(PON).map(([k, x]) => `<option value="${k}">${x[0]}</option>`).join("")}</select></label>
      <label class="f"><span>Končna točka (Endpoint)</span><input id="ob_e" value="${esc(n.endpoint)}"></label>
      <label class="f"><span>Regija</span><input id="ob_r" value="${esc(n.regija)}"></label>
      <label class="f"><span>Vedro (Bucket)</span><input id="ob_v" value="${esc(n.vedro)}" placeholder="npr. higifood-kopije"></label>
      <label class="f"><span>Ključ (Access Key ID)</span><input id="ob_k" value="${esc(n.kljuc_id)}" autocomplete="off"></label>
      <label class="f"><span>Skrivni ključ (Secret Access Key)</span><input type="password" id="ob_s" value="${esc(n.skrivnost)}" autocomplete="new-password"></label>
      <label class="f"><span>Mapa v vedru (neobvezno)</span><input id="ob_m" value="${esc(n.predpona)}" placeholder="npr. higifood"></label></div>
    <p id="ob_st">${stanje()}</p>
    <div class="row"><button class="btn ghost sec" id="ob_t">Preizkusi povezavo</button><button class="btn" id="ob_sh">Shrani</button><button class="btn ghost sec" id="ob_z" ${n.vedro ? "" : "disabled"}>Kopija v oblak zdaj</button><button class="btn ghost sec" id="ob_x" ${n.vedro ? "" : "hidden"}>Izklopi</button></div></div>`);
  const pod = () => ({ endpoint: $("#ob_e").value, regija: $("#ob_r").value, vedro: $("#ob_v").value, kljuc_id: $("#ob_k").value, skrivnost: $("#ob_s").value, predpona: $("#ob_m").value });
  $("#ob_p").onchange = () => { const x = PON[$("#ob_p").value]; $("#ob_e").placeholder = x[1]; $("#ob_r").placeholder = x[2]; if (!$("#ob_e").value || /backblaze|r2\.cloudflare|amazonaws|wasabi/.test($("#ob_e").value)) { $("#ob_e").value = x[1].includes("<") || x[1].endsWith("…") ? "" : x[1]; $("#ob_r").value = x[2]; } };
  { const e = n.endpoint; $("#ob_p").value = /backblaze/.test(e) ? "b2" : /r2\.cloudflare/.test(e) ? "r2" : /amazonaws/.test(e) ? "aws" : /wasabi/.test(e) ? "wasabi" : e ? "drugo" : "b2"; if (!e) $("#ob_p").onchange(); }
  $("#ob_t").onclick = async () => { try { await api("POST", "/api/kopija/oblak/preizkus", pod()); toast("Povezava deluje: zapis, branje in brisanje uspešni"); } catch (e) { fail(e); } };
  $("#ob_sh").onclick = async () => { try { await api("PUT", "/api/kopija/oblak", pod()); toast("Shranjeno"); pageAdmin(v); } catch (e) { fail(e); } };
  $("#ob_z").onclick = async () => { $("#ob_st").innerHTML = '<span class="mut">Nalagam …</span>'; try { const r = await api("POST", "/api/kopija/oblak/zdaj", {}); toast("Kopija naložena: " + r.datoteka); pageAdmin(v); } catch (e) { fail(e); pageAdmin(v); } };
  $("#ob_x").onclick = () => confirmBox("Izklopim kopijo v oblak? (Že naložene kopije ostanejo v vaši shrambi.)", async () => { try { await api("PUT", "/api/kopija/oblak", { endpoint: "", vedro: "", kljuc_id: "", skrivnost: "", predpona: "" }); toast("Izklopljeno"); pageAdmin(v); } catch (e) { fail(e); } });
}
// Varnost prijave: obvezna dvostopenjska prijava po vlogah
async function varnostCard(v) {
  const n = await api("GET", "/api/varnost").catch(() => null); if (!n || !v.isConnected) return;
  const VL = [["admin", "Administrator"], ["svetovalec", "HACCP-svetovalec"], ["odgovorna", "Odgovorna oseba stranke"], ["zaposleni", "Zaposleni stranke"]];
  v.insertAdjacentHTML("beforeend", `<div class="card" id="var-card" style="margin-top:16px"><h2>Varnost prijave</h2><p class="mut">Za izbrane vloge je dvostopenjska prijava (koda iz aplikacije na telefonu) obvezna. Uporabnik brez nje po prijavi najprej vidi samo navodila za nastavitev. Priporočeno: administrator in svetovalec.</p>
    ${VL.map(([k, l]) => `<label style="display:flex;gap:8px;align-items:center;margin:4px 0"><input type="checkbox" data-o2="${k}" style="width:auto;min-height:0" ${n.obvezna_2fa.includes(k) ? "checked" : ""}> ${l} <span class="mut">(${n.brez_2fa[k] || 0} brez dvostopenjske prijave)</span></label>`).join("")}
    <div class="row" style="margin-top:8px"><button class="btn" id="var_s">Shrani</button>${["admin", "svetovalec"].every(k => n.obvezna_2fa.includes(k)) ? "" : '<button class="btn ghost" id="var_p">Vklopi priporočeno (administrator in svetovalec)</button>'}</div></div>`);
  const vp = $("#var_p"); if (vp) vp.onclick = () => { ["admin", "svetovalec"].forEach(k => { $(`[data-o2="${k}"]`).checked = true; }); $("#var_s").click(); };
  $("#var_s").onclick = async () => { try { const izb = $$("[data-o2]").filter(c => c.checked).map(c => c.dataset.o2); await api("PUT", "/api/varnost", { obvezna_2fa: izb }); toast("Shranjeno"); if (izb.includes(ME.u.vloga) && !ME.u.totp) setTimeout(() => location.reload(), 800); } catch (e) { fail(e); } };
}
// zavihki Administracije: kartice se razvrstijo po naslovu (tudi tiste, ki se naložijo pozneje)
const ADM_ZAV = [["kopije", "Varnostne kopije", ["Varnostne kopije", "Kopija na drugo mesto", "Kopija v oblak (izven strežnika)", "Arhiv evidenc"]], ["varnost", "Varnost", ["Varnost prijave", "Revizijska sled"]], ["obvestila", "E-pošta", ["E-poštna obvestila"]],
  ["dokumenti", "Dokumenti", ["Tiskanje dokumentacije", "Logotip v dokumentih"]], ["podatki", "Podatki in baza", ["Seznam podjetij (FURS)", "Baza znanja in orodja"]], ["program", "Program", ["Program", "Dostop iz omrežja (testiranje)"]]];
function admZavihki(v, zac) {
  zac = zac || (/^#\/admin\/(\w+)/.exec(location.hash) || [])[1]; // ponovni izris ostane na istem zavihku
  let zav = ADM_ZAV.some(z => z[0] === zac) ? zac : "kopije";
  v.insertAdjacentHTML("afterbegin", `<nav class="steps adm-zav" aria-label="Razdelki administracije">${ADM_ZAV.map(([id, ime]) => `<button data-zav="${id}" class="${id === zav ? "on" : ""}">${ime}</button>`).join("")}</nav>`);
  const skupina = c => { const h = (c.querySelector("h2") || {}).textContent || ""; const z = ADM_ZAV.find(x => x[2].some(n => h.startsWith(n))); return z ? z[0] : "program"; };
  const oznaci = () => { $$(".card", v).filter(c => c.parentElement === v || c.parentElement.parentElement === v).forEach(c => { if (!c.dataset.sk) c.dataset.sk = skupina(c); c.hidden = c.dataset.sk !== zav; }); };
  $$(".adm-zav button", v).forEach(b => b.onclick = () => { zav = b.dataset.zav; $$(".adm-zav button", v).forEach(x => x.classList.toggle("on", x === b)); oznaci(); history.replaceState(null, "", "#/admin/" + zav); });
  oznaci(); new MutationObserver(oznaci).observe(v, { childList: true, subtree: true });
}
async function pageAdmin(v, m) {
  const [audit, upd, ns, kn] = await Promise.all([api("GET", "/api/revizijska-sled?n=100"), api("GET", "/api/posodobitve").catch(() => []), api("GET", "/api/nastavitve"), api("GET", "/api/kopija/nastavitve")]);
  if (!v.isConnected) return; // uporabnik je medtem odprl drugo stran
  v.innerHTML = `<div class="grid g2">
  <div class="card"><h2>Varnostne kopije</h2><p class="mut">Kopija vsebuje bazo znanja, vse podatke strank, priloge in uporabnike. Samodejna kopija se naredi vsak dan (zadnjih 30 se hrani v mapi <code>podatki/_kopije</code>). Kopijo hranite na varnem mestu: vsebuje osebne podatke.</p>
   <div class="row"><a class="btn" href="/api/kopija" download>Prenesi kopijo (.zip)</a><button class="btn ghost" id="kenc">Prenesi šifrirano kopijo (.hfbk)</button><label class="btn ghost sec" style="display:inline-block">Obnovi iz kopije<input type="file" id="rf" accept=".zip,.hfbk" hidden></label></div><p class="mut">Pred obnovo se samodejno naredi kopija trenutnega stanja.</p></div>
  <div class="card"><h2>Kopija na drugo mesto</h2><p class="mut">Dnevna kopija se poleg mape <code>podatki/_kopije</code> prepiše še v mapo, ki jo določite (npr. USB-ključ, zunanji disk ali sinhronizirana mapa Dropbox/OneDrive). Hrani se zadnjih 30.</p>
   <div class="row"><input id="k_m" value="${esc(kn.mapa)}" placeholder="npr. D:\\Kopije\\HACCP ali /Volumes/USB/HACCP" style="max-width:420px"><button class="btn" id="k_s">Shrani in naredi kopijo</button><button class="btn ghost sec" id="k_z">Kopija zdaj</button></div>
   <div class="row"><label class="f" style="margin:0;min-width:300px"><span>Geslo za šifriranje kopij na drugem mestu (neobvezno, vsaj 8 znakov)</span><input type="password" id="k_g" value="${kn.sifrirano ? "********" : ""}" autocomplete="new-password"></label><span class="mut">Geslo je shranjeno na strežniku (varuje kopijo na USB/oblaku, ne pa strežnika samega). Brez njega kopije ne morete obnoviti; zapišite ga.</span></div>
   <p id="k_st" class="mut">${kn.stanje && kn.stanje.cas ? (kn.stanje.ok ? `<span class="badge ok">Zadnja kopija na drugo mesto: ${fdt(kn.stanje.cas)}</span> ${esc(kn.stanje.mapa)}` : `<span class="badge bad">Zadnja kopija ni uspela: ${esc(kn.stanje.napaka)}</span>`) : "Ni nastavljeno."}</p></div>
  <div class="card"><h2>E-poštna obvestila</h2><p class="mut">Neobvezno. Če vnesete SMTP strežnik, sistem enkrat dnevno pošlje opomnike o rokih (pregledi, poteki izobraževanj in opreme, odprti CAPA, dogodki iz koledarja) odgovornim osebam strank in svetovalcem. Geslo se hrani samo na strežniku. Brez SMTP-ja ostanejo opozorila na nadzorni plošči.</p>
   <div class="fgrid"><label class="f"><span>Način pošiljanja</span><select id="n_n"><option value="smtp" ${!ns.nacin || ns.nacin === "smtp" ? "selected" : ""}>SMTP (strežnik in vrata)</option><option value="resend" ${ns.nacin === "resend" ? "selected" : ""}>Resend – HTTPS API</option><option value="brevo" ${ns.nacin === "brevo" ? "selected" : ""}>Brevo – HTTPS API</option></select><small class="mut">HTTPS API deluje tudi, ko ponudnik strežnika zapre odhodna vrata SMTP (465, 587).</small></label><label class="f n-api"><span>Ključ API</span><input id="n_k" type="password" value="${esc(ns.api_kljuc || "")}" autocomplete="new-password"></label></div>
   <div class="fgrid n-smtp"><label class="f"><span>SMTP strežnik</span><input id="n_s" value="${esc(ns.streznik || "")}"></label><label class="f"><span>Vrata</span><input id="n_v" type="number" value="${esc(ns.vrata || "")}" placeholder="587"></label><label class="f"><span>Varnost</span><select id="n_z"><option value="starttls" ${ns.varnost === "starttls" ? "selected" : ""}>STARTTLS (587)</option><option value="ssl" ${ns.varnost === "ssl" ? "selected" : ""}>SSL/TLS (465)</option><option value="brez" ${ns.varnost === "brez" ? "selected" : ""}>brez (samo notranje omrežje)</option></select></label><label class="f"><span>Uporabniško ime</span><input id="n_u" value="${esc(ns.uporabnik || "")}" autocomplete="off"></label><label class="f"><span>Geslo</span><input id="n_p" type="password" value="${esc(ns.geslo || "")}" autocomplete="new-password"></label></div><div class="fgrid"><label class="f"><span>Pošiljatelj (Od)</span><input id="n_o" value="${esc(ns.od || "")}" placeholder="HiGiFood &lt;obvestila@domena.si&gt;"></label><label class="f wide"><span>Naslov aplikacije v sporočilu</span><input id="n_a" value="${esc(ns.naslov_aplikacije || "")}" placeholder="https://haccp.vasa-domena.si"></label></div>
   <div class="row"><button class="btn" id="n_save">Shrani nastavitve</button><input id="n_t" placeholder="testni e-naslov" style="max-width:220px"><button class="btn ghost sec" id="n_test">Pošlji test</button><button class="btn ghost sec" id="n_now">Pošlji opomnike zdaj</button><button class="btn ghost sec n-smtp" id="n_vr">Preveri odhodna vrata</button></div><div id="n_vrr"></div></div>
  <div class="card" id="tiskc"><h2>Tiskanje dokumentacije</h2><p class="mut">Določite, katero dokumentacijo si lahko posamezne vloge izpišejo (PDF, Word, Excel, tisk). Administrator lahko izpisuje vse. Omejitev velja za izpisovanje v aplikaciji.</p><div id="tiskb"></div></div>
  <div class="card" id="omrc"><h2>Dostop iz omrežja (testiranje)</h2><div id="omrb"><p class="mut">Nalaganje …</p></div></div>
  <div class="card" id="arhc"><h2>Arhiv evidenc</h2><p class="mut">Evidence starejše od izbranega števila let se stisnejo v datoteko v mapi <code>podatki/_arhiv</code> in odstranijo iz žive baze. Arhiv lahko prenesete ali vrnete. Zakonski roki hrambe veljajo za vas: pred arhiviranjem preverite zahteve.</p><div class="row"><label class="f" style="margin:0"><span>Starejše od (let)</span><input type="number" id="ah_l" value="5" min="1" max="30" style="width:110px"></label><button class="btn ghost sec" id="ah_p">Preveri</button><button class="btn" id="ah_a">Arhiviraj</button></div><div id="ah_r"></div></div>
  <div class="card"><h2>Logotip v dokumentih</h2><p class="mut">Logotip (PNG, JPEG ali WebP do 1,5 MB) se prikaže na naslovnici PDF in Word dokumentov. Če lastnega logotipa ne naložite, se uporabi logotip HiGiFood.</p><div class="row"><img id="lg_prev" alt="" style="max-height:60px;max-width:180px;border:1px solid var(--line);border-radius:6px;padding:4px;background:#fff" hidden><input type="file" id="lg_f" accept="image/png,image/jpeg,image/webp" style="max-width:260px"><button class="btn" id="lg_up">Naloži</button><button class="btn ghost sec" id="lg_del">Odstrani</button></div></div>
  <div class="card"><h2>Program</h2><p class="mut">Če program teče skrito (brez okna), ga tu ustavite. Ponovni zagon: <code>HiGiFood.vbs</code> ali <code>HACCP-sistem.exe</code>.</p><button class="btn danger" id="p_stop">Ustavi program</button></div>
  <div class="card"><h2>Baza znanja in orodja</h2><div class="row"><a class="btn ghost" href="/baza/">Urejevalnik baze znanja</a><a class="btn ghost" href="/generator/">Generator dokumentacije</a></div><h3>Uporabljene posodobitve baze</h3>${upd.length ? `<div class="tw"><table class="t"><tr><th>ID</th><th>Datum</th><th>Opis</th></tr>${upd.slice(-6).reverse().map(u => `<tr><td>${esc(u.id)}</td><td>${esc(u.datum)}</td><td>${esc(u.opis)}</td></tr>`).join("")}</table></div>` : '<p class="mut">Ni.</p>'}</div></div>
  <div class="card"><h2>Revizijska sled</h2><p>${audit.preveritev.ok ? `<span class="badge ok">Veriga zgoščenk veljavna (${mnx(audit.preveritev.vnosov, ["vnos", "vnosa", "vnosi", "vnosov"])})</span>` : '<span class="badge bad">Revizijska sled je bila spremenjena!</span>'}</p><div class="tw" style="max-height:420px;overflow:auto"><table class="t"><tr><th>Kdaj</th><th>Kdo</th><th>Dejanje</th><th>Zbirka</th><th>Opis</th></tr>${audit.vnosi.map(e => `<tr><td>${fdt(e.cas)}</td><td>${esc(e.ime || "–")}</td><td>${esc(e.akcija)}</td><td>${esc(e.zbirka)}</td><td>${esc(e.opis)}</td></tr>`).join("")}</table></div></div>`;
  fetch("/api/logo").then(r => { const im = $("#lg_prev"); if (!im) return; const lastni = r.status === 200; im.src = lastni ? "/api/logo?t=" + Date.now() : "/logo-svetlo.png"; im.alt = lastni ? "Lastni logotip" : "Privzeti logotip HiGiFood"; im.title = im.alt; im.hidden = false; }).catch(() => {}); // brez lastnega: privzeti logotip, ne prazna slika
  api("GET", "/api/tisk").then(t => {
    const V = [["svetovalec", "Svetovalec"], ["odgovorna", "Odgovorna oseba"], ["zaposleni", "Zaposleni"]];
    $("#tiskb").innerHTML = `<div class="tw"><table class="t"><thead><tr><th>Dokumentacija</th>${V.map(x => `<th>${x[1]}</th>`).join("")}</tr></thead><tbody>${Object.keys(t.kategorije).map(k => `<tr><td>${esc(t.kategorije[k])}</td>${V.map(x => `<td><input type="checkbox" data-k="${k}" data-v="${x[0]}" aria-label="${esc(t.kategorije[k] + ": " + x[1])}" ${t.pravila[k][x[0]] ? "checked" : ""}></td>`).join("")}</tr>`).join("")}</tbody></table></div><div class="row"><button class="btn" id="tisks">Shrani</button></div>`;
    $("#tisks").onclick = async () => { const pr = {}; $$("#tiskb input[data-k]").forEach(c => { (pr[c.dataset.k] = pr[c.dataset.k] || {})[c.dataset.v] = c.checked; }); try { await api("PUT", "/api/tisk", { pravila: pr }); toast("Shranjeno"); } catch (e) { fail(e); } };
  }).catch(() => {});
  api("GET", "/api/omrezje").then(r => { if (!$("#omrb")) return; $("#omrb").innerHTML = r.omrezje ? `<p>Program je dosegljiv drugim računalnikom v istem omrežju na naslovih:</p><ul>${r.naslovi.map(a => `<li><code>${esc(a)}</code></li>`).join("") || "<li>naslova ni mogoče ugotoviti</li>"}</ul><p class="mut">Povezava ni šifrirana (http): uporabljajte samo testne podatke. Če se drugi računalnik ne more povezati, zaženite <code>odpri-pozarni-zid.bat</code> kot administrator.</p>` : `<p class="mut">Program je trenutno dosegljiv samo na tem računalniku. Za testiranje na drugih računalnikih v istem omrežju ga zaženite z <code>HiGiFood-test-omrezje.vbs</code> (testni način).</p>`; }).catch(() => { $("#omrb").innerHTML = ""; });
  const arhList = async () => { const L = await api("GET", "/api/arhiv"); if (!$("#ah_r")) return; $("#ah_r").innerHTML = L.length ? `<div class="tw"><table class="t">${L.map(f => `<tr><td>${esc(f.ime)}</td><td>${Math.round(f.velikost / 1024)} kB</td><td>${fdt(f.cas)}</td><td style="white-space:nowrap"><a class="btn sm ghost sec" href="/api/arhiv/${encodeURIComponent(f.ime)}" download>Prenesi</a> <button class="btn sm ghost sec" data-ar="${esc(f.ime)}">Vrni v bazo</button></td></tr>`).join("")}</table></div>` : '<p class="mut">Arhiva še ni.</p>'; $$("[data-ar]").forEach(b => b.onclick = async () => { if (!window.confirm("Vrnem zapise iz arhiva v bazo?")) return; try { const r = await api("POST", "/api/arhiv/" + encodeURIComponent(b.dataset.ar) + "/obnovi"); toast("Vrnjenih zapisov: " + r.stevilo); arhList(); } catch (e) { fail(e); } }); };
  arhList().catch(() => {});
  $("#ah_p").onclick = async () => { try { const r = await api("POST", "/api/arhiv", { leta: +$("#ah_l").value, samo_preveri: true }); toast(r.stevilo + " zapisov starejših od " + fdate(r.meja)); } catch (e) { fail(e); } };
  $("#ah_a").onclick = async () => { try { const pr = await api("POST", "/api/arhiv", { leta: +$("#ah_l").value, samo_preveri: true }); if (!pr.stevilo) return toast("Ni zapisov za arhiviranje."); if (!window.confirm("Arhiviram " + mnx(pr.stevilo, ["zapis", "zapisa", "zapisi", "zapisov"]) + "?")) return; const r = await api("POST", "/api/arhiv", { leta: +$("#ah_l").value }); toast("Arhiviranih zapisov: " + r.stevilo); arhList(); } catch (e) { fail(e); } };
  $("#lg_up").onclick = () => { const f = $("#lg_f").files[0]; if (!f) return toast("Izberite datoteko.", true); const rd = new FileReader(); rd.onload = async () => { try { await api("POST", "/api/logo", { tip: f.type, podatki: String(rd.result).split(",")[1] }); await loadLogo(); toast("Logotip shranjen"); pageAdmin(v); } catch (e) { fail(e); } }; rd.readAsDataURL(f); };
  $("#lg_del").onclick = async () => { try { await api("DELETE", "/api/logo"); await loadLogo(); toast("Logotip odstranjen"); pageAdmin(v); } catch (e) { fail(e); } };
  $("#k_s").onclick = async () => { try { const r = await api("PUT", "/api/kopija/nastavitve", { mapa: $("#k_m").value, geslo: $("#k_g").value }); toast(r.stanje && r.stanje.ok === false ? "Kopija ni uspela: " + r.stanje.napaka : "Shranjeno, kopija narejena", r.stanje && r.stanje.ok === false); pageAdmin(v); } catch (e) { fail(e); } };
  $("#k_z").onclick = async () => { try { const r = await api("POST", "/api/kopija/zdaj"); toast(r.stanje && r.stanje.ok === false ? "Kopija ni uspela: " + r.stanje.napaka : "Kopija narejena", r.stanje && r.stanje.ok === false); pageAdmin(v); } catch (e) { fail(e); } };
  $("#p_stop").onclick = () => confirmBox("Program se bo ustavil. Za ponoven zagon zaženite HiGiFood.vbs oziroma HACCP-sistem.exe. Nadaljujem?", async () => { try { await api("POST", "/api/ustavi"); document.body.innerHTML = '<div style="padding:40px;font:16px system-ui"><h2>Program je ustavljen.</h2><p>To okno lahko zaprete. Za ponoven zagon zaženite HiGiFood.vbs ali HACCP-sistem.exe.</p></div>'; } catch (e) { fail(e); } }, true);
  const nacinVid = () => { const api = $("#n_n").value !== "smtp"; $$(".n-api").forEach(x => { x.hidden = !api; }); $$(".n-smtp").forEach(x => { x.hidden = api; }); };
  $("#n_n").onchange = nacinVid; nacinVid();
  $("#n_vr").onclick = async () => { const b = $("#n_vr"), o = $("#n_vrr"); b.disabled = true; o.innerHTML = '<p class="mut">Preverjam (do 5 s) …</p>'; try { const r = await api("POST", "/api/obvestila/vrata", { streznik: $("#n_s").value || "smtp.gmail.com" }); o.innerHTML = `<p>${r.rezultati.map(x => `<span class="badge ${x.odprta ? "ok" : "bad"}">${esc(r.streznik)}:${x.vrata} ${x.odprta ? "odprta" : "zaprta (" + esc(x.napaka) + ")"}</span>`).join(" ")}${r.rezultati.every(x => !x.odprta) ? ' Odhodna vrata SMTP so zaprta – izberite način »HTTPS API« (Resend ali Brevo).' : ""}</p>`; } catch (e) { fail(e); o.innerHTML = ""; } finally { b.disabled = false; } };
  const nv = () => ({ nacin: $("#n_n").value, api_kljuc: $("#n_k").value, streznik: $("#n_s").value, vrata: $("#n_v").value, varnost: $("#n_z").value, uporabnik: $("#n_u").value, geslo: $("#n_p").value, od: $("#n_o").value, naslov_aplikacije: $("#n_a").value });
  $("#n_save").onclick = () => api("PUT", "/api/nastavitve", nv()).then(() => toast("Shranjeno")).catch(fail);
  $("#n_test").onclick = async () => { try { await api("PUT", "/api/nastavitve", nv()); await api("POST", "/api/obvestila/test", { komu: $("#n_t").value }); toast("Testno sporočilo poslano"); } catch (e) { fail(e); } };
  $("#n_now").onclick = async () => { try { const r = await api("POST", "/api/obvestila/zdaj"); toast(`Prejemnikov: ${r.prejemniki}, poslano: ${r.poslano}${r.napake.length ? ", napake: " + r.napake.join("; ") : ""}`, !!r.napake.length); } catch (e) { fail(e); } };
  $("#kenc").onclick = () => modal("Šifrirana kopija", `<p class="err" id="ferr"></p><label class="f req"><span>Geslo (vsaj 8 znakov)</span><input type="password" id="kg1" autocomplete="new-password"></label><label class="f req"><span>Ponovite geslo</span><input type="password" id="kg2" autocomplete="new-password"></label><p class="note">Če geslo pozabite, kopije ni mogoče obnoviti.</p>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Prenesi", fn: async () => { if ($("#kg1").value !== $("#kg2").value) { $("#ferr").textContent = "Gesli se ne ujemata."; return false; } try { const r = await fetch("/api/kopija/sifrirana", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ geslo: $("#kg1").value }) }); if (!r.ok) throw new Error((await r.json()).napaka); dlBlob(await r.blob(), "higifood-kopija-" + today() + ".hfbk"); } catch (e) { $("#ferr").textContent = e.message; return false; } } }]);
  $("#rf").onchange = e => {
    const f = e.target.files[0]; if (!f) return;
    const enc = /\.hfbk$/i.test(f.name); let geslo = "";
    const go = () => confirmBox("Obnova prepiše vse trenutne podatke s kopijo. Nadaljujem?", async () => {
      // datoteka gre na strežnik nespremenjena (brez base64), geslo kodirano (glave HTTP ne smejo vsebovati šumnikov)
      const r = await fetch("/api/obnovi", { method: "POST", headers: Object.assign({ "Content-Type": "application/octet-stream" }, geslo ? { "X-Kopija-Geslo": encodeURIComponent(geslo), "X-Kopija-Geslo-Kodirano": "1" } : {}), body: f }); const j = await r.json();
      if (!r.ok) throw new Error(j.napaka); toast("Obnovljeno: " + mnx(j.datotek, ["datoteka", "datoteki", "datoteke", "datotek"])); setTimeout(() => location.reload(), 800);
    }, true);
    if (enc) modal("Šifrirana kopija", `<label class="f req"><span>Geslo kopije</span><input type="password" id="kg0" autocomplete="off"></label>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Naprej", fn: () => { geslo = $("#kg0").value; if (!geslo) return false; setTimeout(go, 60); } }]); else go();
  };
  admZavihki(v, m && m[1]); oblakCard(v); varnostCard(v); zavezanciCard(v);
}
// seznam davčnih zavezancev FURS za izpolnjevanje podatkov strank
async function zavezanciCard(v) {
  const z = await api("GET", "/api/zavezanci").catch(() => null); if (!z || !v.isConnected) return;
  const stanje = z => !z.na_voljo ? '<span class="badge bad">ni na voljo (potreben je Node.js 22 s SQLite)</span>' : z.zapisov ? `<span class="badge ok">${Number(z.zapisov).toLocaleString("sl")} ${mn(z.zapisov, ["podjetje ali s.p.", "podjetji ali s.p.", "podjetja ali s.p.", "podjetij in s.p."])}</span> <span class="mut">osveženo ${fdt(z.osvezeno)}</span>` : '<span class="badge warn">še ni prenesen</span>';
  v.insertAdjacentHTML("beforeend", `<div class="card" id="zav-card" style="margin-top:16px"><h2>Seznam podjetij (FURS)</h2>
    <p class="mut">Pri vnosu stranke se po davčni številki ali nazivu izpolnijo matična številka, dejavnost, naziv in naslov. Program uradni seznam davčnih zavezancev FURS (odprti podatki) prenese enkrat na dan; seznam ni del varnostnih kopij.</p>
    <p id="zav_s">${stanje(z)}</p>${z.napaka ? `<p class="err" id="zav_e">Zadnji prenos ni uspel: ${esc(z.napaka)}</p>` : ""}
    <label class="f" style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="zav_a" ${z.samodejno !== false ? "checked" : ""} style="width:auto"> Samodejno osveževanje enkrat na dan</label>
    <details><summary>Naslovi datotek</summary><label class="f"><span>En naslov na vrstico (prazno = privzeti naslov FURS)</span><textarea id="zav_n" placeholder="${esc(z.privzeti.join("\n"))}">${esc((z.naslovi || []).join("\n") === z.privzeti.join("\n") ? "" : (z.naslovi || []).join("\n"))}</textarea></label></details>
    <div class="row" style="flex-wrap:wrap;gap:8px"><button class="btn" id="zav_o">Prenesi zdaj</button><button class="btn ghost sec" id="zav_sh">Shrani nastavitve</button><label class="btn ghost sec" style="margin:0">Uvozi datoteko …<input type="file" id="zav_f" accept=".zip,.csv,.txt" hidden></label></div></div>`);
  const osvezi = z => { $("#zav_s").innerHTML = stanje(z); const e = $("#zav_e"); if (e) e.remove(); };
  $("#zav_sh").onclick = async () => { try { osvezi(await api("PUT", "/api/zavezanci", { samodejno: $("#zav_a").checked, naslovi: $("#zav_n").value.split("\n").map(x => x.trim()).filter(Boolean) })); toast("Shranjeno"); } catch (e) { fail(e); } };
  $("#zav_o").onclick = async () => { const b = $("#zav_o"); b.disabled = true; $("#zav_s").innerHTML = '<span class="mut">Prenašam seznam (lahko traja minuto) …</span>'; try { osvezi(await api("POST", "/api/zavezanci/osvezi", {})); toast("Seznam osvežen"); } catch (e) { $("#zav_s").innerHTML = `<span class="err">${esc(e.message)}</span>`; } finally { b.disabled = false; } };
  $("#zav_f").onchange = async e => {
    const f = e.target.files[0]; if (!f) return; $("#zav_s").innerHTML = '<span class="mut">Uvažam …</span>';
    const u8 = new Uint8Array(await f.arrayBuffer()); let bin = ""; for (let i = 0; i < u8.length; i += 8192) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
    try { const r = await fetch("/api/zavezanci/uvozi", { method: "POST", headers: { "Content-Type": "text/plain" }, body: btoa(bin) }), j = await r.json(); if (!r.ok) throw new Error(j.napaka); osvezi(j); toast("Uvoženo: " + mnx(j.zapisov, ["zapis", "zapisa", "zapisi", "zapisov"])); }
    catch (er) { $("#zav_s").innerHTML = `<span class="err">${esc(er.message)}</span>`; } e.target.value = "";
  };
}

navItem("koledar", "Koledar in roki", "#/koledar");
navItem("kos", "Koš (izbrisano)", "#/kos", ["admin", "svetovalec", "odgovorna"]);
navItem("storitve", "Storitve", "#/storitve", ["admin", "svetovalec"]);
navItem("generator", "Generator dokumentacije", "/generator/");
navItem("uporabniki", "Uporabniki", "#/uporabniki", ["admin", "svetovalec"]);
navItem("admin", "Administracija", "#/admin", ["admin"]);
route(/^\/koledar$/, pageKoledar, "Koledar in roki", "koledar");
route(/^\/storitve$/, pageStoritve, "Storitve po strankah", "storitve");
route(/^\/uporabniki$/, pageUporabniki, "Uporabniki", "uporabniki");
route(/^\/admin(?:\/(\w+))?$/, pageAdmin, "Administracija", "admin");

async function pageKos(v) {
  const L = await api("GET", "/api/kos"), IME = { uporabniki: "Uporabnik", sarze: "Šarža", jedi: "Jed", certifikacija: "Ocena certifikacije", potrditve: "Potrditev", stranke: "Stranka", obrati: "Obrat", osebje: "Zaposleni", dobavitelji: "Dobavitelj", oprema: "Oprema", usposabljanja: "Usposabljanje", nacrti: "HACCP načrt", navodila: "Navodilo", dogodki: "Dogodek", storitve: "Storitev", urnik: "Urnik vnosov", priloge: "Priloga", ciscenje_nacrt: "Opravilo čiščenja", vabe: "Vaba", kemikalije: "Čistilo", tlorisi: "Tloris" };
  v.innerHTML = `<p class="note info">Izbrisani zapisi se hranijo 30 dni; v tem času jih lahko obnovite. Pri izbrisani stranki se obnovijo tudi njeni obrati, zaposleni, načrti in drugo. Evidence in neskladnosti se ne brišejo nikoli.</p><div class="tw"><table class="t"><tr><th>Kaj</th><th>Vrsta</th><th>Stranka</th><th>Izbrisano</th><th>Izbrisal</th><th>Še dni (dokončni izbris)</th><th></th></tr>${L.map(x => `<tr><td>${esc(x.ime)}${x.otrok ? ` <span class="mut">(+ ${x.otrok} podrejenih)</span>` : ""}</td><td>${esc(IME[x.zbirka] || x.zbirka)}</td><td>${esc(x.stranka)}</td><td>${fdt(x.cas)}</td><td>${esc(x.izbrisal || "")}</td><td>${x.preostalo_dni} <small class="mut">(izbris ${x.izbris ? fdate(x.izbris) : "–"})</small></td><td style="white-space:nowrap"><button class="btn sm" data-ob="${x.id}">Obnovi</button>${ME.u.vloga === "admin" ? ` <button class="btn sm danger" data-tr="${x.id}">Izbriši trajno</button>` : ""}</td></tr>`).join("") || '<tr><td colspan="7" class="empty">Koš je prazen.</td></tr>'}</table></div>`;
  $$("[data-ob]", v).forEach(b => b.onclick = async () => { try { await api("POST", "/api/kos/" + b.dataset.ob + "/obnovi"); toast("Obnovljeno"); pageKos(v); } catch (e) { fail(e); } });
  $$("[data-tr]", v).forEach(b => b.onclick = () => confirmBox("Zapis bo trajno izbrisan. Nadaljujem?", async () => { await api("DELETE", "/api/kos/" + b.dataset.tr); toast("Izbrisano trajno"); pageKos(v); }, true));
}
route(/^\/kos$/, pageKos, "Koš (izbrisano)", "kos");
