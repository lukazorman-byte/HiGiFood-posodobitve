// Naprave iz baze znanja (baza/naprave.json): temperaturni režim in protokoli čiščenja po napravi.
// Iz naprav, obkljukanih pri obratu, se ustvarijo oprema (z mejami), načrt čiščenja in urnik meritev – en vnos, brez podvajanja.

// naprava iz baze po imenu ali vrsti opreme
const napravaIzBaze = (db, ime, tip) => { const n = db.naprave || [], i = String(ime || "").trim().toLowerCase(); return n.find(x => x.naziv.toLowerCase() === i) || (i && n.find(x => i.startsWith(x.naziv.toLowerCase()))) || (tip && n.find(x => x.tip === tip && x.tip !== "drugo")) || null; };
// število kosov iz opisa (»3 kosi«, »2x«, »2 ×«)
const kosov = opis => { const m = /(\d+)\s*(kos|x\b|×)/i.exec(String(opis || "")); return m ? Math.min(20, Math.max(1, +m[1])) : 1; };
// naprava potrebuje zapis v opremi: ima meje, spremljanje ali servis (pribor in higiena brez meril ne)
const vOpremo = n => n.meja_min !== "" || n.meja_max !== "" || n.frekvenca_ur || n.interval_dni || n.tip !== "drugo";

// predlog: kaj ustvariti za obrat (oprema, čiščenje, urnik), z oznako, kar že obstaja
async function predlogNaprav(db, sid, ob) {
  const [oprema, cisc, urnik] = await Promise.all([D.list("oprema", { stranka_id: sid }), D.list("ciscenje_nacrt", { stranka_id: sid }), D.list("urnik", { stranka_id: sid }).catch(() => [])]);
  const out = [], vObratu = x => (x.obrat_id || "") === (ob.id || "");
  for (const sel of ob.naprave || []) {
    const n = napravaIzBaze(db, sel.ime); if (!n) { out.push({ ime: sel.ime, brez: true }); continue; }
    const k = kosov(sel.opis), imena = k > 1 ? Array.from({ length: k }, (_, i) => n.naziv + " " + (i + 1)) : [sel.ime];
    if (vOpremo(n)) for (const im of imena) out.push({ vrsta: "oprema", n, ime: im, ze: oprema.some(o => vObratu(o) && String(o.naziv).toLowerCase() === im.toLowerCase()) });
    if (n.frekvenca_ur) for (const im of imena) out.push({ vrsta: "urnik", n, ime: im, ze: urnik.some(u => vObratu(u) && u.naprava === im) });
    for (const c of n.ciscenje) out.push({ vrsta: "ciscenje", n, ime: sel.ime, c, ze: cisc.some(x => vObratu(x) && String(x.podrocje || "").toLowerCase() === sel.ime.toLowerCase() && String(x.opravilo || "").toLowerCase() === c.opravilo.toLowerCase()) });
  }
  // prostori obrata: protokoli čiščenja tal, sten, odtokov … (baza/prostori.json)
  for (const sel of ob.prostori || []) {
    const pr = (db.prostori || []).find(x => x.naziv.toLowerCase() === String(sel.ime).trim().toLowerCase()); if (!pr) { out.push({ ime: sel.ime, brez: true }); continue; }
    for (const c of pr.ciscenje) out.push({ vrsta: "ciscenje", n: pr, ime: sel.ime, c, ze: cisc.some(x => vObratu(x) && String(x.podrocje || "").toLowerCase() === sel.ime.toLowerCase() && String(x.opravilo || "").toLowerCase() === c.opravilo.toLowerCase()) });
  }
  return out;
}
async function ustvariIzNaprav(sid, ob, izbrani) {
  let n = 0;
  for (const p of izbrani) {
    if (p.vrsta === "oprema") await D.add("oprema", { stranka_id: sid, obrat_id: ob.id, naziv: p.ime, tip: p.n.tip, meja_min: p.n.meja_min, meja_max: p.n.meja_max, interval_dni: p.n.interval_dni || "", opomba: [p.n.mejna_opis && "Meje: " + p.n.mejna_opis + " (predlog iz baze znanja – potrdi odgovorna oseba)", p.n.vir && "Vir: " + p.n.vir, p.n.opomba].filter(Boolean).join("\n") });
    else if (p.vrsta === "urnik") await D.add("urnik", { stranka_id: sid, obrat_id: ob.id, vrsta: p.n.tip === "pomivalni stroj" ? "oprema" : "temperatura", naprava: p.ime, frekvenca_ur: p.n.frekvenca_ur });
    else await D.add("ciscenje_nacrt", { stranka_id: sid, obrat_id: ob.id, podrocje: p.ime, opravilo: p.c.opravilo, sredstvo: p.c.sredstvo, koncentracija: p.c.koncentracija, kontaktni_cas: p.c.kontaktni_cas, metoda: p.c.metoda, kontrola: p.c.kontrola, pogostost_dni: p.c.pogostost_dni, krat_na_dan: String(p.c.krat_na_dan || 1), zacetek: today(), aktivno: true });
    n++;
  }
  return n;
}
// okno: izbira obrata in postavk; obstoječe postavke so označene in se ne ustvarijo znova
async function napraveVOpremo(ctx, done) {
  const db = await baza(), obrati = (await D.list("obrati", { stranka_id: ctx.stranka_id })).filter(o => (o.naprave || []).length || (o.prostori || []).length);
  if (!obrati.length) return toast("Pri obratih ni obkljukanih naprav ali prostorov. Uredite obrat in jih obkljukajte.", true);
  let ob = obrati[0], P = [];
  const VR = { oprema: "Oprema (meje)", urnik: "Urnik meritev", ciscenje: "Načrt čiščenja" };
  const risi = async () => {
    P = await predlogNaprav(db, ctx.stranka_id, ob);
    const nove = P.filter(p => !p.brez && !p.ze).length;
    $("#nv_b").innerHTML = `<p class="mut">Iz baze znanja: temperaturne meje so predlog, ki ga potrdi odgovorna oseba; koncentracijo in kontaktni čas vpišite po navodilih proizvajalca sredstva. Že obstoječe postavke se ne podvojijo.</p>
      <div class="tw" style="max-height:52vh;overflow:auto"><table class="t"><tr><th></th><th>Ustvari</th><th>Naprava</th><th>Vsebina</th></tr>${P.map((p, i) => p.brez ? `<tr><td></td><td class="mut">ni v bazi</td><td>${esc(p.ime)}</td><td class="mut">dodajte ročno</td></tr>` : `<tr><td><input type="checkbox" data-nv="${i}" ${p.ze ? "disabled" : "checked"} aria-label="${esc(VR[p.vrsta] + ": " + p.ime)}"></td><td>${VR[p.vrsta]}${p.ze ? ' <span class="badge">že obstaja</span>' : ""}</td><td>${esc(p.ime)}</td><td>${p.vrsta === "oprema" ? esc(p.n.mejna_opis || "brez temperaturne meje") : p.vrsta === "urnik" ? "vnos vsakih " + esc(p.n.frekvenca_ur) + " h" : esc(p.c.opravilo) + ` <small class="mut">(${+p.c.pogostost_dni === 1 ? (+p.c.krat_na_dan > 1 ? p.c.krat_na_dan + "× dnevno" : "dnevno") : "vsakih " + p.c.pogostost_dni + " dni"})</small>`}</td></tr>`).join("")}</table></div>
      <p class="mut" style="margin-top:6px">Novih postavk: ${nove}.</p>`;
  };
  modal("Naprave in prostori obrata → oprema, urnik in načrt čiščenja", `${obrati.length > 1 ? `<label class="f"><span>Obrat</span><select id="nv_o">${obrati.map(o => `<option value="${o.id}">${esc(o.naziv)}</option>`).join("")}</select></label>` : `<p><b>${esc(ob.naziv)}</b></p>`}<div id="nv_b"><p class="mut">Nalaganje …</p></div>`, [{ t: "Prekliči", cls: "ghost sec" }, { t: "Ustvari izbrano", fn: async () => {
    const izb = $$("[data-nv]:checked").map(c => P[+c.dataset.nv]); if (!izb.length) { toast("Ni izbranih postavk.", true); return false; }
    const n = await ustvariIzNaprav(ctx.stranka_id, ob, izb); toast("Ustvarjeno: " + n + " (oprema, urnik, načrt čiščenja)"); done && done();
  } }]);
  const so = $("#nv_o"); if (so) so.onchange = () => { ob = obrati.find(o => o.id === so.value); risi(); };
  await risi();
}
// HACCP čarovnik: procesni koraki in nevarnosti iz naprav obrata (predlog, ki ga uporabnik potrdi)
function korakiIzNaprav(W, db, ob) {
  const nk = [], nh = []; if (!ob) return { nk, nh };
  for (const sel of ob.naprave || []) {
    const n = napravaIzBaze(db, sel.ime); if (!n || !n.korak) continue;
    let k = W.koraki.find(x => String(x.naziv || "").trim().toLowerCase() === n.korak.toLowerCase());
    if (!k) { k = { id: uidc(), naziv: n.korak, tip: guessTipKoraka(n.korak), predlog: true }; W.koraki.push(k); nk.push(k.naziv); }
    if (n.nevarnost && !W.nevarnosti.some(h => h.korak_id === k.id && String(h.nevarnost || "").toLowerCase() === n.nevarnost.opis.toLowerCase())) {
      W.nevarnosti.push({ id: uidc(), korak_id: k.id, tip: n.nevarnost.tip, nevarnost: n.nevarnost.opis, obstojec: n.mejna_opis ? "Naprava " + sel.ime + ": " + n.mejna_opis + (n.vir ? " (vir: " + n.vir + ")" : "") : "", verjetnost: "", teza: "", predlog: true, potrjeno: false }); nh.push(n.nevarnost.opis);
    }
  }
  return { nk, nh };
}
const guessTipKoraka = n => { n = n.toLowerCase(); return /skladi/.test(n) ? "skladiščenje" : /toplotn|cvrt|pogrev|kuhan/.test(n) ? "toplotna obdelava" : /hlaj/.test(n) ? "hlajenje" : /pakir/.test(n) ? "pakiranje" : /razstav|izdaj|vroče/.test(n) ? "prodaja / izdaja" : "priprava"; };
// navodilo »Čiščenje in razkuževanje« iz načrta čiščenja (en vir: načrt; navodilo se ob spremembi načrta osveži)
function navodiloIzNacrta(stranka, nacrt, obrati) {
  const om = Object.fromEntries((obrati || []).map(o => [o.id, o.naziv])), pog = n => +n.pogostost_dni === 1 ? (+n.krat_na_dan > 1 ? n.krat_na_dan + "× dnevno" : "dnevno") : +n.pogostost_dni === 7 ? "tedensko" : +n.pogostost_dni === 30 ? "mesečno" : n.pogostost_dni ? "vsakih " + n.pogostost_dni + " dni" : "po potrebi";
  const akt = nacrt.filter(n => n.aktivno !== false).sort((a, b) => String(om[a.obrat_id] || "").localeCompare(String(om[b.obrat_id] || ""), "sl") || String(a.podrocje || "").localeCompare(String(b.podrocje || ""), "sl"));
  const odg = [...new Set(akt.map(n => n.odgovoren).filter(Boolean))];
  const L = ["Čiščenje in razkuževanje", "1. NAMEN", "Čiste in razkužene površine, naprave in prostori preprečujejo kontaminacijo živil.", "", "2. OBSEG", "Vsi prostori in naprave iz načrta čiščenja" + (Object.keys(om).length > 1 ? " (po obratih)" : "") + ".", "", "3. ODGOVORNOSTI", odg.length ? "Izvajajo: " + odg.join(", ") + ". Nadzor: odgovorna oseba." : "Izvajajo zaposleni po razporedu, nadzor odgovorna oseba.", "", "4. POSTOPEK"];
  let ob = null;
  for (const n of akt) { if (Object.keys(om).length > 1 && n.obrat_id !== ob) { ob = n.obrat_id; L.push(om[ob] || "Brez obrata"); } L.push("- " + [n.podrocje, n.opravilo].filter(Boolean).join(": ") + " – " + pog(n) + (n.sredstvo ? "; " + n.sredstvo : "") + (n.koncentracija ? ", koncentracija " + n.koncentracija : "") + (n.kontaktni_cas ? ", kontaktni čas " + n.kontaktni_cas : "") + (n.metoda ? ". " + n.metoda : "")); }
  L.push("", "5. KONTROLA", [...new Set(akt.map(n => n.kontrola).filter(Boolean))].slice(0, 6).map(k => "- " + k).join("\n") || "- vizualna kontrola po izvedbi", "", "6. UKREPI OB ODSTOPANJU", "Ponovno čiščenje in razkuževanje; ob ponavljanju neskladnost (CAPA).", "", "7. EVIDENCE", "Izvedba se beleži v evidenci čiščenja (Danes → Čiščenje).");
  return L.join("\n");
}
async function navodiloCiscenjaIzNacrta(ctx, done) {
  const [nacrt, obrati, nav] = await Promise.all([D.list("ciscenje_nacrt", { stranka_id: ctx.stranka_id }), D.list("obrati", { stranka_id: ctx.stranka_id }), D.list("navodila", { stranka_id: ctx.stranka_id })]);
  if (!nacrt.filter(n => n.aktivno !== false).length) return toast("Načrt čiščenja je prazen (Higiena → Načrt čiščenja).", true);
  const vs = navodiloIzNacrta(ctx.stranka, nacrt, obrati), obst = nav.find(n => n.iz_nacrta_ciscenja && n.status !== "zastarelo");
  if (obst) await D.set("navodila", obst.id, { vsebina: vs, _razlog: "Posodobljeno iz načrta čiščenja", _ver: obst.spremenjeno || obst.ustvarjeno });
  else await D.add("navodila", { stranka_id: ctx.stranka_id, naslov: "Čiščenje in razkuževanje", vrsta: "Predpogojni program", tema: "ciscenje", iz_nacrta_ciscenja: true, verzija_oznaka: "1.0", status: "osnutek", vsebina: vs });
  toast(obst ? "Navodilo čiščenja je posodobljeno iz načrta." : "Navodilo čiščenja je ustvarjeno iz načrta (nadomesti splošno predlogo v HACCP načrtu)."); done && done();
}
// obrazec opreme: meje iz baze naprav, če niso vpisane (po vrsti ali nazivu)
SPEC.oprema.onOpen = async () => {
  const db = await baza(), tip = $("#f_tip"), naz = $("#f_naziv"), mn = $("#f_meja_min"), mx = $("#f_meja_max"); if (!tip || !mn || !mx) return;
  const predlagaj = () => { if (mn.value !== "" || mx.value !== "") return; const n = napravaIzBaze(db, naz && naz.value, tip.value); if (!n || (n.meja_min === "" && n.meja_max === "")) return; mn.value = n.meja_min; mx.value = n.meja_max; toast("Meje iz baze znanja: " + n.mejna_opis + " – preverite in potrdite.", "opozorilo"); };
  tip.addEventListener("change", predlagaj); if (naz) naz.addEventListener("change", predlagaj);
};
